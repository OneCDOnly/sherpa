#!/bin/bash
#*
#* Please don't edit this file directly, it was built and/or modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#*
#* sherpa-manager.sh
#*	  Copyright (C) 2017-2026 OneCD.
#*
#* Contact:
#*	  one.cd.only@gmail.com
#*
#* Description:
#*	  This is the management script for the sherpa mini-package-manager. It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#*
#* Project:
#*	  https://git.io/sherpa
#*
#* Support forum topic:
#*	  https://community.qnap.com/t/qpkg-sherpa-a-mini-package-manager-cli/1081
#*
#* Tested on:
#*	  GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	  GNU bash, version 3.2.57(1)-release (arm-none-linux-gnueabi)
#*	  GNU bash, version 3.2.57(1)-release (arm-openwrt-linux-gnu)
#*	  GNU bash, version 3.2.57(4)-release (arm-unknown-linux-gnueabihf)
#*	  GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	  GNU bash, version 3.2.57(1)-release (x86_64-QNAP-linux-gnu)
#*		 Copyright (C) 2007 Free Software Foundation, Inc.
#*
#* Notes:
#*	  All sherpa scripts are optimised for compatibility with Bash 3.2 (via QTS BusyBox), as this is the native QNAP NAS shell. Be-careful reusing code in other shells. These scripts contain syntax quirks often compatible only with Bash.
#*
#* License:
#*	  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	  You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
#*
set -o nounset
shopt -s extglob
[[ $- != *m* ]]||set +m
[[ -L /dev/fd ]]||/bin/ln -fns /proc/self/fd /dev/fd
readonly r_args_raw=$*
Init(){ ConfirmEnv||return
ClaimLockfile||return
StartScriptTimer
SetTraps
HideCursor
HideKeystrokes
SetCMDs
LoadConsts
LoadDefaults
ShowAsProc init
ConfigEnv||return
CreatePaths||return
CreatePackagePaths||return
PrepareArgs
ParseManagementArgs||return
ParseHelpArgs||return
ArchivePriorSessLog
StartDebugLog
ParseShowArgs||return
ParseListArgs||return
ParseActionArgs||return
ShowTitle
CheckEnv
ShowArgSuggestions
DebugLogEnv
CheckTasks
AssignQpkgsToActions
return 0;}
ShowResults(){ FuncInit
if [[ ${generate_show_report:=false} = true ]];then if [[ $useropt_show_log_last = true ]];then ReleaseLockfile
ViewLogLast;Display;elif [[ $useropt_show_log_tail = true ]];then ReleaseLockfile
ViewLogTail;Display;elif [[ $useropt_show_backups = true ]];then ReleaseLockfile
ReportBackups;Display;elif [[ $useropt_show_dependencies = true ]];then ReleaseLockfile
ReportDependencies;Display;elif [[ $useropt_show_features = true ]];then ReleaseLockfile
ReportFeatures;Display;elif [[ $useropt_show_packages = true ]];then ReleaseLockfile
ReportPackages;Display;elif [[ $useropt_show_repos = true ]];then ReleaseLockfile
ReportRepos;Display;elif [[ $useropt_show_status = true ]];then ReportStatuses;Display;show_action_results_report=false;fi;fi
if [[ ${generate_list_report:=false} = true ]];then show_action_results_report=false
if [[ $useropt_list_versions = true ]];then ReleaseLockfile
ShowVersionsList;else ShowQPKGLists;fi;fi
if [[ ${useropt_help_basic:=false} = true ]];then ShowHelpBasic
ShowHelpBasicExamples
Display;fi;if [[ ${generate_help_report:=false} = true ]];then IsAnsiStrippingSupported||colourful=false
if [[ $useropt_help_tips = true ]];then ShowHelpTips
elif [[ $useropt_help_abbreviations = true ]];then HelpAbbreviations
elif [[ $useropt_help_actions = true ]];then ShowHelpActions
elif [[ $useropt_help_actions_all = true ]];then ShowHelpActionsAll
elif [[ $useropt_help_lists = true ]];then ShowHelpLists
elif [[ $useropt_help_options = true ]];then ShowHelpOptions
elif [[ $useropt_help_packages = true ]];then ShowHelpPackages
elif [[ $useropt_help_show = true ]];then ShowHelpShow
elif [[ $useropt_help_problems = true ]];then ShowHelpProblems
elif [[ $useropt_help_upgrades = true ]];then ShowHelpUpgrades
elif [[ $useropt_help_groups = true ]];then ShowHelpGroups;fi;Display;fi;ReleaseLockfile
if [[ ${show_action_results_report:=false} = true ]];then ReportAllActionResults
Display;fi;[[ ${show_backuploc:=false} = true ]]&&ShowHelpBackupLocation
[[ ${show_suggest_raise_issue:=false} = true ]]&&ShowHelpIssue
EndScriptTimer
EndDebugLog
FuncExit
[[ ${archive_debug_afterward:=false} = true ]]&&ArchiveActiveSessLog
ResetActiveSessLog
IsNtError;}
StartScriptTimer(){ r_script_startseconds=$(ConvertNowToSeconds)
readonly r_script_startseconds;}
EndScriptTimer(){ r_script_endseconds=$(ConvertNowToSeconds)
readonly r_script_endseconds;}
SetTraps(){ trap CaughtSIGINT SIGINT
trap CaughtEXIT EXIT;}
StartDebugLog(){ DebugInfoMajSepr
DebugScript info started "$(ConvertSecondsToFullDate "$r_script_startseconds")"
DebugScript info PID "$$"
DebugInfoMinSepr
ShowLogMarkersAsDebug
DebugInfoMinSepr
DebugVar r_this_script_ver
DebugVar r_this_package_ver;}
EndDebugLog(){ DebugInfoMinSepr
DebugScript info finished "$(ConvertNowToFullDate)"
DebugScript info 'elapsed time' "$(ConvertSecondsToDuration "$(( r_script_endseconds - r_script_startseconds ))")"
DebugInfoMajSepr;}
LoadConsts(){ printf -v r_chars_tab '\t'
r_cert_db_pathfile=/etc/config/nas_sign_qpkg.db
r_entware_packages_last_updated=20261106
r_file_change_threshold_minutes=60
r_script_built_epoch=1795307899
r_this_script_ver=261122
readonly r_cert_db_pathfile
readonly r_chars_tab
readonly r_entware_packages_last_updated
readonly r_file_change_threshold_minutes
readonly r_script_built_epoch
readonly r_this_script_ver
r_regex_delete_empty_lines='/^$/d;/^[[:space:]]*$/d'
r_regex_fix_kib='s/kB/kiB/'
r_regex_strip_ansi='s/\x1b\[[0-9;]*m//g'
r_regex_strip_comments='/^#[[:blank:]].*/d;/#$/d;s/[[:blank:]]#[[:blank:]].*//'
r_regex_strip_lead_whitespace='s/^[[:blank:]]*//'
r_regex_strip_tail_whitespace='s/[[:blank:]]*$//'
r_regex_strip_upto_colon='s/^.*:[[:blank:]]//'
r_regex_delete_firstlast_empty_lines='1{'$r_regex_delete_empty_lines'};${'$r_regex_delete_empty_lines'}'
r_regex_process_ram=$r_regex_strip_upto_colon';s/kB//;s/[[:blank:]]//g'
r_regex_process_screen_sessions=$r_regex_delete_empty_lines';'$r_regex_strip_lead_whitespace
readonly r_regex_delete_empty_lines
readonly r_regex_delete_firstlast_empty_lines
readonly r_regex_fix_kib
readonly r_regex_process_ram
readonly r_regex_process_screen_sessions
readonly r_regex_strip_ansi
readonly r_regex_strip_comments
readonly r_regex_strip_lead_whitespace
readonly r_regex_strip_tail_whitespace
readonly r_regex_strip_upto_colon
e_inurl='invalid URL'
e_noact='undefined action'
e_nochk='undefined checksum'
e_nocmd='undefined command'
e_noext='undefined exitcode'
e_nofil='undefined filename'
e_nofun='undefined function'
e_nonam='undefined name'
e_noopr='undefined operation'
e_nopfi='undefined pathfile'
e_nopid='undefined process ID'
e_nopnm='undefined package name'
e_noprm='undefined prompt'
e_nopth='undefined path'
e_nopty='undefined package type'
e_norea='undefined reason'
e_nores='undefined result'
e_nostr='undefined string'
e_notir='undefined tier'
e_nourl='undefined URL'
e_noval='undefined value'
e_novar='undefined variable'
readonly e_inurl
readonly e_noact
readonly e_nochk
readonly e_nocmd
readonly e_noext
readonly e_nofil
readonly e_nofun
readonly e_nonam
readonly e_noopr
readonly e_nopfi
readonly e_nopid
readonly e_nopnm
readonly e_noprm
readonly e_nopth
readonly e_nopty
readonly e_norea
readonly e_nores
readonly e_nostr
readonly e_notir
readonly e_nourl
readonly e_noval
readonly e_novar
r_qpkg_disable_timeout_seconds=10
r_qpkg_enable_timeout_seconds=10
r_qpkg_restart_timeout_seconds=1800
r_qpkg_start_timeout_seconds=1500
r_qpkg_status_check_timeout_seconds=15
r_qpkg_stop_timeout_seconds=300
readonly r_qpkg_disable_timeout_seconds
readonly r_qpkg_enable_timeout_seconds
readonly r_qpkg_restart_timeout_seconds
readonly r_qpkg_start_timeout_seconds
readonly r_qpkg_status_check_timeout_seconds
readonly r_qpkg_stop_timeout_seconds
r_report_lazy_column_width=28
r_report_qpkg_abbreviations_column_width=76
r_report_qpkg_action_column_width=27
r_report_qpkg_active_test_builtin_column_width=9
r_report_qpkg_appl_version_column_width=22
r_report_qpkg_author_column_width=20
r_report_qpkg_auto_update_column_width=11
r_report_qpkg_can_backup_column_width=8
r_report_qpkg_can_clean_column_width=9
r_report_qpkg_can_start_to_update_column_width=9
r_report_qpkg_cert_enddate_column_width=34
r_report_qpkg_cert_issuer_column_width=19
r_report_qpkg_cert_startdate_column_width=34
r_report_qpkg_cert_valid_column_width=18
r_report_qpkg_dependencies_column_width=29
r_report_qpkg_install_date_column_width=34
r_report_qpkg_is_complete_column_width=9
r_report_qpkg_is_enabled_column_width=8
r_report_qpkg_is_enhanced_column_width=9
r_report_qpkg_is_installed_column_width=10
r_report_qpkg_is_managed_column_width=8
r_report_qpkg_is_prohibited_column_width=11
r_report_qpkg_is_signed_column_width=8
r_report_qpkg_min_ram_column_width=13
r_report_qpkg_name_column_width=21
r_report_qpkg_opt_dependencies_column_width=29
r_report_qpkg_os_version_column_width=8
r_report_qpkg_path_column_width=47
r_report_qpkg_repo_column_width=42
r_report_qpkg_status_column_width=23
r_report_qpkg_tier_column_width=9
r_report_qpkg_uniqueunpack_column_width=9
r_report_qpkg_version_column_width=19
readonly r_report_lazy_column_width
readonly r_report_qpkg_abbreviations_column_width
readonly r_report_qpkg_action_column_width
readonly r_report_qpkg_active_test_builtin_column_width
readonly r_report_qpkg_appl_version_column_width
readonly r_report_qpkg_author_column_width
readonly r_report_qpkg_auto_update_column_width
readonly r_report_qpkg_can_backup_column_width
readonly r_report_qpkg_can_clean_column_width
readonly r_report_qpkg_can_start_to_update_column_width
readonly r_report_qpkg_dependencies_column_width
readonly r_report_qpkg_install_date_column_width
readonly r_report_qpkg_is_complete_column_width
readonly r_report_qpkg_is_enabled_column_width
readonly r_report_qpkg_is_enhanced_column_width
readonly r_report_qpkg_is_installed_column_width
readonly r_report_qpkg_is_managed_column_width
readonly r_report_qpkg_is_prohibited_column_width
readonly r_report_qpkg_is_signed_column_width
readonly r_report_qpkg_min_ram_column_width
readonly r_report_qpkg_name_column_width
readonly r_report_qpkg_opt_dependencies_column_width
readonly r_report_qpkg_os_version_column_width
readonly r_report_qpkg_path_column_width
readonly r_report_qpkg_repo_column_width
readonly r_report_qpkg_status_column_width
readonly r_report_qpkg_tier_column_width
readonly r_report_qpkg_uniqueunpack_column_width
readonly r_report_qpkg_version_column_width
r_debug_log_first_column_width=9
r_debug_log_second_column_width=25
r_report_qpkg_description_column_width=225
readonly r_debug_log_first_column_width
readonly r_debug_log_second_column_width
readonly r_report_qpkg_description_column_width
r_help_desc_indent=3
r_help_syntax_indent=6
r_log_tail_lines=5000
r_report_action_result_indent=4
r_report_column_spacing=2
r_report_file_bytes_column_width=14
r_report_file_change_date_column_width=60
r_report_file_name_column_width=35
r_report_highlight_backups_older_than='2 weeks ago'
r_report_info_name_column_width=14
UpdateSessionColumns
r_debug_log_width=$(( sess_columns - 12 ))
readonly r_debug_log_width
readonly r_help_desc_indent
readonly r_help_syntax_indent
readonly r_log_tail_lines
readonly r_report_action_result_indent
readonly r_report_column_spacing
readonly r_report_file_bytes_column_width
readonly r_report_file_change_date_column_width
readonly r_report_file_name_column_width
readonly r_report_highlight_backups_older_than
readonly r_report_info_name_column_width
r_chars_alert='! '
r_chars_attention='* '
r_chars_blank='  '
r_chars_bullet='• '
r_chars_dash='- '
r_chars_dropend='└─ '
r_chars_note='* '
r_chars_regular_prompt='$ '
r_chars_results='= '
r_chars_super_prompt='# '
r_extended_date_format='+%a %-d %b %Y'
r_extended_time_format='%-I:%M:%S %p %Z'
r_full_date_format='+%A %-d %B %Y'
r_chars_normal=$r_chars_bullet
r_chars_sudo_prompt=$r_chars_regular_prompt'sudo '
r_extended_datetime_format=$r_extended_date_format' '$r_extended_time_format
r_full_datetime_format=$r_full_date_format' '$r_extended_time_format
if IsOsCanSudo;then if [[ $(GetUserSudoUID) = undefined ]];then r_help_syntax_prefix=$r_chars_super_prompt
r_help_syntax_sudo_prefix=$r_chars_super_prompt;else r_help_syntax_prefix=$r_chars_regular_prompt
r_help_syntax_sudo_prefix=$r_chars_sudo_prompt;fi;else r_help_syntax_prefix=$r_chars_super_prompt
r_help_syntax_sudo_prefix=$r_chars_super_prompt;fi;local -r r_extended_time_format
local -r r_full_datetime_format
readonly r_chars_alert
readonly r_chars_attention
readonly r_chars_blank
readonly r_chars_bullet
readonly r_chars_dash
readonly r_chars_dropend
readonly r_chars_normal
readonly r_chars_note
readonly r_chars_regular_prompt
readonly r_chars_results
readonly r_chars_sudo_prompt
readonly r_chars_super_prompt
readonly r_extended_date_format
readonly r_extended_datetime_format
readonly r_help_syntax_prefix
readonly r_help_syntax_sudo_prefix
local r_orange
r_orange='\033[1;38;5;214m'
local -r r_orange
r_ani_chars=(2 '⢎⡀' '⢎⠁' '⠎⠑' '⠊⠱' '⠈⡱' '⢀⡱' '⢄⡰' '⢆⡠')
r_ani_colour=$r_orange
r_ani_first_frame=2
r_ani_frame_duration=0.06
r_ani_frame_step=1
r_ani_id=1
r_ani_reverse_motion=false
r_ani_width=${r_ani_chars[0]}
r_ani_total_frames=${#r_ani_chars[@]}
r_ani_last_frame=$r_ani_total_frames
if [[ $r_ani_reverse_motion = true ]];then r_ani_first_frame=$r_ani_total_frames
r_ani_last_frame=2
r_ani_frame_step=-$r_ani_frame_step;fi;readonly r_ani_chars
readonly r_ani_colour
readonly r_ani_first_frame
readonly r_ani_frame_duration
readonly r_ani_frame_step
readonly r_ani_id
readonly r_ani_last_frame
readonly r_ani_reverse_motion
readonly r_ani_total_frames
readonly r_ani_width;}
LoadDefaults(){ alternate_report_lines=true
archive_debug_afterward=false
colourful=$r_colourful_default
generate_help_report=false
generate_list_report=false
generate_report_headers=false
generate_show_report=false
get_qpkg_extended_states=false
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
release_lock=true
run_package_actions=false
show_action_results_failed=false
show_action_results_ok=false
show_action_results_report=false
show_action_results_skipped=false
show_action_results_zero=false
show_backuploc=false
show_suggest_raise_issue=false
show_title=true
switch_branch=false
switch_colour=false
switch_report_info=false
switch_terse=false
title_art_shown=false
title_shown=false
action_msg_pipe_fd=none
backup_stdin_fd=none
package_release_version=v261122
proc_counts_path=''
qpkg_name=sherpa
user_branch_value=''
user_report_info_value=''
user_terse_value=''
useropt_debug=false
useropt_fix=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_show=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_list_versions=false
useropt_show_about=false
useropt_show_aboutall=false
useropt_show_aboutextra=false
useropt_show_aboutsites=false
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_features=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_previous_action_results_report=false
useropt_show_report_info=$(LoadSetting ReportInfo true)
useropt_show_repos=false
useropt_show_status=false
useropt_terse=$(LoadSetting Terse true)
useropt_verbose=false
useropt_branch=$(LoadSetting Git_Branch stable);}
SetCMDs(){ r_gnu_awk_cmd=/opt/bin/awk
r_gnu_dd_cmd=/opt/bin/dd
r_gnu_df_cmd=/opt/bin/df
r_gnu_find_cmd=/opt/bin/find
r_gnu_free_cmd=/opt/bin/free
r_gnu_grep_cmd=/opt/bin/grep
r_gnu_more_cmd=/opt/bin/more
r_gnu_nice_cmd=/opt/bin/nice
r_gnu_timeout_cmd=/opt/bin/timeout
r_gnu_uname_cmd=/opt/bin/uname
r_less_cmd=/opt/bin/less
r_opkg_cmd=/opt/bin/opkg
r_python3_cmd=/opt/bin/python3
r_python_cmd=/opt/bin/python
r_pip_cmd=$r_python3_cmd' -m pip'
readonly r_gnu_awk_cmd
readonly r_gnu_dd_cmd
readonly r_gnu_df_cmd
readonly r_gnu_find_cmd
readonly r_gnu_free_cmd
readonly r_gnu_grep_cmd
readonly r_gnu_more_cmd
readonly r_gnu_nice_cmd
readonly r_gnu_timeout_cmd
readonly r_gnu_uname_cmd
readonly r_less_cmd
readonly r_opkg_cmd
readonly r_pip_cmd
readonly r_python3_cmd
readonly r_python_cmd
[[ ! -x /bin/less ]]&&/bin/ln -sf /bin/busybox /bin/less
[[ ! -x /usr/bin/sort ]]&&/bin/ln -sf /bin/busybox /usr/bin/sort
[[ -x $r_python3_cmd &&! -L $r_python_cmd ]]&&/bin/ln -s "$r_python3_cmd" "$r_python_cmd"
SetOsPauseMethod;}
IsCMDsOk(){ local -a a
local -a b
local c
b=()
a=(awk busybox cat chmod date df grep ln ls md5sum mkdir mknod mktemp more mv pidof ping ps renice rm rmdir sed sh sha1sum tar touch tr uname uniq)
b+=("${a[@]/#//bin/}")
a=(curl getcfg ldd rmcfg setcfg)
b+=("${a[@]/#//sbin/}")
a=(basename cp cut dirname du free head openssl readlink stat tail tee unzip uptime wc which xargs)
b+=("${a[@]/#//usr/bin/}")
a=(python2)
b+=("${a[@]/#//usr/local/bin/}")
a=(7z qpkg_service)
b+=("${a[@]/#//usr/local/sbin/}")
a=(screen)
b+=("${a[@]/#//usr/sbin/}")
for c in "${b[@]}";do IsCriticalFile "$c"||return;done;return 0;}
ConfigEnv(){ SetHardwareCpuThreads
SetHardwareInstalledRAM
SetNasArch
SetQpkgArch
local r_default_vol_mount_point
local r_sherpa_packages_base_url
a_args=()
a_args_incomplete=()
qpkg_index=0
r_concurrency=$r_cpu_threads
r_entware_type=$(GetQpkgEntwareType)
r_sherpa_packages_base_url='https://github.com/OneCDOnly/sherpa.packages'
r_this_package_ver=$(GetQpkgInstalledVer)
useropt_branch=$(GetUserGitBranch)
[[ $useropt_branch = unstable ]]&&package_release_version=testing
r_objects_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
r_packages_archive_url=$r_sherpa_packages_base_url/releases/download/$package_release_version/$r_nas_qpkg_arch.packages.tar.gz
local -r r_sherpa_packages_base_url
readonly r_concurrency
readonly r_entware_type
readonly r_objects_archive_url
readonly r_packages_archive_url
readonly r_this_package_ver
r_default_vol_mount_point=$(GetUserDefVol)
r_screen_socket_path=/var/run/.screen
r_sys_log_path=/var/log
r_sys_run_path=/var/run
r_this_package_path=$(GetQpkgInstalledPath)
r_qpkg_bu_path=$r_default_vol_mount_point/.qpkg_config_backup
r_qpkg_service_result_path=$r_sys_log_path
readonly r_default_vol_mount_point
readonly r_qpkg_bu_path
readonly r_qpkg_service_result_path
readonly r_screen_socket_path
readonly r_sys_log_path
readonly r_sys_run_path
readonly r_this_package_path
ConfirmVarIsDefined r_default_vol_mount_point "${r_default_vol_mount_point:-}" "$e_nopth"||return
if ! ConfirmVarIsDefined r_this_package_path "${r_this_package_path:-}" "$e_nopth" &>/dev/null||[[ ! -d $r_this_package_path ]];then ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1;fi;r_cache_path=$r_this_package_path/cache
r_log_path=$r_this_package_path/log
r_ipk_cache_path=$r_cache_path/IPKs
r_pip_cache_path=$r_cache_path/PIPs
r_qpkg_cache_path=$r_cache_path/QPKGs
r_ipk_downgrade_path=$r_ipk_cache_path/downgrade
r_ipk_download_path=$r_ipk_cache_path/downloads
r_qpkg_download_path=$r_qpkg_cache_path/downloads
readonly r_cache_path
readonly r_ipk_cache_path
readonly r_ipk_downgrade_path
readonly r_ipk_download_path
readonly r_log_path
readonly r_pip_cache_path
readonly r_qpkg_cache_path
readonly r_qpkg_download_path
r_inhibit_display_pathfile=$r_cache_path/display.inhibit
r_objects_archive_pathfile=$r_cache_path/objects.tar.gz
r_objects_pathfile=$r_cache_path/objects
r_packages_archive_pathfile=$r_cache_path/$r_nas_qpkg_arch.packages.tar.gz
r_packages_pathfile=$r_cache_path/$r_nas_qpkg_arch.packages
r_prev_ipk_list_pathfile=$r_ipk_cache_path/ipk-list.save
r_session_archive_log_pathfile=$r_log_path/session.archive.log
readonly r_inhibit_display_pathfile
readonly r_objects_archive_pathfile
readonly r_objects_pathfile
readonly r_packages_archive_pathfile
readonly r_packages_pathfile
readonly r_prev_ipk_list_pathfile
readonly r_session_archive_log_pathfile
r_temp_log_path=$r_sys_log_path/sherpa.d
r_temp_run_path=$r_sys_run_path/sherpa.d
r_action_counts_path=$r_temp_run_path/action/count
r_action_log_path=$r_temp_log_path/action/log
r_async_procs_path=$r_temp_run_path/proc
r_qpkg_states_path=$r_temp_run_path/qpkg/state
r_report_path=$r_temp_log_path/report
r_run_logs_path=$r_temp_run_path/log
r_temp_report_path=$r_temp_run_path/report
r_action_times_path=$r_action_log_path/times
r_animation_path=$r_async_procs_path/animation
r_report_flags_path=$r_temp_report_path/flag
r_report_rows_path=$r_temp_report_path/row
readonly r_action_counts_path
readonly r_action_log_path
readonly r_action_times_path
readonly r_animation_path
readonly r_async_procs_path
readonly r_qpkg_states_path
readonly r_report_flags_path
readonly r_report_path
readonly r_report_rows_path
readonly r_run_logs_path
readonly r_temp_log_path
readonly r_temp_report_path
readonly r_temp_run_path
r_abort_actions_pathfile=$r_temp_run_path/abort.action
r_action_msg_pipe=$r_temp_run_path/action-messages.pipe
r_action_results_pathfile=$r_action_log_path/action-results.log
r_oom_log_pathfile=$r_temp_log_path/oom.log
r_ram_freeused_output_pathfile=$r_temp_log_path/ram.freeused
r_ramfs_freespace_output_pathfile=$r_temp_log_path/ramfs.freespace
r_report_output_pathfile=$r_temp_log_path/report.ansi
r_screen_sessions_output_pathfile=$r_temp_log_path/screen.sessions
r_session_last_pathfile=$r_temp_log_path/session-last.log
r_session_tail_pathfile=$r_temp_log_path/session-tail.log
session_active_log_pathfile=$r_temp_log_path/session.$$.active.log
readonly r_abort_actions_pathfile
readonly r_action_msg_pipe
readonly r_action_results_pathfile
readonly r_oom_log_pathfile
readonly r_ram_freeused_output_pathfile
readonly r_ramfs_freespace_output_pathfile
readonly r_report_output_pathfile
readonly r_screen_sessions_output_pathfile
readonly r_session_last_pathfile
readonly r_session_tail_pathfile
r_external_apps_path=/opt
r_external_apps_temp_path=$r_external_apps_path.temp
r_external_packages_archive_pathfile=$r_external_apps_path/var/opkg-lists/entware
r_external_packages_pathfile=$r_cache_path/Packages
readonly r_external_apps_path
readonly r_external_apps_temp_path
readonly r_external_packages_archive_pathfile
readonly r_external_packages_pathfile
r_ani_end_pathfile=$r_animation_path/$r_ani_id.end
r_ani_frame_pathfile=$r_animation_path/$r_ani_id.frame
r_ani_pid_pathfile=$r_animation_path/$r_ani_id.pid
r_ani_resume_pathfile=$r_animation_path/$r_ani_id.resume
readonly r_ani_end_pathfile
readonly r_ani_frame_pathfile
readonly r_ani_pid_pathfile
readonly r_ani_resume_pathfile
ClearAnimationFiles
/bin/rm -f "$r_report_output_pathfile" "$r_ramfs_freespace_output_pathfile" "$r_inhibit_display_pathfile";}
ShowLogMarkersAsDebug(){ local -a a_a
local -i b
local -i c
local d
local e
a_a=(Markers:)
a_a+=('(**) detected')
a_a+=('(II) information')
a_a+=('(WW) warning')
a_a+=('(EE) error')
a_a+=('(LL) log file')
a_a+=('(vv) variable name & value')
a_a+=('(aa) array name & values')
a_a+=('(--) processing')
a_a+=('(==) done')
a_a+=('(>>) f entry')
a_a+=('(<<) f exit')
a_a+=('(\\) async f entry')
a_a+=('(//) async f exit')
a_a+=('(NA) not-applicable')
a_a+=('($1) positional argument value')
b=${#a_a[@]}
a_a=("${a_a[@]/%/,}")
a_a[0]=${a_a[0]/,/}
a_a[b-1]=${a_a[b-1]/,/.}
d=${a_a[0]}
for(( c = 1;c<= b - 1;c++ ));do e=${a_a[c]}
if(( ( ${#d} + ${#e} + 2 )<= r_debug_log_width ));then d+=" $e";else DebugInfo "$(TextDarkGrey "$d")"
d=$e;fi;done;(( ${#d}>0 ))&&DebugInfo "$(TextDarkGrey "$d")";}
LoadLists(){ [[ ${lists_loaded:=false} = false ]]||return 0
local a
ar_package_tiers=(independent auxiliary optional dependent)
ar_qpkg_tiers=(independent optional dependent)
ar_qpkg_basic_states=(complete enabled installed)
ar_qpkg_extended_states=(active backedup downloaded installable missing signed upgradable)
ar_qpkg_is_groups=(all canbackup canclean canrestarttoupdate dependent hasdependents independent optional)
ar_qpkg_isnt_groups=(canclean)
ar_qpkg_service_results=(failed ok)
ar_qpkg_transient_states=(restarting slow starting stopping unknown)
ar_qpkg_is_states=(${ar_qpkg_basic_states[*]} ${ar_qpkg_extended_states[*]} ${ar_qpkg_transient_states[*]})
ar_qpkg_isnt_states=(${ar_qpkg_basic_states[*]} ${ar_qpkg_extended_states[*]} ${ar_qpkg_transient_states[*]})
ar_ipk_actions=(downgrade download uninstall upgrade install)
ar_pip_actions=(uninstall upgrade install)
ar_qpkg_actions=(status list rebuild reassign download backup resign unsign deactivate disable uninstall update upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
ar_user_qpkg_actions=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall resign restore status uninstall update upgrade)
readonly ar_ipk_actions
readonly ar_package_tiers
readonly ar_pip_actions
readonly ar_qpkg_actions
readonly ar_qpkg_basic_states
readonly ar_qpkg_extended_states
readonly ar_qpkg_is_groups
readonly ar_qpkg_is_states
readonly ar_qpkg_isnt_groups
readonly ar_qpkg_isnt_states
readonly ar_qpkg_service_results
readonly ar_qpkg_tiers
readonly ar_qpkg_transient_states
readonly ar_user_qpkg_actions
for a in "${ar_qpkg_actions[@]}" debug downgrade fix;do readonly r_"$(Lowercase "$a")"_log_file=$a.log;done;lists_loaded=true;}
CreatePaths(){ ClearPath "$r_temp_run_path" "$r_async_procs_path"
MakePath "$r_action_counts_path" 'action counts'||return
MakePath "$r_action_log_path" 'action logs'||return
MakePath "$r_action_times_path" 'action times'||return
MakePath "$r_animation_path" 'animation process tracking'||return
MakePath "$r_async_procs_path" 'asynchronous process tracking'||return
MakePath "$r_cache_path" cache||return
MakePath "$r_log_path" 'persistent logs'||return
MakePath "$r_qpkg_bu_path" 'QPKG backup'||return
MakePath "$r_qpkg_states_path" states||return
MakePath "$r_run_logs_path" 'run logs'||return
MakePath "$r_temp_log_path" 'temporary logs'||return
MakePath "$r_temp_run_path" 'temporary runtime files'||return;}
CreatePackagePaths(){ ClearPath "$r_cache_path" "$r_ipk_cache_path"
ClearPath "$r_cache_path" "$r_ipk_download_path"
ClearPath "$r_cache_path" "$r_pip_cache_path"
MakePath "$r_ipk_cache_path" 'IPK cache'||return
MakePath "$r_ipk_downgrade_path" 'IPK downgrade'||return
MakePath "$r_ipk_download_path" 'IPK download'||return
MakePath "$r_pip_cache_path" 'PIP cache'||return
MakePath "$r_qpkg_cache_path" 'QPKG cache'||return
MakePath "$r_qpkg_download_path" 'QPKG download'||return;}
CreateReportPaths(){ ClearPath "$r_temp_report_path" "$r_report_flags_path"
ClearPath "$r_temp_report_path" "$r_report_rows_path"
MakePath "$r_report_flags_path" 'report flags'||return
MakePath "$r_report_rows_path" 'report rows'||return
MakePath "$r_temp_report_path" 'temporary reports'||return;}
ClearCachePath(){ if [[ -n $r_cache_path &&-d $r_cache_path ]];then ClearPath "$r_this_package_path" "$r_cache_path"
ShowAsDone 'persistent cache cleared';fi;return 0;}
ClearTempRunPath(){ if [[ -n $r_temp_run_path &&-d $r_temp_run_path ]];then ClearPath "$r_sys_run_path" "$r_temp_run_path"
ShowAsDone 'temp runtime cleared';fi;return 0;}
ClearTempLogPath(){ if [[ -n $r_temp_log_path &&-d $r_temp_log_path ]];then ClearPath "$r_sys_log_path"/sherpa "$r_temp_log_path"
ShowAsDone 'temp logs cleared';fi;return 0;}
DebugLogEnv(){ if [[ $useropt_show_about = false &&$useropt_show_aboutall = false ]];then [[ $run_package_actions = true ]]||return 0
IsDebug||return 0;fi;FuncInit
if [[ $useropt_show_about = true ||$useropt_show_aboutall = true ]];then useropt_debug=true
useropt_verbose=true;fi;local -i n
local a
local b
SetHardwarePlatform
SetOsKernelPageSize
DebugInfoMinSepr
DebugHardware ok 'NAS model' "$(get_display_name)"
DebugHardware ok CPU "$(GetHardwareCpuName)"
DebugHardware ok 'CPU stepping' "$(GetHardwareCpuStepping)"
DebugHardware ok 'CPU architecture' "$(GetCpuDataWidth)"
DebugHardware ok 'available CPU threads' "$r_cpu_threads"
DebugHardware ok 'basic CPU SHA1 benchmark' "$(GetHardwareCpuBenchmark)"
DebugHardware ok RAM "${r_nas_ram_gb}GiB"
DebugKernel ok name "$(GetOsKernelName)"
DebugKernel ok version "$(GetOsKernelVersion)"
a='page size'
b=$r_kernel_page_size
if IsOsStdKernelPageSize;then DebugKernel ok "$a" "$b";else DebugKernel warning "$a" "$b";fi;DebugFirmware ok OS "$(GetOsName)"
SetOsFirmwareVersion
a=version
b=$r_nas_firmware_version
if IsOsSupported;then DebugFirmware ok "$a" "$b";else DebugFirmware warning "$a" "$b";fi;SetOsFirmwareDate
a='build date'
b=$(ConvertAsSmartDate "$r_nas_firmware_date")
if IsOsCompatibleWithSigned;then DebugFirmware ok "$a" "$b";else DebugFirmware warning "$a" "$b";fi;DebugFirmware ok platform "$r_nas_platform"
if IsOsOnline;then DebugOS ok state online;else DebugOS warning state "$(GetOsState)";fi;DebugOS ok uptime "$(GetOsUptime)"
a='load averages'
b=$(GetPrettyLoadAverages)
DebugOS ok "$a" "$b"
DebugStorage ok 'default volume mounted' "$(GetUserDefVol)"
DebugStorage ok 'basic write benchmark' "$(GetHardwareVolumeBenchmark)"
if [[ -L /opt ]];then DebugStorage ok /opt "$(/usr/bin/readlink /opt 2>/dev/null)"
elif [[ -d /opt ]];then DebugStorage ok /opt 'is a directory, not a symlink';else DebugStorage ok /opt 'not present';fi;DebugUserspace ok libc "$(GetUserLIBC)"
DebugUserspace ok 'libc copyright' "$(GetUserLIBCCopyright)"
DebugUserspace ok '$EUID' "$EUID"
a='$SUDO_UID'
if IsOsCanSudo;then if [[ $EUID = 0 ]];then DebugUserspace ok "$a" N/A;else DebugUserspace ok "$a" "$(GetUserSudoUID)";fi;else DebugUserspace ok "$a" N/A;fi;DebugUserspace ok 'BusyBox version' "$(GetBusyBoxVersion)"
DebugUserspace ok 'BusyBox copyright' "$(GetBusyBoxCopyright)"
DebugUserspace ok 'BusyBox function count' "$(GetBusyBoxFunctionCount)"
DebugScript ok 'QPKG version' "$(ConvertAsSmartDate "$r_this_package_ver")"
DebugScript ok 'manager version' "$(ConvertAsSmartDate "$r_this_script_ver")"
DebugScript ok 'manager epoch' "$(ConvertAsSmartDate "$r_script_built_epoch")"
DebugScript ok 'objects epoch' "$(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
DebugScript ok 'packages epoch' "$(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
a='package release'
if ! [[ $package_release_version = testing ]];then DebugQpkg ok "$a" "$(ConvertAsSmartDate "$package_release_version")";else DebugQpkg warning "$a" "$package_release_version";fi;a='allow unofficial'
if IsOsCanUnofficialPackages;then if IsOsAllowUnofficialPackages;then DebugQpkg detect "$a" yes;else DebugQpkg warning "$a" no;fi;else DebugQpkg detect "$a" N/A;fi;a='require signed'
if IsOsCanManageSignedPackages;then if IsOsRequireSignedPackages;then DebugQpkg detect "$a" yes;else DebugQpkg detect "$a" no;fi;else DebugQpkg detect "$a" N/A;fi;SetQpkgArch
DebugQpkg detect architecture "$r_nas_qpkg_arch ($(DecodeQpkgArch $r_nas_qpkg_arch))"
a="date $(FormatPackageName Entware) installed"
if IsQpkgInstalled Entware;then b=$(ConvertAsSmartDate "$(GetQpkgInstalledDate Entware)")
if ! IsEntwareUpgradable;then DebugQpkg detect "$a" "$b";else DebugQpkg warning "$a" "$b";fi;a=$(FormatPackageName Entware)' type'
b=$r_entware_type
if [[ $r_entware_type = std ]];then DebugQpkg detect "$a" "$b";else DebugQpkg warning "$a" "$b";fi;else DebugQpkg detect "$a" N/A;fi;SetOsFirmwareVer
a=$(FormatPackageName SortMyQPKGs)
if IsQpkgInstalled SortMyQPKGs;then DebugQpkg detect "$a" installed;else
if(( 10#$r_nas_firmware_ver<10#$(ConvertFirmwareVersionStringToNumber 4.0.0)||10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 5.2.0) ));then DebugQpkg detect "$a" N/A;else DebugQpkg warning "$a" 'not installed';fi;fi
a=$(FormatPackageName IncreaseTimeouts)
if IsOsCanQpkgTimeout;then if IsQpkgInstalled IncreaseTimeouts;then if IsQpkgTimeoutsIncreased;then DebugQpkg detect "$a" active;else DebugQpkg warning "$a" inactive;fi;else DebugQpkg detect "$a" 'not installed';fi;else DebugQpkg detect "$a" N/A;fi;DebugInfoMinSepr
if [[ $useropt_show_about = true ]];then useropt_debug=false
useropt_verbose=false
return;fi;if [[ -n ${r_websites:-} ]];then for(( n = 0;n<${#r_websites[@]};n++ ));do if IsSiteUp ${r_websites[n]};then DebugWebsite ok "${r_websites[n]}" up;else DebugWebsite warning "${r_websites[n]}" down;fi;done;fi
DebugInfoMinSepr
if [[ -x $r_gnu_df_cmd ]];then Executer "$r_gnu_df_cmd --human-readable --local --print-type -t ext2 -t ext3 -t ext4 -t zfs -t tmpfs" "$r_ramfs_freespace_output_pathfile" '' 1
elif (/bin/df -T &>/dev/null);then Executer '/bin/df -hT' "$r_ramfs_freespace_output_pathfile" '' 1;else Executer '/bin/df -h' "$r_ramfs_freespace_output_pathfile" '' 1
fi|/bin/grep -iEv '^(devtmpfs|cgroup_root)'
DebugInfoMinSepr
Executer "SCREENDIR=$r_screen_socket_path /usr/sbin/screen -ls;true" "$r_screen_sessions_output_pathfile" '' 1|/bin/sed "$r_regex_process_screen_sessions"
DebugInfoMinSepr
if [[ -x $r_gnu_free_cmd ]];then Executer "$r_gnu_free_cmd --human --total" "$r_ram_freeused_output_pathfile" '' 1
elif (/usr/bin/free -m &>/dev/null);then Executer '/usr/bin/free -m' "$r_ram_freeused_output_pathfile" '' 1;else Executer '/usr/bin/free' "$r_ram_freeused_output_pathfile" '' 1;fi;DebugInfoMinSepr
Executer "! /bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg" "$r_oom_log_pathfile" '' 1
DebugInfoMinSepr
if [[ $useropt_show_aboutall = true ]];then useropt_debug=false
useropt_verbose=false;fi;FuncExit;}
CheckTasks(){ if [[ $arg_problem = true ||$useropt_help_basic = true ]];then generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_extended_states=false
run_package_actions=false
show_action_results_report=false;fi;[[ $get_qpkg_extended_states = true ]]||return 0
FuncInit;local action
local build_extended_states
local group
local installed_version
local state
local target_packages
action=''
build_extended_states=false
group=''
installed_version=''
state=''
target_packages=''
if [[ $useropt_fix = true ||$useropt_show_status = true ]];then build_extended_states=true
elif [[ $useropt_help_abbreviations = true ||$useropt_show_backups = true ||$useropt_show_dependencies = true ||$useropt_show_features = true ||$useropt_show_packages = true ||$useropt_show_repos = true ]];then build_extended_states=true
elif [[ $useropt_help_actions = true ||$useropt_help_actions_all = true ||$useropt_help_basic = true ||$useropt_help_groups = true ||$useropt_help_lists = true ||$useropt_help_options = true ||$useropt_help_packages = true ||$useropt_help_problems = true ||$useropt_help_show = true ||$useropt_help_tips = true ||$useropt_help_upgrades = true ||$useropt_list_versions = true ||$useropt_show_about = true ||$useropt_show_about = true ||$useropt_show_previous_action_results_report = true ||$useropt_show_log_last = true ||$useropt_show_log_tail = true ||$switch_branch = true ||$switch_colour = true ||$switch_report_info = true ||$switch_terse = true ]];then :;else LoadDatabase
for action in "${ar_user_qpkg_actions[@]}";do if QPKGs-AC${action}-to.IsAny;then build_extended_states=true
break;fi;for group in "${ar_qpkg_is_groups[@]}";do if QPKGs.AC${action}GR${group}.IsSet;then build_extended_states=true
break 2;fi;done;for group in "${ar_qpkg_isnt_groups[@]}";do if QPKGs.AC${action}GRNT${group}.IsSet;then build_extended_states=true
break 2;fi;done;for state in "${ar_qpkg_extended_states[@]}";do case $state in downloaded)
continue;;*)if QPKGs.AC${action}IS${state}.IsSet;then build_extended_states=true
break 2;fi;esac;done;for state in "${ar_qpkg_extended_states[@]}";do case $state in downloaded)
continue;;*)if QPKGs.AC${action}ISNT${state}.IsSet;then build_extended_states=true
break 2;fi;esac;done;done;fi
[[ $build_extended_states = true ]]&&BuildExtendedQPKGsStates
if IsValidQpkgInstalled Entware;then if [[ $r_entware_type = none ]];then DebugAsWarn "$(FormatPackageName Entware) appears to be installed but is inactive. Please consider starting the $(FormatPackageName Entware) QPKG.";fi;if [[ $useropt_fix = true ]]||QPKGs-ACupgrade-to.Exist Entware;then ipks_install=true
ipks_upgrade=true
pips_install=true;fi;SetQpkgArch
case $r_nas_qpkg_arch in a41)
if IsOsNonStdKernelPageSize;then target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($r_opkg_cmd list-installed|/bin/grep "^${target_packages%% *} *"|/usr/bin/head -n1|/usr/bin/cut -d' ' -f3|/usr/bin/cut -d'-' -f1)
installed_version=${installed_version//.}
if IsInteger "$installed_version"&&(( installed_version>238 ));then ipks_downgrade=true
ShowAsNote "various IPKs will be downgraded to suit $r_kernel_page_size kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages";else IPKs-ACdowngrade-sk:Add "$target_packages";fi;fi
esac;fi
BuildQPKGsIsCanBackup
BuildQPKGsIsCanRestartToUpdate
BuildQPKGsIsCanClean
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-ISupgradable.Exist sherpa;then ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be upgraded"
QPKGs-ACupgrade-to:Add sherpa;fi;FuncExit;}
WaitForPidsThenRemove(){ [[ -n ${1:-} ]]||return
[[ -s $1 ]]||return
wait $(<"$1") 2>/dev/null
/bin/rm -f "$1";}
AssignQpkgsToActions(){ [[ $run_package_actions = true ]]||return 0
FuncInit;PauseSpinner
ShowAsProc 'action assignment'
ResumeSpinner
local action
local prospect
local qpkg_name
if IsOsOnline&&IsValidQpkgInstalled Entware&&IsEntwareUpgradable&&(IsNonStatusActionRequested||[[ $useropt_fix = true ]]);then ShowAsNote "the $(TextBrightOrange Entware) QPKG will be reinstalled (Entware packages were last updated in $(ConvertLongDateAsHuman $r_entware_packages_last_updated))"
QPKGs-ACreinstall-to:Add Entware;fi;if QPKGs-ACrebuild-to.IsAny;then for qpkg_name in $(QPKGs-ACrebuild-to:Array);do SetQpkgIndex
if IsNtValidQpkgInstalled "$qpkg_name"&&(IsQpkgBackupExist||(QPKGs-ACbackup-to.Exist "O$qpkg_name"&&QPKGs-ACuninstall-to.Exist "O$qpkg_name"));then QPKGs-ACinstall-to:Add "$qpkg_name"
QPKGs-ACrestore-to:Add "$qpkg_name";fi;done;fi
for qpkg_name in $(QPKGs-ACinstall-to:Array) $(QPKGs-ACreinstall-to:Array);do SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do [[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect"&&QPKGs-ACinstall-to:Add "$prospect";done;done;for qpkg_name in $(GetQpkgsIsValidInstalled);do if [[ $useropt_fix = true ]]||QPKGs-ACactivate-to.Exist "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do [[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect"&&QPKGs-ACinstall-to:Add "$prospect";done;fi;done;for action in activate deactivate disable enable install reinstall reactivate uninstall upgrade;do for qpkg_name in $(QPKGs-AC${action}-to:Array);do if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do IsQpkgEnabled "$prospect"&&! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACreactivate-to:Add "$prospect";done;fi;done;done;for action in deactivate uninstall;do for qpkg_name in $(QPKGs-AC${action}-to:Array);do if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do IsValidQpkgInstalled "$prospect"&&QPKGs-ACdeactivate-to:Add "$prospect";done;fi;done;done;qpkg_name=Entware
if QPKGs-ACreinstall-to.Exist "$qpkg_name";then QPKGs-ACreinstall-to:Remove "$qpkg_name"
QPKGs-ACuninstall-to:Add "$qpkg_name"
QPKGs-ACinstall-to:Add "$qpkg_name"
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do IsValidQpkgInstalled "$prospect"&&QPKGs-ACclean-to:Add "$prospect";done;fi
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do if IsQpkgEnabled "$prospect";then QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect";fi;done;fi;done;for action in reinstall reactivate upgrade;do for qpkg_name in $(QPKGs-AC${action}-to:Array);do if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do if IsQpkgEnabled "$prospect";then QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect";fi;done;fi;done;done;for qpkg_name in $(QPKGs-ACuninstall-to:Array);do if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do if IsQpkgEnabled "$prospect";then QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect";fi;done;fi;done;for action in backup restore upgrade reinstall;do for qpkg_name in $(QPKGs-AC${action}-to:Array);do if IsQpkgEnabled "$qpkg_name";then QPKGs-ACdeactivate-to:Add "$qpkg_name"
! QPKGs-ACuninstall-to.Exist "$qpkg_name"&&! QPKGs-ACinstall-to.Exist "$qpkg_name"&&QPKGs-ACactivate-to:Add "$qpkg_name";fi;done;done;for action in reinstall install activate reactivate;do for qpkg_name in $(QPKGs-AC${action}-to:Array);do SetQpkgIndex
for prospect in $(GetQpkgDbDependencies) $(GetQpkgDbOptionals);do IsValidQpkgInstalled "$prospect"&&IsQpkgEnabled "$prospect"&&QPKGs-ACreactivate-to:Add "$prospect";done;done;done;if QPKGs.ACuninstallGRall.IsSet;then QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init;else QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)";fi;a_QPKGs_were_installed_name=()
a_QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then for qpkg_name in $(QPKGs-ACuninstall-to:Array);do if IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then a_QPKGs_were_installed_name+=("$qpkg_name")
SetQpkgIndex
a_QPKGs_were_installed_path+=("$(/usr/bin/dirname "$(GetQpkgInstalledPath)")");fi;QPKGs-ACdeactivate-to:Add "$qpkg_name";done;fi
QPKGs-ACdownload-to:Add "$(QPKGs-ACinstall-to:Array)"
for qpkg_name in $(QPKGs-ACreinstall-to:Array);do IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACdownload-to:Add "$qpkg_name";done;for qpkg_name in $(QPKGs-ACupgrade-to:Array);do QPKGs-ISupgradable.Exist "$qpkg_name"&&QPKGs-ACdownload-to:Add "$qpkg_name";done;if IsOsCanManageSignedPackages&&QPKGs-ACinstall-to.IsAny;then QPKGs-ACsign-to:Add "$(QPKGs-ACinstall-to:Array)";fi;if QPKGs-ACresign-to.IsAny;then for qpkg_name in $(QPKGs-ACresign-to:Array);do QPKGs-ACunsign-to:Add "$qpkg_name"
QPKGs-ACsign-to:Add "$qpkg_name";done;fi
if [[ $useropt_fix = true ]];then IsOsCanManageSignedPackages&&QPKGs-ACsign-to:Add "$(GetQpkgsIsValidInstalled)"
for qpkg_name in $(QPKGs-GRdependent:Array);do IsQpkgEnabled "$qpkg_name"&&QPKGs-ACreactivate-to:Add "$qpkg_name";done;Executer "SCREENDIR=$r_screen_socket_path /usr/sbin/screen -wipe;true" "$r_screen_sessions_output_pathfile" '' 1|/bin/sed "$r_regex_process_screen_sessions";fi;QPKGs-ACuninstall-to:Remove sherpa
QPKGs-ACsign-to.IsAny&&LoadQpkgSigningCert
FuncExit;}
ProcActions(){ [[ $run_package_actions = true ]]||return
FuncInit;PauseSpinner
ShowAsProc 'package actions'
ResumeSpinner
local -i tier_index
local action
local state
local tier
/bin/rm -f "$r_action_results_pathfile" 2>/dev/null
ProcAction status all QPKG 'live status'
if [[ $useropt_show_status = false ]];then for action in "${ar_user_qpkg_actions[@]}";do for state in "${ar_qpkg_is_states[@]}";do case $state in downloaded|installed)
continue;;*)QPKGs.AC${action}IS${state}.IsSet&&QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
esac;done;for state in "${ar_qpkg_isnt_states[@]}";do case $state in enabled|downloaded)
continue;;*)QPKGs.AC${action}ISNT${state}.IsSet&&QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
esac;done;done;fi
ProcAction rebuild all QPKG meta-rebuild
ProcAction reassign all QPKG reassign
ProcAction download all QPKG download
if QPKGs-ACdownload-er.IsNone&&QPKGs-ACdownload-se.IsNone&&QPKGs-ACdownload-sa.IsNone;then for(( tier_index = ${#ar_package_tiers[@]} - 1;tier_index>= 0;tier_index-- ));do tier=${ar_package_tiers[tier_index]}
if [[ $tier != auxiliary ]];then ProcAction deactivate $tier QPKG deactivate
ProcAction disableau $tier QPKG 'disable auto-update'
ProcAction backup $tier QPKG backup
ProcAction disable $tier QPKG disable
ProcAction uninstall $tier QPKG uninstall
IsOsCanManageSignedPackages&&ProcAction unsign $tier QPKG unsign
elif IsQpkgEnabled Entware;then ModPathToEntware
PIPs:uninstall
IPKs:uninstall;fi;done;for tier in "${ar_package_tiers[@]}";do if [[ $tier != auxiliary ]];then IsOsCanManageSignedPackages&&ProcAction sign $tier QPKG '"sign"'
ProcAction upgrade $tier QPKG upgrade
ProcAction reinstall $tier QPKG reinstall
ProcAction install $tier QPKG install
ProcAction restore $tier QPKG restore
ProcAction enableau $tier QPKG 'enable auto-update'
ProcAction clean $tier QPKG clean
ProcAction update $tier QPKG update
ProcAction enable $tier QPKG enable
ProcAction reactivate $tier QPKG reactivate
ProcAction activate $tier QPKG activate;else for action in status install reinstall upgrade activate;do if QPKGs-ACinstall-ok.Exist Entware||QPKGs-AC${action}-to.IsAny;then ipks_downgrade=true
ipks_install=true
ipks_upgrade=true
pips_install=true
break;fi;done;if IsQpkgEnabled Entware;then ModPathToEntware
IPKs:upgrade
IPKs:install
IPKs:downgrade
PIPs:upgrade
PIPs:install;fi;fi;done;fi
IsOsCanManageSignedPackages&&ProcAction unsign all QPKG unsign
EndSpinner
if IsDebug;then ListQPKGsActions
ListIPKsActions
ListPIPsActions;fi;if [[ $title_shown = true ]];then if IsNtError;then ShowAsDone 'actions complete';else ShowAsFail 'actions complete with errors';fi;fi
show_action_results_report=true
FuncExit;}
ProcAction(){ FuncInit
local -a a_target_packages
local -i package_index
local -i pid
local -i total_count
local a
local group
local msg1_key
local msg1_value
local msg2_key
local msg2_value
local package
local r_action
local r_action_intransitive_msg
local r_package_type
local r_pid_pathfile
local r_tier
local re
local state
local target_object_name
a=_ExecOneActionWithManyForks_
a_target_packages=()
msg1_key=''
msg1_value=''
msg2_key=''
msg2_value=''
pid=0
r_action=${1:?${FUNCNAME[0]}(): $e_noact}
r_action_intransitive_msg=${4:?${FUNCNAME[0]}(): $e_noact message}
r_package_type=${3:?${FUNCNAME[0]}(): $e_nopty}
r_pid_pathfile=$(CreatePidFilePathName)
r_tier=${2:?${FUNCNAME[0]}(): $e_notir}
re=''
total_count=0
local -r r_action
local -r r_action_intransitive_msg
local -r r_package_type
local -r r_pid_pathfile
local -r r_tier
DebugVar r_action
DebugVar r_package_type
DebugVar r_tier
case $r_package_type in QPKG)
target_object_name=AC${r_action}-to
if [[ $r_tier = all ]];then a_target_packages=($(${r_package_type}s-$target_object_name:Array));else for package in $(${r_package_type}s-$target_object_name:Array);do ${r_package_type}s-GR${r_tier}.Exist "$package"&&a_target_packages+=("$package");done;fi
total_count=${#a_target_packages[@]}
DebugVar total_count
if(( total_count == 0 ));then DebugInfo 'nothing to process.'
FuncExit;return;fi;if(( total_count == 1 ));then fork_progress_prefix="$r_action_intransitive_msg $(TextBrightOrange "${a_target_packages[0]}") $r_package_type";else fork_progress_prefix="$r_action_intransitive_msg $([[ $r_tier != all ]]&&TextBrightOrange "$r_tier ")$(Uppercase "$r_package_type")$(Pluralise "$total_count")";fi;SetMaxForks "$r_action"
InitActionForkCounters
OpenMsgPipe
re=\\bEntware\\b
if [[ $r_action = uninstall &&${a_target_packages[*]} =~ $re ]];then ShowKeystrokes;fi;PauseSpinner
CreateAndSetPidFile
$a "_${r_package_type}:${r_action}_" "${a_target_packages[@]}" &
pid=$!
DebugAsDone "${FUNCNAME[0]}() has forked '$a()' for action '$r_action' with PID '$pid'"
WriteToPidFile "$pid" "$pidfile"
AppendToPidsFile "$pid" "$r_pid_pathfile"
while(( ${#a_target_packages[@]}>0 ))&&[[ ! -e $r_abort_actions_pathfile ]];do ReadFromMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in run)
eval "$msg1_value";;change)
while true;do for state in "${ar_qpkg_is_states[@]}";do case $msg1_value in "IS${state}")
IsFuncExist QPKGs-ISNT${state}:Init&&QPKGs-ISNT${state}:Remove "$msg2_value"
IsFuncExist QPKGs-IS${state}:Init&&QPKGs-IS${state}:Add "$msg2_value"
break 2
esac;done;for state in "${ar_qpkg_isnt_states[@]}";do case $msg1_value in "ISNT${state}")
IsFuncExist QPKGs-IS${state}:Init&&QPKGs-IS${state}:Remove "$msg2_value"
IsFuncExist QPKGs-ISNT${state}:Init&&QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac;done;for group in "${ar_qpkg_is_groups[@]}";do case $msg1_value in "GR${group}")
IsFuncExist QPKGs-GRNT${group}:Init&&QPKGs-GRNT${group}:Remove "$msg2_value"
IsFuncExist QPKGs-GR${group}:Init&&QPKGs-GR${group}:Add "$msg2_value"
break 2
esac;done;for group in "${ar_qpkg_isnt_groups[@]}";do case $msg1_value in "GRNT${group}")
IsFuncExist QPKGs-GR${group}:Init&&QPKGs-GR${group}:Remove "$msg2_value"
IsFuncExist QPKGs-GRNT${group}:Init&&QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac;done;DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break;done;;update)
case $msg1_value in ok)
[[ $r_action != status ]]&&(( done_ok_count++ ));;er)
(( done_fail_count++ ));;sk)
(( skip_ok_count++ ));;se)
(( skip_error_count++ ));;sa)
(( skip_abort_count++ ))
/bin/touch "$r_abort_actions_pathfile"
esac;case $msg1_value in en)
:;;ok|er|sk|se|sa)
IsFuncExist QPKGs-AC${r_action}-to:Init&&QPKGs-AC${r_action}-to:Remove "$msg2_value"
IsFuncExist QPKGs-AC${r_action}-${msg1_value}:Init&&QPKGs-AC${r_action}-${msg1_value}:Add "$msg2_value"
IsFuncExist QPKGs-AC${r_action}-dn:Init&&QPKGs-AC${r_action}-dn:Add "$msg2_value";;ex)
for package_index in "${!a_target_packages[@]}";do if [[ ${a_target_packages[package_index]} = "$msg2_value" ]];then unset 'a_target_packages[package_index]'
break;fi;done;;*)DebugAsWarn "unidentified update in message queue: '$msg1_value'"
esac;;*)DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac;[[ -e $r_abort_actions_pathfile ]]&&break;done;(( done_fail_count>0 ))&&show_action_results_failed=true
(( done_ok_count>0 ))&&show_action_results_ok=true
(( skip_ok_count>0||skip_error_count>0||skip_abort_count>0 ))&&show_action_results_skipped=true
WaitForPidsThenRemove "$r_pid_pathfile"
CloseMsgPipe
[[ ${useropt_terse:=true} = false &&$useropt_verbose = false ]]&&echo
ShowAsProc 'package actions'
ResumeSpinner;;IPK|PIP)
if [[ $ipks_downgrade = true ||$ipks_install = true ||$ipks_upgrade = true ||$pips_install = true ]];then PauseSpinner
InitActionForkCounters
${r_package_type}s:${r_action}
ResumeSpinner;fi;esac;EraseForkCountPaths
FuncExit
IsNtError;}
OpenMsgPipe(){ [[ -p $r_action_msg_pipe ]]&&/bin/rm -f "$r_action_msg_pipe"
[[ ! -d $(/usr/bin/dirname "$r_action_msg_pipe") ]]&&/bin/mkdir -p "$(/usr/bin/dirname "$r_action_msg_pipe")"
[[ ! -p $r_action_msg_pipe ]]&&/bin/mknod "$r_action_msg_pipe" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd<>$r_action_msg_pipe";} 2>/dev/null
CloseMsgPipe(){ if [[ -n ${backup_stdin_fd:-} ]];then [[ $backup_stdin_fd != none ]]&&eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]]&&eval "exec $backup_stdin_fd>&-";fi;[[ -n ${action_msg_pipe_fd:-} &&$action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd>&-"
[[ -n ${r_action_msg_pipe:-} &&-p $r_action_msg_pipe ]]&&/bin/rm -f "$r_action_msg_pipe";} 2>/dev/null
SetMaxForks(){ [[ -n ${1:-} ]]||return
local -i default_forks
local a
local reason
default_forks=$r_concurrency
max_forks=$default_forks
reason=''
if IsVerbose;then max_forks=1
reason='verbose mode is active'
elif IsDebug;then max_forks=1
reason='debug mode is active';else case $1 in ?(re)install|upgrade)
max_forks=1;;sign|unsign)
max_forks=1;;@(dis|en)able)
max_forks=1;;clean)
max_forks=$(( ( r_concurrency + 1 ) / 2 ));;backup|deactivate|download|uninstall|update)
max_forks=4;;@(dis|en)ableau|rebuild)
max_forks=8;;status)
a=$(GetOsSysLoad1MinAverage)
if IsThisLoadAverageInsane "$a";then max_forks=1
elif IsThisLoadAverageHigh "$a";then max_forks=2
elif IsThisLoadAverageElevated "$a";then max_forks=4;else max_forks=8;fi;esac;(( max_forks != default_forks ))&&reason="'$1' was requested";fi;[[ -n $reason ]]&&DebugInfo "setting \$max_forks to $max_forks because $reason.";}
PrepareArgs(){ ShowAsProc args
StartSpinner
local a
a=$(Lowercase "${r_args_raw//,/ }")
a_args=(${a/--/})
arg_problem=false
[[ -z $r_args_raw ]]&&useropt_help_basic=true;}
ParseManagementArgs(){ FuncInit
local -a a_args_remaining
local action
local arg
local awaiting_group
local current_action
local group
local potential_action
local requires_group
local user_action
a_args_remaining=()
action=''
awaiting_group=false
current_action=''
group=''
potential_action=''
requires_group=false
user_action=''
for arg in ${a_args[@]+"${a_args[@]}"};do [[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then action=$potential_action;DebugVar action
potential_action=''
case $action in debug|verbose)
requires_group=false
user_action=$arg
EnableVerbose
EnableDebugToArchiveAndFile;;fix)
LoadDatabase
generate_show_report=true
get_qpkg_extended_states=true
requires_group=false
run_package_actions=true
user_action=$arg
useropt_fix=true;;follow|report-info|terse)
requires_group=true
user_action=$arg
show_title=false;;reset)
DeleteSetting Git_Branch announce
DeleteSetting Terse announce
DeleteSetting ReportInfo announce
Reset
esac;if [[ -n $user_action &&$user_action != "$current_action" ]];then [[ $awaiting_group = true ]]&&a_args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue;fi;fi
group=$(MatchNoun $arg)
DebugVar group
if [[ -n $action &&-n $group ]];then case $action in follow)
case $group in ?(un)stable)
action=''
awaiting_group=false
run_package_actions=false
switch_branch=true
user_branch_value=$group
WriteBranch;;*)a_args_remaining+=("$action")
esac;;report-info)
case $group in true|false)
action=''
awaiting_group=false
switch_report_info=true
user_report_info_value=$group
WriteReportInfo;;*)a_args_remaining+=("$action")
esac;;terse)
case $group in true|false)
action=''
awaiting_group=false
switch_terse=true
user_terse_value=$group
WriteTerse;;*)a_args_remaining+=("$action")
esac;;*)a_args_remaining+=("$arg")
esac;else a_args_remaining+=("$arg");fi;done;if [[ $requires_group = true &&$awaiting_group = true ]];then a_args_incomplete+=("$user_action");fi;a_args=(${a_args_remaining[@]+"${a_args_remaining[@]}"})
FuncExit;}
ParseHelpArgs(){ FuncInit
local -a a_args_remaining
local action
local arg
local awaiting_group
local current_action
local group
local potential_action
local requires_group
local user_action
a_args_remaining=()
action=''
awaiting_group=false
current_action=''
group=''
potential_action=''
requires_group=false
user_action=''
for arg in ${a_args[@]+"${a_args[@]}"};do [[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then action=$potential_action;DebugVar action
potential_action=''
case $action in help)
requires_group=true
user_action=$arg
esac;if [[ -n $user_action &&$user_action != "$current_action" ]];then [[ $awaiting_group = true ]]&&a_args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue;fi;fi
group=$(MatchNoun $arg)
DebugVar group
case $group in abs|actions|all|all-actions|groups|lists|options|packages|problems|show|tips|upgrades)
[[ -z $action ]]&&action=help
esac;if [[ -n $action &&-n $group ]];then case $action in help)
case $group in abs)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true;;actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true;;all|all-actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true;;groups)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true;;lists)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true;;options)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true;;packages)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true;;problems)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true;;show)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_show=true;;tips)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true;;upgrades)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true;;*)a_args_remaining+=("$action")
esac;;*)a_args_remaining+=("$arg")
esac;else a_args_remaining+=("$arg");fi;done;if [[ $requires_group = true &&$awaiting_group = true ]];then a_args_incomplete+=("$user_action");fi;for arg in ${a_args_incomplete[*]+"${a_args_incomplete[*]}"};do case $arg in help)
run_package_actions=false
useropt_help_basic=true
local a=''
local a_tmp=()
for a in ${a_args_incomplete[*]+"${a_args_incomplete[*]}"};do [[ $a != "$arg" ]]&&a_tmp+=($a);done;if(( ${#a_tmp[@]} == 0 ));then a_args_incomplete=();else a_args_incomplete=("${a_tmp[@]}");fi;unset a_tmp
esac;done;a_args=(${a_args_remaining[@]+"${a_args_remaining[@]}"})
FuncExit;}
ParseShowArgs(){ FuncInit
local -a a_args_remaining
local action
local arg
local awaiting_group
local current_action
local group
local potential_action
local requires_group
local user_action
a_args_remaining=()
action=''
awaiting_group=false
current_action=''
group=''
potential_action=''
requires_group=false
user_action=''
for arg in ${a_args[@]+"${a_args[@]}"};do [[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then action=$potential_action;DebugVar action
potential_action=''
case $action in show)
requires_group=true
user_action=$arg
esac;if [[ -n $user_action &&$user_action != "$current_action" ]];then [[ $awaiting_group = true ]]&&a_args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue;fi;fi
group=$(MatchNoun $arg)
DebugVar group
case $group in about|about-all|about-extra|about-sites|abs|backups|dependent|features|last|packages|repositories|results|status|tail)
[[ -z $action ]]&&action=show
esac;if [[ -n $action &&-n $group ]];then case $action in show)
case $group in about)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_about=true;;about-extra)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_aboutextra=true;;about-sites)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_aboutsites=true;;about-all)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_aboutextra=true
useropt_show_aboutsites=true
useropt_show_aboutall=true;;abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_help_abbreviations=true;;backups)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_backups=true;;dependent)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true;;features)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_features=true;;last)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_last=true;;packages)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_packages=true;;repositories)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true;;results)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_previous_action_results_report=true
show_action_results_report=true;;status)
LoadObjects
QPKGs.ACstatusGRall:Set
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
useropt_show_status=true;;tail)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_tail=true;;*)a_args_remaining+=("$action")
esac;;*)a_args_remaining+=("$arg")
esac;else a_args_remaining+=("$arg");fi;done;if [[ $requires_group = true &&$awaiting_group = true ]];then a_args_incomplete+=("$user_action");fi;a_args=(${a_args_remaining[@]+"${a_args_remaining[@]}"})
FuncExit;}
ParseListArgs(){ FuncInit
local -a a_args_remaining
local action
local arg
local awaiting_group
local current_action
local group
local potential_action
local requires_group
local user_action
a_args_remaining=()
action=''
awaiting_group=false
current_action=''
group=''
potential_action=''
requires_group=false
user_action=''
for arg in ${a_args[@]+"${a_args[@]}"};do [[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then action=$potential_action;DebugVar action
potential_action=''
case $action in list)
requires_group=true
user_action=$arg
esac;if [[ -n $user_action &&$user_action != "$current_action" ]];then [[ $awaiting_group = true ]]&&a_args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue;fi;fi
group=$(MatchNoun $arg)
DebugVar group
case $group in ?(NT)installed|upgradable|versions)
[[ -z $action ]]&&action=list
esac;if [[ -n $action &&-n $group ]];then case $action in list)
case $group in all|?(in)dependent|optional)
LoadObjects
QPKGs.AClistGR${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;?(NT)active)
LoadObjects
QPKGs.AClistIS${group}:Set
QPKGs.ACstatusISinstalled:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=true
show_title=false;;?(NT)backedup|?(NT)complete|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AClistIS${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;versions)
LoadDatabase
action=''
awaiting_group=false
generate_list_report=true
show_title=false
useropt_list_versions=true;;*)a_args_remaining+=("$action")
esac;;*)a_args_remaining+=("$arg")
esac;else a_args_remaining+=("$arg");fi;done;if [[ $requires_group = true &&$awaiting_group = true ]];then a_args_incomplete+=("$user_action");fi;a_args=(${a_args_remaining[@]+"${a_args_remaining[@]}"})
FuncExit;}
ParseActionArgs(){ FuncInit
local -a a_args_remaining
local action
local arg
local awaiting_group
local current_action
local group
local potential_action
local requires_group
local user_action
a_args_remaining=()
action=''
awaiting_group=false
current_action=''
group=''
potential_action=''
requires_group=false
user_action=''
[[ -n ${a_args[*]+"${a_args[*]}"} ]]&&LoadDatabase
for arg in ${a_args[@]+"${a_args[@]}"};do [[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then action=$potential_action;DebugVar action
potential_action=''
case $action in ?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|rebuild|?(re|un)install|resign|restore|update)
requires_group=true
user_action=$arg;;upgrade)
get_qpkg_extended_states=true
requires_group=true
user_action=$arg;;status)
generate_show_report=true
get_qpkg_extended_states=true
requires_group=true
user_action=$arg
useropt_show_status=true
esac;if [[ -n $user_action &&$user_action != "$current_action" ]];then [[ $awaiting_group = true ]]&&a_args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue;fi;fi
group=$(MatchNoun $arg);DebugVar group
if [[ -n $action &&-n $group ]];then case $action in ?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|@(re|un)install|resign|restore|update|upgrade)
case $group in ?(NT)active)
LoadObjects
QPKGs.AC${action}IS${group}:Set
QPKGs.ACstatusISinstalled:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac;esac;case $group in all|canbackup|?(NT)canclean|canrestarttoupdate|?(in)dependent|hasdependents)
LoadObjects
QPKGs.AC${action}GR${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AC${action}IS${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;*)[[ $action != show ]]||continue
LoadObjects
QPKGs-AC${action}-to:Add "$group"
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac;else a_args_remaining+=("$arg");fi;done;if [[ $requires_group = true &&$awaiting_group = true ]];then a_args_incomplete+=("$user_action");fi;for arg in ${a_args_incomplete[*]+"${a_args_incomplete[*]}"};do action=$(MatchVerb $arg)
case $action in status)
LoadObjects
QPKGs.ACstatusISinstalled:Set
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
local a=''
local a_tmp=()
for a in ${a_args_incomplete[*]+"${a_args_incomplete[*]}"};do [[ $a != "$arg" ]]&&a_tmp+=($a);done;if(( ${#a_tmp[@]} == 0 ));then a_args_incomplete=();else a_args_incomplete=("${a_tmp[@]}");fi;unset a_tmp
esac;done;a_args=(${a_args_remaining[@]+"${a_args_remaining[@]}"})
FuncExit;}
MatchVerb(){ [[ -n ${1:-} ]]||return
case $1 in backup|clean|@(dis|en)able|fix|follow|help|reassign|rebuild|reinstall|report-info|reset|restore|terse|update|upgrade)
printf '%s' "$1";;activate|start)
printf activate;;add|install)
printf install;;deactivate|stop)
printf deactivate;;d?(e)bug)
printf debug;;disable-auto-update)
printf disableau;;enable-auto-update)
printf enableau;;list|ls)
printf list;;reactivate|restart)
printf reactivate;;remove|rm|uninstall)
printf uninstall;;report|show|view)
printf show;;resign|re-sign)
printf resign;;s|status?(es))
printf status;;v|verbose)
printf verbose
esac;}
MatchNoun(){ [[ -n ${1:-} ]]||return
case $1 in backedup|canbackup|complete|installable|installed|missing|results|show|?(un)stable)
printf '%s' "$1";;a|about)
printf about;;a-all|about-all|all-a|all-about)
printf about-all;;a-sites|about-sites|sites-a|sites-about)
printf about-sites;;a-extra|about-extra|extra-a|extra-about)
printf about-extra;;abs|abbreviations)
printf abs;;action?(s))
printf actions;;action?(s)-all|all-action?(s))
printf all-actions;;active|n?(o)@(n|t)?(-)inactive|n?(o)@(n|t)?(-)stopped|started)
printf active;;all|entire|everything)
printf all;;b|backups)
printf backups;;d|deps|dependencies|dependent?(s))
printf dependent;;disable|false|no|off|unset)
printf false;;disabled|n?(o)@(n|t)?(-)enabled)
printf NTenabled;;enable|on|set|true|yes)
printf true;;enabled|n?(o)@(n|t)?(-)disabled)
printf enabled;;f|features)
printf features;;group?(s))
printf groups;;inactive|n?(o)@(n|t)?(-)active|n?(o)@(n|t)?(-)started|stopped)
printf NTactive;;indep?(endent)?(s))
printf independent;;l|last)
printf last;;list?(s))
printf lists;;log|tail)
printf tail;;me|problem?(s))
printf problems;;new|updat?(e)able|upgrad@(a|e)ble)
printf upgradable;;no@(n|t)-back?(ed)up)
printf NTbackedup;;n?(o)@(n|t)?(-)installable)
printf NTinstallable;;n?(o)@(n|t)?(-)installed)
printf NTinstalled;;n?(o)@(n|t)?(-)missing)
printf NTmissing;;n?(o)@(n|t)?(-)upgradable)
printf NTupgradable;;@(in|nt|not)?(-)complete)
printf NTcomplete;;o|option?(s))
printf options;;optional?(s))
printf optional;;p|package?(s)|qpkg?(s))
printf packages;;r|repos|repositories)
printf repositories;;s|status?(es))
printf status;;tip?(s))
printf tips;;upgrade?(s)|upgrading)
printf upgrades;;version?(s))
printf versions;;*)QpkgMatchAbbrv "$1"
esac;}
ShowArgSuggestions(){ FuncInit
local -a a_args_remaining
local arg
a_args_remaining=()
CreateReportPaths
if [[ -n ${a_args_incomplete[*]+"${a_args_incomplete[*]}"} ]];then run_package_actions=false
for arg in ${a_args_incomplete[*]+"${a_args_incomplete[*]}"};do case $arg in ?(de|re)activate|backup|clean|@(dis|en)able|@(dis|en)able-auto-update|reassign|@(re|un)install|?(re)start|restore|rm|sign|stop)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false;;terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
DisplayAsProjSynIndentExam '' "$arg enable"
DisplayAsProjSynIndentExam '' "$arg disable"
arg_problem=true
useropt_help_basic=false;;follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to '$arg' like" "$arg stable"
DisplayAsProjSynIndentExam '' "$arg unstable"
arg_problem=true
useropt_help_basic=false;;install|rebuild)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg all"
arg_problem=true
useropt_help_basic=false;;list)
DisplayAsProjSynExam "please provide a valid source to '$arg' like" "$arg installable"
DisplayAsProjSynIndentExam '' "$arg new"
arg_problem=true
useropt_help_basic=false;;show)
DisplayAsProjSynExam "please provide a valid source after '$arg' like" "$arg abs"
DisplayAsProjSynIndentExam '' "$arg log"
DisplayAsProjSynIndentExam '' "$arg packages"
DisplayAsProjSynIndentExam '' "$arg results"
arg_problem=true
useropt_help_basic=false;;upgrade)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg new"
arg_problem=true
useropt_help_basic=false;;*)arg_problem=true
a_args_remaining+=("$arg")
esac;done>"$r_report_output_pathfile"
if(( ${#a_args_remaining[@]}>0 ));then ShowAsError "incomplete argument$(Pluralise "${#a_args_remaining[@]}") '${a_args_remaining[*]}'. Please check the arguments again"
arg_problem=true
a_args_remaining=();fi;fi
if(( ${#a_args[@]}>0 ));then run_package_actions=false
for arg in ${a_args[@]+"${a_args[@]}"};do case $arg in active|all|@(dis|en)abled|started)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "deactivate $arg"
arg_problem=true
useropt_help_basic=false;;all-activate|activate-all)
DisplayAsProjSynExam 'to activate all QPKGs, use' 'activate all'
arg_problem=true
useropt_help_basic=false;;all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed QPKG configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false;;all-deactivate|deactivate-all)
DisplayAsProjSynExam 'to deactivate all QPKGs, use' 'deactivate all'
arg_problem=true
useropt_help_basic=false;;all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all QPKGs, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false;;all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed QPKG configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false;;all-stop|stop-all)
DisplayAsProjSynExam 'to stop all QPKGs, use' 'stop all'
arg_problem=true
useropt_help_basic=false;;all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all QPKGs, use' 'uninstall all'
arg_problem=true
useropt_help_basic=false;;all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all QPKGs, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false;;check)
DisplayAsProjSynExam "'check' has been replaced by 'fix', so please use" fix
arg_problem=true
useropt_help_basic=false;;@(dis|en)able|false|off|no|on|true|yes)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "terse $arg"
arg_problem=true
useropt_help_basic=false;;download)
ShowAsError "'$arg' is not a manual action"
arg_problem=true
useropt_help_basic=false;;@(in|not-)active|?(in)dependent?(s)|stopped)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "activate $arg"
arg_problem=true
useropt_help_basic=false;;?(un)stable)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "follow $arg"
arg_problem=true
useropt_help_basic=false;;*)arg_problem=true
a_args_remaining+=("$arg")
esac;done>>"$r_report_output_pathfile"
if(( ${#a_args_remaining[@]}>0 ));then ShowAsError "unidentified word$(Pluralise "${#a_args_remaining[@]}") '${a_args_remaining[*]}'. Please check the arguments again"
arg_problem=true
useropt_help_basic=false;fi;fi
[[ -s $r_report_output_pathfile ]]&&/bin/cat "$r_report_output_pathfile"
DebugArray a_args_incomplete ${a_args_incomplete[*]+"${a_args_incomplete[*]}"}
DebugArray a_args_remaining ${a_args_remaining[@]+"${a_args_remaining[@]}"}
FuncExit;}
AllocPackGroupsToAcs(){ FuncInit
PauseSpinner
ShowAsProc 'package groups'
ResumeSpinner
local action
local group
for action in "${ar_user_qpkg_actions[@]}";do for group in "${ar_qpkg_is_groups[@]}";do QPKGs.AC${action}GR${group}.IsSet||continue
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then DebugAsDone "action: '$action', group: 'GR${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process";else ShowAsWarn "unable to find any 'GR$group' QPKGs to '$(Lowercase "$action")'";fi;done;for group in "${ar_qpkg_isnt_groups[@]}";do if QPKGs.AC${action}GRNT${group}.IsSet;then QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process";else ShowAsWarn "unable to find any 'GRNT$group' QPKGs to '$(Lowercase "$action")'";fi;fi;done;done;FuncExit;}
AllocPackStatesToAcs(){ FuncInit
PauseSpinner
ShowAsProc 'conditional package states'
ResumeSpinner
local action
local check_later
local state
check_later=false
for action in "${ar_user_qpkg_actions[@]}";do for state in "${ar_qpkg_is_states[@]}";do check_later=false
[[ $state = downloaded ]]&&continue
QPKGs.AC${action}IS${state}.IsSet||continue
if [[ $state = active ]];then check_later=true
elif [[ $state = installed ]];then QPKGs-AC${action}-to:Add "$(GetQpkgsIsInstalled)"
elif [[ $state = enabled ]];then QPKGs-AC${action}-to:Add "$(GetQpkgsIsEnabled)";else QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)";fi;if QPKGs-AC${action}-to.IsAny;then DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-QPKGs later after 'status' has been determined";else ShowAsWarn "unable to find any '$state' QPKGs to '$(Lowercase "$action")'";fi;done;for state in "${ar_qpkg_isnt_states[@]}";do check_later=false
[[ $state = downloaded ]]&&continue
QPKGs.AC${action}ISNT${state}.IsSet||continue
if [[ $state = active ]];then check_later=true
elif [[ $state = installed ]];then QPKGs-AC${action}-to:Add "$(GetQpkgsNtInstalled)"
elif [[ $state = enabled ]];then QPKGs-AC${action}-to:Add "$(GetQpkgsNtEnabled)";else QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)";fi;if QPKGs-AC${action}-to.IsAny;then DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-QPKGs later after 'status' has been determined";else ShowAsWarn "unable to find any 'not $state' QPKGs to '$(Lowercase "$action")'";fi;done;done;FuncExit;}
ResetArchivedLogs(){ if [[ -n $r_log_path &&-d $r_log_path ]];then ClearPath "$r_this_package_path" "$r_log_path"
echo "$(date): log cleared">"$session_active_log_pathfile"
ShowAsDone 'persistent logs cleared';fi;return 0;}
#Quiz()
PatchEntwareService(){ local insertion_text
local match_text
local r_package_init_pathfile
insertion_text=''
match_text=''
r_package_init_pathfile=$(GetQpkgServicePathFile Entware)
local -r r_package_init_pathfile
if /bin/grep "$r_external_apps_temp_path" "$r_package_init_pathfile" &>/dev/null;then DebugInfo 'patch: "'$r_external_apps_path' shuffle" - already done';else match_text='# sym-link $QPKG_DIR to /opt'
insertion_text='external_apps_path='$r_external_apps_path' external_apps_temp_path='$r_external_apps_temp_path';/bin/rmdir "$external_apps_path" "$external_apps_temp_path" 2>/dev/null;[[ -d $external_apps_path \&\& ! -L $external_apps_path \&\& ! -d $external_apps_temp_path ]] \&\& /bin/mv "$external_apps_path" "$external_apps_temp_path"'
ShoeHornTextLine "$match_text" "$insertion_text" "$r_package_init_pathfile"
match_text='/bin/ln -sf $QPKG_DIR /opt'
insertion_text='(shopt -s dotglob;[[ -L $external_apps_path \&\& -d $external_apps_temp_path ]] \&\& { /bin/mv "$external_apps_temp_path"/* "$external_apps_path"/;/bin/rm -rf "${external_apps_temp_path:?no path specified}";})'
ShoeHornTextLine "$match_text" "$insertion_text" "$r_package_init_pathfile"
DebugAsDone 'patch: "'$r_external_apps_path' shuffle"';fi;return 0;}
ShoeHornTextLine(){ [[ -n ${1:-} ]]||return
[[ -n ${2:-} ]]||return
[[ -s ${3:-} ]]||return
local prefix
prefix='# The following line was inserted by sherpa: https://git.io/sherpa'
/bin/sed -i "s|$1|${1}\n\n${r_chars_tab}${prefix}\n${r_chars_tab}${2}\n|" "$3";}
SaveIpkList(){ $r_opkg_cmd list-installed>"$r_prev_ipk_list_pathfile"
[[ -s $r_prev_ipk_list_pathfile ]]&&DebugAsDone "saved installed IPK list to $(FormatFileName "$r_prev_ipk_list_pathfile")";} 2>/dev/null
LoadIpkList(){ local name
local separator
local version
if [[ -s $r_prev_ipk_list_pathfile ]];then DebugInfo "IPKs are being loaded from $(FormatFileName "$r_prev_ipk_list_pathfile")"
while read -r name separator version;do IPKs-ACinstall-to:Add "$(Lowercase "$name")";done<"$r_prev_ipk_list_pathfile";fi;}
CalcIpkDepsToInstall(){ IsCriticalFile $r_gnu_grep_cmd||return
FuncInit;local -a a_dep_acc
local -a a_this_list
local -i iterations
local -i pre_exclude_count
local -i requested_count
local complete
local element
local ipk_titles
local pre_exclude_list
local r_iteration_limit
local req_list
complete=false
element=''
iterations=0
r_iteration_limit=20
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
local -r r_iteration_limit
a_dep_acc=($req_list)
a_this_list=($req_list)
requested_count=$(/usr/bin/wc -w<<<"$req_list")
if(( requested_count == 0 ));then DebugAsWarn 'no IPKs requested'
FuncExit 1;return;fi;IsFile "$r_external_packages_archive_pathfile"&&IsNtFile "$r_external_packages_pathfile"&&OpenIpkArchive
if IsNtFile "$r_external_packages_pathfile";then DebugAsWarn 'no external package file found'
FuncExit 1;return;fi;EndSpinner
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while(( iterations<= r_iteration_limit ));do ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#a_dep_acc[@]}" 'unique IPK'
(( iterations++ ))
printf -v ipk_titles '^Package: %s$\|' "${a_this_list[@]}"
ipk_titles=${ipk_titles%??}
a_this_list=($($r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$r_external_packages_pathfile"|$r_gnu_grep_cmd -vG '^Section:\|^Version:'|$r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator "$ipk_titles"|$r_gnu_grep_cmd -vG "$ipk_titles"|$r_gnu_grep_cmd -vG '^Package: '|/bin/sed 's/^Depends: //;s/, /\n/g'|/usr/bin/sort|/bin/uniq))
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#a_dep_acc[@]}" 'unique IPK'
if(( ${#a_this_list[@]} == 0 ));then complete=true
break;else a_dep_acc+=(${a_this_list[*]})
a_dep_acc=($(DeDupeWords "${a_dep_acc[*]}"));fi;done;Pause 0.2
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
if [[ $complete = true ]];then DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")";else DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$r_iteration_limit [$r_iteration_limit]"
show_suggest_raise_issue=true;fi;pre_exclude_list=${a_dep_acc[*]}
pre_exclude_count=$(/usr/bin/wc -w<<<"$pre_exclude_list")
if(( pre_exclude_count>0 ));then ShowAsProc 'exclude IPKs already installed'
StartSpinner
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do if [[ $element != 'ca-certs' &&$element != 'python3-gdbm' ]];then if [[ $element != 'libjpeg' ]];then if ! $r_opkg_cmd status "$element"|/bin/grep "Status:.*installed" &>/dev/null;then IPKs-ACdownload-to:Add "$element";fi;elif ! $r_opkg_cmd status 'libjpeg-turbo'|/bin/grep "Status:.*installed" &>/dev/null;then IPKs-ACdownload-to:Add 'libjpeg-turbo';fi;fi;done;EndSpinner;else DebugAsDone 'no IPKs to exclude';fi;FuncExit;}
CalcIpkDownloadSize(){ FuncInit
local -a a_sizes
local -i size_count
size_count=$(IPKs-ACdownload-to:Count)
IsFile "$r_external_packages_archive_pathfile"&&IsNtFile "$r_external_packages_pathfile"&&OpenIpkArchive
if IsNtFile "$r_external_packages_pathfile";then DebugAsWarn 'no external package file found'
FuncExit 1;return;fi;if(( size_count>0 ));then EndSpinner
ShowAsProc "calculate size of IPK$(Pluralise "$size_count") to download"
StartSpinner
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
a_sizes=($($r_gnu_grep_cmd -w '^Package:\|^Size:' "$r_external_packages_pathfile"|$r_gnu_grep_cmd --after-context 1 --no-group-separator ": $(/bin/sed 's/ /$ /g;s/\$ /\$\\\|: /g'<<<"$(IPKs-ACdownload-to:List)")"|/bin/grep '^Size:'|/bin/sed 's/^Size: //'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$(( ${a_sizes[*]} ))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download";else DebugAsDone 'no IPKs to size';fi;FuncExit;}
IPKs:upgrade(){ [[ $ipks_upgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit;local -i pid
local -i total_count
local -i z
local action
local desc
local log_pathfile
local package_name
local package_type
action=upgrade
log_pathfile=$r_log_path/ipks.$r_upgrade_log_file
package_name=auxiliary
package_type=IPK
z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($r_opkg_cmd list-upgradable|/usr/bin/cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if(( total_count>0 ));then desc="$action $total_count $package_name ${package_type}$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
UpdateDirSizeProgress_prefix=$desc
PauseSpinner
_DirSizeMonitor_ &
pid=$!
Executer "$r_opkg_cmd upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$log_pathfile" log:failure-only
z=$?
KillPID "$pid"
UpdateDirSizeProgress final
if(( z == 0 ));then NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" "$action"
DebugAsDone "$desc"
SaveActionResultMetrics ok '' "$total_count";else NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" "$action"
SaveActionResultMetrics er "$z" "$total_count";fi;[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
ResumeSpinner;fi;FuncExit $z;}
IPKs:install(){ [[ $ipks_install = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit;local -i pid
local -i total_count
local -i z
local action
local desc
local package_name
local package_type
local qpkg_name
action=install
package_name=auxiliary
package_type=IPK
z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware||([[ $useropt_fix = true ]]&&IsValidQpkgInstalled Entware);then IPKs-ACinstall-to:Add "$r_essential_ipks"
if [[ -s $r_prev_ipk_list_pathfile &&$useropt_fix = false ]];then LoadIpkList
/bin/mv -f "$r_prev_ipk_list_pathfile" "$r_prev_ipk_list_pathfile.installing";fi;fi
if QPKGs.ACinstallGRall.IsSet;then for qpkg_name in $(QPKGs-GRall:Array);do SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)";done;else
for qpkg_name in $(QPKGs-GRall:Array);do if QPKGs-ACinstall-to.Exist "$qpkg_name"||IsValidQpkgInstalled "$qpkg_name"||(QPKGs-ACreinstall-to.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name");then SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)";fi;done;fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if(( total_count>0 ))&&IsEntwareSiteUp;then desc="$action $total_count $package_name ${package_type}$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
UpdateDirSizeProgress_prefix=$desc
PauseSpinner
_DirSizeMonitor_ &
pid=$!
Executer "$r_opkg_cmd install --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$r_log_path/ipks.$r_install_log_file" log:failure-only
z=$?
KillPID "$pid"
UpdateDirSizeProgress final
if(( z == 0 ));then NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" "$action"
DebugAsDone "$desc"
SaveActionResultMetrics ok '' "$total_count"
HideKeystrokes
SetCapabilities
/bin/rm -f "$r_prev_ipk_list_pathfile.installing";else NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" "$action"
SaveActionResultMetrics er "$z" "$total_count"
if [[ -s $r_prev_ipk_list_pathfile.installing ]];then /bin/mv -f "$r_prev_ipk_list_pathfile.installing" "$r_prev_ipk_list_pathfile.install.failed";fi;fi
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
ResumeSpinner;fi;FuncExit $z;}
IPKs:downgrade(){ [[ $ipks_downgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit;local -i done_fail_count
local -i done_ok_count
local -i total_count
local -i z
local action
local curl_insecure_opt
local desc
local log_pathfile
local name
local package_name
local package_type
local remote_url
local url_prefix
local url_suffix
package_name=auxiliary
package_type=IPK
z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
IsOsCanSecureDownload||curl_insecure_opt='--insecure'
if(( total_count>0 ))&&IsEntwareSiteUp;then action=download
desc="$action $total_count $package_name ${package_type}$(Pluralise "$total_count")";done_fail_count=0;done_ok_count=0
log_pathfile=$r_log_path/ipks.$r_download_log_file
PauseSpinner
ShowAsProc "$desc"
SetQpkgArch
case $r_nas_qpkg_arch in a41)
if IsOsNonStdKernelPageSize;then url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.38-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 0 "$total_count"
(( done_ok_count++ ))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$(/usr/bin/basename "$remote_url")
Executer "/sbin/curl $curl_insecure_opt --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only;done;ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
url_prefix=''
url_suffix='';fi;esac;[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
total_count=1
action=downgrade
desc="$action $total_count $package_name ${package_type}$(Pluralise "$total_count")";done_fail_count=0;done_ok_count=0
log_pathfile=$r_log_path/ipks.$r_downgrade_log_file
PauseSpinner
ShowAsProc "$desc"
ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
Executer "$r_opkg_cmd install --force-downgrade --cache $r_ipk_cache_path --tmp-dir $r_ipk_downgrade_path $r_ipk_downgrade_path/*.ipk" "$log_pathfile" log:failure-only
z=$?
if(( z == 0 ));then (( done_ok_count++ ))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" "$action"
DebugAsDone "$desc"
SaveActionResultMetrics ok '' "$done_ok_count";else (( done_fail_count++ ))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" "$action"
SaveActionResultMetrics er "$z" "$done_fail_count";fi;ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo;fi;FuncExit $z;}
IPKs:uninstall(){ :;}
PIPs:upgrade(){ :;}
PIPs:install(){ [[ $pips_install = true ]]||return
IsQpkgEnabled Entware||return
$r_opkg_cmd status python3-pip|/bin/grep "Status:.*installed" &>/dev/null||return
IsNtError||return
FuncInit;local -i done_fail_count
local -i done_ok_count
local -i total_count
local -i z
local action
local desc
local exec_cmd
local log_pathfile
local package_name
local package_type
action=install;done_fail_count=0;done_ok_count=0
log_pathfile=$r_action_log_path/pips.$r_install_log_file
package_name=auxiliary
package_type=PIP
total_count=0
z=0
PIPs-ACinstall-to:Add "$r_base_pips"
(( total_count++ ))
if ! PIPs-ACinstall-to.IsAny;then FuncExit $z
return;fi;exec_cmd="$r_pip_cmd install --upgrade --no-input $(PIPs-ACinstall-to:List) --cache-dir $r_pip_cache_path --root-user-action=ignore"
desc="$action $total_count $package_name ${package_type}$(Pluralise "$total_count")"
EndSpinner
ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 0 "$total_count"
StartSpinner
Executer "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if(( z == 0 ));then (( done_ok_count++ ))
DebugAsDone "$desc"
SaveActionResultMetrics ok '' "$done_ok_count";else (( done_fail_count++ ))
SaveActionResultMetrics er "$z" "$done_fail_count";fi;EndSpinner
ShowAsPercentProgress "$desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
StartSpinner
FuncExit $z;}
PIPs:uninstall(){ :;}
OpenIpkArchive(){ if [[ ! -s $r_external_packages_archive_pathfile ]];then ShowAsError 'unable to locate the IPK database file'
return 1;fi;Executer "/usr/local/sbin/7z e -o$(/usr/bin/dirname "$r_external_packages_pathfile") $r_external_packages_archive_pathfile" "$r_cache_path/ipk.archive.extract" log:failure-only
if [[ ! -s $r_external_packages_pathfile ]];then ShowAsError 'unable to open the IPK database file'
return 1;fi;return 0;}
CloseIpkArchive(){ /bin/rm -f "$r_external_packages_pathfile";} 2>/dev/null
_ExecOneActionWithManyForks_(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nofun"||exit
FuncForkInit
local -a a_c
local -i pid
local a
local qpkg_name
local r_pid_pathfile
a=$1
pid=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
shift
a_c=("$@")
for qpkg_name in "${a_c[@]}";do [[ ! -e $r_abort_actions_pathfile ]]||break
while(( worker_count>= max_forks ));do [[ ! -e $r_abort_actions_pathfile ]]||break 2
Pause 0.2
UpdateActionForkProgress;done;MarkActionForkAsQueued
SetQpkgIndex
(CreateAndSetPidFile
$a &
pid=$!
DebugAsDone "${FUNCNAME[0]}() has forked '$a()' for package '$qpkg_name' with PID '$pid'"
WriteToPidFile "$pid" "$pidfile"
AppendToPidsFile "$pid" "$r_pid_pathfile")
UpdateActionForkProgress;done;while(( worker_count>0 ));do [[ ! -e $r_abort_actions_pathfile ]]||break
Pause 0.2
UpdateActionForkProgress;done;WaitForPidsThenRemove "$r_pid_pathfile"
UpdateActionForkProgress
Pause 0.2
FuncForkExit;}
_DirSizeMonitor_(){ [[ -d $dir_location ]]||exit
(( dir_bytes>0 ))||exit
local -i last_bytes
local old_debug
local old_terse
local old_verbose
current_bytes=-1
last_active_epoch=0
last_bytes=0
old_debug=$useropt_debug
old_terse=$useropt_terse
old_verbose=$useropt_verbose
useropt_debug=false
useropt_terse=true
useropt_verbose=false
while(( current_bytes<dir_bytes ));do [[ ! -e $r_abort_actions_pathfile ]]||break
Pause 0.2
UpdateDirSizeProgress
if(( current_bytes != last_bytes ));then last_active_epoch=$(ConvertNowToSeconds)
last_bytes=$current_bytes;fi;done;useropt_debug=$old_debug
useropt_terse=$old_terse
useropt_verbose=$old_verbose;}
KillPID(){ [[ -n ${1:-} ]]&&(( $1>0 ))&&[[ -d /proc/$1 ]]||return
kill -9 "$1"
wait;} &>/dev/null
Reset(){ ClearCachePath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
ClearTempLogPath
ClearTempRunPath
exit 0;}
WriteBranch(){ local a
if [[ $switch_branch = true &&-n $user_branch_value ]];then for a in unstable stable;do [[ $a != "$user_branch_value" ]]&&continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then SaveSetting Git_Branch "$useropt_branch";else SaveSetting Git_Branch "$useropt_branch" announce
Reset;fi;switch_branch=false
return;done;ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1;fi;}
WriteReportInfo(){ local a
if [[ $switch_report_info = true &&-n $user_report_info_value ]];then for a in true false;do [[ $a != "$user_report_info_value" ]]&&continue
useropt_show_report_info=$user_report_info_value
if [[ ${1:-} = silent ]];then SaveSetting ReportInfo "$useropt_show_report_info";else SaveSetting ReportInfo "$useropt_show_report_info" announce;fi;switch_report_info=false
return;done;ShowAsAbort "user setting '$user_report_info_value' is not 'true' or 'false'"
run_package_actions=false
return 1;fi;}
WriteTerse(){ local a
if [[ $switch_terse = true &&-n $user_terse_value ]];then for a in true false;do [[ $a != "$user_terse_value" ]]&&continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then SaveSetting Terse "$useropt_terse";else SaveSetting Terse "$useropt_terse" announce;fi;switch_terse=false
return;done;ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1;fi;}
SaveSetting(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_noval"||return
local a
a=$(Lowercase "$2")
case $a in true|false)
a=$(Uppercase "$a")
esac;/sbin/setcfg sherpa "$1" "$a" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]]&&ShowAsDone "user setting '$1 = $a' saved";}
LoadSetting(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_noval"||return
local a
a=$(Lowercase "$2")
if [[ ! -x /sbin/getcfg ]];then printf '%s' "$a"
return;fi;Lowercase "$(/sbin/getcfg sherpa "$1" -d "$a" -f /etc/config/qpkg.conf)";}
DeleteSetting(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
if [[ $(LoadSetting "$1" none) != none ]];then /sbin/setcfg -e sherpa "$1" -f /etc/config/qpkg.conf
[[ ${2:-} = announce ]]&&ShowAsDone "user setting '$1' deleted";fi;}
LenANSIDiff(){ local a
local b
a=${1:-}
b=$(StripANSICodes "$a")
printf '%s' "$(( ${#a} - ${#b} ))"
return 0;}
AddSeparators(){ [[ -z ${1:-} ]]&&return
local a
a=$(Trim "$1")
a=${a// /, }
a=${a//!/ }
printf '%s' "$a";}
DisplayAsProjSynExam(){ printf "\n${r_chars_bullet}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf "\n%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsProjSynIndentExam(){ if [[ -n $1	]];then printf "\n%${r_help_desc_indent}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf '\n';fi;printf "%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsSynExam(){ printf "\n${r_chars_bullet}%s:\n%${r_help_syntax_indent}s${r_help_syntax_prefix}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}";}
DisplayAsIndentItem(){ printf "%${r_help_desc_indent}s${r_chars_bullet}%s\n" '' "$(Capitalise "${1:-}")";}
DisplayAsIndentQuotedInfoItem(){ if IsOsCanAutowidthTableColumns;then printf "%${r_help_desc_indent}s%s|%s\n" '' "'${1:-}'" "${r_chars_dash}$(AddPeriod "${2:-}")";else printf "%${r_help_desc_indent}s%-$(( r_report_info_name_column_width + 2 + $(LenANSIDiff "${1:-}") ))s%s\n" '' "'${1:-}'" "${r_chars_dash}$(AddPeriod "${2:-}")";fi;}
GeneratePacksReportTitleRow(){ local -a a_headers
a_headers=('QPKG name:' 'Appl. version:' 'Description:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_qpkg_appl_version_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_qpkg_description_column_width";fi;printf '\n';}
_GeneratePacksReportDataRow_(){ local -a a_column_vars
local a
local mode
a_column_vars=(app_ver description name)
mode=''
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;name=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
app_ver=$(GetQpkgDbApplVer)
description=$(Capitalise "$(GetQpkgDbDesc "$name")")
case $app_ver in dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac;if IsQpkgMissing;then mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled;else mode=normal
/bin/touch "$r_report_flags_path"/state-installed;fi;case $mode in mute)
app_ver_msg=$(FormatReportField "$app_ver" mute)
description_msg=$(FormatReportField "$description" normal_mute)
name_msg=$(FormatReportField "$name" mute);;highlight)
name_msg=$(FormatReportField "$name" alert);;*)app_ver_msg=$(FormatReportField "$app_ver")
description_msg=$(FormatReportField "$description" normal)
name_msg=$(FormatReportField "$name")
esac;if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$2";then TextOnDarkGrey "$(printf '%s' "$name_msg|$app_ver_msg|$(FormatReportFieldWidth "$description_msg" "$r_report_qpkg_description_column_width")")";else printf '%s' "$name_msg|$app_ver_msg|$description_msg";fi;else FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$app_ver_msg" "$r_report_qpkg_appl_version_column_width"
printf ' %s' "$description_msg";fi;printf '\n';}
GenerateStatusReportTitleRow(){ local -a a_headers
local a
a=''
QPKGs-ISupgradable.IsAny&&a=" $(TextBrightWhite '(')$(TextBrightOrange new)$(TextBrightWhite ')')"
a_headers=("$(TextBrightWhite 'QPKG name:')" "$(TextBrightWhite 'Status:')" "$(TextBrightWhite 'Last action (result):')" "$(TextBrightWhite 'QPKG version')${a}$(TextBrightWhite ':')" "$(TextBrightWhite 'Appl. version:')" "$(TextBrightWhite 'Installation path:')")
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "${a_headers[*]}");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
printf '%s' "$(TextBrightWhite 'Status & Last action (result):')";fi;printf '\n';}
_GenerateStatusReportDataRow_(){ local -a a_column_vars
local a
local auxiliary_column
local mode
local req_alert
local req_attention
local req_normal_notice
local req_notice
local req_oops
local result
a_column_vars=(action app_ver auxiliary name path status ver)
auxiliary_column=status
mode=''
req_alert=false
req_attention=false
req_normal_notice=false
req_notice=false
req_oops=false
result=''
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;app_ver=$(GetQpkgDbApplVer)
name=$qpkg_name
path=$(GetQpkgInstalledPath)
ver=$(GetQpkgInstalledVer)
if IsValidQpkgInstalled;then mode=normal
/bin/touch "$r_report_flags_path"/state-installed
elif IsQpkgMissing;then mode=missing
/bin/touch "$r_report_flags_path"/status-missing
elif IsQpkgInstalled;then if IsNtQpkgComplete "$name";then mode=incomplete
/bin/touch "$r_report_flags_path"/status-incomplete
elif IsNtQpkgAuthorOk;then mode=author
/bin/touch "$r_report_flags_path"/status-wrongauthor;fi;else mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled;fi;case $app_ver in dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac;case $mode in missing|mute|normal)
if IsQpkgDbSherpaCompatible;then action=$(GetQpkgServiceAction)
/bin/touch "$r_report_flags_path"/action-$action
if [[ $action = not-found ]];then if IsOsStartingPackages&&IsQpkgEnabled;then action=$(TextBrightOrange pending)
/bin/touch "$r_report_flags_path"/action-pending;else action=$(TextDarkGrey not-found);fi;fi
result=$(GetQpkgServiceResult)
/bin/touch "$r_report_flags_path"/result-$result
case $result in aborted|failed)
action+=" ($(TextBrightRed "$result"))";;in-progress)
action+=" ($(TextBrightOrange "$result"))";;ok)
action+=" ($(TextBrightGreen "$(Uppercase "$result")"))"
esac;else action=unsupported
/bin/touch "$r_report_flags_path"/action-unsupported
action=$(TextDarkGrey "$action");fi;;*)/bin/touch "$r_report_flags_path"/na
esac;case $mode in author)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${a_column_vars[@]}";do case $a in name)
:;;auxiliary)
auxiliary_msg=$(FormatReportField 'incompatible author' attention_highlight)
req_attention=true;;*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac;done;;incomplete)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${a_column_vars[@]}";do case $a in name)
:;;auxiliary)
auxiliary_msg=$(FormatReportField 'incomplete installation' attention_highlight)
req_attention=true;;*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac;done;;missing)
for a in "${a_column_vars[@]}";do case $a in action)
local ${a}_msg="$(FormatReportField "${!a}")";;name)
:;;auxiliary)
auxiliary_msg=$(FormatReportField missing alert)
req_alert=true;;*)local ${a}_msg="$(FormatReportField "${!a}" oops)"
req_oops=true
esac;done;;mute)
path=N/A
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then auxiliary='insufficient installed RAM'
elif IsQpkgProhibited;then auxiliary='prohibited package'
elif IsQpkgConflicts;then auxiliary='conflict exists';fi;if [[ $auxiliary != false ]];then if IsOsCanAutowidthTableColumns;then auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute);else auxiliary_msg="not installable, $auxiliary";fi;else
if IsOsCanAutowidthTableColumns;then auxiliary_msg=$(FormatReportField 'not installed' normal_mute);else auxiliary_msg='not installed';fi;fi
ver=$(GetQpkgDbVer)
for a in "${a_column_vars[@]}";do case $a in name|auxiliary|status)
:;;*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac;done;;*)for a in "${a_column_vars[@]}";do case $a in name|auxiliary)
:;;status)
if IsQpkgEnabled "$qpkg_name";then status_msg+=' '$(TextBrightGreen enabled)
/bin/touch "$r_report_flags_path"/state-enabled;else status_msg+=' '$(TextBrightRed disabled)
/bin/touch "$r_report_flags_path"/state-disabled;fi;if QPKGs-ISactive.Exist "$qpkg_name";then status_msg+=' '$(TextBrightGreen active)
/bin/touch "$r_report_flags_path"/status-active
elif QPKGs-ISslow.Exist "$qpkg_name";then status_msg+=' '$(TextBrightOrange slow)
/bin/touch "$r_report_flags_path"/status-slow
elif QPKGs-ISNTactive.Exist "$qpkg_name";then status_msg+=' '$(TextBrightRed inactive)
/bin/touch "$r_report_flags_path"/status-inactive;else status_msg+=' '$(TextBrightOrange unknown)
/bin/touch "$r_report_flags_path"/status-unknown;fi;if QPKGs-ISupgradable.Exist "$qpkg_name";then status_msg+=' '$(TextBrightOrange upgradable);fi;status_msg=$(FormatReportField "$(AddSeparators "$status_msg")" normal);;*)local ${a}_msg="$(FormatReportField "${!a}")"
esac;done;esac;if QPKGs-ISupgradable.Exist "$qpkg_name";then ver_msg+=" ($(TextBrightOrange "$(GetQpkgDbVer)"))"
/bin/touch "$r_report_flags_path"/state-upgradable;fi;[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
name_msg=$(FormatReportPackageName "$name")
if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$1";then TextOnDarkGrey "$(printf '%s' "$name_msg|$status_msg|$action_msg|$ver_msg|$app_ver_msg|$(FormatReportFieldWidth "$path_msg" "$r_report_qpkg_path_column_width")")";else printf '%s' "$name_msg|$status_msg|$action_msg|$ver_msg|$app_ver_msg|$path_msg";fi;else FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
if [[ -z $auxiliary_msg ]];then printf '%s' "$(LTrim "$status_msg"), $(LTrim "$action_msg")";else printf '%s' "$(TextDarkGrey "! $status_msg, $(LTrim "$action_msg")")";fi;fi
printf '\n';}
GenerateReposReportTitleRow(){ local -a a_headers
a_headers=('QPKG name:' 'Repository:' 'Installation date:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_qpkg_repo_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_qpkg_install_date_column_width";fi;printf '\n';}
_GenerateReposReportDataRow_(){ local -a a_column_vars
local a
local auxiliary_column
local mode
local req_alert
local req_attention
local req_normal_notice
local req_notice
local req_oops
local store_id
a_column_vars=(assigned_repo auxiliary install_date name)
auxiliary_column=assigned_repo
mode=''
req_alert=false
req_attention=false
req_normal_notice=false
req_notice=false
req_oops=false
store_id=$(GetQpkgInstalledStoreID)
[[ $store_id = undefined ]]&&store_id=sherpa
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;name=$qpkg_name
if IsQpkgMissing;then mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsValidQpkgInstalled;then mode=normal
/bin/touch "$r_report_flags_path"/state-installed;else mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled;fi;if [[ $store_id = sherpa ]];then assigned_repo=sherpa
/bin/touch "$r_report_flags_path"/repo-sherpa;else assigned_repo=$(GetRepoURLFromStoreID "$store_id");fi;case $mode in highlight)
auxiliary_msg=$(FormatReportField missing alert)
install_date_msg=$(FormatReportField "$(GetQpkgInstalledDate)" oops)
req_alert=true;;mute)
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then auxiliary='insufficient installed RAM'
elif IsQpkgProhibited;then auxiliary='prohibited package';fi;if [[ $auxiliary != false ]];then if IsOsCanAutowidthTableColumns;then auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute);else auxiliary_msg="not installable, $auxiliary";fi;else
if IsOsCanAutowidthTableColumns;then auxiliary_msg=$(FormatReportField 'not installed' normal_mute);else auxiliary_msg='not installed';fi;fi
install_date_msg=$(FormatReportField N/A mute);;*)case $assigned_repo in sherpa)
assigned_repo_msg=$(FormatReportField "$assigned_repo" normal_ok);;undefined)
assigned_repo_msg=N/A
/bin/touch "$r_report_flags_path"/na;;*)assigned_repo_msg=$(FormatReportField "$assigned_repo" attention_highlight)
/bin/touch "$r_report_flags_path"/repo-other
esac;install_date_msg=$(FormatReportField "$(ConvertAsSmartDate "$(GetQpkgInstalledDate)")")
esac;[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
name_msg=$(FormatReportPackageName "$name")
if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$1";then TextOnDarkGrey "$(printf '%s' "$name_msg|$assigned_repo_msg|$(FormatReportFieldWidth "$install_date_msg" "$r_report_qpkg_install_date_column_width")")";else printf '%s' "$name_msg|$assigned_repo_msg|$install_date_msg";fi;else
if [[ -z $auxiliary_msg ]];then FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$assigned_repo_msg" "$r_report_qpkg_repo_column_width"
FormatReportFieldWidth "$install_date_msg" "$r_report_qpkg_install_date_column_width";else printf '%s %s' "$(TextDarkGrey "$name_msg")" "$(TextDarkGrey "($(LTrim "$assigned_repo_msg"))")";fi;fi
printf '\n';}
GenerateAbsReportTitleRow(){ local -a a_headers
a_headers=('QPKG name:' 'Installed?' 'Acceptable QPKG name abbreviations and aliases:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_qpkg_abbreviations_column_width";fi;printf '\n';}
_GenerateAbsReportDataRow_(){ local -a a_column_vars
local a
local auxiliary_column
local mode
local req_alert
local req_attention
local req_normal_notice
local req_notice
local req_oops
a_column_vars=(abs auxiliary installed name)
auxiliary_column=installed
mode=''
req_alert=false
req_attention=false
req_normal_notice=false
req_notice=false
req_oops=false
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;name=$qpkg_name
if IsQpkgMissing;then mode=highlight
req_alert=true
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled;else mode=normal
/bin/touch "$r_report_flags_path"/state-installed;fi;abs=$(AddSeparators "$(GetQpkgDbAbbrvs "$qpkg_name")")
case $mode in mute)
if IsQpkgProhibited;then auxiliary='prohibited package'
elif ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then auxiliary='insufficient installed RAM';fi;if [[ $auxiliary != false ]];then auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute)
abs_msg=$(FormatReportField N/A normal_mute);else abs_msg=$(FormatReportField "$abs" normal_mute);fi;installed_msg=$(FormatReportField false mute);;highlight)
abs_msg=$(FormatReportField "$abs" normal_notice)
auxiliary_msg=$(FormatReportField missing alert);;*)abs_msg=$(FormatReportField "$abs" normal)
installed_msg=$(FormatReportField true)
esac;[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
name_msg=$(FormatReportPackageName "$name")
if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$1";then TextOnDarkGrey "$(printf '%s' "$name_msg|$installed_msg|$(FormatReportFieldWidth "$abs_msg" "$r_report_qpkg_abbreviations_column_width")")";else printf '%s' "$name_msg|$installed_msg|$abs_msg";fi;else FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$abs_msg" "$r_report_qpkg_abbreviations_column_width";fi;printf '\n';}
GenerateDepsReportTitleRow(){ local -a a_headers
a_headers=('QPKG name:' 'Dependencies:' 'Optionals:' 'Prohibited?' 'Installed?' 'Enabled?' 'Complete?' 'Managed?' 'Signed?' 'Certificate issuer:' 'Certificate start datetime:' 'Certificate end datetime:' 'Cert. valid?' 'Minimum RAM:' 'Min. OS:' 'Max. OS:' 'Installed QPKG author:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth "${a_headers[3]}" "$r_report_qpkg_is_prohibited_column_width"
FormatReportFieldWidth "${a_headers[4]}" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "${a_headers[5]}" "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth "${a_headers[6]}" "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth "${a_headers[7]}" "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth "${a_headers[8]}" "$r_report_qpkg_is_signed_column_width"
FormatReportFieldWidth "${a_headers[9]}" "$r_report_qpkg_cert_issuer_column_width"
FormatReportFieldWidth "${a_headers[10]}" "$r_report_qpkg_cert_startdate_column_width"
FormatReportFieldWidth "${a_headers[11]}" "$r_report_qpkg_cert_enddate_column_width"
FormatReportFieldWidth "${a_headers[12]}" "$r_report_qpkg_cert_valid_column_width"
FormatReportFieldWidth "${a_headers[13]}" "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth "${a_headers[14]}" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "${a_headers[15]}" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "${a_headers[16]}" "$r_report_lazy_column_width";fi;printf '\n';}
_GenerateDepsReportDataRow_(){ local -a a_column_vars
local a
local auxiliary_column
local dep_name
local deps_raw
local mode
local opt_deps_raw
local req_alert
local req_attention
local req_normal_notice
local req_notice
local req_oops
a_column_vars=(author auxiliary cert_enddate cert_issuer cert_startdate cert_valid complete deps enabled installed managed max_os min_os min_ram name opt_deps prohibited signed)
auxiliary_column=deps
dep_name=''
mode=''
req_alert=false
req_attention=false
req_normal_notice=false
req_notice=false
req_oops=false
db_qpkg_cert=$(GetQpkgDbCert)
db_qpkg_cert_issuer=$(GetQpkgDbCertIssuer)
deps_raw=$(GetQpkgDbDependencies "$qpkg_name")
opt_deps_raw=$(GetQpkgDbOptDependencies "$qpkg_name")
db_qpkg_cert_enddate_epoch=$(GetQpkgDbCertEndDateEpoch)
db_qpkg_cert_startdate_epoch=$(GetQpkgDbCertStartDateEpoch)
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;name=$qpkg_name
author=$(GetQpkgAuthor)
max_os=$(GetQpkgDbMaxOSVer "$name")
min_os=$(GetQpkgDbMinOSVer "$name")
min_ram=$(GetQpkgDbMinRAM "$name")
IsQpkgRepoSelfManaged&&managed=true
IsQpkgEnabled "$name"&&enabled=true
IsQpkgComplete "$name"&&complete=true
IsQpkgSigned "$name"&&signed=true
(( db_qpkg_cert_startdate_epoch>0 ))&&cert_startdate=$(ConvertSecondsToFullDate "$db_qpkg_cert_startdate_epoch")
(( db_qpkg_cert_enddate_epoch>0 ))&&cert_enddate=$(ConvertSecondsToFullDate "$db_qpkg_cert_enddate_epoch")
IsQpkgDbCertValid&&cert_valid=true
IsQpkgProhibited "$name"&&prohibited=true
[[ -z $deps_raw ]]&&deps_raw=none
[[ -z $opt_deps_raw ]]&&opt_deps_raw=none
[[ -n $max_os &&$max_os != none ]]&&(( ${#max_os} == 3 )) &&max_os=${max_os:0:1}.${max_os:1:1}.${max_os:2:1}
[[ -n $min_os &&$min_os != none ]]&&(( ${#min_os} == 3 )) &&min_os=${min_os:0:1}.${min_os:1:1}.${min_os:2:1}
[[ $min_ram != none ]]&&min_ram=$(FormatAsThous "$min_ram")kB
/bin/touch "$r_report_flags_path"/deps
if IsQpkgMissing;then mode=missing
req_alert=true
elif IsValidQpkgInstalled;then mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then mode=author
req_attention=true
/bin/touch "$r_report_flags_path"/status-wrongauthor;else mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled;fi;case $mode in author)
for a in "${a_column_vars[@]}";do case $a in author)
author_msg=$(FormatReportField "$author" attention_highlight);;auxiliary)
auxiliary_msg=$(FormatReportField 'author incompatible' attention_highlight);;name)
:;;*)local ${a}_msg="$(FormatReportField N/A highlight)"
esac;done;;missing)
auxiliary_msg=$(FormatReportField missing alert);;mute)
deps=''
if [[ $deps_raw != none ]];then for dep_name in $deps_raw;do [[ -n $deps ]]&&deps+=' '
deps+=$dep_name;done;else
deps=$deps_raw;fi;opt_deps=''
if [[ $opt_deps_raw != none ]];then for dep_name in $opt_deps_raw;do [[ -n $opt_deps ]]&&opt_deps+=' '
opt_deps+=$dep_name;done;else
opt_deps=$opt_deps_raw;fi;/bin/touch "$r_report_flags_path"/na
author_msg=$(FormatReportField N/A mute)
cert_enddate_msg=$(FormatReportField N/A mute)
cert_issuer_msg=$(FormatReportField N/A mute)
cert_startdate_msg=$(FormatReportField N/A mute)
cert_valid_msg=$(FormatReportField N/A mute)
complete_msg=$(FormatReportField N/A mute)
deps_msg=$(FormatReportField "${deps// /, }" normal_mute)
enabled_msg=$(FormatReportField N/A mute)
installed_msg=$(FormatReportField "$installed" mute)
managed_msg=$(FormatReportField N/A mute)
opt_deps_msg=$(FormatReportField "${opt_deps// /, }" mute)
signed_msg=$(FormatReportField N/A mute)
if ! IsQpkgProhibited "$qpkg_name";then prohibited_msg=$(FormatReportField "$prohibited" mute);else prohibited_msg=$(FormatReportField "$prohibited" attention_highlight)
req_attention=true;fi;if IsQpkgDbMaxOSVerOk "$qpkg_name";then max_os_msg=$(FormatReportField "$max_os" mute);else max_os_msg=$(FormatReportField "$max_os" attention_highlight)
req_attention=true;fi;if IsQpkgDbMinOSVerOk "$qpkg_name";then if [[ $min_os != none ]];then min_os_msg=$(FormatReportField "$min_os" mute);else min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true;fi;else min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true;fi;if IsQpkgDbMinRAMOk "$qpkg_name";then min_ram_msg=$(FormatReportField "$min_ram" mute);else min_ram_msg=$(FormatReportField "$min_ram" attention_highlight)
req_attention=true;fi;;*)author_msg=$(FormatReportField "$author" ok)
deps=''
if [[ $deps_raw != none ]];then for dep_name in $deps_raw;do [[ -n $deps ]]&&deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then deps+=$(TextBrightGreen "$dep_name");else deps+=$(TextBrightRed "$dep_name")
req_oops=true;fi;done;else
deps=$deps_raw;fi;deps_msg=$(FormatReportField "${deps// /, }" normal)
opt_deps=''
if [[ $opt_deps_raw != none ]];then for dep_name in $opt_deps_raw;do [[ -n $opt_deps ]]&&opt_deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then opt_deps+=$(TextBrightGreen "$dep_name");else opt_deps+=$dep_name;fi;done;else
opt_deps=$opt_deps_raw;fi;opt_deps_msg=$(FormatReportField "${opt_deps// /, }")
if ! IsQpkgProhibited "$qpkg_name";then prohibited_msg=$(FormatReportField "$prohibited");else prohibited_msg=$(FormatReportField "$prohibited" notice)
req_oops=true;fi;if IsQpkgEnabled;then enabled_msg=$(FormatReportField "$enabled" ok);else enabled_msg=$(FormatReportField "$enabled" notice)
req_oops=true;fi;installed_msg=$(FormatReportField true ok)
if IsQpkgComplete;then complete_msg=$(FormatReportField "$complete" ok);else complete_msg=$(FormatReportField "$complete" notice)
req_oops=true;fi;if IsQpkgRepoSelfManaged;then managed_msg=$(FormatReportField "$managed" ok);else managed_msg=$(FormatReportField "$managed" highlight);fi;if IsQpkgDbMaxOSVerOk;then if [[ $max_os != none ]];then max_os_msg=$(FormatReportField "$max_os" ok);else max_os_msg=$(FormatReportField "$max_os");fi;else max_os_msg=$(FormatReportField "$max_os" alert)
req_oops=true;fi;if IsQpkgDbMinOSVerOk;then if [[ $min_os != none ]];then min_os_msg=$(FormatReportField "$min_os" ok);else min_os_msg=$(FormatReportField "$min_os");fi;else min_os_msg=$(FormatReportField "$min_os" alert)
req_oops=true;fi;if IsQpkgDbMinRAMOk;then if [[ $min_ram != none ]];then min_ram_msg=$(FormatReportField "$min_ram" ok);else min_ram_msg=$(FormatReportField "$min_ram");fi;else min_ram_msg=$(FormatReportField "$min_ram" alert)
req_oops=true;fi;if IsOsCanManageSignedPackages;then if [[ $signed = true ]];then signed_msg=$(FormatReportField "$signed" ok)
cert_issuer_msg=$(FormatReportField "$db_qpkg_cert_issuer" ok)
if(( db_qpkg_cert_startdate_epoch<$(ConvertNowToSeconds) ));then cert_startdate_msg=$(FormatReportField "$cert_startdate" ok);else cert_startdate_msg=$(FormatReportField "$cert_startdate" highlight);fi;if(( db_qpkg_cert_enddate_epoch>$(ConvertNowToSeconds) ));then cert_enddate_msg=$(FormatReportField "$cert_enddate" ok);else cert_enddate_msg=$(FormatReportField "$cert_enddate" oops);fi;if [[ $cert_valid = true ]];then cert_valid_msg=$(FormatReportField "$cert_valid" ok);else cert_valid_msg=$(FormatReportField "$cert_valid" oops);fi;else signed_msg=$(FormatReportField "$signed" alert)
cert_issuer_msg=$(FormatReportField N/A oops)
cert_startdate_msg=$(FormatReportField N/A oops)
cert_enddate_msg=$(FormatReportField N/A oops)
cert_valid_msg=$(FormatReportField "$cert_valid" oops)
req_oops=true;fi;else signed_msg=$(FormatReportField N/A ok)
cert_issuer_msg=$(FormatReportField N/A ok)
cert_startdate_msg=$(FormatReportField N/A ok)
cert_enddate_msg=$(FormatReportField N/A ok)
cert_valid_msg=$(FormatReportField N/A ok);fi;esac;[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
name_msg=$(FormatReportPackageName "$name")
if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$1";then TextOnDarkGrey "$(printf '%s' "$name_msg|$deps_msg|$opt_deps_msg|$prohibited_msg|$installed_msg|$enabled_msg|$complete_msg|$managed_msg|$signed_msg|$cert_issuer_msg|$cert_startdate_msg|$cert_enddate_msg|$cert_valid_msg|$min_ram_msg|$min_os_msg|$max_os_msg|$(FormatReportFieldWidth "$author_msg" "$r_report_qpkg_author_column_width")")";else printf '%s' "$name_msg|$deps_msg|$opt_deps_msg|$prohibited_msg|$installed_msg|$enabled_msg|$complete_msg|$managed_msg|$signed_msg|$cert_issuer_msg|$cert_startdate_msg|$cert_enddate_msg|$cert_valid_msg|$min_ram_msg|$min_os_msg|$max_os_msg|$author_msg";fi;else FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$deps_msg" "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth "$opt_deps_msg" "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth "$prohibited_msg" "$r_report_qpkg_is_prohibited_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$enabled_msg" "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth "$complete_msg" "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth "$managed_msg" "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth "$signed_msg" "$r_report_qpkg_is_signed_column_width"
FormatReportFieldWidth "$cert_issuer_msg" "$r_report_qpkg_cert_issuer_column_width"
FormatReportFieldWidth "$cert_startdate_msg" "$r_report_qpkg_cert_startdate_column_width"
FormatReportFieldWidth "$cert_enddate_msg" "$r_report_qpkg_cert_enddate_column_width"
FormatReportFieldWidth "$cert_valid_msg" "$r_report_qpkg_cert_valid_column_width"
FormatReportFieldWidth "$min_ram_msg" "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth "$min_os_msg" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "$max_os_msg" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "$author_msg" "$r_report_qpkg_author_column_width";fi;printf '\n';}
GenerateFeaturesReportTitleRow(){ local -a a_headers
a_headers=('QPKG name:' 'Independ:' 'Optional:' 'Depend:' 'Enhanced:' 'CanBack:' 'CanClean:' 'StartUpd:' 'AutoUpdate:' 'LiveTest:' 'UniqUnpack:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${a_headers[3]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${a_headers[4]}" "$r_report_qpkg_is_enhanced_column_width"
FormatReportFieldWidth "${a_headers[5]}" "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth "${a_headers[6]}" "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth "${a_headers[7]}" "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth "${a_headers[8]}" "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth "${a_headers[9]}" "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth "${a_headers[10]}" "$r_report_lazy_column_width";fi;printf '\n';}
_GenerateFeaturesReportDataRow_(){ local -a a_column_vars
local a
local auxiliary_column
local mode
local req_alert
local req_attention
local req_normal_notice
local req_notice
local req_oops
a_column_vars=(active_test autoupdate auxiliary backup clean dependent enhanced independent name optional restart_to_update uniqueunpack)
auxiliary_column=independent
mode=''
req_alert=false
req_attention=false
req_normal_notice=false
req_notice=false
req_oops=false
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;name=$qpkg_name
if IsQpkgMissing;then mode=missing
req_alert=true
elif IsValidQpkgInstalled;then mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then mode=author
req_attention=true;else mode=mute;fi;case $mode in author)
auxiliary='author incompatible'
auxiliary_msg=$(FormatReportField "$auxiliary" attention_highlight);;missing)
auxiliary=missing
auxiliary_msg=$(FormatReportField "$auxiliary" alert);;mute)
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
autoupdate=N/A
IsQpkgDbCanBackup&&backup=true
IsQpkgDbCanClean&&clean=true
IsQpkgDbIndependent&&independent=true
IsQpkgDbDependent&&dependent=true
IsQpkgDbOptional&&optional=true
if IsQpkgDbCanRestartToUpdate;then restart_to_update=true
elif [[ $name = sherpa ]];then restart_to_update=true;fi;IsQpkgDbSherpaCompatible&&enhanced=true
IsQpkgDbUniqueUnpack&&uniqueunpack=true
for a in "${a_column_vars[@]}";do case $a in auxiliary)
:;;*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac;done;;*)auxiliary=''
auxiliary_msg=''
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
if IsValidQpkgInstalled&&IsQpkgDbCanRestartToUpdate;then IsQpkgAutoUpdate&&autoupdate=true
elif [[ $name = sherpa ]];then autoupdate=true;else autoupdate=N/A
/bin/touch "$r_report_flags_path"/na;fi;IsQpkgDbCanBackup&&backup=true
IsQpkgDbCanClean&&clean=true
IsQpkgDbIndependent&&independent=true
IsQpkgDbDependent&&dependent=true
IsQpkgDbOptional&&optional=true
if IsQpkgDbCanRestartToUpdate;then restart_to_update=true
elif [[ $name = sherpa ]];then restart_to_update=true;fi;IsQpkgDbSherpaCompatible&&enhanced=true
IsQpkgDbUniqueUnpack&&uniqueunpack=true
for a in "${a_column_vars[@]}";do case $a in auxiliary)
:;;*)case ${!a} in true|N/A)
local ${a}_msg="$(FormatReportField "${!a}")";;*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac;esac;done;esac;[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
name_msg=$(FormatReportPackageName "$name")
if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$1";then TextOnDarkGrey "$(printf '%s' "$name_msg|$independent_msg|$optional_msg|$dependent_msg|$enhanced_msg|$backup_msg|$clean_msg|$restart_to_update_msg|$autoupdate_msg|$active_test_msg|$(FormatReportFieldWidth "$uniqueunpack_msg" "$r_report_qpkg_uniqueunpack_column_width")")";else printf '%s' "$name_msg|$independent_msg|$optional_msg|$dependent_msg|$enhanced_msg|$backup_msg|$clean_msg|$restart_to_update_msg|$autoupdate_msg|$active_test_msg|$uniqueunpack_msg";fi;else FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$independent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$optional_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$dependent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$enhanced_msg" "$r_report_qpkg_is_enhanced_column_width"
FormatReportFieldWidth "$backup_msg" "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth "$clean_msg" "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth "$restart_to_update_msg" "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth "$autoupdate_msg" "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth "$active_test_msg" "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth "$uniqueunpack_msg" "$r_report_qpkg_uniqueunpack_column_width";fi;printf '\n';}
GenerateBacksReportTitleRow(){ local -a a_headers
a_headers=('Backup file:' 'Size in bytes:' 'Backup date:')
if IsOsCanAutowidthTableColumns;then (IFS='|'
printf '%s' "$(TextBrightWhite "${a_headers[*]}")");else FormatReportFieldWidth "${a_headers[0]}" "$r_report_file_name_column_width"
FormatReportFieldWidth "${a_headers[1]}" "$r_report_file_bytes_column_width"
FormatReportFieldWidth "${a_headers[2]}" "$r_report_file_change_date_column_width";fi;printf '\n';}
_GenerateBacksReportItemLine_(){ local -a a_column_vars
local a
local mode
a_column_vars=(epoch_time file_bytes file_name)
mode=''
for a in "${a_column_vars[@]}";do local ${a}=false
local ${a}_msg='';done;epoch_time=${1:-0}
file_name=${2:-}
file_bytes=$(FormatAsThous "${3:-0}")
if(( ${epoch_time%.*}<$(/bin/date --date="${4:-'1 week ago'}" +%s) ));then mode=highlight
/bin/touch "$r_report_flags_path"/backup-file-old;else mode=normal
/bin/touch "$r_report_flags_path"/backup-file-ok;fi;case $mode in normal)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")")
file_bytes_msg=$(FormatReportField "$file_bytes")
file_name_msg=$(FormatReportField "$file_name" normal);;highlight)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")" notice)
file_bytes_msg=$(FormatReportField "$file_bytes" oops)
file_name_msg=$(FormatReportField "$file_name" notice)
esac;if IsOsCanAutowidthTableColumns;then if IsThisAnAlternateLine "$5";then TextOnDarkGrey "$(printf '%s' "$file_name_msg|$file_bytes_msg|$(FormatReportFieldWidth "$epoch_time_msg" "$r_report_qpkg_install_date_column_width")")";else printf '%s' "$file_name_msg|$file_bytes_msg|$epoch_time_msg";fi;else FormatReportFieldWidth "$file_name_msg" "$r_report_file_name_column_width"
FormatReportFieldWidth "$file_bytes_msg" "$r_report_file_bytes_column_width"
FormatReportFieldWidth "$epoch_time_msg" "$r_report_file_change_date_column_width";fi;printf '\n';}
FormatReportField(){ local a
local b
local c
a=''
b=''
c=${2:-blank}
IsOsCanAutowidthTableColumns||c=blank
case $c in alert)
a=$(TextBrightRedBlink "$r_chars_alert")
b=$(TextBrightRedBlink "${1:-}");;notice)
a=$(TextBrightRed "$r_chars_alert")
b=$(TextBrightRed "${1:-}");;normal_notice)
a=$(TextBrightRed "$r_chars_normal")
b=$(TextBrightRed "${1:-}");;oops)
a=$r_chars_blank
b=$(TextBrightRed "${1:-}");;attention_highlight)
a=$(TextBrightOrange "$r_chars_attention")
b=$(TextBrightOrange "${1:-}");;highlight)
a=$r_chars_blank
b=$(TextBrightOrange "${1:-}");;normal_ok)
a=$r_chars_normal
b=$(TextBrightGreen "${1:-}");;ok)
a=$r_chars_blank
b=$(TextBrightGreen "${1:-}");;normal_mute)
a=$(TextDarkGrey "$r_chars_normal")
b=$(TextDarkGrey "${1:-}");;alert_mute)
a=$(TextDarkGrey "$r_chars_alert")
b=$(TextDarkGrey "${1:-}");;mute)
a=$r_chars_blank
b=$(TextDarkGrey "${1:-}");;normal)
a=$r_chars_normal
b=$1;;*)a=$r_chars_blank
b=$1
esac;printf '%s' "${a}${b}";}
FormatReportFieldWidth(){ [[ -n ${1:-} &&-n ${2:-} ]]||return
(( $2>= 0 ))||return
printf "%-$(( $(LenANSIDiff "$1") + $2 + r_report_column_spacing ))s" "$1";}
DisplayAsHelpTitle(){ printf '\n%s\n' "${r_chars_bullet}$(Capitalise "${1:-}"|/bin/tr -s ' ')";}
DisplayAsHelpTitleHighlighted(){ printf '\n%s\n' "$(TextBrightOrange "${r_chars_bullet}$(Capitalise "${1:-}")")";}
DisplayAsIndentActionResultDurationReason(){ [[ -n ${1:-} &&-n ${2:-} ]]||return
local action
local duration
action=''
duration=''
case $1 in disableau)
action='disable auto-update';;enableau)
action='enable auto-update';;*)action=$1
esac;[[ -n ${3:-} ]]&&duration=$(ConvertMillisecondsToDuration "$3")
printf "%${r_report_action_result_indent}s" ''
if [[ -z ${4:-} ]];then printf '%s %s%s' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")";else printf '%s %s%s (%s)' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")" "$4";fi;printf '\n';}
EraseThisLine(){ [[ ${useropt_verbose:=false} = false ]]&&printf '\033[2K\r';}>&2
Display(){ if [[ -z ${1:-} ]];then printf '\n';else printf '%s\n' "$1";fi;}
DisplayWait(){ printf '%s' "${1:-}";}
ShowHelpActions(){ DisplayProcReport actions
{ ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these QPKGs (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'clean local repository files from these QPKGs (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these QPKGs. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these QPKGs. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all required application dependencies are installed' fix
DisplayAsProjSynIndentExam 'install these QPKGs' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'reactivate these QPKGs (this will upgrade internal applications where-supported and enabled)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these QPKGs ('install' QPKGs, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these QPKGs' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam "re\"sign\" these QPKGs (unsign QPKGs, then sign them again)" "resign $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "re-sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these QPKGs' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'update these QPKG internal applications only' "update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these QPKGs (this will force-upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all QPKGs can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia';}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpActionsAll(){ DisplayProcReport 'all actions'
{ ShowHelpBasic
DisplayAsHelpTitle "the 'all' group applies to all QPKGs. If $(ShowAsAction) is 'install all' then all available QPKGs will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all QPKGs (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all QPKGs (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all QPKGs' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all QPKGs. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on QPKG activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all QPKGs. QPKGs must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on QPKG activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (this will upgrade internal applications where-supported and enabled)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all QPKGs where backup files exist ('install' QPKGs and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all QPKGs' 'reinstall all'
DisplayAsProjSynIndentExam "re\"sign\" all QPKGs (unsign QPKGs, then sign them again)" 'resign all'
DisplayAsProjSynIndentExam '' 're-sign all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'status all'
DisplayAsProjSynIndentExam 'uninstall all QPKGs' 'uninstall all'
DisplayAsProjSynIndentExam 'update all QPKG internal applications only' 'update all'
DisplayAsProjSynIndentExam 'upgrade all QPKGs (and internal applications where-supported)' 'upgrade all';}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpBackupLocation(){ DisplayAsSynExam 'the backup location can be accessed by running' "cd $r_qpkg_bu_path"
return 0;}
ShowHelpBasic(){ DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0;}
ShowHelpBasicExamples(){ {
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show QPKGs'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')";}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpGroups(){ DisplayProcReport groups
{ ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only active QPKGs' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only disabled QPKGs' "$(ShowAsAction) disabled"
DisplayAsProjSynIndentExam 'select only enabled QPKGs' "$(ShowAsAction) enabled"
DisplayAsProjSynIndentExam 'select only inactive QPKGs' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installable QPKGs' "$(ShowAsAction) installable"
DisplayAsProjSynIndentExam 'select only installed QPKGs' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing QPKGs (these are partly-installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)";}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpIssue(){ DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://community.qnap.com/t/qpkg-sherpa-a-mini-package-manager-cli/1081')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log;Display;return 0;}
ShowHelpLists(){ DisplayProcReport lists
{ ShowHelpBasic
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available QPKGs' 'list all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed QPKGs' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only QPKGs that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam '' new
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
DisplayAsProjSynIndentExam '' versions;}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpShow(){ DisplayProcReport show
{ ShowHelpBasic
DisplayAsHelpTitle "'show' usage examples:"
DisplayAsProjSynIndentExam 'show QPKG abbreviations' 'show abbreviations'
DisplayAsProjSynIndentExam '' 'show abs'
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'show QPKG dependency report' 'show dependencies'
DisplayAsProjSynIndentExam '' 'show deps'
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'show QPKG repository assignments report' 'show repositories'
DisplayAsProjSynIndentExam '' 'show repos'
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show last session action results' 'show results'
DisplayAsProjSynIndentExam '' results;}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpOptions(){ DisplayProcReport options
{ ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v";}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpPackages(){ DisplayProcReport packages
{ ShowHelpBasic
DisplayAsHelpTitle 'usage examples for QPKGs will go here.';}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpProblems(){ DisplayProcReport problems
{ ShowHelpBasic
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'activate these QPKGs' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'clear local repository files from these QPKGs' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all required application dependencies are installed' fix
IsOsCanQpkgTimeout&&DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'find the live status of each application in these QPKGs' "status $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "s $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")";}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpUpgrades(){ DisplayProcReport upgrades
{ ShowHelpBasic
DisplayAsHelpTitle 'usage examples for upgrading your QPKGs:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable QPKGs' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'find the live application status of upgradable QPKGs' 'status upgradable'
DisplayAsProjSynIndentExam '' 's upgradable'
DisplayAsProjSynIndentExam '' 's new';}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpTips(){ DisplayProcReport tips
{ ShowHelpBasic
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) QPKGs" 'install all'
DisplayAsProjSynIndentExam "install all installable $(ShowAsTitleName) QPKGs" 'install installable'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam 'reactivate all QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive QPKGs' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
ShowHelpBackupLocation;}>"$r_report_output_pathfile"
ShowReport
return 0;}
ViewLogLast(){ ExtractPrevSessFromTail;EraseThisLine;if [[ -s $r_session_last_pathfile ]];then DisplayFileInViewport "$r_session_last_pathfile" linenumbers:on;else ShowAsError 'no last session log to display';fi;return 0;}
ViewLogTail(){ ExtractTailFromLog;EraseThisLine;if [[ -s $r_session_tail_pathfile ]];then DisplayFileInViewport "$r_session_tail_pathfile" linenumbers:on;else ShowAsError 'no session log tail to display';fi;return 0;}
DisplayFileInViewport(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nopfi"||return
/bin/sed -i "$r_regex_delete_firstlast_empty_lines" "$1"
[[ -s $1 ]]||return
local -a a_b
local arg
local headers
local linenumbers
local linewrap
local options
local r_prompt
local report_pathfile
local scrolltoend
report_pathfile=$1
shift
a_b=("${@:-}")
headers=false
linenumbers=false
linewrap=false
options=''
r_prompt=' File viewer\: use arrow-keys to scroll up-down & left-right, press Q to quit '
scrolltoend=false
local -r r_prompt
for arg in "${a_b[@]}";do [[ $arg = headers:on ]]&&headers=true
[[ $arg = linenumbers:on ]]&&linenumbers=true
[[ $arg = linewrap:on ]]&&linewrap=true
[[ $arg = scrollto:end ]]&&scrolltoend=true;done;echo
if [[ $useropt_verbose = false &&-x $r_less_cmd ]];then options+=' --tilde'
options+=' --mouse'
options+=' --RAW-CONTROL-CHARS'
options+=' --shift=4'
options+=' --quit-if-one-screen'
options+=' --quit-on-intr'
options+=' --redraw-on-quit'
if IsReportLargerThanViewport "$report_pathfile";then IsLessSupportHeaders&&[[ $headers = true ]]&&options+=' --header=1,'$(CalcReportFirstColumnWidth "$report_pathfile")
[[ $linewrap = false ]]&&options+=' --chop-long-lines'
[[ $scrolltoend = true ]]&&options+=' +G';fi;[[ $linenumbers = true ]]&&options+=' --LINE-NUMBERS'
LESSSECURE=1 $r_less_cmd $options --prompt "$r_prompt" "$report_pathfile"
elif [[ $useropt_verbose = false &&-x $r_gnu_more_cmd ]];then $r_gnu_more_cmd "$report_pathfile"
elif [[ $useropt_verbose = false &&-x /bin/more ]];then /bin/more "$report_pathfile"
elif [[ -x /bin/cat ]];then [[ $linenumbers = true ]]&&options=' --number'
/bin/cat $options "$report_pathfile";else echo -e "$(<"$report_pathfile")";fi;}
CalcReportFirstColumnWidth(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nopfi"||return
[[ -s $1 ]]||return
local a
local b
local c
a=$(/bin/sed "$r_regex_strip_comments"<"$1")
a=$(/bin/sed "$r_regex_strip_tail_whitespace"<<<"$a")
a=$(/bin/sed "$r_regex_delete_empty_lines"<<<"$a")
a=$(/usr/bin/head -n1<<<"$a")
a=$(StripANSICodes "$a")
b=$(/usr/bin/cut -f2 -d:<<<"$a"):
b=$(/bin/sed "$r_regex_strip_lead_whitespace"<<<"$b")
c=${a%%$b*}
printf '%s' "${#c}";}
GetLogSessStartLine(){ local -i a
a=$(( $(/bin/grep -n 'SCRIPT:.*started:' "$r_session_tail_pathfile"|/usr/bin/tail -n${1:-1}|/usr/bin/head -n1|/usr/bin/cut -d':' -f1) - 1 ))
(( a<1 ))&&a=1
printf '%s' "$a";}
GetLogSessFinishLine(){ local -i a
a=$(( $(/bin/grep -n 'SCRIPT:.*finished:' "$r_session_tail_pathfile"|/usr/bin/tail -n${1:-1}|/usr/bin/cut -d':' -f1) + 2 ))
(( a == 2 ))&&a=3
printf '%s' "$a";}
ArchiveActiveSessLog(){ [[ -n ${session_active_log_pathfile:-} &&-s $session_active_log_pathfile ]]&&/bin/cat "$session_active_log_pathfile">>"$r_session_archive_log_pathfile";}
ArchivePriorSessLog(){ local f
for f in "$r_log_path"/session.*.active.log;do if [[ -f $f &&$f != "$session_active_log_pathfile" ]];then /bin/cat "$f">>"$r_session_archive_log_pathfile"
/bin/rm -f "$f";fi;done;} 2>/dev/null
ResetActiveSessLog(){ /bin/rm -f "$session_active_log_pathfile";} 2>/dev/null
ExtractPrevSessFromTail(){ local -i end_line
local -i old_session
local -i old_session_limit
local -i start_line
old_session=1
old_session_limit=12
ExtractTailFromLog
if [[ -s $r_session_tail_pathfile ]];then end_line=$(GetLogSessFinishLine "$old_session")
start_line=end_line+1
while(( start_line>= end_line ));do start_line=$(GetLogSessStartLine "$old_session")
(( old_session++ ))
(( old_session>old_session_limit ))&&break;done;/bin/sed "$start_line,$end_line!d" "$r_session_tail_pathfile">"$r_session_last_pathfile";else /bin/rm -f "$r_session_last_pathfile";fi;return 0;} 2>/dev/null
ExtractTailFromLog(){ if [[ -s $r_session_archive_log_pathfile ]];then /usr/bin/tail -n${r_log_tail_lines} "$r_session_archive_log_pathfile">"$r_session_tail_pathfile";else /bin/rm -f "$r_session_tail_pathfile";fi;return 0;} 2>/dev/null
InitActionForkCounters(){ MakePath "$r_action_counts_path" 'action fork counters'
proc_counts_path=$(/bin/mktemp -d "$r_action_counts_path"/"${FUNCNAME[1]}"_XXXXXX)
ConfirmVarIsDefined proc_counts_path "${proc_counts_path:-}" "$e_nopth"||return
EraseForkCountPaths
proc_done_fail_count_path=$proc_counts_path/done.fail.count
proc_done_ok_count_path=$proc_counts_path/done.ok.count
proc_queued_count_path=$proc_counts_path/queued.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_working_count_path=$proc_counts_path/working.count
MakePath "$proc_done_fail_count_path" 'forks completed failed count'
MakePath "$proc_done_ok_count_path" 'forks completed OK count'
MakePath "$proc_queued_count_path" 'forks queued count'
MakePath "$proc_skip_abort_count_path" 'forks skipped-aborted count'
MakePath "$proc_skip_error_count_path" 'forks skipped-error count'
MakePath "$proc_skip_ok_count_path" 'forks skipped-ok count'
MakePath "$proc_working_count_path" 'forks working count'
InitProgress;}
IncrementActionForkIndex(){ local a
(( fork_index++ ))
printf -v a '%02d' "$fork_index"
proc_done_fail_pathfile=$proc_done_fail_count_path/$a
proc_done_ok_pathfile=$proc_done_ok_count_path/$a
proc_queued_pathfile=$proc_queued_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_working_pathfile=$proc_working_count_path/$a;}
RefreshActionForkCounts(){ done_fail_count=$(FileCountAll "$proc_done_fail_count_path");done_ok_count=$(FileCountAll "$proc_done_ok_count_path")
queued_count=$(FileCountAll "$proc_queued_count_path")
skip_abort_count=$(FileCountAll "$proc_skip_abort_count_path")
skip_error_count=$(FileCountAll "$proc_skip_error_count_path")
skip_ok_count=$(FileCountAll "$proc_skip_ok_count_path")
working_count=$(FileCountAll "$proc_working_count_path")
skipper_count=$(( skip_ok_count + skip_error_count + skip_abort_count ))
worker_count=$(( queued_count + working_count ));} &>/dev/null
RefreshDirSizeCount(){ [[ -d $dir_location ]]||exit
IsCriticalFile $r_gnu_find_cmd||exit
current_bytes=$($r_gnu_find_cmd "$dir_location" -type f -name '*.ipk' -exec /usr/bin/du --bytes --total --apparent-size {} + 2>/dev/null|/bin/grep total$|/usr/bin/cut -f1)
[[ -z $current_bytes ]]&&current_bytes=0;} &>/dev/null
EraseForkCountPaths(){ ClearPath "$r_action_counts_path" "$proc_counts_path"
/bin/rmdir "$proc_counts_path"
[[ -e $r_abort_actions_pathfile ]]&&/bin/rm -f "$r_abort_actions_pathfile";} &>/dev/null
InitProgress(){ fork_index=0
RefreshActionForkCounts;}
UpdateActionForkProgress(){ local a
RefreshActionForkCounts
[[ $useropt_verbose = false &&! -e $r_inhibit_display_pathfile ]]||return
a=$(PercFrac "$done_ok_count" "$skipper_count" "$done_fail_count" "$total_count")
if(( done_ok_count>0 ));then [[ -n $a ]]&&a+=', '
a+=$(TextBrightGreen "$done_ok_count")' OK';fi;if(( skipper_count>0 ));then [[ -n $a ]]&&a+=', '
a+=$(TextBrightOrange "$skipper_count")' skipped';fi;if(( done_fail_count>0 ));then [[ -n $a ]]&&a+=', '
a+=$(TextBrightRed "$done_fail_count")' failed';fi;if(( worker_count>0 ));then [[ -n $a ]]&&a+=', '
a+=$(TextBrightYellow "$worker_count")' in-progress';fi;[[ -n $a ]]&&ShowAsProc "${fork_progress_prefix:-}" "$a "
return 0;}>&2
UpdateDirSizeProgress(){ (( dir_bytes>0 ))||return
local -i r_stalled_seconds_threshold
local -i stalled_seconds
local perc_msg
local progress_msg
local stalled_msg
r_stalled_seconds_threshold=4
local -r r_stalled_seconds_threshold
if [[ ${1:-} = final ]];then current_bytes=$dir_bytes;else RefreshDirSizeCount
(( ${last_active_epoch:=0} != 0 ))&&stalled_seconds=$(CalcAmountDiff "$(ConvertNowToSeconds)" "$last_active_epoch");fi;perc_msg=$((200*(current_bytes)/(dir_bytes)%2+100*(current_bytes)/(dir_bytes)))%
(( current_bytes<dir_bytes ))&&[[ $perc_msg = '100%' ]]&&perc_msg=99%
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$dir_bytes")"))"
if(( stalled_seconds>= r_stalled_seconds_threshold ));then stalled_msg=' stalled for '
if(( stalled_seconds<60 ));then stalled_msg+=$stalled_seconds' seconds';else stalled_msg+=$(ConvertSecondsToDuration "$stalled_seconds");fi;if(( stalled_seconds>= 90 ));then stalled_msg+=': cancel with CTRL+C and try again later';fi;if(( stalled_seconds>= 90 ));then stalled_msg=$(TextBrightRed "$stalled_msg")
elif(( stalled_seconds>= 45 ));then stalled_msg=$(TextBrightOrange "$stalled_msg")
elif(( stalled_seconds>= 20 ));then stalled_msg=$(TextBrightYellow "$stalled_msg");fi;progress_msg+=$stalled_msg;fi;[[ ! -e $r_inhibit_display_pathfile ]]||return
ShowAsProc "$UpdateDirSizeProgress_prefix" "$progress_msg"
return 0;}>&2
ShowQPKGsMissing(){ ! QPKGs.AClistISmissing.IsSet||return 0
! QPKGs.ACreinstallISmissing.IsSet||return 0
local a
local b
case $(QPKGs-ISmissing:Count) in 0)
return 0;;1)
a=' is'
b='it';;*)a='s are'
b='them'
esac;ShowAsNote "the $(FormatNWords "$(QPKGs-ISmissing:List)" 3 TextBrightRed) QPKG${a} missing or broken. Please reinstall $b"
return 1;}
ShowQPKGsNewVers(){ ! QPKGs.AClistISupgradable.IsSet||return 0
! QPKGs.ACupgradeISupgradable.IsSet||return 0
local a
local b
case $(QPKGs-ISupgradable:Count) in 0)
return 0;;1)
a='a '
b='version is';;*)b='versions are'
esac;ShowAsNote "${a}new QPKG $b available for $(FormatNWords "$(QPKGs-ISupgradable:List)" 3 TextBrightOrange)"
return 1;}
ConfirmEnv(){ if IsInTerminal;then r_colourful_default=true;else r_colourful_default=false;fi;readonly r_colourful_default
SetColourisation
IsOsOk||return
IsUserOk||return
IsCMDsOk||return;}
CheckEnv(){ [[ $run_package_actions = true ]]||return 0
FuncInit;ShowAsProc 'check environment'
ResumeSpinner
CheckSelfSigned
CheckIncompatibleQPKGs
CheckProblemEnabledQPKGs
CheckWebsitesUp
CheckSystemLoad
CheckOOM
CheckNews
FuncExit;}
ListQPKGsActions(){ IsDebug||return
FuncInit;local a
local b
local border_shown
border_shown=false
for a in "${ar_qpkg_actions[@]}";do for b in ok er sk se sa;do if QPKGs-AC${a}-${b}.IsAny;then if [[ $border_shown = false ]];then DebugInfoMinSepr
border_shown=true;fi;case $b in ok|sk)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac;fi;done;done;[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListIPKsActions(){ IsDebug||return
FuncInit;local a
local border_shown
border_shown=false
for a in "${ar_ipk_actions[@]}";do if IPKs-AC${a}-ok.IsAny;then if [[ $border_shown = false ]];then DebugInfoMinSepr
border_shown=true;fi;DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) ";fi;if IPKs-AC${a}-er.IsAny;then if [[ $border_shown = false ]];then DebugInfoMinSepr
border_shown=true;fi;DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) ";fi;done;[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListPIPsActions(){ IsDebug||return
FuncInit;local a
DebugInfoMinSepr
for a in "${ar_pip_actions[@]}";do PIPs-AC${a}-ok.IsAny&&DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny&&DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) ";done;DebugInfoMinSepr
FuncExit;}
ListQPKGsStates(){ IsDebug||return
FuncInit;local a
BuildExtendedQPKGsStates
DebugInfoMinSepr
for a in "${ar_qpkg_is_states[@]}" "${ar_qpkg_service_results[@]}";do [[ $a = installed ]]&&continue
if [[ $a = unknown ]];then QPKGs-IS${a}.IsAny&&DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) ";else QPKGs-IS${a}.IsAny&&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) ";fi;done;for a in "${ar_qpkg_isnt_states[@]}" "${ar_qpkg_service_results[@]}";do [[ $a = installed ]]&&continue
if [[ $a = ok ]];then QPKGs-ISNT${a}.IsAny&&DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then QPKGs-ISNT${a}.IsAny&&DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) ";else QPKGs-ISNT${a}.IsAny&&DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) ";fi;done;for a in "${ar_qpkg_transient_states[@]}";do QPKGs-IS${a}.IsAny&&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) ";done;DebugInfoMinSepr
FuncExit;}
CheckSelfSigned(){ FuncInit
if IsOsCanManageSignedPackages&&IsOsRequireSignedPackages&&IsNtQpkgSigned sherpa;then [[ $title_art_shown = true ]]&&Display
ShowAsWarn "$(ShowAsTitleName) is unsigned, and $(GetOsName) is presently configured to require all packages to be signed."
ShowAsWarn "Please either self-sign $(ShowAsTitleName) with 'sherpa resign self', or allow unsigned QPKGs in your $(GetOsName) App Center";fi;FuncExit;}
CheckIncompatibleQPKGs(){ FuncInit
local a
if [[ -n ${r_base_qpkg_conflicts_with:-} ]];then for a in "${r_base_qpkg_conflicts_with[@]}";do if IsQpkgEnabled "$a";then ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
FuncExit 1;return;fi;done;fi
FuncExit;}
CheckProblemEnabledQPKGs(){ FuncInit
local a
if [[ -n ${r_base_qpkg_warnings:-} ]];then for a in "${r_base_qpkg_warnings[@]}";do if IsQpkgEnabled "$a";then ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
FuncExit 1;return;fi;done;fi
FuncExit;}
CheckWebsitesUp(){ IsNtDebug||return 0
FuncInit;local -i n
if [[ -n ${r_websites:-} ]];then for(( n = 0;n<${#r_websites[@]};n++ ));do IsSiteUp ${r_websites[n]}||ShowAsWarn "${r_websites[n]} is down";done;fi
FuncExit;}
CheckSystemLoad(){ FuncInit
local a
if IsOsStartingPackages;then ShowAsNote "$(GetOsName) is starting QPKGs, check again in a few minutes"
elif IsOsStarting;then ShowAsNote "$(GetOsName) is still booting, check again in a few minutes"
elif IsOsStopping;then ShowAsNote "$(GetOsName) is shutting-down"
elif IsOsStoppingPackages;then ShowAsNote "$(GetOsName) is stopping QPKGs";fi;a=$(GetOsSysLoad1MinAverage)
if IsThisLoadAverageInsane "$a";then ShowAsWarn 'the NAS has an exceptionally-high system-load, recommend aborting and trying again later'
elif IsThisLoadAverageHigh "$a";then ShowAsWarn 'the NAS has an unusually-high system-load, so this may take a while'
elif IsThisLoadAverageElevated "$a";then ShowAsNote 'the NAS has an elevated system-load, so this may take longer than usual';fi;FuncExit;}
CheckOOM(){ IsNtDebug||return 0
FuncInit;if(( $(/bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg|/usr/bin/wc -l)>0 ));then ShowAsWarn "the $(TextBrightRed 'Out-Of-Memory killer') has been triggered, check for $(TextBrightRed inactive) QPKGs";fi;FuncExit;}
CheckNews(){ FuncInit
FuncExit;}
BuildExtendedQPKGsStates(){ FuncInit
if [[ ${qpkgs_states_built:=false} = true ]];then DebugAsDetect 'states are already built.'
FuncExit;return;fi;LoadDatabase
InitQPKGsStates
RefreshAndStoreQPKGsStates
LoadQPKGsStates
ShowQPKGsMissing
ShowQPKGsNewVers
FuncExit;}
InitQPKGsStates(){ LoadObjects||return
FuncInit;local a
for a in "${ar_qpkg_is_states[@]}";do [[ $a = active ]]&&continue
IsFuncExist QPKGs-IS${a}:Init&&QPKGs-IS${a}:Init;done;for a in "${ar_qpkg_isnt_states[@]}";do [[ $a = active ]]&&continue
IsFuncExist QPKGs-ISNT${a}:Init&&QPKGs-ISNT${a}:Init;done;ClearPath "$r_temp_run_path"/qpkg "$r_qpkg_states_path"
qpkgs_states_built=false
FuncExit;}
CreatePidFilePathName(){ printf '%s' "$r_async_procs_path/${FUNCNAME[1]}.pids";}
RefreshAndStoreQPKGsStates(){ FuncInit
local qpkg_name
local r_pid_pathfile
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
PauseSpinner
ShowAsProc 'basic package states'
ResumeSpinner
for qpkg_name in $(QPKGs-GRall:Array);do if IsQpkgUpgradable;then echo upgradable;else echo notupgradable
fi>>"$r_qpkg_states_path/$qpkg_name";done &
AppendToPidsFile "$!" "$r_pid_pathfile"
for qpkg_name in $(QPKGs-GRall:Array);do if IsQpkgInstallable;then echo installable;else echo notinstallable
fi>>"$r_qpkg_states_path/$qpkg_name";done &
AppendToPidsFile "$!" "$r_pid_pathfile"
for qpkg_name in $(QPKGs-GRall:Array);do if IsQpkgMissing;then echo missing;else echo notmissing
fi>>"$r_qpkg_states_path/$qpkg_name";done &
AppendToPidsFile "$!" "$r_pid_pathfile"
for qpkg_name in $(QPKGs-GRall:Array);do if IsQpkgBackupExist;then echo backedup;else echo notbackedup
fi>>"$r_qpkg_states_path/$qpkg_name";done &
AppendToPidsFile "$!" "$r_pid_pathfile"
WaitForPidsThenRemove "$r_pid_pathfile"
FuncExit;}
LoadQPKGsStates(){ FuncInit
local a
local b
local qpkg_name
PauseSpinner
ShowAsProc 'load QPKG states'
ResumeSpinner
for qpkg_name in $(QPKGs-GRall:Array);do a=$r_qpkg_service_result_path/$qpkg_name.action
b=$r_qpkg_service_result_path/$qpkg_name.result
if [[ -s $a &&-s $b ]];then case $(<"$b") in in-progress)
case $(<"$a") in start)
QPKGs-ISstarting:Add "$qpkg_name";;restart)
QPKGs-ISrestarting:Add "$qpkg_name";;stop)
QPKGs-ISstopping:Add "$qpkg_name"
esac;;ok)
QPKGs-ISok:Add "$qpkg_name";;failed)
QPKGs-ISNTok:Add "$qpkg_name"
esac;fi
a=$r_qpkg_states_path/$qpkg_name
[[ -s $a ]]||continue
for b in $(<"$a");do case $b in backedup)
QPKGs-ISbackedup:Add "$qpkg_name";;backupable)
:;;installable)
QPKGs-ISinstallable:Add "$qpkg_name";;missing)
QPKGs-ISmissing:Add "$qpkg_name"
QPKGs-ISok:Remove "$qpkg_name"
QPKGs-ISNTok:Add "$qpkg_name";;notbackedup)
QPKGs-ISNTbackedup:Add "$qpkg_name";;notbackupable)
:;;notinstallable)
QPKGs-ISNTinstallable:Add "$qpkg_name";;notmissing)
QPKGs-ISNTmissing:Add "$qpkg_name";;notupgradable)
QPKGs-ISNTupgradable:Add "$qpkg_name";;upgradable)
QPKGs-ISupgradable:Add "$qpkg_name"
esac;done;done;qpkgs_states_built=true
FuncExit;}
BuildQPKGsIsCanBackup(){ FuncInit
local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgDbCanBackup "$qpkg_name"&&QPKGs-GRcanbackup:Add "$qpkg_name";done;FuncExit;}
BuildQPKGsIsCanRestartToUpdate(){ FuncInit
local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgDbCanRestartToUpdate "$qpkg_name"&&QPKGs-GRcanrestarttoupdate:Add "$qpkg_name";done;FuncExit;}
BuildQPKGsIsCanClean(){ FuncInit
local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgDbCanClean "$qpkg_name"&&QPKGs-GRcanclean:Add "$qpkg_name";done;FuncExit;}
HelpAbbreviations(){ FuncInit
local -i m
local -i n
local a
local b
local qpkg_name
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
LoadDatabase
DisplayProcReport abbreviations
CreateReportPaths
{ ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages).";}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GenerateAbsReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do (( n++ ))
SetQpkgIndex
_GenerateAbsReportDataRow_ "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>>"$r_report_output_pathfile";fi;DisplayAsProjSynExam "example: to install $(FormatPackageName SABnzbd), $(FormatPackageName HeadPhones) and $(FormatPackageName nzbToMedia) all-at-once" 'install sab hp nzb2'>>"$r_report_output_pathfile"
ShowReport
ListQPKGsStates
FuncExit;}
ReportBackups(){ FuncInit
local -i file_bytes
local -i m
local -i n
local a
local b
local epoch_time
local file_date
local file_name
local file_time
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport backups
CreateReportPaths
printf -v a '\n%s\n' "$(GenerateBacksReportTitleRow)"
if [[ -x $r_gnu_find_cmd ]];then while read -r epoch_time file_name file_bytes;do [[ -z $epoch_time ||-z $file_name ]]&&break
(( n++ ))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than" "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done<<<"$($r_gnu_find_cmd "$r_qpkg_bu_path"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2>/dev/null|/usr/bin/sort)";else while read -r file_date file_time file_name file_bytes;do [[ -z $file_date ||-z $file_name ]]&&break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$(/usr/bin/basename "$file_name")
(( n++ ))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than" "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done<<<"$(cd "$r_qpkg_bu_path"&&/bin/ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2>/dev/null|/bin/awk '{print $6" "$7" "$8" "$5}')";fi;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile";fi;ShowReport
FuncExit;}
ReportDependencies(){ FuncInit
generate_report_headers=true
local -i m
local -i n
local a
local b
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport dependency
CreateReportPaths
IsAnsiStrippingSupported||colourful=false
printf -v a '\n%s\n' "$(GenerateDepsReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do (( n++ ))
SetQpkgIndex
_GenerateDepsReportDataRow_ "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile";fi;ShowReport
ListQPKGsStates
FuncExit;}
ReportFeatures(){ FuncInit
generate_report_headers=true
local -i m
local -i n
local a
local b
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport features
CreateReportPaths
IsAnsiStrippingSupported||colourful=false
printf -v a '\n%s\n' "$(GenerateFeaturesReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do (( n++ ))
SetQpkgIndex
_GenerateFeaturesReportDataRow_ "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportHeadingsInfo>>"$r_report_output_pathfile";fi;ShowReport
ListQPKGsStates
FuncExit;}
ReportPackages(){ FuncInit
local -i m
local -i n
local a
local b
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport package
CreateReportPaths
IsAnsiStrippingSupported||colourful=false
{ ShowHelpBasic
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once.";}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GeneratePacksReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do (( n++ ))
SetQpkgIndex
_GeneratePacksReportDataRow_ "$qpkg_name" "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile";fi;{
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs';}>>"$r_report_output_pathfile"
ShowReport
ListQPKGsStates
FuncExit;}
ReportRepos(){ FuncInit
generate_report_headers=true
local -i m
local -i n
local a
local b
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport repository
CreateReportPaths
IsAnsiStrippingSupported||colourful=false
printf -v a '\n%s\n' "$(GenerateReposReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do (( n++ ))
SetQpkgIndex
_GenerateReposReportDataRow_ "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile";fi;ShowReport
ListQPKGsStates
FuncExit;}
ReportStatuses(){ FuncInit
generate_report_headers=true
local -i m
local -i n
local a
local b
local r_pid_pathfile
n=0
r_pid_pathfile=$(CreatePidFilePathName)
local -r r_pid_pathfile
DisplayProcReport status
CreateReportPaths
IsAnsiStrippingSupported||colourful=false
for qpkg_name in $(QPKGs-GRall:Array);do QPKGs-ACstatus-dn.Exist "$qpkg_name"||continue
(( n++ ))
SetQpkgIndex
_GenerateStatusReportDataRow_ "$n">"$r_report_rows_path/$n" &
AppendToPidsFile "$!" "$r_pid_pathfile";done;printf -v a '%s\n' "$(GenerateStatusReportTitleRow)"
m=$n
WaitForPidsThenRemove "$r_pid_pathfile"
for(( n = 1;n<= m;n++ ));do b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<"$b")";done;if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile";fi;ShowReport
ListQPKGsStates
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_failed=false
FuncExit;}
ReportAllActionResults(){ local -i a
local -i b
local -i c
local -i d
local -i datetime
local -i duration
local -i e
local -i quantity
local action
local package_name
local package_type
local reason
local result
a=0
d=0
if [[ $useropt_show_previous_action_results_report = true ]];then show_action_results_failed=true
show_action_results_ok=true
show_action_results_skipped=true;fi;if [[ -s $r_action_results_pathfile ]];then DisplayProcReport results
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do if(( datetime>0&&duration>0 ));then (( a == 0 ))&&a=$datetime
b=$datetime
c=$duration
(( d++ ));fi;done<"$r_action_results_pathfile"
a=$(ConvertMillisecondsToSeconds "$a")
b=$(ConvertMillisecondsToSeconds "$b")
c=$(ConvertMillisecondsToSeconds "$c")
(( b>0 ))&&e=b+c+1
if [[ $show_action_results_ok = true ||$show_action_results_skipped = true ||$show_action_results_failed = true ||$show_action_results_zero = true ]];then {
DisplayAsHelpTitle "package action$(Pluralise "$d") started @ $(ConvertSecondsToTime "$a"), ended @ $(ConvertSecondsToTime "$e"), elapsed = $(ConvertSecondsToDuration "$(CalcAmountDiff "$a" "$e")")"
[[ $show_action_results_ok = true ]]&&ReportActionResults ok
[[ $show_action_results_skipped = true ]]&&ReportActionResults sk
[[ $show_action_results_failed = true ]]&&ReportActionResults er
[[ $show_action_results_zero = true ]]&&ShowZeroQpkgs;}>"$r_report_output_pathfile"
ShowReport;fi;else ShowAsDone 'no action results to report';fi;}
ReportActionResults(){ local -i count
local -i datetime
local -i duration
local -i quantity
local action
local package_name
local package_type
local reason
local result
count=0
if [[ -s $r_action_results_pathfile ]];then while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do if [[ $result = "${1:-}" ]]||[[ $1 = sk&&($result = se ||$result = sa) ]];then [[ $action = status &&$useropt_show_previous_action_results_report = false ]]&&continue
(( count++ ))
(( count>1 ))&&break;fi;done<"$r_action_results_pathfile"
if(( count == 1 ));then case $1 in ok)
DisplayAsHelpTitle "this package action completed $(TextBrightGreen OK):";;sk)
DisplayAsHelpTitle "this package action was $(TextBrightOrange skipped) (and why):";;er)
DisplayAsHelpTitle "this package action $(TextBrightRed failed) (and why):"
esac;elif(( count>1 ));then case $1 in ok)
DisplayAsHelpTitle "these package actions completed $(TextBrightGreen OK):";;sk)
DisplayAsHelpTitle "these package actions were $(TextBrightOrange skipped) (and why):";;er)
DisplayAsHelpTitle "these package actions $(TextBrightRed failed) (and why):"
esac;fi
if(( count>= 1 ));then while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do if [[ $result = "${1:-}" ]]||[[ $1 = sk&&($result = se ||$result = sa) ]];then [[ $action = status &&$useropt_show_previous_action_results_report = false ]]&&continue
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason" "$package_type" "$quantity";fi;done<"$r_action_results_pathfile";fi;fi
if(( count == 0 ));then case $1 in ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK).";;sk)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped).";;er)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac;fi
return 0;}
GenerateReportInfo(){ [[ $useropt_show_report_info = true ]]||return
DisplayAsHelpTitle 'report information:'
local a
a=$({
if [[ -e "$r_report_flags_path"/status-missing ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightRed missing)" 'QPKG is missing from its installation path. Please reinstall it';fi;if [[ -e "$r_report_flags_path"/req-alert ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" 'QPKG is prevented from working correctly';fi;if [[ -e "$r_report_flags_path"/state-disabled ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightRed disabled)" "QPKG won't be started at bootup. Enable it first, then start it";fi;if [[ -e "$r_report_flags_path"/status-inactive ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightRed inactive)" 'application process is dead or not-started. Try starting it';fi;if [[ -e "$r_report_flags_path"/result-aborted ]];then DisplayAsIndentQuotedInfoItem "($(TextBrightRed aborted))" 'previous action was aborted';fi;if [[ -e "$r_report_flags_path"/result-failed ]];then DisplayAsIndentQuotedInfoItem "($(TextBrightRed failed))" 'previous action failed';fi;if [[ -e "$r_report_flags_path"/backup-file-old ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" "QPKG backup file was updated more than $r_report_highlight_backups_older_than.";fi;if [[ -e "$r_report_flags_path"/state-upgradable ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange upgradable)" 'a new QPKG version is available'
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange new))" 'the new QPKG version';fi;if [[ -e "$r_report_flags_path"/status-wrongauthor ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange 'author incompatible')" "QPKG is a non-compatible, identically-named duplicate of a $(ShowAsTitleName) QPKG";fi;if [[ -e "$r_report_flags_path"/req-attention ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" "QPKG cannot be managed with $(ShowAsTitleName)";fi;if [[ -e "$r_report_flags_path"/state-notinstallable ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" 'QPKG cannot be installed';fi;if [[ -e "$r_report_flags_path"/action-pending ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange pending)" 'QPKG is waiting to run an action. Check again shortly';fi;if [[ -e "$r_report_flags_path"/status-stopping ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange stopping)" 'QPKG is stopping. Check again shortly';fi;if [[ -e "$r_report_flags_path"/status-slow ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange slow)" 'application is alive, but was slow to respond to the status request. Check again shortly';fi;if [[ -e "$r_report_flags_path"/status-starting ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange starting)" 'QPKG is starting. Check again shortly';fi;if [[ -e "$r_report_flags_path"/result-in-progress ]];then DisplayAsIndentQuotedInfoItem "($(TextBrightOrange in-progress))" 'an action is in-progress. Check again shortly';fi;if [[ -e "$r_report_flags_path"/status-unknown ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange unknown)" 'application status could not be determined';fi;if [[ -e "$r_report_flags_path"/repo-other ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '* URL')" 'another repository is managing this QPKG';fi;if [[ -e "$r_report_flags_path"/state-enabled ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightGreen enabled)" 'QPKG will be started at bootup';fi;if [[ -e "$r_report_flags_path"/status-active ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightGreen active)" 'application is alive (and responsive if a daemon)';fi;if [[ -e "$r_report_flags_path"/result-ok ]];then DisplayAsIndentQuotedInfoItem "($(TextBrightGreen OK))" 'previous action was successful';fi;if [[ -e "$r_report_flags_path"/repo-sherpa ]];then DisplayAsIndentQuotedInfoItem "$(TextBrightGreen sherpa)" "$(ShowAsTitleName) is managing this QPKG";fi;if [[ -e "$r_report_flags_path"/app-dynamic ]];then DisplayAsIndentQuotedInfoItem dynamic 'application version is the latest available';fi;if [[ -e "$r_report_flags_path"/app-static ]];then DisplayAsIndentQuotedInfoItem static 'application version auto-update is disabled or unsupported';fi;if [[ -e "$r_report_flags_path"/app-final ]];then DisplayAsIndentQuotedInfoItem final 'application version is the last available';fi;if [[ -e "$r_report_flags_path"/na ]];then DisplayAsIndentQuotedInfoItem N/A 'not applicable';fi;if [[ -e "$r_report_flags_path"/action-not-found ]];then DisplayAsIndentQuotedInfoItem "$(TextDarkGrey not-found)" 'action tracking files were not found';fi;if [[ -e "$r_report_flags_path"/action-unsupported ]];then DisplayAsIndentQuotedInfoItem "$(TextDarkGrey unsupported)" 'action tracking is unsupported by this QPKG';fi;})
if [[ -n $a ]];then if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s\n' "$a";fi;fi
if [[ -e $r_report_flags_path/deps ]];then DisplayAsHelpTitle "QPKG dependencies are automatically installed/started/stopped/restarted as-required by $(ShowAsTitleName).";fi;if(( $(FileCountSpec "$r_report_flags_path/backup-file-*")>0 ));then DisplayAsIndentItem "backups are listed oldest-first."
DisplayAsIndentItem "all $(ShowAsTitleName) backup files are stored here: $r_qpkg_bu_path";fi;DisplayAsProjSynIndentExam 'to disable this report information panel' 'report-info off';}
GenerateReportHeadingsInfo(){ [[ $useropt_show_report_info = true ]]||return
DisplayAsHelpTitle 'column headings:'
local a
a=$({
DisplayAsIndentQuotedInfoItem Independ 'is independent of other QPKGs'
DisplayAsIndentQuotedInfoItem Optional 'is an optional addon for another QPKG'
DisplayAsIndentQuotedInfoItem Depend 'is dependent on other QPKGs'
DisplayAsIndentQuotedInfoItem Enhanced "$(ShowAsTitleName) enhanced service actions are supported"
DisplayAsIndentQuotedInfoItem CanBack "application config 'backup' and 'restore' are supported"
DisplayAsIndentQuotedInfoItem CanClean "application 'clean' is supported"
DisplayAsIndentQuotedInfoItem StartUpd 'application restart-to-update is supported'
DisplayAsIndentQuotedInfoItem AutoUpdate 'application restart-to-update is enabled'
DisplayAsIndentQuotedInfoItem LiveTest "has a built-in 'status' check, and can test for daemon live status"
DisplayAsIndentQuotedInfoItem UniqUnpack "QPKG unpacks to a unique path during 'install'/'reinstall'/'upgrade'";})
[[ -n $a ]]||return
if IsOsCanAutowidthTableColumns;then printf '%s' "$a"|Tableise;else printf '%s\n' "$a";fi;}
ShowReport(){ EndSpinner;EraseThisLine;if [[ -s $r_report_output_pathfile ]];then if [[ $generate_report_headers = true ]];then DisplayFileInViewport "$r_report_output_pathfile" headers:on;else DisplayFileInViewport "$r_report_output_pathfile";fi;else ShowAsError 'report not found';fi;}
ShowVersionsList(){ EndSpinner;EraseThisLine;Display "QPKG: $(ConvertAsSmartDate "$r_this_package_ver")"
Display "manager: $(ConvertAsSmartDate "$r_script_built_epoch")"
Display "objects: $(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
Display "packages: $(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
return 0;}
ShowQPKGLists(){ [[ ${packages_loaded:=false} = true ]]||return
local a
for a in "${ar_qpkg_basic_states[@]}";do case $a in complete)
if QPKGs.AClistIS${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsIsComplete)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsNtComplete)"
ShowQPKGList AClist-to
return;fi;;enabled)
if QPKGs.AClistIS${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsIsEnabled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsNtEnabled)"
ShowQPKGList AClist-to
return;fi;;installed)
if QPKGs.AClistIS${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsIsValidInstalled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then QPKGs-AClist-to:Add "$(GetQpkgsNtInstalled)"
ShowQPKGList AClist-to
return;fi;esac;done;for a in "${ar_qpkg_extended_states[@]}";do case $a in downloaded|signed)
:;;*)if QPKGs.AClistIS${a}.IsSet;then ShowQPKGList IS${a}
return
elif QPKGs.AClistISNT${a}.IsSet;then ShowQPKGList ISNT${a}
return;fi;esac;done;for a in "${ar_qpkg_is_groups[@]}";do case $a in canbackup|canrestarttoupdate)
:;;*)if QPKGs.AClistGR${a}.IsSet;then ShowQPKGList GR${a}
return;fi;esac;done;for a in "${ar_qpkg_isnt_groups[@]}";do case $a in all|canbackup|canrestarttoupdate)
:;;*)if QPKGs.AClistGRNT${a}.IsSet;then ShowQPKGList GRNT${a}
return;fi;esac;done;}
ShowQPKGList(){ [[ -n ${1:-} ]]||return
local qpkg_name
EndSpinner;EraseThisLine;if IsFuncExist QPKGs-$1.IsAny&&QPKGs-$1.IsAny;then for qpkg_name in $(QPKGs-$1:Array);do Display "$qpkg_name";done;else
ShowAsError 'unable to find any matching QPKGs';fi;return 0;}
SendParentCommand(){ WriteToMsgPipe run "${1:-}";}
SendPackageStateChange(){ [[ -n ${1:-} ]]||return
WriteToMsgPipe change "$1" package "$qpkg_name";}
SendActionStateUpdate(){ [[ -n ${1:-} ]]||return
WriteToMsgPipe update "$1" package "$qpkg_name";}
WriteToMsgPipe(){ [[ ${action_msg_pipe_fd:=none} != none &&-e /proc/$$/fd/$action_msg_pipe_fd ]]&&echo "${1:-null}|${2:-null}|${3:-null}|${4:-null}">&$action_msg_pipe_fd
return 0;}
ReadFromMsgPipe(){ IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value<&$action_msg_pipe_fd
eval "$1='${_msg1_key:-null}' $2='${_msg1_value:-null}' $3='${_msg2_key:-null}' $4='${_msg2_value:-null}'"
return 0;}
FindNextFD(){ local -i fd
for fd in {10..100};do if [[ ! -e /proc/$$/fd/$fd ]];then printf '%s' "$fd"
return 0;fi;done;return 1;}
MarkActionForkAsQueued(){ IncrementActionForkIndex
[[ -n $proc_queued_pathfile ]]&&/bin/touch "$proc_queued_pathfile";}
MarkActionForkAsEntry(){ [[ -n ${proc_queued_pathfile:-} &&-e $proc_queued_pathfile ]]&&/bin/mv "$proc_queued_pathfile" "$proc_working_pathfile"
SendActionStateUpdate en;}
MarkActionForkAsExit(){ SendActionStateUpdate ex;}
MarkActionForkAsDoneOk(){ [[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_done_ok_pathfile ]]&&/bin/mv "$proc_working_pathfile" "$proc_done_ok_pathfile"
SendActionStateUpdate ok;}
MarkActionForkAsDoneError(){ [[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_done_fail_pathfile ]]&&/bin/mv "$proc_working_pathfile" "$proc_done_fail_pathfile"
SendActionStateUpdate er;}
MarkActionForkAsSkippedOk(){ [[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_ok_pathfile ]]&&/bin/mv "$proc_working_pathfile" "$proc_skip_ok_pathfile"
SendActionStateUpdate sk;}
MarkActionForkAsSkippedAbort(){ [[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_abort_pathfile ]]&&/bin/mv "$proc_working_pathfile" "$proc_skip_abort_pathfile"
SendActionStateUpdate sa;}
MarkActionForkAsSkippedError(){ [[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_error_pathfile ]]&&/bin/mv "$proc_working_pathfile" "$proc_skip_error_pathfile"
SendActionStateUpdate se;}
NoteIpkAcAsOk(){ IPKs-AC"$2"-to:Remove "${1:-}"
IPKs-AC"$2"-ok:Add "${1:-}"
return 0;}
NoteIpkAcAsEr(){ local a
a="failing request to $2 $(FormatPackageName "${1:-}")"
[[ -n ${3:-} ]]&&a+=' as '$3
DebugAsError "$a">&2
IPKs-AC"$2"-to:Remove "${1:-}"
IPKs-AC"$2"-er:Add "${1:-}"
return 0;}
ModPathToEntware(){ local a
local b
a=/opt/bin:/opt/sbin
if IsQpkgEnabled Entware;then ! [[ $PATH =~ $a ]]||return
b=$(/bin/sed "s|${a}:||"<<<"$PATH:")
export PATH=$a:${b%:}
DebugAsDone 'prepended Entware to $PATH';else [[ $PATH =~ $a ]]||return
b=$(/bin/sed "s|${a}:||"<<<"$PATH:")
export PATH=${b%:}
DebugAsDone 'removed Entware from $PATH';fi;DebugVar PATH
return 0;}
GetHardwareCpuName(){ local a
if a=$(GetCpuModel);then printf '%s' "$a"
elif a=$(GetCpuName);then printf '%s' "$a";else printf unknown
return 1;fi;return 0;}
GetHardwareCpuStepping(){ local a
local b
if a=$(GetCpuStepping);then printf '%s' "$a"
elif a=$(GetCpuVariant)&&b=$(GetCpuRevision);then printf 'r%sp%s' "$a" "$b";else printf unknown
return 1;fi;return 0;}
GetCpuModel(){ local a
a=$(GetValueFromFile '^model name' /proc/cpuinfo)||return 1
printf '%s' "$a"
return 0;}
GetCpuName(){ local a
a=$(GetValueFromFile '^Processor name' /proc/cpuinfo)||return 1
printf '%s' "$a"
return 0;}
GetCpuStepping(){ local a
a=$(GetValueFromFile '^stepping' /proc/cpuinfo)||return 1
printf '%s' "$(( a ))"
return 0;}
GetCpuVariant(){ local a
a=$(GetValueFromFile '^CPU variant' /proc/cpuinfo)||return 1
printf '%s' "$(( a ))"
return 0;}
GetCpuRevision(){ local a
a=$(GetValueFromFile '^CPU revision' /proc/cpuinfo)||return 1
printf '%s' "$(( a ))"
return 0;}
GetValueFromFile(){ [[ -n "${1:-}" &&-n "${2:-}" &&-e $2 ]]||return 1
local a
a=$(/bin/grep "$1" "$2" 2>/dev/null)||return 1
printf '%s' "$(GetFirstLineSecondField "$a")"
return 0;}
GetCountOfValuesFromFile(){ [[ -n "${1:-}" &&-n "${2:-}" &&-e $2 ]]||return 1
local a
a=$(/bin/grep -c "$1" "$2" 2>/dev/null)||return 1
printf '%s' "$a"
return 0;}
GetFirstLineSecondField(){ [[ -n "$1" ]]||return 1
/usr/bin/head -n1<<<"$1"|/bin/sed "$r_regex_strip_upto_colon"|/bin/tr -s ' ';}
GetHardwareCpuBenchmark(){ local -i a
local -i b
local c
a=-20
b=16
if [[ ! -x $r_gnu_dd_cmd ]];then printf "unable to measure, GNU 'dd' is unavailable"
return 1;fi;if [[ -x $r_gnu_nice_cmd ]];then c=$({ $r_gnu_nice_cmd -$a $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b|/bin/sha1sum>/dev/null;} 2>&1)
elif [[ -x /bin/renice ]];then /bin/renice $a $$ &>/dev/null
c=$({ $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b|/bin/sha1sum>/dev/null;} 2>&1)
/bin/renice 0 $$ &>/dev/null;fi;c=$(/bin/grep copied<<<"$c"|/usr/bin/cut -d, -f4)
c=${c//[[:blank:]]/}
if [[ -z $c ]];then printf 'unable to measure'
return 1;fi;printf '%s' "$c"
return 0;}
GetHardwareVolumeBenchmark(){ local -i a
local b
local c
local d
a=-20
c=10k
d=$(GetUserDefVol)/zero
if [[ -d $(/usr/bin/dirname "$d") ]];then [[ -e $d ]]&&/bin/rm -f "$d"
if [[ ! -x $r_gnu_dd_cmd ]];then printf "unable to measure, GNU 'dd' is unavailable"
return 1;fi;if [[ -x $r_gnu_nice_cmd ]];then b=$($r_gnu_nice_cmd -$a $r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$c 2>&1)
elif [[ -x /bin/renice ]];then /bin/renice $a $$ &>/dev/null
b=$($r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$c 2>&1)
/bin/renice 0 $$ &>/dev/null;fi;[[ -e $d ]]&&/bin/rm -f "$d";fi;b=$(/bin/grep copied<<<"$b"|/usr/bin/cut -d, -f4)
b=${b//[[:blank:]]/}
if [[ -z $b ]];then printf 'unable to measure'
return 1;fi;printf '%s' "$b"
return 0;}
GetNasArch(){ /bin/uname -m;}
GetCpuDataWidth(){ local a
case $r_nas_arch in x86_64|aarch64)
a=64b;;i686|x86)
a=32b;;armv7l)
case $r_nas_platform in ARM_AL|ARM_MS)
a=32b;;*)a=unknown
esac;;armv5tel)
a=16b/32b;;*)a=unknown
esac;printf '%s (%s)' "$r_nas_arch" "$a";}
GetOsKernelName(){ /bin/uname -o ||{ [[ -x $r_gnu_uname_cmd ]]&&$r_gnu_uname_cmd -o;}||/bin/uname;} 2>/dev/null
GetOsKernelVersion(){ /bin/uname -r;}
GetOsKernelPageSize(){ local a
local -i b
if [[ -x /sbin/hal_app ]];then a=$(/sbin/hal_app --get_pagesize)
[[ -n $a ]]||return
b=$(( a / ( 2 ** 10 ) ))
printf '%skiB' "$b";else /bin/grep KernelPageSize /proc/1/smaps|/usr/bin/head -n1|/usr/bin/cut -f2 -d':'|/bin/tr -d ' '|/bin/sed "$r_regex_fix_kib";fi;}
GetHardwarePlatform(){ /sbin/getcfg '' Platform -d undefined -f /etc/platform.conf;}
GetUserDefVol(){ /sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info;}
GetRepoURLFromStoreID(){ [[ -n ${1:-} ]]||return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf;}
GetOsUptime(){ local a
a=$(</proc/uptime)
ConvertSecondsToDuration "${a%%.*}";}
GetUserLIBC(){ local a
a=$(/sbin/ldd --version|/usr/bin/head -n1)
printf '%s' "${a:4}";}
GetUserLIBCCopyright(){ /sbin/ldd --version|/bin/grep -i copyright|/bin/sed 's/\$//';}
GetBusyBoxVersion(){ /bin/busybox|/usr/bin/head -n1;}
GetBusyBoxCopyright(){ /bin/busybox|/usr/bin/head -n2|/usr/bin/tail -n1;}
GetBusyBoxFunctionCount(){ local -i a
a=$(/bin/busybox --list 2>/dev/null|/usr/bin/wc -l)
if [[ -n $a ]]&&IsInteger $a&&(( a>0 ));then printf '%s' "$a";else a=$(/bin/busybox)
a=${a//[!\,]/}
printf '%s' "${#a}";fi;} 2>/dev/null
GetOsSysLoad1MinAverage(){ local a
read -r a _</proc/loadavg
printf '%s' "$a";}
GetHardwareCpuThreads(){ local a
if a=$(GetCountOfValuesFromFile '^processor' /proc/cpuinfo);then printf '%d' "$a"
elif a=$(GetCountOfValuesFromFile '^Processor' /proc/cpuinfo);then printf '%d' "$a";else printf 0
return 1;fi;return 0;}
GetHardwareInstalledRAMkb(){ /bin/grep MemTotal /proc/meminfo|/bin/sed "$r_regex_process_ram";}
GetHardwareInstalledRAMgb(){ local a
local b
local c
a=$(/bin/grep MemTotal /proc/meminfo|/bin/sed "$r_regex_process_ram")
b=$(((( a / 1024 ) * 1000 ) / 1024 ))
c=${b%???}.${b:${#b}<3?0:-3}
printf '%.2f' "$c";}
GetOsFirmwareVersion(){ /sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf;}
GetOsFirmwareBuild(){ printf '%04d' "$(( 10#$(/sbin/getcfg System Number -d 0 -f /etc/config/uLinux.conf) ))";}
GetOsFirmwareDate(){ printf '%08d' "$(( 10#$(/sbin/getcfg System 'Build Number' -d 0 -f /etc/config/uLinux.conf) ))";}
GetOsFirmwareVer(){ printf '%010d' "$(( 10#$(ConvertFirmwareVersionStringToNumber "$(GetOsFirmwareVersion).$(GetOsFirmwareBuild)") ))";}
GetOsName(){ IsQuTS&&printf 'QuTS hero'||printf QTS;}
GetQpkgArch(){ if [[ $(get_display_name) = 'TS-269H' ]];then printf i53
return;fi;SetNasArch
SetOsFirmwareVer
SetHardwarePlatform
case $r_nas_arch in x86_64)
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.3.0) ))&&printf i64||printf i86;;i686|x86)
printf i86;;armv5tel)
printf a19;;armv7l)
case $r_nas_platform in ARM_MS)
printf a31;;ARM_AL)
printf a41;;*)printf unknown
esac;;aarch64)
printf a64;;*)printf unknown
esac;}
DecodeQpkgArch(){ [[ -n ${1:-} ]]||return
case $1 in a19)
printf ARMv5tel;;a31|a41)
printf ARMv7l;;a64)
printf aarch64;;i53)
printf 'Intel x86_CE53xx';;i64)
printf 'Intel x86-64';;i86)
printf 'Intel x86';;*)printf unknown
esac;}
GetQpkgEntwareType(){ if IsQpkgInstalled Entware;then if [[ -e /opt/etc/passwd ]];then if [[ -L /opt/etc/passwd ]];then printf std;else printf alt;fi;else printf none;fi;else printf not-installed;fi;} 2>/dev/null
GetUserSudoUID(){ printf '%s' "${SUDO_UID:-undefined}";}
GetOsState(){ local a
a=''
if IsOsStarting;then a=booting;fi;if IsOsStartingPackages;then [[ -n $a ]]&&a+=', '
a+='starting QPKGs';fi;if IsOsStopping;then a=shutting-down;fi;if IsOsStoppingPackages;then [[ -n $a ]]&&a+=', '
a+='stopping QPKGs';fi;[[ -z $a ]]&&a=online
printf '%s' "$a";}
GetUserGitBranch(){ /sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf;}
GetLessVersion(){ if [[ -x $r_less_cmd ]];then $r_less_cmd -V|/usr/bin/head -n1|/usr/bin/cut -d' ' -f2;else printf unknown;fi;}
ShowZeroQpkgs(){ [[ ${packages_loaded:=false} = true ]]||return
local a
local b
for a in "${ar_qpkg_is_states[@]}";do for b in "${ar_user_qpkg_actions[@]}";do [[ $b = list ]]&&continue
if QPKGs.AC${b}IS${a}.IsSet&&QPKGs-AC${b}-ok.IsNone;then ShowAsWarn "no QPKGs were able to $(Lowercase "$b")";fi;done;done;return 0;}
ClaimLockfile(){ local a
r_lock_pathfile=/var/lock/sherpa.pid
readonly r_lock_pathfile
for a in sherpa-manager.sh sherpa-manager.source;do if [[ -e $r_lock_pathfile &&-d /proc/$(<"$r_lock_pathfile") &&$(</proc/"$(<"$r_lock_pathfile")"/cmdline) =~ $a ]];then ShowAsAbort "a running $(ShowAsTitleName) instance was found (PID:$(<"$r_lock_pathfile")), please wait for it to complete"
release_lock=false
return 1;fi;done;echo "$$">"$r_lock_pathfile"
return 0;}
ReleaseLockfile(){ [[ ${release_lock:=true} = true ]]||return
[[ -n ${r_lock_pathfile:-} ]]&&/bin/rm -f "$r_lock_pathfile";}
EnableVerbose(){ useropt_verbose=true
DebugVar useropt_verbose
useropt_terse=false
ShowKeystrokes
ShowCursor;}
EnableDebugToArchiveAndFile(){ useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward;}
#DisableDebugToArchiveAndFile()
SaveActionResultMetrics(){ local r_action_times_pathfile
local r_clean_action
local r_duration
local r_qty
local r_reason
local r_result_code
local r_starttime
local r_var_name
local r_var_safe_name
r_clean_action=${action//\"/}
r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
r_qty=${3:-1}
r_reason=${2:-}
r_result_code=${1:?${FUNCNAME[0]}(): $e_nores}
r_action_times_pathfile=$r_action_times_path/$r_clean_action.milliseconds
r_var_safe_name=${r_var_name//[.-]/_};r_var_safe_name=${r_var_safe_name//:/_}
r_starttime=$(ConvertNanosecondsToMilliseconds "${!r_var_safe_name}")
r_duration=$(CalcAmountDiff "$r_starttime" "$(ConvertNowToMilliseconds)")
local -r r_action_times_pathfile
local -r r_clean_action
local -r r_duration
local -r r_qty
local -r r_reason
local -r r_result_code
local -r r_starttime
local -r r_var_name
local -r r_var_safe_name
echo "$r_starttime|$action|$r_qty|$package_name|$package_type|$r_result_code|$r_duration|$r_reason">>"$r_action_results_pathfile"
if [[ -s $r_action_times_pathfile ]]&&/bin/grep "^$package_name|"<"$r_action_times_pathfile" &>/dev/null;then /bin/sed -i "/^$package_name|/d" "$r_action_times_pathfile";fi;echo "$package_name|$r_duration">>"$r_action_times_pathfile"
case $r_result_code in ok)
DebugAsInfo "$r_reason";;sk)
DebugAsWarn "$r_reason";;er|se|sa)
DebugAsError "$r_reason"
esac;return 0;}
_QPKG:status_(){ [[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
action=status
b=''
package_name=$qpkg_name
package_type=QPKG
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_status_log_file
z=0
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit
DebugAsProcActionPackageName
a=$(GetQpkgDbActiveTest)
IsDebug&&b+='DEBUG_QPKG=true '
if [[ $a = builtin ]];then r_local_pathfile=$(GetQpkgServicePathFile)
local -r r_local_pathfile
if [[ -x $r_gnu_timeout_cmd ]];then $r_gnu_timeout_cmd "$r_qpkg_status_check_timeout_seconds" /bin/sh -c "$b \"$r_local_pathfile\" status"
z=$?;else Executer "$b \"$r_local_pathfile\" status" "$r_log_pathfile" log:failure-only
z=$?;fi;elif [[ $a != none ]];then eval "$a" &>/dev/null
z=$?;fi;DebugVar z
case $z in 0)
SendPackageStateChange ISactive;;1)
SendPackageStateChange ISNTactive;;124)
SendPackageStateChange ISslow;;*)SendPackageStateChange ISunknown
esac;SaveActionResultMetrics ok "returned: $z"
MarkActionForkAsDoneOk
FuncForkExit $z;}
_QPKG:rebuild_(){ FuncForkInit
local -i z
local action
local package_name
local package_type
action=meta-rebuild
package_name=$qpkg_name
package_type=QPKG
z=0
if IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsValidQpkgInstalled;then if IsQpkgBackupExist;then SaveActionResultMetrics sk "already installed, please use 'restore' instead";else SaveActionResultMetrics sk 'already installed & backup file unavailable';fi;MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgBackupExist&&! (QPKGs-ACbackup-to.Exist "O$qpkg_name"&&QPKGs-ACuninstall-to.Exist "O$qpkg_name");then SaveActionResultMetrics sk 'backup file unavailable'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
SaveActionResultMetrics ok
MarkActionForkAsDoneOk
FuncForkExit $z;}
_QPKG:reassign_(){ FuncForkInit
local -i z
local action
local b
local package_name
local package_type
local r_log_pathfile
action=reassign
package_name=$qpkg_name
package_type=QPKG
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reassign_log_file
z=0
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif [[ $(GetQpkgInstalledStoreID) = sherpa ||$(GetQpkgInstalledStoreID) = undefined ]];then SaveActionResultMetrics sk 'already assigned to sherpa'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
Executer "/sbin/setcfg -e $qpkg_name store -f /etc/config/qpkg.conf" "$r_log_pathfile" log:failure-only
z=$?
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:download_(){ FuncForkInit
local -i z
local action
local curl_insecure_opt
local package_name
local package_type
local r_local_filename
local r_local_pathfile
local r_log_pathfile
local r_remote_filename
local r_remote_hash
local r_remote_url
action=download
package_name=$qpkg_name
package_type=QPKG
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_download_log_file
r_remote_hash=$(GetQpkgDbHash)
r_remote_url=$(GetQpkgDbURL)
z=0
r_remote_filename=$(/usr/bin/basename "$r_remote_url")
r_local_pathfile=$r_qpkg_download_path/$r_remote_filename
r_local_filename=$(/usr/bin/basename "$r_local_pathfile")
local -r r_local_filename
local -r r_local_pathfile
local -r r_log_pathfile
local -r r_remote_filename
local -r r_remote_hash
local -r r_remote_url
if IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
IsOsCanManageSignedPackages&&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then SaveActionResultMetrics sk "incompatible $(GetOsName) version"
IsOsCanManageSignedPackages&&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinRAMOk;then SaveActionResultMetrics sk 'insufficient installed RAM'
IsOsCanManageSignedPackages&&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgConflicts&&! QPKGs-ACuninstall-to.Exist "O$qpkg_name";then SaveActionResultMetrics sk 'conflicting package installed'
IsOsCanManageSignedPackages&&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif IsFile "$r_local_pathfile";then if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then SaveActionResultMetrics sk 'already downloaded'
MarkActionForkAsSkippedOk
z=2;else DebugInfo "deleting $(FormatFileName "$r_local_filename") as checksum is incorrect"
/bin/rm -f "$r_local_pathfile" 2>/dev/null;fi;fi
(( z == 0 ))||FuncForkExit $z
if IsNtFile "$r_local_pathfile";then DebugAsProc "$action $(FormatFileName "$r_remote_filename") ..."
IsOsCanSecureDownload||curl_insecure_opt='--insecure'
/bin/rm -f "$r_log_pathfile" 2>/dev/null
Executer "/sbin/curl $curl_insecure_opt --location --output \"$r_local_pathfile\" \"$r_remote_url\"" "$r_log_pathfile" log:failure-only
z=$?
if(( z == 0 ));then if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then [[ $(Lowercase "${r_local_pathfile##*.}") = zip ]]&&/usr/bin/unzip -nq "$r_local_pathfile" -d "$r_qpkg_download_path"
SaveActionResultMetrics ok
SendPackageStateChange ISdownloaded
MarkActionForkAsDoneOk;else SaveActionResultMetrics er "cache file $(FormatFileName "$r_local_filename") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkActionForkAsDoneError
z=1;fi;else SaveActionResultMetrics er "$z"
MarkActionForkAsDoneError
z=1;fi;fi
FuncForkExit $z;}
_QPKG:install_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a='INSTALL_QPKG=true '
action=install
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgDbPathFilename)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_install_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsQpkgInstalled;then SaveActionResultMetrics sk "already installed, please use 'reinstall' instead"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then SaveActionResultMetrics sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinRAMOk;then SaveActionResultMetrics sk 'insufficient installed RAM'
MarkActionForkAsSkippedOk
z=2
elif IsQpkgConflicts;then SaveActionResultMetrics sk 'conflicting package installed'
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then SaveActionResultMetrics se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
if [[ $qpkg_name = Entware ]]&&IsNtValidQpkgInstalled Entware &&QPKGs-ACinstall-to.Exist Entware;then if [[ -d $r_external_apps_path &&! -L $r_external_apps_path &&! -e $r_external_apps_temp_path ]];then DebugAsProc "move-aside $r_external_apps_path ..."
/bin/mv "$r_external_apps_path" "$r_external_apps_temp_path"
DebugAsDone complete;fi;fi
DebugAsProcActionPackageName
IsDebug&&a+='DEBUG_QPKG=true '
[[ ${a_QPKGs_were_installed_name[*]:-} = *"$qpkg_name"* ]]&&a+="QINSTALL_PATH=$(GetQpkgInstalledOriginalPath "$qpkg_name") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if(( z == 0||z == 10 ));then SaveActionResultMetrics ok "v$(GetQpkgInstalledVer)"
if [[ $qpkg_name = Entware ]];then SendParentCommand ModPathToEntware
PatchEntwareService
if [[ -L $r_external_apps_path &&-d $r_external_apps_temp_path ]];then DebugAsProc "restore-into $r_external_apps_path ..."
(shopt -s dotglob;/bin/mv "$r_external_apps_temp_path"/* "$r_external_apps_path"/)
/bin/rm -rf "${r_external_apps_temp_path:?${FUNCNAME[0]}(): $e_nopth}"
DebugAsDone complete;fi;fi
MarkActionForkAsDoneOk
z=0;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reinstall_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a='REINSTALL_QPKG=true '
action=reinstall
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgDbPathFilename)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reinstall_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtQpkgInstalled;then SaveActionResultMetrics sk "not already installed, please use 'install' instead"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then SaveActionResultMetrics se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
IsDebug&&a+='DEBUG_QPKG=true '
IsValidQpkgInstalled&&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath)") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if(( z == 0||z == 10 ));then SaveActionResultMetrics ok "v$(GetQpkgInstalledVer)"
IsQpkgDbCanClean&&SendParentCommand "QPKGs-ACclean-to:Add $qpkg_name"
MarkActionForkAsDoneOk
z=0;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:update_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=update
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_update_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanClean;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" update" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:upgrade_(){ FuncForkInit
local -i z=0
local a
local action
local b
local current_ver
local package_name
local package_type
local prev_ver
local r_local_pathfile
local r_log_pathfile
a='UPGRADE_QPKG=true '
action=upgrade
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgDbPathFilename)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_upgrade_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif ! QPKGs-ISupgradable.Exist "$qpkg_name";then SaveActionResultMetrics sk "no new $package_type is available"
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then SaveActionResultMetrics se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
prev_ver=$(GetQpkgInstalledVer)
IsDebug&&a+='DEBUG_QPKG=true '
IsValidQpkgInstalled&&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath "$qpkg_name")") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if(( z== 0||z == 10 ));then SendPackageStateChange ISNTupgradable
SendParentCommand "QPKGs-ACupdate-to:Remove $qpkg_name"
IsQpkgDbCanClean&&SendParentCommand "QPKGs-ACclean-to:Add $qpkg_name"
current_ver=$(GetQpkgInstalledVer)
if [[ $current_ver = "$prev_ver" ]];then SaveActionResultMetrics ok "v$current_ver";else SaveActionResultMetrics ok "v$prev_ver -> v$current_ver";fi;MarkActionForkAsDoneOk
z=0;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:uninstall_(){ FuncForkInit
local -i z
local a
local action
local b
local current_ver
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a='UNINSTALL_QPKG=true '
action=uninstall
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgInstalledPath)/.uninstall.sh
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_uninstall_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then SaveActionResultMetrics sk "it's needed here! 😉"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$(FormatFileName '.uninstall.sh') undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics er "$(FormatFileName '.uninstall.sh') not found"
MarkActionForkAsDoneError
z=1;fi;(( z == 0 ))||FuncForkExit $z
[[ $qpkg_name = Entware ]]&&SaveIpkList
current_ver=$(GetQpkgInstalledVer)
DebugAsProcActionPackageName
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only
z=$?
if(( z == 0 ));then [[ -x /sbin/qpkg_cli ]]&&! QPKGs-ACinstall-to.Exist "$qpkg_name" &&/sbin/qpkg_cli --remove "$qpkg_name" &>/dev/null
SaveActionResultMetrics ok "v$current_ver"
/sbin/rmcfg "$qpkg_name" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $qpkg_name = Entware ]];then SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities;fi;SendPackageStateChange ISNTactive
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:activate_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
local timeout
a=''
action=activate
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_activate_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then SaveActionResultMetrics sk "disabled, please 'enable' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
IsOsCanQpkgTimeout&&timeout='-t '$r_qpkg_start_timeout_seconds
if IsDebug;then a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" start" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then Executer "/usr/local/sbin/qpkg_service $timeout start $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1;else Executer "\"$r_local_pathfile\" start" "$r_log_pathfile" log:failure-only
z=$?;fi;LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
if [[ $qpkg_name = Entware ]];then SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities;fi;SendPackageStateChange ISactive
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
SendPackageStateChange ISNTactive
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reactivate_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
local timeout
a=''
action=reactivate
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reactivate_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then SaveActionResultMetrics sk "disabled, please 'enable' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
IsOsCanQpkgTimeout&&timeout='-t '$r_qpkg_restart_timeout_seconds
if IsDebug;then a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" restart" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then Executer "/usr/local/sbin/qpkg_service $timeout restart $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1;else Executer "\"$r_local_pathfile\" restart" "$r_log_pathfile" log:failure-only
z=$?;fi;LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
SendParentCommand "QPKGs-ACactivate-to:Remove $qpkg_name"
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:deactivate_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
local timeout
a=''
action=deactivate
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_deactivate_log_file
z=0
local -r r_local_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
IsOsCanQpkgTimeout&&timeout='-t '$r_qpkg_stop_timeout_seconds
DebugAsProcActionPackageName
if IsDebug;then a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" stop" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then Executer "/usr/local/sbin/qpkg_service $timeout stop $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1;else Executer "\"$r_local_pathfile\" stop" "$r_log_pathfile" log:failure-only
z=$?;fi;LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
if [[ $qpkg_name = Entware ]];then SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities;fi;SendPackageStateChange ISNTactive
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:enable_(){ FuncForkInit
local -i z=0
local action
local package_name
local package_type
local r_log_pathfile
local timeout
a=''
action=enable
package_name=$qpkg_name
package_type=QPKG
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_enable_log_file
timeout=''
z=0
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgEnabled;then SaveActionResultMetrics sk 'already enabled'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
IsOsCanQpkgTimeout&&timeout='-t '$r_qpkg_enable_timeout_seconds
DebugAsProcActionPackageName
Executer "/usr/local/sbin/qpkg_service $timeout enable $qpkg_name" "$r_log_pathfile" log:failure-only
SaveActionResultMetrics ok
MarkActionForkAsDoneOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:disable_(){ FuncForkInit
local -i z
local action
local package_name
local package_type
local r_log_pathfile
local timeout
a=''
action=disable
package_name=$qpkg_name
package_type=QPKG
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_disable_log_file
timeout=''
z=0
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then SaveActionResultMetrics sk 'already disabled'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
IsOsCanQpkgTimeout&&timeout='-t '$r_qpkg_disable_timeout_seconds
DebugAsProcActionPackageName
Executer "/usr/local/sbin/qpkg_service $timeout disable $qpkg_name" "$r_log_pathfile" log:failure-only
SaveActionResultMetrics ok
MarkActionForkAsDoneOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:enableau_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=enableau
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_enableau_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanRestartToUpdate;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then SaveActionResultMetrics sk "'auto-update' is always enabled"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProc "enable auto-update $(FormatPackageName) ..."
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" enable-auto-update" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:disableau_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=disableau
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_disableau_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanRestartToUpdate;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then SaveActionResultMetrics sk "'auto-update' cannot be disabled"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProc "disable auto-update $(FormatPackageName) ..."
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" disable-auto-update" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:backup_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=backup
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_backup_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanBackup;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProc "$action $(FormatPackageName) configuration ..."
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" backup" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
SendPackageStateChange ISbackedup
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
SendParentCommand "QPKGs-ACuninstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACrestore-to:Remove $qpkg_name"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:restore_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=restore
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_restore_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then if IsQpkgBackupExist;then SaveActionResultMetrics sk "not installed, try 'rebuild' instead";else SaveActionResultMetrics sk 'not installed & backup file unavailable';fi;MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanBackup;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgBackupExist;then SaveActionResultMetrics sk 'backup file unavailable'
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProc "$action $(FormatPackageName) configuration ..."
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" restore" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk;else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
_QPKG:clean_(){ FuncForkInit
local -i z
local a
local action
local b
local package_name
local package_type
local r_local_pathfile
local r_log_pathfile
a=''
action=clean
package_name=$qpkg_name
package_type=QPKG
r_local_pathfile=$(GetQpkgServicePathFile)
r_log_pathfile=$r_action_log_path/$qpkg_name.$r_clean_log_file
z=0
local -r r_local_pathfile
local -r r_log_pathfile
if IsNtValidQpkgInstalled;then SaveActionResultMetrics sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanClean;then SaveActionResultMetrics sk "unsupported by this $package_type"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then SaveActionResultMetrics sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then SaveActionResultMetrics se "$package_type service-script file undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then SaveActionResultMetrics se "$package_type service-script file not found"
MarkActionForkAsSkippedError
z=4;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
IsDebug&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" clean" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
if(( z == 0 ));then SaveActionResultMetrics ok
MarkActionForkAsDoneOk
SendParentCommand "QPKGs-ACupdate-to:Remove $qpkg_name";else b=$(GetQpkgServiceExplanation)||b=$z
SaveActionResultMetrics er "$b"
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:sign_(){ [[ ! -e $r_abort_actions_pathfile ]]||exit
FuncForkInit
local -i retries
local -i z
local action
local package_name
local package_type
local pysqlite_command
local query
local table
action='"sign"'
package_name=$qpkg_name
package_type=QPKG
table=Certificate
z=0
if IsQpkgProhibited;then SaveActionResultMetrics sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif ! IsOsCanManageSignedPackages;then SaveActionResultMetrics sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ ! -s $r_cert_db_pathfile ]];then SaveActionResultMetrics sa "$(GetOsName) $package_type certificate database unavailable, no further signing will occur"
MarkActionForkAsSkippedAbort
z=3
elif IsQpkgSigned;then SaveActionResultMetrics sk 'already signed'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
query="INSERT INTO $table (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$package_name','$r_qpkg_certificate','$r_qpkg_signature')"
uri="file:$r_cert_db_pathfile"
read -r -d '' pysqlite_command<<EOB
import sqlite3
import sys
import ctypes
from ctypes import util
sqlite_path = ctypes.util.find_library('sqlite3')
if sqlite_path:
    sqlite3_lib = ctypes.CDLL(sqlite_path)
    sqlite3_lib.sqlite3_config(17, 1)
conn = sqlite3.connect('$uri')
cursor = conn.cursor()
try:
    cursor.execute("""$query""")
    conn.commit()
finally:
    cursor.close()
    conn.close()
    sys.exit()
EOB
for(( retries = 0;retries<10;retries++ ));do /usr/local/bin/python2 -c "$pysqlite_command"
z=$?
case $z in 5)
Pause 0.5;;*)break
esac;done;if(( z == 0 ));then SaveActionResultMetrics ok
SendPackageStateChange ISsigned
MarkActionForkAsDoneOk;else SaveActionResultMetrics er "($z) but don't know why. Please report this as a bug"
SendParentCommand 'show_suggest_raise_issue=true'
MarkActionForkAsDoneError;fi;ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:unsign_(){ [[ ! -e $r_abort_actions_pathfile ]]||exit
FuncForkInit
local -i retries
local -i z
local action
local match_column
local package_name
local package_type
local pysqlite_command
local query
local table
action='"unsign"'
match_column=QpkgName
package_name=$qpkg_name
package_type=QPKG
table=Certificate
z=0
if ! IsOsCanManageSignedPackages;then SaveActionResultMetrics sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then SaveActionResultMetrics sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ ! -s $r_cert_db_pathfile ]];then SaveActionResultMetrics sa "$(GetOsName) $package_type certificate database unavailable, no further unsigning will occur"
MarkActionForkAsSkippedAbort
z=3
elif IsNtQpkgSigned;then SaveActionResultMetrics sk 'not signed'
MarkActionForkAsSkippedOk
z=2;fi;(( z == 0 ))||FuncForkExit $z
DebugAsProcActionPackageName
query="DELETE from $table WHERE $match_column = ?"
uri="file:$r_cert_db_pathfile"
read -r -d '' pysqlite_command<<EOB
import sqlite3
import sys
import ctypes
from ctypes import util
sqlite_path = ctypes.util.find_library('sqlite3')
if sqlite_path:
    sqlite3_lib = ctypes.CDLL(sqlite_path)
    sqlite3_lib.sqlite3_config(17, 1)
conn = sqlite3.connect('$uri')
cursor = conn.cursor()
try:
    cursor.execute("""$query""", ('$package_name',))
    conn.commit()
finally:
    cursor.close()
    conn.close()
    sys.exit()
EOB
for(( retries = 0;retries<10;retries++ ));do /usr/local/bin/python2 -c "$pysqlite_command"
z=$?
case $z in 5)
Pause 0.5;;*)z=0
break
esac;done;if(( z == 0 ));then SaveActionResultMetrics ok
SendPackageStateChange ISsigned
MarkActionForkAsDoneOk;else SaveActionResultMetrics er "($z) but don't know why. Please report this as a bug"
SendParentCommand 'show_suggest_raise_issue=true'
MarkActionForkAsDoneError;fi;FuncForkExit $z;}
ClearQpkgInstalledAppCenterNotifier(){ [[ -x /sbin/qpkg_cli ]]&&/sbin/qpkg_cli --cancel "$qpkg_name"
IsValidQpkgInstalled||return
/sbin/setcfg "$qpkg_name" Status complete -f /etc/config/qpkg.conf
return 0;} &>/dev/null
LogQpkgServiceResult(){ local a
local b
a=$r_qpkg_service_result_path/$qpkg_name.log
if ! b=$(GetQpkgServiceResult);then DebugAsWarn "unable to get status of $(FormatPackageName) service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1;fi;case $b in failed)
if [[ -s $a ]];then DebugAsError "$(FormatPackageName) service action failed. Check $(FormatFileName "$a") for more information"
AddExtLogToSessLog "$a";else DebugAsError "$(FormatPackageName) service action failed";fi;;in-progress)
DebugInfo "$(FormatPackageName) service action is in-progress";;ok)
DebugInfo "$(FormatPackageName) service action completed OK";;*)DebugAsWarn "$(FormatPackageName) service status is unrecognised or unsupported"
esac;return 0;}
GetQpkgInstalledPath(){ /sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Install_Path -d undefined -f /etc/config/qpkg.conf;}
GetQpkgServicePathFile(){ /sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Shell -d undefined -f /etc/config/qpkg.conf;}
GetQpkgDbApplVer(){ local -i i
local a
a=''
if(( qpkg_index>0 ));then a=${r_qpkg_appl_version[qpkg_index]}
[[ $a = version ]]&&a=${r_qpkg_version[qpkg_index]}
[[ $a != none ]]||return;else for i in "${!r_qpkg_name[@]}";do if [[ ${r_qpkg_name[i]} = "$qpkg_name" ]];then a=${r_qpkg_appl_version[i]}
[[ $a = version ]]&&a=${r_qpkg_version[i]}
[[ $a != none ]]||return
break;fi;done;fi
[[ -n $a ]]||return
[[ $a = dynamic ]]&&IsValidQpkgInstalled &&! IsQpkgAutoUpdate &&a=static
printf '%s' "$a"
return 0;}
GetQpkgDbVer(){ local -i i
local a
a=''
a=${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}
if [[ -n $a ]];then for i in "${!r_qpkg_name[@]}";do if [[ ${r_qpkg_name[i]} = "$a" ]];then printf '%s' "${r_qpkg_version[i]}"
return 0;fi;done;fi
return 1;}
GetQpkgInstalledVer(){ /sbin/getcfg "${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}" Version -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledStoreID(){ /sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" store -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledDate(){ /sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" date -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledOriginalPath(){ local -i i
local a
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
if(( ${#a_QPKGs_were_installed_name[@]}>0 ));then for i in "${!a_QPKGs_were_installed_name[@]}";do [[ ${a_QPKGs_were_installed_name[i]} = "$a" ]]||continue
printf '%s' "${a_QPKGs_were_installed_path[i]}"
return 0;done;fi
return 1;}
GetQpkgDbPathFilename(){ local a
a=$(GetQpkgDbURL)
[[ -n $a ]]||return
[[ $(Lowercase "${a##*.}") != qpkg ]]&&a=${a%.*}.qpkg
printf '%s' "$r_qpkg_download_path/$(/usr/bin/basename "$a")"
return 0;}
GetQpkgDbHash(){ [[ -n $qpkg_name ]]&&(( qpkg_index>0 ))||return
local a
a=${r_qpkg_hash[qpkg_index]}
[[ $a != none ]]||return
printf '%s' "$a"
return 0;}
GetQpkgDbURL(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do if [[ ${r_qpkg_name[i]} = "$1" ]];then printf '%s' "${r_qpkg_url[i]}"
return 0;fi;done;return 1;else a=${r_qpkg_url[qpkg_index]}
[[ -n $a ]]||a=none
printf '%s' "$a";fi;return 0;}
GetQpkgDbMinRAM(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_min_ram_kb[i]}
break;done;else
a=${r_qpkg_min_ram_kb[qpkg_index]};fi;[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMinOSVer(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_min_os_version[i]}
break;done;else
a=${r_qpkg_min_os_version[qpkg_index]};fi;[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMaxOSVer(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_max_os_version[i]}
break;done;else
a=${r_qpkg_max_os_version[qpkg_index]};fi;[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbAuthor(){ local -i i
for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" ]]||continue
printf '%s' "${r_qpkg_author[i]}"
return 0;done;return 1;}
GetQpkgAuthor(){ /sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Author -d undefined -f /etc/config/qpkg.conf;}
GetQpkgDbDesc(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_description[i]}
break;done;else
a=${r_qpkg_description[qpkg_index]};fi;[[ -n $a ]]||a=none
printf '%s' "$a."
return 0;}
GetQpkgDbAbbrvs(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_abbrvs[i]}
break;done;else
a=${r_qpkg_abbrvs[qpkg_index]};fi;[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbDependencies(){ local alt
local first
local found
local g
local oldIFS
local out
local x
alt=''
first=''
found=false
g=${r_qpkg_depends_on[qpkg_index]}
oldIFS=$IFS
out=''
[[ $g = none ]]&&return 1
if [[ $g != *'|'* ]];then printf '%s' "$g"
return 0;fi;IFS=' '
for x in $g;do found=false
if [[ $x != *'|'* ]];then out+=' '$x
continue;fi;IFS='|'
for alt in $x;do [[ -z $first &&-n $alt ]]&&first=$alt
out+=' '$alt
found=true
break;done;[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then out+=' '$first
first='';fi;done;printf '%s' "$out"
return 0;}
GetQpkgDbOptDependencies(){ local alt
local first
local found
local g
local oldIFS
local out
local x
alt=''
first=''
found=false
g=${r_qpkg_opt_depends_on[qpkg_index]}
oldIFS=$IFS
out=''
[[ $g = none ]]&&return 1
if [[ $g != *'|'* ]];then printf '%s' "$g"
return 0;fi;IFS=' '
for x in $g;do found=false
if [[ $x != *'|'* ]];then out+=' '$x
continue;fi;IFS='|'
for alt in $x;do [[ -z $first &&-n $alt ]]&&first=$alt
out+=' '$alt
found=true
break;done;[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then out+=' '$first
first='';fi;done;printf '%s' "$out"
return 0;}
GetQpkgDbDependents(){ [[ -n $qpkg_name ]]&&(( qpkg_index>0 ))||return
local -a a_ar
local -i i
local re
re=\\b${qpkg_name}\\b
if QPKGs-GRindependent.Exist "$qpkg_name";then for i in "${!r_qpkg_name[@]}";do if [[ ${r_qpkg_depends_on[i]} =~ $re ]];then [[ ${a_ar[*]+"${a_ar[*]}"} != "${r_qpkg_name[i]}" ]]&&a_ar+=(${r_qpkg_name[i]});fi;done;fi
if [[ -n ${a_ar[*]+"${a_ar[*]}"} ]];then printf '%s' "${a_ar[*]}"
return 0;fi;return 1;}
GetQpkgDbOptionals(){ [[ -n $qpkg_name ]]&&(( qpkg_index>0 ))||return
local -a a_ar
local -i i
local re
re=\\b${qpkg_name}\\b
if QPKGs-GRoptional.Exist "$qpkg_name";then for i in "${!r_qpkg_name[@]}";do if [[ ${r_qpkg_opt_depends_on[i]} =~ $re ]];then [[ ${a_ar[*]+"${a_ar[*]}"} != "${r_qpkg_name[i]}" ]]&&a_ar+=(${r_qpkg_name[i]});fi;done;fi
if [[ -n ${a_ar[*]+"${a_ar[*]}"} ]];then printf '%s' "${a_ar[*]}"
return 0;fi;return 1;}
GetQpkgConflicts(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_conflicts_with[i]}
break;done;else
a=${r_qpkg_conflicts_with[qpkg_index]};fi;[[ -n $a ]]||a=none
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgDbIPKs(){ [[ -n $qpkg_name ]]&&(( qpkg_index>0 ))||return
local a
a=${r_qpkg_requires_ipks[qpkg_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgDbActiveTest(){ [[ -n $qpkg_name ]]&&(( qpkg_index>0 ))||return
local a
a=${r_qpkg_test_for_active[qpkg_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgServiceAction(){ local a
a=$r_qpkg_service_result_path/${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}.action
if [[ -s $a ]];then printf '%s' "$(<"$a")"
return 0;else printf not-found
return 1;fi;}
GetQpkgServiceExplanation(){ local a
a=$r_qpkg_service_result_path/${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}.explanation
if [[ -s $a ]];then printf '%s' "$(<"$a")"
return 0;else printf not-found
return 1;fi;}
GetQpkgServiceResult(){ local a
a=$r_qpkg_service_result_path/${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}.result
if [[ -s $a ]];then printf '%s' "$(<"$a")"
return 0;else printf not-found
return 1;fi;}
GetQpkgsIsInstalled(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgInstalled||continue
echo "$qpkg_name";done;}
GetQpkgsIsValidInstalled(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsValidQpkgInstalled||continue
echo "$qpkg_name";done;}
GetQpkgsNtInstalled(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsNtQpkgInstalled||continue
echo "$qpkg_name";done;}
GetQpkgsIsEnabled(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgEnabled||continue
echo "$qpkg_name";done;}
GetQpkgsNtEnabled(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsValidQpkgInstalled||continue
IsNtQpkgEnabled||continue
echo "$qpkg_name";done;}
GetQpkgsIsComplete(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgComplete||continue
echo "$qpkg_name";done;}
GetQpkgsNtComplete(){ local qpkg_name
for qpkg_name in $(QPKGs-GRall:Array);do IsQpkgInstalled||continue
IsNtQpkgComplete||continue
echo "$qpkg_name";done;}
QpkgServiceResultWasOk(){ [[ -n ${qpkg_name:-} ]]||return
[[ $(GetQpkgServiceResult) = ok ]];}
QpkgMatchAbbrv(){ [[ -n ${1:-} ]]||return
local -a a_ar
local -i i
local -i j
local -i z
z=1
for i in "${!r_qpkg_name[@]}";do a_ar=(${r_qpkg_abbrvs[i]})
for j in "${!a_ar[@]}";do [[ ${a_ar[j]} = "$1" ]]||continue
printf '%s' "${r_qpkg_name[i]}"
z=0
break 2;done;done;return $z;}
IsUserOk(){ if ! IsUserSU;then if IsOsCanSudo;then ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${r_chars_sudo_prompt}sherpa $r_args_raw">&2;else ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again";fi;return 1;fi;return 0;}
IsUserSU(){ (( EUID == 0 ));}
IsCriticalFile(){ [[ -n ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]||exit
local a
a=${1%% *}
if ! [[ -f $a ||-L $a ]];then ShowAsAbort "a required NAS system file $(FormatFileName "$a") is missing"
return 1;fi;return 0;}
IsNtCriticalFile(){ ! IsCriticalFile "${1:?${FUNCNAME[0]}(): $e_nopfi}";}
IsFile(){ [[ -n ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]||exit
local a
a=${1%% *}
[[ -s $a ]];}
IsNtFile(){ ! IsFile "${1:?${FUNCNAME[0]}(): $e_nopfi}";}
IsFileRecent(){ [[ -e ${1:-} ]]&&(( ( $(ConvertNowToSeconds) - $(FileLastStatusChangeEpoch "$1") ) / 60<= ${2:-1440} ));}
#IsFileNewer()
#(( $(FileLastModifiedEpoch "$1")>$(FileLastModifiedEpoch "$2") ))
IsUrl(){ [[ -n ${1:?${FUNCNAME[0]}(): $e_nourl} ]]||return
[[ $(Lowercase "$1") == http* ]];}
IsNtUrl(){ ! IsUrl "${1:?${FUNCNAME[0]}(): $e_nourl}";}
IsEntwareUpgradable(){ local a
a=$(GetQpkgInstalledDate Entware)
if [[ $a = undefined ]]||(( ${a//[!0-9]/}<r_entware_packages_last_updated ));then case $r_nas_arch in armv5tel|i686|x86)
:;;*)return
esac;fi
false;}
IsEntwareSiteUp(){ IsSiteUp bin.entware.net;}
IsNonStatusActionRequested(){ local action
for action in "${ar_qpkg_actions[@]}";do if QPKGs-AC${action}-to.IsAny;then [[ $action != status ]]||continue
return;fi;done;false;}
IsOsOk(){ if ! IsOsQNAP;then ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1;fi;return 0;}
IsOsQNAP(){ [[ -s /etc/init.d/functions ]];}
IsQuTS(){ /bin/grep zfs /proc/filesystems;} &>/dev/null
IsOsSupported(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.0.0) ));}
IsOsCanAsyncQpkgActions(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 5.2.0) ));}
IsOsCanSecureDownload(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.5.5) ));}
IsOsCanQpkgTimeout(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.3.0) &&10#$r_nas_firmware_ver<= 10#$(ConvertFirmwareVersionStringToNumber 5.1.9) ))&&[[ $r_nas_qpkg_arch != i86 ]];}
IsOsCanManageSignedPackages(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.3.7) ));}
IsOsCanUnofficialPackages(){ SetOsFirmwareVer
(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber 4.3.3)&&10#$r_nas_firmware_ver<= 10#$(ConvertFirmwareVersionStringToNumber 4.3.6) ));}
IsOsCanSudo(){ [[ -x /usr/bin/sudo ]];}
IsOsCanSedExtRegex(){ (( $(echo -en "\033[1;97ma"|/bin/sed -r "$r_regex_strip_ansi"|/usr/bin/wc -c) == 1 ));}
IsOsCanAutowidthTableColumns(){ [[ -x $r_gnu_awk_cmd ]];}
IsOsCompatibleWithSigned(){ SetOsFirmwareDate
(( r_nas_firmware_date<20201015||r_nas_firmware_date>20201020 ));}
IsOsRequireSignedPackages(){ [[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert -u -d FALSE) = FALSE ]];}
IsOsAllowUnofficialPackages(){ [[ $(/sbin/getcfg 'QPKG Management' Check_Official -u -d TRUE) = FALSE ]];}
IsOsStarting(){ /bin/ps|/bin/grep '/bin/sh /etc/init.d/rcS'|/bin/grep -v grep;} &>/dev/null
IsOsStopping(){ /bin/ps|/bin/grep '/bin/sh /etc/init.d/rcK'|/bin/grep -v grep;} &>/dev/null
IsOsStartingPackages(){ if IsOsCanAsyncQpkgActions;then /bin/ps|/bin/grep '/usr/local/sbin/qpkg_service start'|/bin/grep -v grep;else IsOsStarting;fi;} &>/dev/null
IsOsStoppingPackages(){ if IsOsCanAsyncQpkgActions;then /bin/ps|/bin/grep '/usr/local/sbin/qpkg_service stop'|/bin/grep -v grep;else IsOsStopping;fi;} &>/dev/null
IsOsOnline(){ [[ $(GetOsState) = online ]];}
IsOsStdKernelPageSize(){ SetOsKernelPageSize
[[ $r_kernel_page_size = 4kiB ]];}
IsOsNonStdKernelPageSize(){ ! IsOsStdKernelPageSize;}
IsThisLoadAverageElevated(){ IsThisLoadAverageAboveTrigger "$1" 1;}
IsThisLoadAverageHigh(){ IsThisLoadAverageAboveTrigger "$1" 4;}
IsThisLoadAverageInsane(){ IsThisLoadAverageAboveTrigger "$1" 8;}
IsThisLoadAverageAboveTrigger(){ local -i a
local b
a=$(( r_cpu_threads * ${2:-1} * 100 ))
b=${1:-1}
b=$(( 10#${b/./} ))
(( b>= a ));}
IsOsSedExtRegexSupported(){ [[ ${sed_ext_regex_supported:-unset} = unset ]]&&SetOsSedRegexSupport
(( sed_ext_regex_supported == 0 ));}
IsInTerminal(){ [[ -t 0 ]];}
IsError(){ [[ ${_script_error_flag_:=false} = true ]];}
IsNtError(){ [[ ${_script_error_flag_:=false} != true ]];}
IsQpkgRepoSelfManaged(){ local a
a=$(GetQpkgInstalledStoreID "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ -z $a ||$a = undefined ||$a = sherpa ]];}
IsNtQpkgRepoSelfManaged(){ ! IsQpkgRepoSelfManaged "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgBackupExist(){ local a
local new
local old
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}.config.tar.gz
new=$r_qpkg_bu_path/$a
old=$r_qpkg_bu_path/O$a
if [[ -e $old &&! -e $new ]];then if(( $(/usr/bin/stat -c %s "$old")<= ( 500 * ( 2 ** 20 ) ) ));then /usr/bin/cp "$old" "$new";else /bin/mv "$old" "$new";fi;fi
[[ -e $new ]];}
IsQpkgUpgradable(){ IsValidQpkgInstalled&&IsQpkgRepoSelfManaged&&IsNtQpkgProhibited&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk&&[[ $(GetQpkgInstalledVer) != "$(GetQpkgDbVer)" ]];}
IsQpkgInstallable(){ IsNtQpkgInstalled&&IsNtValidQpkgInstalled&&IsNtQpkgProhibited&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk;}
IsQpkgDbDependent(){ (( qpkg_index>0 ))||return
[[ ${r_qpkg_depends_on[qpkg_index]} != none ]];}
IsQpkgDbIndependent(){ ! IsQpkgDbOptional&&! IsQpkgDbDependent;}
IsQpkgDbOptional(){ local -i i
local re
re=\\b${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}\\b
for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_opt_depends_on[i]} =~ $re ]]||continue
return 0;done;return 1;}
IsQpkgDbMinRAMOk(){ local a
a=$(GetQpkgDbMinRAM "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ -n $a ]]||return
[[ $a = none ]]||(( r_nas_ram_kb>= a ));}
IsQpkgDbMinOSVerOk(){ local a
a=$(GetQpkgDbMinOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
SetOsFirmwareVer
[[ -n $a ]]||return
[[ $a = none ]]||(( 10#$r_nas_firmware_ver>= 10#$(ConvertFirmwareVersionStringToNumber "$a") ));}
IsQpkgDbMaxOSVerOk(){ local a
a=$(GetQpkgDbMaxOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
SetOsFirmwareVer
[[ -n $a ]]||return
[[ $a = none ]]||(( 10#$r_nas_firmware_ver<= 10#$(ConvertFirmwareVersionStringToNumber "$a") ));}
IsQpkgDbCanBackup(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_can_backup[i]}
break;done;else
a=${r_qpkg_can_backup[qpkg_index]};fi;[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbCanRestartToUpdate(){ local -i i
for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" ]]||continue
if ${r_qpkg_can_restart_to_update[i]};then return 0;else break;fi;done;return 1;}
IsQpkgDbCanClean(){ local -i i
for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" ]]||continue
if ${r_qpkg_can_clean[i]};then return 0;else break;fi;done;return 1;}
IsQpkgDbSherpaCompatible(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_is_sherpa_compatible[i]}
break;done;else
a=${r_qpkg_is_sherpa_compatible[qpkg_index]};fi;[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbUniqueUnpack(){ local -i i
local a
a=''
if [[ -n ${1:-} ]];then for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "$1" ]]||continue
a=${r_qpkg_is_unique_unpack[i]}
break;done;else
a=${r_qpkg_is_unique_unpack[qpkg_index]};fi;[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbWillLog(){ local -i i
for i in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" ]]||continue
if ${r_qpkg_will_log[i]};then return 0;else break;fi;done;return 1;}
IsQpkgAutoUpdate(){ [[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Auto_Update -u -f /etc/config/qpkg.conf) = TRUE ]];}
IsQpkgAuthorOk(){ local a
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(GetQpkgDbAuthor "$a") = "$(GetQpkgAuthor "$a")" ]];}
IsNtQpkgAuthorOk(){ ! IsQpkgAuthorOk "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsValidQpkgInstalled(){ local a
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
IsQpkgInstalled "$a"&&IsQpkgAuthorOk "$a";}
IsNtValidQpkgInstalled(){ ! IsValidQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgInstalled(){ local a
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(/sbin/getcfg "$a" Name -d undefined -f /etc/config/qpkg.conf) = "$a" ]];}>/dev/null
IsNtQpkgInstalled(){ ! IsQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgProhibited(){ local re
re=\\b${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}\\b
[[ ${r_qpkg_names_prohibited[*]} =~ $re ]];}
IsNtQpkgProhibited(){ ! IsQpkgProhibited "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgConflicts(){ local a
for a in $(GetQpkgConflicts "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}");do IsQpkgInstalled "$a"&&return;done;return 1;}
IsQpkgMissing(){ local a
a=$(GetQpkgInstalledPath "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ $a != undefined &&! -d $a ]];}
IsQpkgComplete(){ local a
a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(/sbin/getcfg "$a" Status -d undefined -f /etc/config/qpkg.conf) = complete ]]&&[[ $(/sbin/getcfg "$a" Incomplete_Conf -d undefined -f /etc/config/qpkg.conf) != 1 ]];}
IsNtQpkgComplete(){ ! IsQpkgComplete "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgEnabled(){ [[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Enable -u -d undefined -f /etc/config/qpkg.conf) = TRUE ]];}
IsNtQpkgEnabled(){ ! IsQpkgEnabled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgSigned(){ [[ -s $r_cert_db_pathfile ]]||return
local match_column
local package_name
local pysqlite_command
local query
local select_column
local table
local uri
match_column=QpkgName
select_column=Cert
table=Certificate
package_name=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
query="SELECT $select_column from $table WHERE $match_column = ?"
uri="file:$r_cert_db_pathfile?mode=ro"
read -r -d '' pysqlite_command<<EOB
import sqlite3
import sys
import ctypes
from ctypes import util
sqlite_path = ctypes.util.find_library('sqlite3')
if sqlite_path:
    sqlite3_lib = ctypes.CDLL(sqlite_path)
    sqlite3_lib.sqlite3_config(17, 1)
conn = sqlite3.connect('$uri')
cursor = conn.cursor()
try:
    cursor.execute("""$query""", ('$package_name',))
    records = cursor.fetchall()
finally:
    cursor.close()
    conn.close()
    sys.exit(len(records) == 0)
EOB
/usr/local/bin/python2 -c "$pysqlite_command";}
IsNtQpkgSigned(){ ! IsQpkgSigned "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgTimeoutsIncreased(){ [[ -e /usr/local/sbin/qpkg_service.orig ]];}
IsInteger(){ [[ -n ${1:-} ]]||return
! [[ "$1" =~ [^0-9] ]];}
IsDebug(){ [[ $useropt_debug = true ]];}
IsNtDebug(){ ! IsDebug;}
IsVerbose(){ [[ $useropt_verbose = true ]];}
IsAnsiStrippingSupported(){ if IsOsSedExtRegexSupported;then true
elif [[ -x /opt/bin/sed &&-L /opt/etc/passwd ]];then true;else false;fi;}
IsHaveSingleQuote(){ /bin/grep "'"<<<"${1:-}";} &>/dev/null
IsLessSupportHeaders(){ local a
a=$(GetLessVersion)
IsInteger $a&&(( a>= 685 ));}
IsFuncExist(){ [[ -n ${1:-} &&$(type -t "$1") = function ]];}
IsReportLargerThanViewport(){ [[ -n ${1:-} &&-e $1 ]]||return
UpdateSessionRows
UpdateSessionColumns
(( $(/usr/bin/wc -l<"$1")>= sess_rows||$(StripANSICodes "$(<"$1")"|/usr/bin/wc -L)>sess_columns ));}
IsThisAnAlternateLine(){ [[ ${alternate_report_lines:=false} = true ]]&&(( ( ${1:-0} + 1 ) % 2 == 0 ));}
UpdateSessionRows(){ local a
a=''
if IsInTerminal;then if a=$(stty size);then sess_rows=${a% *}
elif a=$(tput lines);then sess_rows=$a;fi;fi
(( ${sess_rows:=0} == 0 ))&&sess_rows=40;} &>/dev/null
UpdateSessionColumns(){ local a
a=''
if IsInTerminal;then if a=$(stty size);then sess_columns=${a#* }
elif a=$(tput cols);then sess_columns=$a;fi;fi
(( ${sess_columns:=0} == 0 ))&&sess_columns=156;} &>/dev/null
CreateAndSetPidFile(){ pidfile=$(/bin/mktemp "$r_async_procs_path"/proc_XXXXXX);}
WriteToPidFile(){ echo "${1:?${FUNCNAME[0]}(): $e_nopid}">"${2:-${pidfile:?${FUNCNAME[0]}(): $e_nopfi}}";}
AppendToPidsFile(){ echo "${1:?${FUNCNAME[0]}(): $e_nopid}">>"${2:-${pidfile:?${FUNCNAME[0]}(): $e_nopfi}}";}
RemovePidFile(){ [[ -n ${pidfile:-} &&-e $pidfile ]]||return
/bin/rm -f "$pidfile";}
LoadQpkgSigningCert(){ r_qpkg_certificate=''
r_qpkg_signature=''
read -r -d '' r_qpkg_certificate<<EOB
-----BEGIN CERTIFICATE-----
MIIDvzCCAqegAwIBAgIEBYuKdDANBgkqhkiG9w0BAQsFADCBgDELMAkGA1UEBhMC
VFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYDVQQKDARR
TkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMMB1FOQVBfQ0ExIDAeBgkqhkiG9w0B
CQEWEXNlY3VyaXR5QHFuYXAuY29tMB4XDTI2MDIwMzEwMzAwM1oXDTI5MDIwMjEw
MzAwM1owgYMxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcM
BlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwDTkFTMRMwEQYDVQQDDApN
eUNsb3VkTmFzMSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBxbmFwLmNvbTCCASIw
DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJ6llr6rT3f6cVcBDPAAF6yYweQ0
158u9ABy/DPxbbo9lwoCCRFQa1w8mLGVp/5/1PBy+Ja5QmJkGUidpUl6gmjlDEUd
UT622BVwGTp1ztBqkgECDByIhz585kWMz96OfAXFneiHWLr906iJLpfyP6b2S5GU
NZAgOk8KzPriKqiWL+8oH3H28qTUOw4qRkSzi+dQbaSP8qCPmEA4Z7KDZzSOn80H
p1CEGrdiH6spGb6AE536BB4GecqUXQQToIGq5kqkuclPSiLBD1Cl1XBhMtj1oWCO
ff/qTD9H9sPqPTrsg14CJmCD35PIofAUO+RcfrCex7teckoPaXVKfxWCFbECAwEA
AaM8MDowOAYDVR0fBDEwLzAtoCugKYYnaHR0cDovL2Rvd25sb2FkLnFuYXAuY29t
L2NybC9xdHNfdjEuY3JsMA0GCSqGSIb3DQEBCwUAA4IBAQAVrG2Zyj9GHp9reg3L
miMkSUi9CDdHKoevmlg73SxkAS1EODnBXvqdWhTBjKDecuAYKFVuPaS7a8541Aym
V1ZrdYyEkZIFPYCeeym/cbvh1sLws27GUTBYk3oklllxUnPTFlZhzp+cS3QcFdJX
U2mmp0ctqO9bQhYeS3j5u6DFSwv3M1vCsasVJiaBeA6icJx9bUeXLR0gilQhqgIl
qcg+ppBMJRCw9+uWEs4fuViDr+o5mUJZwzxfeNz67Mb0d3cnWfoBld/NwksOngRw
cRhmFN34+GmcaB6kUzF+/cl+DhxprF2fcqvWTzdV5EEVZZacHPh8dNOcEMHb8zmt
dCpm
-----END CERTIFICATE-----
EOB
read -r -d '' r_qpkg_signature<<EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename=\"smime.p7m\"
Content-Type: application/pkcs7-mime;smime-type=signed-data;name=\"smime.p7m\"
Content-Transfer-Encoding: base64

MIIGrwYJKoZIhvcNAQcCoIIGoDCCBpwCAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFP3HrmZ/xsYuhW9eoIqUWitMCjlfoIIDwzCCA78wggKnoAMCAQIC
BAWLinQwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZU
YWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwD
TkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBx
bmFwLmNvbTAeFw0yNjAyMDMxMDMwMDNaFw0yOTAyMDIxMDMwMDNaMIGDMQswCQYD
VQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNV
BAoMBFFOQVAxDDAKBgNVBAsMA05BUzETMBEGA1UEAwwKTXlDbG91ZE5hczEgMB4G
CSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20wggEiMA0GCSqGSIb3DQEBAQUA
A4IBDwAwggEKAoIBAQCepZa+q093+nFXAQzwABesmMHkNNefLvQAcvwz8W26PZcK
AgkRUGtcPJixlaf+f9TwcviWuUJiZBlInaVJeoJo5QxFHVE+ttgVcBk6dc7QapIB
AgwciIc+fOZFjM/ejnwFxZ3oh1i6/dOoiS6X8j+m9kuRlDWQIDpPCsz64iqoli/v
KB9x9vKk1DsOKkZEs4vnUG2kj/Kgj5hAOGeyg2c0jp/NB6dQhBq3Yh+rKRm+gBOd
+gQeBnnKlF0EE6CBquZKpLnJT0oiwQ9QpdVwYTLY9aFgjn3/6kw/R/bD6j067INe
AiZgg9+TyKHwFDvkXH6wnse7XnJKD2l1Sn8VghWxAgMBAAGjPDA6MDgGA1UdHwQx
MC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFwLmNvbS9jcmwvcXRzX3YxLmNy
bDANBgkqhkiG9w0BAQsFAAOCAQEAFaxtmco/Rh6fa3oNy5ojJElIvQg3RyqHr5pY
O90sZAEtRDg5wV76nVoUwYyg3nLgGChVbj2ku2vOeNQMpldWa3WMhJGSBT2Annsp
v3G74dbC8LNuxlEwWJN6JJZZcVJz0xZWYc6fnEt0HBXSV1NppqdHLajvW0IWHkt4
+bugxUsL9zNbwrGrFSYmgXgOonCcfW1Hly0dIIpUIaoCJanIPqaQTCUQsPfrlhLO
H7lYg6/qOZlCWcM8X3jc+uzG9Hd3J1n6AZXfzcJLDp4EcHEYZhTd+PhpnGgepFMx
fv3Jfg4caaxdn3Kr1k83VeRBFWWWnBz4fHTTnBDB2/M5rXQqZjGCApowggKWAgEB
MIGJMIGAMQswCQYDVQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQHDAZU
YWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsMA05BUzEQMA4GA1UEAwwHUU5B
UF9DQTEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20CBAWLinQwCwYJ
YIZIAWUDBAIBoIHkMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
AQkFMQ8XDTI2MDcyNzAzMzIzNVowLwYJKoZIhvcNAQkEMSIEIP/Lo9f9SP65wjYV
h1Oeg3EI9SoewSHdEPWTM5tujeZ1MHkGCSqGSIb3DQEJDzFsMGowCwYJYIZIAWUD
BAEqMAsGCWCGSAFlAwQBFjALBglghkgBZQMEAQIwCgYIKoZIhvcNAwcwDgYIKoZI
hvcNAwICAgCAMA0GCCqGSIb3DQMCAgFAMAcGBSsOAwIHMA0GCCqGSIb3DQMCAgEo
MA0GCSqGSIb3DQEBAQUABIIBAIumPJ3zt7SFDFvpIl+2VySFJ/g9Y4mqMVADIJkW
h09w6GmSCx94mxCYwxPP9sAzMy83A2DGbVkEA36wuG7HTRLecxFlgqtKxgZ+U0Sr
7pPFNTcQGjKpxdv7LbNEpTUdhBnd8CwWL5nqfIj35/EjqkdPMOuH8jPRV7No8nSj
/Db+TdJ2BMh3lzxuVGFNDbxzJXMtFuA9XQmgW3zOpfQZC2TOmAVdxV8wijJE3LW1
JhzjybAGqGh79Iy4rOs5dpyRIAlnf+ppYCgZWNLYwi8J0JAOcBMr+CZvhUxQge2A
vhlKNCMp/lp+s1/yiJLAMScaNJiF5joaIekOPfKqH4FTQkc=
EOB
readonly r_qpkg_certificate
readonly r_qpkg_signature;}
MakePath(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nopth"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_norea"||return
if ! /bin/mkdir -p "$1";then ShowAsError "unable to create $2 path $(FormatFileName "$1") $(FormatExitcode "$?")"
show_suggest_raise_issue=true
return 1;fi;return 0;}
ClearPath(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nopth"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_nopth"||return
local parent
local target
parent=$1
target=$(/usr/bin/basename "$2")
ConfirmVarIsDefined target "${target:-}" "$e_nopth"||return
[[ -d $parent/$target ]]&&/bin/rm -rf "${parent:?}/${target:?}"/*;}
ConfirmVarIsDefined(){ local -i backdepth
local first
local second
local third
backdepth=1
first=${1:-undefined}
second=${2:-undefined}
third=${3:-undefined}
[[ $second != undefined ]]||{ ShowAsBug "${FUNCNAME[backdepth]}" "\$$first: '$third'";return;}
return 0;}
FileCountAll(){ [[ -n ${1:-} ]]||return
compgen -G "$1/*"|/usr/bin/wc -l|/bin/sed 's/^ *//';}
FileCountSpec(){ [[ -n ${1:-} ]]||return
compgen -G "$1"|/usr/bin/wc -l|/bin/sed 's/^ *//';}
Executer(){ [[ -n ${1:?${FUNCNAME[0]}(): $e_nocmd} &&-n ${2:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
FuncInit;local -i z
local a
local exec_msg
local r_executer_log_pipe
local r_log_pathfile
a=$(/bin/tr -s ' '<<<"$1")
exec_msg='exec:'
r_log_pathfile=$(/bin/mktemp $r_run_logs_path/${FUNCNAME[0]}_XXXXXX)
z=0
local -r r_log_pathfile
if IsHaveSingleQuote "$a";then exec_msg+=" \"$a\"";else exec_msg+=" '$a'";fi;DebugAsProc "$exec_msg"
FormatCommand "$a">"$2"
if IsDebug;then r_executer_log_pipe=$r_sys_run_path/pipe-$(/bin/date +%s%N)
local -r r_executer_log_pipe
/bin/mknod "$r_executer_log_pipe" p
/usr/bin/tee "$r_log_pathfile"<"$r_executer_log_pipe" &
eval "$1">"$r_executer_log_pipe" 2>&1
z=$?
/bin/rm "$r_executer_log_pipe";else eval "$a">"$r_log_pathfile" 2>&1
z=$?;fi;if [[ -s $r_log_pathfile ]];then ShowAsResultAndStdout "$z" "$(<"$r_log_pathfile")">>"$2"
/bin/rm -f "$r_log_pathfile" 2>/dev/null;else ShowAsResultAndStdout "$z" '<null>'>>"$2";fi;exec_msg='exec: completed'
case $z in 0)
if [[ ${3:-} != log:failure-only ]]||IsDebug;then AddExtLogToSessLog "$2";fi;DebugAsDone "$exec_msg OK ($z)"
IsNtDebug&&/bin/rm -f "$2" 2>/dev/null;;"${4:-}")
if [[ ${3:-} != log:failure-only ]]||IsDebug;then AddExtLogToSessLog "$2";fi;DebugAsWarn "$exec_msg with permitted errors ($z)"
IsNtDebug&&/bin/rm -f "$2" 2>/dev/null;;*)AddExtLogToSessLog "$2"
DebugAsError "$exec_msg with errors ($z)"
esac;FuncExit $z;}
KludgeExecuter(){ [[ -n ${1:?${FUNCNAME[0]}(): $e_nocmd} &&-n ${2:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
FuncInit;local -i pid
local -i z
local a
a=$(/bin/tr -s ' '<<<"$1")
z=0
if IsVerbose;then eval "$a 2>&1|/usr/bin/tee $2" &
else eval "$a">"$2" 2>&1 &
fi;pid=$!
if(( pid>1 ));then wait $pid 2>/dev/null
z=$?;fi;pid=$(FindPid '/bin/sh' "$r_local_pathfile")
if(( pid>1 ));then while [[ -e /proc/$pid ]];do Pause 0.5;done;fi
FuncExit $z;}
FindPid(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nostr"||return
local -a args
local -i loop_count
local -i loop_limit
local -i pid
local arg
local cmdline_pathfile
local exe_pathfile
local pid_path
local remainder
local temp
loop_limit=16
trap "$(shopt -p)" RETURN
shopt -s nullglob nocasematch
for pid_path in /proc/[0-9]*/;do temp=${pid_path#/proc/}
pid=${temp%/}
cmdline_pathfile=/proc/$pid/cmdline
exe_pathfile=/proc/$pid/exe
(( pid>1 ))||continue
[[ -e $cmdline_pathfile &&-r $cmdline_pathfile &&-L $exe_pathfile ]]||continue
args=()
loop_count=0
remainder=''
if exec 3<"$cmdline_pathfile" 2>/dev/null;then while IFS= read -r -u 3 -d '' arg;do args+=("$arg")
(( loop_count++ ));(( loop_count>= loop_limit ))&&break;done;exec 3<&-;fi;(( ${#args[@]}>0 ))||continue
[[ ${args[0]} =~ $1 ]]||continue
remainder=$(IFS=' ';echo "${args[*]:1}")
if [[ -n ${2:-} &&$2 != undefined ]];then [[ "$remainder" == *"$2"* ]]||continue;fi;if [[ -n ${3:-} &&$3 != undefined ]];then [[ "$remainder" == *"$3"* ]]||continue;fi;printf '%s' "$pid"
return;done;return 1;}
DeDupeWords(){ [[ -n ${1:-} ]]||return
/bin/tr ' ' '\n'<<<"$1"|/usr/bin/sort|/bin/uniq|/bin/tr '\n' ' '|/bin/sed "$r_regex_strip_lead_whitespace;$r_regex_strip_tail_whitespace";}
FileMatchesMD5(){ [[ $(GenerateMD5 "${1:?${FUNCNAME[0]}(): $e_nopfi}") = "${2:?${FUNCNAME[0]}(): $e_nochk}" ]];}
#FileLastModifiedEpoch()
FileLastStatusChangeEpoch(){ [[ -n ${1:-} &&-e $1 ]]||return
/usr/bin/stat "$1" -c %Z;}
GenerateMD5(){ [[ -e ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]&&/bin/md5sum "${1:?${FUNCNAME[0]}(): $e_nopfi}"|/usr/bin/cut -f1 -d' ';}
Pluralise(){ (( ${1:-0} != 1 ))&&printf s;}
Capitalise(){ [[ -n ${1:-} ]]||return
if [[ $1 == sherpa* ]];then printf '%s' "$1";else printf '%s' "$(Uppercase ${1:0:1})${1:1}";fi;}
Bracketise(){ [[ -n ${1:-} ]]||return
printf '[%s]' "$1";}
AddPeriod(){ [[ -n ${1:-} ]]||return
[[ ${1: -1} != ':' &&${1: -1} != '?' &&${1: -1} != '.' ]]&&printf '%s.' "$1"||printf '%s' "$1";}
Uppercase(){ [[ -n ${1:-} ]]||return
/bin/tr 'a-z' 'A-Z'<<<"$1";}
Lowercase(){ [[ -n ${1:-} ]]||return
/bin/tr 'A-Z' 'a-z'<<<"$1";}
LTrim(){ [[ -n ${1:-} ]]||return
printf '%s' "${1##+(' ')}";}
RTrim(){ [[ -n ${1:-} ]]||return
printf '%s' "${1%%+(' ')}";}
Trim(){ [[ -n ${1:-} ]]||return
RTrim "$(LTrim "$1")";}
FormatAsThous(){ [[ -n ${1:-} ]]||return
local a
local b
local c
a=${1//[!0-9]/}
b=''
c=''
while(( ${#a}>0 ));do b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then c=$b;else c=$b,$c;fi;if(( ${#b} == 3 ));then a=${a%???};else break;fi;done;printf '%s' "$c"
return 0;}
FormatAsIsoBytes(){ /bin/awk 'BEGIN{ u[0]="B";u[1]="kB";u[2]="MB";u[3]="GB"} { n = $1;i = 0;while(n>1000) { i+=1;n= int((n/1000)+0.5) } print n u[i] } '<<<"${1:-}";}
ShowTitle(){ [[ $show_title = true &&$title_shown = false ]]||return
FuncInit;PauseSpinner;EraseThisLine;if [[ -z ${r_args_raw[*]} ]];then Display "$(ShowTitleArt)"
title_art_shown=true;else Display "$(ShowAsTitleName) $(ShowAsVersion)";fi;title_shown=true
FuncExit;}
ShowAsTitleName(){ TextBrightWhite sherpa;}
ShowTitleArt(){ echo -e "              \033[0;94m▄▄▄▄\033[0m"
echo -e "            \033[0;94m▄██▀  ▀\033[0m"
echo -e "            \033[0;94m███\033[0m"
echo -e "            \033[0;94m███                    ▄\033[0m"
echo -e "   \033[0;94m▄█▀██▄▄  ███           ▄█▀██▄▄  ███▄▄▀▀▄   ███▄▄▀▀▄     ▄▀▀▀▀▄▄\033[0m"
echo -e " \033[0;94m▄██   ████ ███ ▄███▄   ▄██   ████ ███▀  ▐██▄ ███▀    █▄     ▄▄▄███\033[0m"
echo -e "\033[0;94m▐███▄    ▀  ███▀  ███  ████  ▄██▀  ███    ▀▀  ███     ██  ▄██  ▀███\033[0m"
echo -e " \033[0;94m▀█\033[0;94;44m▀█▄█▀█\033[0;94m▄  \033[0;94;44m█▀▄\033[0;34m   \033[0;94;44m▄\033[0;94m█\033[0;94;44m▀\033[0;34m \033[0;37m \033[0;94;44m█\033[0;94m██\033[0;94;44m▀\033[0;94m▄█▀\033[0;34m▀    \033[0;94m█\033[0;94;44m▄\033[0;94m█\033[0;34m        \033[0;94m█\033[0;94;44m▄\033[0;94m█▄\033[0;34m \033[0;94m▄▄███\033[0;37m \033[0;94m██\033[0;94;44m▄\033[0;94m█\033[0;34m   \033[0;94;44m▀\033[0;94m█\033[0;94;44m▄\033[0m"
echo -e "  \033[0;34m▄   \033[0;94m▀\033[0;94;44m▀▀▄▄\033[0;37m \033[0;94;44m ▀ \033[0;34m   \033[0;94;44m▀▄▀\033[0;34m  \033[0;94;44m▀▄▀▀\033[0;34m▌       \033[0;94;44m▀▄▀\033[0;34m        \033[0;94;44m▀▄▀\033[0;34m \033[0;94m▀███▀\033[0;34m  \033[0;94;44m▀▄▀▄\033[0;34m   \033[0;94;44m▀▄▀\033[0m"
echo -e " \033[0;34;44m \033[0;34m▄\033[0;34;44m \033[0;34m▄  \033[0;94;44m▀▄\033[0;34m█▀\033[0;37m \033[0;34;44m   \033[0;34m   \033[0;34;44m   \033[0;34m  \033[0;34m \033[0;34;44m   \033[0;34m▄   ▄▄▀ \033[0;94;44m█▀\033[0;34m█        ██\033[0;94;44m▄\033[0;34m   \033[0;94m▀     \033[0;34m▀██  ▄███ ▄\033[0m"
echo -e "  \033[0;34m▀▀██▀▀    ▀▀     ▀▀▀\033[0;37m \033[0;34m  ▀▀▀▀▀▀    ▀█▄        \033[0;34m▄██        \033[0;34m    ▀▀ ▀▀ ▀\033[0m"
echo -e "                                               \033[0;34m▀█\033[0m"
echo -e " \033[0;96m█\033[0m $(ShowAsDescription)"
echo -e " \033[0;36m█\033[0m $(ShowAsCopyrightBasic)"
echo -e " \033[0;90m█\033[0m $(ShowAsVersion)";}
ShowAsDescription(){ printf '%s' 'A mini-package-manager for QNAP NAS';}
ShowAsCopyrightBasic(){ printf '%s' 'Copyright (C) 2017-2026 OneCD';}
ShowAsVersion(){ printf '%s' "v$r_this_script_ver-$useropt_branch ($r_nas_qpkg_arch)";}
ShowAsAction(){ TextBrightYellow "$(Bracketise action)";}
ShowAsSetting(){ TextBrightYellow "$(Bracketise setting)";}
ShowAsPackages(){ TextBrightOrange "$(Bracketise packages)";}
ShowAsPackageGroup(){ TextBrightOrange "$(Bracketise 'package group')";}
ShowAsOptions(){ TextBrightRed "$(Bracketise options)";}
FormatPackageName(){ printf '%s' "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
FormatReportPackageName(){ if [[ $req_alert = true ]];then FormatReportField "$name" alert
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then FormatReportField "$name" attention_highlight
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $req_normal_notice = true ]];then FormatReportField "$name" normal_notice
/bin/touch "$r_report_flags_path"/req-normal-notice
elif [[ $req_notice = true ]];then FormatReportField "$name" notice
/bin/touch "$r_report_flags_path"/req-notice
elif [[ $req_oops = true ]];then FormatReportField "$name" oops
/bin/touch "$r_report_flags_path"/req-oops
elif [[ $mode = mute ]];then if IsOsCanAutowidthTableColumns;then FormatReportField "$name" mute;else FormatReportField "$name";fi;else FormatReportField "$name";fi;}
FormatFileName(){ printf '%s' "'${1:?${FUNCNAME[0]}(): $e_nofil}'";}
ShowAsURL(){ TextUnderlinedCyan "${1:?${FUNCNAME[0]}(): $e_nourl}";}
FormatExitcode(){ printf '%s' "'${1:?${FUNCNAME[0]}(): $e_noext}'";}
FormatLogFilename(){ printf '%s' "${r_chars_results}log file: '${1:?${FUNCNAME[0]}(): $e_nofil}'";}
FormatCommand(){ echo "${r_chars_results}command: '${1:?${FUNCNAME[0]}(): $e_nocmd}'";}
FormatNWords(){ (( ${#1}>0 ))||return
local -i n
local -i word_count
local -i words_max
local a
local word_colour
local words
a=''
word_colour=${3:-TextUncoloured}
words=($1)
words_max=${2:-3}
word_count=${#words[@]}
for(( n = 1;n<= word_count;n++ ));do if(( n == 1&&words_max == 1 ));then if(( word_count == 1 ));then a+=$($word_colour "${words[n-1]}");else a+=$($word_colour "$(( word_count - words_max + 1 ))")' others';fi;break
elif(( n>= words_max&&( word_count - words_max )>0 ));then a+=$($word_colour "$(( word_count - words_max + 1 ))")' others'
break;fi;a+=$($word_colour "${words[n-1]}")
if((( n + 1 ) == word_count ))||((( n + 1 )>= words_max&&( word_count - words_max )>0 ));then a+=' & '
elif(( n<word_count ));then a+=', ';fi;done;printf '%s' "$a";}
GetPrettyLoadAverages(){ local a
local b
local c
read -r a b c _</proc/loadavg
printf '%s, %s, %s' "$(FormatAsLoadAverage "$a" 1m)" "$(FormatAsLoadAverage "$b" 5m)" "$(FormatAsLoadAverage "$c" 15m)";}
FormatAsLoadAverage(){ local a
local b
a=$1
b=$2
if IsThisLoadAverageInsane "$1";then a=$(TextBrightRed "$1")
b=$(TextBrightRed "$2")
elif IsThisLoadAverageHigh "$1";then a=$(TextBrightOrange "$1")
b=$(TextBrightOrange "$2")
elif IsThisLoadAverageElevated "$1";then a=$(TextBrightYellow "$1")
b=$(TextBrightYellow "$2");fi;printf '%s (%s)' "$a" "$b";}
ShowAsResultAndStdout(){ [[ -n ${1:-} &&-n ${2:-} ]]||return
local a
a=$r_chars_results
(( ${1:-0} != 0 ))&&a=$r_chars_alert
echo "${a}result: $(FormatExitcode "$1")"
echo "${a}────────── stdout/stderr begins below ──────────"
echo "$2"
echo "${a}────────── stdout/stderr is complete ──────────";}
DisplayProcReport(){ [[ ${report_title_shown:=false} = false ]]||return
local a
a=''
[[ -n ${1:-} ]]&&a=$1' '
ShowAsProc "${a}report"
StartSpinner
report_title_shown=true;}
DebugInfoMajSepr(){ DebugInfo "$(TextDarkGrey "$(eval printf '%0.s═' "{1..${r_debug_log_width:=1}}")")";}
DebugInfoMinSepr(){ DebugInfo "$(TextDarkGrey "$(eval printf '%0.s─' "{1..${r_debug_log_width:=1}}")")";}
DebugExtLogMinSepr(){ DebugAsLog "$(eval printf '%0.s─' "{1..${r_debug_log_width:=1}}")";}
DebugHardware(){ DebugItem "${1:-}" hardware "${2:-}" "${3:-}";}
DebugKernel(){ DebugItem "${1:-}" kernel "${2:-}" "${3:-}";}
DebugFirmware(){ DebugItem "${1:-}" firmware "${2:-}" "${3:-}";}
DebugOS(){ DebugItem "${1:-}" os "${2:-}" "${3:-}";}
DebugUserspace(){ DebugItem "${1:-}" userspace "${2:-}" "${3:-}";}
DebugWebsite(){ DebugItem "${1:-}" webserver "${2:-}" "${3:-}";}
DebugStorage(){ DebugItem "${1:-}" storage "${2:-}" "${3:-}";}
DebugScript(){ DebugItem "${1:-}" script "${2:-}" "${3:-}";}
DebugIpk(){ DebugItem "${1:-}" ipk "${2:-}" "${3:-}";}
DebugQpkg(){ DebugItem "${1:-}" qpkg "${2:-}" "${3:-}";}
DebugItem(){ [[ -n ${1:-} &&-n ${2:-} &&-n ${3:-} &&-n ${4:-} ]]||return
local a
a=$(Uppercase "$2")
case $1 in error)
DebugErrorTabld "$a" "$3" "$4";;warning)
DebugWarningTabld "$a" "$3" "$4";;info)
DebugInfoTabld "$a" "$3" "$4";;*)DebugDetectTabld "$a" "$3" "$4"
esac;}
DebugDetectTabld(){ if [[ ${3:-} = N/A ]];then DebugAsNA "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" N/A)"
elif [[ -z ${3:-} ]];then DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")";else DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")";fi;}
DebugInfoTabld(){ if [[ -z ${3:-} ]];then DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")";else DebugAsInfo "$(printf "%${r_debug_log_first_column_width:=1}s: %${r_debug_log_second_column_width:=1}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")";fi;}
DebugWarningTabld(){ if [[ -z ${3:-} ]];then DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")";else DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")";fi;}
DebugErrorTabld(){ if [[ -z ${3:-} ]];then DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")";else DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")";fi;}
DebugVar(){ if [[ -n ${!1:-} ]];then DebugAsVar "\$$1: '${!1}'";else DebugAsVar "\$$1: null";fi;}
DebugArray(){ [[ -n ${1:-} ]]||return
if [[ -n ${2:-} ]];then DebugAsArray "\$$1: ['$2']";else DebugAsArray "\$$1: null";fi;}
DebugInfo(){ [[ -n ${1:-} ]]||return
if [[ ${2:-} = ' ' ||${2:-} = "'' " ]];then DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then DebugAsInfo "$1: ${2:-}";else DebugAsInfo "$1";fi;}
FuncInit(){ local r_var_name
local r_var_safe_name
r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
r_var_safe_name=${r_var_name//[.-]/_}
r_var_safe_name=${r_var_safe_name//:/_}
local -r r_var_name
local -r r_var_safe_name
eval "$r_var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn;}
FuncExit(){ local r_var_name
local r_var_safe_name
r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
r_var_safe_name=${r_var_name//[.-]/_}
r_var_safe_name=${r_var_safe_name//:/_}
local -r r_var_name
local -r r_var_safe_name
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!r_var_safe_name}" "$(ConvertNowToNanoseconds)")")"
return ${1:-0};}
FuncForkInit(){ [[ -n ${pidfile:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
trap '[[ -n ${pidfile:-} &&-e $pidfile ]]&&/bin/rm -f "$pidfile" 2>/dev/null;exit' SIGINT
orig_session_active_log_pathfile=$session_active_log_pathfile
session_active_log_pathfile=$(/bin/mktemp "$r_action_log_path"/"${FUNCNAME[1]}"_XXXXXX)
local r_var_name
local r_var_safe_name
r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
r_var_safe_name=${r_var_name//[.-]/_}
r_var_safe_name=${r_var_safe_name//:/_}
local -r r_var_name
local -r r_var_safe_name
eval "$r_var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncForkEn
[[ ${FUNCNAME[1]} != _ExecOneActionWithManyForks_ ]]&&MarkActionForkAsEntry;}
FuncForkExit(){ local r_var_name
local r_var_safe_name
r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
r_var_safe_name=${r_var_name//[.-]/_}
r_var_safe_name=${r_var_safe_name//:/_}
local -r r_var_name
local -r r_var_safe_name
[[ ${FUNCNAME[1]} != _ExecOneActionWithManyForks_ ]]&&MarkActionForkAsExit
DebugAsFuncForkEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!r_var_safe_name}" "$(ConvertNowToNanoseconds)")")"
if [[ -n ${session_active_log_pathfile:-} &&-e $session_active_log_pathfile ]];then if [[ -s $session_active_log_pathfile ]];then /bin/cat "$session_active_log_pathfile">>"$orig_session_active_log_pathfile";fi;/bin/rm -f "$session_active_log_pathfile";fi;RemovePidFile
exit ${1:-0};} 2>/dev/null
CalcAmountDiff(){ if(( $2>$1 ));then printf '%s' "$(( $2 - $1 ))";else printf '%s' "$(( $1 - $2 ))";fi;} 2>/dev/null
CalcMillisecondsDiffFromNanoseconds(){ printf '%s' "$(( ( $2 - $1 ) / ( 10 ** 6 ) ))";} 2>/dev/null
ConvertSecondsToFullDate(){ /bin/date -d @"${1:-}" "$r_extended_datetime_format";} 2>/dev/null
ConvertSecondsToTime(){ /bin/date -d @"${1:-}" '+%-l:%M:%S %p'|/bin/tr -s ' ';} 2>/dev/null
ConvertSecondsToDuration(){ local -i d
local -i h
local -i m
local -i s
d=$(( ${1:-0} / 86400 ))
h=$(( ${1:-0} % 86400 / 3600 ))
m=$(( ${1:-0} % 3600 / 60 ))
s=$(( ${1:-0} % 60 ))
if(( d>= 1 ));then printf '%01dd:%02dh:%02dm:%02ds' "$d" "$h" "$m" "$s"
elif(( h>= 1 ));then printf '%01dh:%02dm:%02ds' "$h" "$m" "$s"
elif(( m>= 1 ));then printf '%01dm:%02ds' "$m" "$s"
elif(( s>1 ));then printf "%d second$(Pluralise $s)" "$s"
elif(( s == 1 ));then printf "~ %d second" "$s";else s=1
printf '< %d second' "$s";fi;} 2>/dev/null
ConvertMillisecondsToSeconds(){ printf '%s' "$(( $1 / ( 10 ** 3 ) ))";} 2>/dev/null
ConvertMillisecondsToDuration(){ ConvertSecondsToDuration "$(ConvertMillisecondsToSeconds "${1:-}")";} 2>/dev/null
ConvertMillisecondsToFuncDuration(){ if(( ${1:-0}<30000 ));then printf '%s' "$(FormatAsThous "${1:-0}")ms"|/usr/bin/tail -n1;else ConvertMillisecondsToDuration "$1";fi;} 2>/dev/null
ConvertNanosecondsToMilliseconds(){ printf '%s' "$(( $1 / ( 10 ** 6 ) ))";} 2>/dev/null
ConvertLongDateAsHuman(){ [[ -n ${1:-} ]]||return
local -i a
local -i b
local c
a=${1//[!0-9]/}
if(( ${#a} != 8 ));then printf 'invalid longdate code length'
return 1;fi;b=10#${a:6:2}
c=''
if(( b>= 1&&b<= 10 ));then c=early
elif(( b>= 11&&b<= 20 ));then c=mid
elif(( b>= 21&&b<= 31 ));then c=late;else printf 'invalid day code'
return 1;fi;b=${a:4:2}
if(( b<1||b>12 ));then printf 'invalid month code'
return 1;fi;printf '%s-%s %s' "$c" "$(/bin/date -d 2025-$b-01 '+%B')" "${a::4}";}
ConvertAsSmartDate(){ [[ -n ${1:-} ]]||return
local -i a
local b
a=${1//[!0-9]/}
b=''
case ${#a} in 6)
b=$(/bin/date -d "${a::2}-${a:2:2}-${a:4:2}" "$r_extended_date_format");;7)
b=$(/bin/date -d "${a:1:2}-${a:3:2}-${a:5:2}" "$r_extended_date_format");;8)
b=$(/bin/date -d ${a::4}-${a:4:2}-${a:6:2} "$r_extended_date_format");;10)
b=$(/bin/date -d @"$a" "$r_extended_datetime_format")
esac;if [[ -n $b ]];then printf '%s (%s)' "$1" "$b";else printf '%s' "$1";fi;return;} 2>/dev/null
ConvertNowToFullDate(){ /bin/date "$r_extended_datetime_format";} 2>/dev/null
ConvertNowToSeconds(){ /bin/date +%s;} 2>/dev/null
ConvertNowToMilliseconds(){ ConvertNanosecondsToMilliseconds "$(ConvertNowToNanoseconds)";} 2>/dev/null
ConvertNowToNanoseconds(){ /bin/date +%s%N;} 2>/dev/null
ConvertFirmwareVersionStringToNumber(){ local -i intermediate
local -i major
local -i minor
local -i r_build_trim
local -i r_intermediate_trim
local -i r_major_trim
local -i r_minor_trim
local build
build=0
intermediate=0
major=0
minor=0
r_build_trim=4
r_intermediate_trim=2
r_major_trim=2
r_minor_trim=2
local -r r_build_trim
local -r r_intermediate_trim
local -r r_major_trim
local -r r_minor_trim
while IFS=. read -r major intermediate minor build _;do printf "%0${r_major_trim}d%0${r_intermediate_trim}d%0${r_minor_trim}d%0${r_build_trim}d" "$(( 10#${major:0:r_major_trim} ))" "$(( 10#${intermediate:0:r_intermediate_trim} ))" "$(( 10#${minor:0:r_minor_trim} ))" "$(( 10#${build:0:r_build_trim} ))";done<<<"$1";}
DebugAsFuncEn(){ DebugThis "(>>) ${FUNCNAME[2]}()";}
DebugAsFuncEx(){ DebugThis "(<<) ${FUNCNAME[2]}()${1:-0}|${2:-}";}
DebugAsFuncForkEn(){ DebugThis '(\\) '"${FUNCNAME[2]}()";}
DebugAsFuncForkEx(){ DebugThis "(//) ${FUNCNAME[2]}()${1:-0}|${2:-}";}
DebugAsProc(){ [[ -n ${1:-} ]]&&DebugThis "(--) $1";}
DebugAsProcActionPackageName(){ DebugAsProc "$action $(FormatPackageName) ...";}
DebugAsDone(){ [[ -n ${1:-} ]]&&DebugThis "(==) $1";}
DebugAsDetect(){ [[ -n ${1:-} ]]&&DebugThis "(**) $1";}
DebugAsInfo(){ [[ -n ${1:-} ]]&&DebugThis "(II) $1";}
DebugAsWarn(){ [[ -n ${1:-} ]]&&DebugThis "($(TextBrightOrange WW)) $(TextBrightOrange "$1")";}
DebugAsError(){ [[ -n ${1:-} ]]&&DebugThis "($(TextBrightRed EE)) $(TextBrightRed "$1")";}
DebugAsLog(){ [[ -n ${1:-} ]]&&DebugThis "(LL) $1";}
DebugAsVar(){ [[ -n ${1:-} ]]&&DebugThis "(vv) $1";}
DebugAsArray(){ [[ -n ${1:-} ]]&&DebugThis "(aa) $1";}
DebugAsNA(){ [[ -n ${1:-} ]]&&DebugThis "($(TextDarkGrey NA)) $(TextDarkGrey "$1")";}
DebugThis(){ [[ -n ${1:-} ]]||return
local a
local b
a=dbug
b=$1
[[ ${useropt_verbose:-false} = true ]]&&ShowAsDebug "$b"
if [[ ${useropt_show_about:=false} = false &&${useropt_show_aboutall:=false} = false ]];then WriteToLog "$a" "$b";fi;}
AddExtLogToSessLog(){ local a
local b
a=''
b=false
if IsVerbose;then b=true
useropt_verbose=false;fi;DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(FormatLogFilename "${1:?${FUNCNAME[0]}(): $e_nopfi}")"
while read -r a;do DebugAsLog "$a";done<"$1"
DebugExtLogMinSepr
useropt_verbose=$b;}
ShowAsProcLong(){ [[ -n ${1:-} ]]&&ShowAsProc "${1:-} (might take a while)" "${2:-}";}>&2
ShowAsProc(){ [[ -n ${1:-} ]]||return
local a
local b
local c
local d
a=proc
b=$1
c=''
[[ -n ${2:-} ]]&&c=$2
d="$b ... $c"
if [[ -z ${r_inhibit_display_pathfile:-} ]]||[[ -n ${r_inhibit_display_pathfile:-} &&! -e $r_inhibit_display_pathfile ]];then if [[ ${useropt_verbose:=false} = false &&${useropt_terse:=true} = true ]]||[[ ${useropt_verbose:=false} = false &&-n $c ]];then OpStepClearWait "$(TextBrightYellow "$a")" "$d";else OpStepClear "$(TextBrightYellow "$a")" "$d";fi;fi
WriteToLog "$a" "$d";}>&2
ShowAsDebug(){ [[ -n ${1:-} ]]&&OpStepClear "$(TextBlackOnCyan dbug)" "$1";}
ShowAsNote(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=note
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightYellow "$a")" "$b"
WriteToLog "$a" "$b";}>&2
ShowAsDone(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a='done'
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightGreen "$a")" "$b"
WriteToLog "$a" "$b";}>&2
ShowAsNews(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=news
b=$1
OpStepClear "$(TextBrightWhiteBlink "$a")" "$b"
WriteToLog "$a" "$b";}>&2
ShowAsWarn(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=warn
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightOrange "$a")" "$b"
WriteToLog "$a" "$b";}>&2
ShowAsAbort(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=bort
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError;}>&2
ShowAsFail(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=fail
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b";}>&2
ShowAsError(){ [[ -n ${1:-} ]]||return
PauseSpinner
local a
local b
a=derp
b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError;}>&2
ShowAsBug(){ [[ -n ${1:-} &&-n ${2:-} ]]||return
PauseSpinner
local -i i
local a
local b
local c
a=buug
b='fstack: '
c=' '
for(( i = ${#FUNCNAME[@]} - 1;i>= 0;i-- ));do (( i != ( ${#FUNCNAME[@]} - 1 ) ))&&b+="${c}>${c}"
if [[ ${FUNCNAME[i]} = "$1" ]];then b+="${FUNCNAME[i]}($2)";else b+="${FUNCNAME[i]}()";fi;done;OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError;}>&2
#ShowAsQuiz()
#ShowAsQuizDone()
ShowAsPercentProgress(){ local -i b
local -i c
local -i d
local -i e
local a
local f
a=${1:-}
b=${3:-0}
c=${4:-0}
d=${5:-0}
e=${6:-0}
f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then ShowAsProc "$a" "$f ";else ShowAsProcLong "$a" "$f";fi;(( ( b + c + d )>= e ))&&Pause 0.1
return 0;}>&2
PercFrac(){ local -i a
local -i b
local c
a=${1:-0}+${2:-0}+${3:-0}
b=${4:-0}
c=''
(( b>0 ))||return
if(( a>b ));then a=$b
c='100%';else c=$(( 200 * ( a + 1 ) / ( b + 1 ) % 2 + 100 * ( a + 1 ) / ( b + 1 ) ))%;fi;printf '%s' "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0;} 2>/dev/null
ShowAsIterativeProgress(){ ConfirmVarIsDefined 1 "${1:-}" "$e_noopr"||return
ConfirmVarIsDefined 3 "${3:-}" "$e_nostr"||return
ConfirmVarIsDefined 5 "${5:-}" "$e_nostr"||return
local -i a
local -i b
local c
local d
local e
local f
local old_debug
local old_terse
local old_verbose
a=${2:-0}
b=${4:-0}
c=$1
d=$3
e=$5
f="$(TextBrightWhite "$a") ${d}$(Pluralise "$a") ($(TextBrightWhite "$b") ${e}$(Pluralise "$b"))"
old_debug=$useropt_debug
old_terse=$useropt_terse
old_verbose=$useropt_verbose
useropt_debug=false
useropt_terse=true
useropt_verbose=false
if [[ ${6:-short} != long ]];then ShowAsProc "$c" "$f";else ShowAsProcLong "$c" "$f";fi;useropt_debug=$old_debug
useropt_terse=$old_terse
useropt_verbose=$old_verbose
return 0;}
ShowAsActionLogDetail(){ ConfirmVarIsDefined 2 "${2:-}" "$e_nopnm"||return
ConfirmVarIsDefined 7 "${7:-}" "$e_nostr"||return
local package_type
local quantity_msg
package_type=$7$(Pluralise "$8")
quantity_msg=''
case $8 in 0)
quantity_msg='no ';;1)
:;;*)quantity_msg=$8' '
esac;ConfirmVarIsDefined 8 "${8:-}" "$e_noval"||return
case ${4:-} in er)
if [[ -n "${6:-}" ]];then case $3 in download|?(reas)sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "\"$6\"";;*)if IsQpkgDbWillLog "$2";then DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "for more information: /etc/init.d/$(/usr/bin/basename "$(GetQpkgServicePathFile "$2")") log";else DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "\"$6\"";fi;esac;else DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" 'no reason was provided by the service-script';fi;;sk*)if [[ -n "${6:-}" ]];then DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "$6";else DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "no reason provided";fi;;*)DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" "$5" "$6"
esac;return 0;}
OpStepClearWait(){ local -i n
n=4
[[ $colourful = true ]]&&n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
OpStepClear(){ local -i n
n=4
[[ $colourful = true ]]&&n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
WriteToLog(){ [[ -n ${1:-} &&-n ${2:-} ]]||return
[[ ${useropt_debug:=false} = true &&-n ${session_active_log_pathfile:-} ]]&&printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")">>"$session_active_log_pathfile";}
TextBrightGreen(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;32m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightYellow(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;33m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
#TextBrightYellowBlink()
TextBrightOrange(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;38;5;214m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightOrangeBlink(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;5;38;5;214m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightRed(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;31m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightRedBlink(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;5;31m%s\033[25m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextDarkGrey(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;90m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextOnDarkGrey(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[48;5;233m%s\033[49m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextUnderlinedCyan(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[4;36m%s\033[0m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBlackOnCyan(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[30;46m%s\033[0m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightWhite(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;97m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextBrightWhiteBlink(){ [[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then printf '\033[1;5;97m%s\033[39;22m' "$1";else printf '%s' "$1";fi;} 2>/dev/null
TextUncoloured(){ [[ -n ${1:-} ]]||return
printf '%s' "$1";}
Tableise(){ [[ -x $r_gnu_awk_cmd ]]||return
$r_gnu_awk_cmd '{
nf[NR]=NF
for (i = 1;i<= NF;i++) {
cell[NR,i] = $i
gsub(/\033\[[0-9;]*[mK]/, "", $i)
len[NR,i] = l = length($i)
if (l>max[i]) max[i] = l;};}
END {
for (row = 1;row<= NR;row++) {
for (col = 1;col<nf[row];col++)
printf "%s%*s%s", cell[row,col], max[col]-len[row,col], "", OFS
print cell[row,nf[row]];};}' FS='|' OFS="$(printf "%$(( r_report_column_spacing ))s")";}
StripANSICodes(){ if IsOsSedExtRegexSupported;then echo -en "${1:-}"|/bin/sed -r "$r_regex_strip_ansi"
elif [[ -x /opt/bin/sed &&-L /opt/etc/passwd ]];then echo -en "${1:-}"|/opt/bin/sed -r "$r_regex_strip_ansi";else echo -en "${1:-}";fi;} 2>/dev/null
SetQpkgIndex(){ [[ -n ${qpkg_name:-} ]]||return
SetQpkgArch
for qpkg_index in "${!r_qpkg_name[@]}";do [[ ${r_qpkg_name[qpkg_index]} = "$qpkg_name" ]]||continue
return 0;done;qpkg_index=0
return 1;}
SetError(){ run_package_actions=false
IsError&&return
_script_error_flag_=true
DebugVar _script_error_flag_;}
SetHardwareCpuThreads(){ if [[ ${r_cpu_threads:-unset} = unset ]];then r_cpu_threads=$(GetHardwareCpuThreads)
readonly r_cpu_threads;fi;}
SetHardwareInstalledRAM(){ if [[ ${r_nas_ram_kb:-unset} = unset ]];then r_nas_ram_kb=$(GetHardwareInstalledRAMkb)
readonly r_nas_ram_kb;fi;if [[ ${r_nas_ram_gb:-unset} = unset ]];then r_nas_ram_gb=$(GetHardwareInstalledRAMgb)
readonly r_nas_ram_gb;fi;}
SetHardwarePlatform(){ if [[ ${r_nas_platform:-unset} = unset ]];then r_nas_platform=$(GetHardwarePlatform)
readonly r_nas_platform;fi;}
SetCapabilities(){ SetColourisation
UpdateOsSedRegexSupport;}
SetColourisation(){ colourful=$r_colourful_default
SendParentCommand "colourful=$colourful";}
SetOsSedRegexSupport(){ IsOsCanSedExtRegex
sed_ext_regex_supported=$?;}
SetOsKernelPageSize(){ if [[ ${r_kernel_page_size:-unset} = unset ]];then r_kernel_page_size=$(GetOsKernelPageSize)
readonly r_kernel_page_size;fi;}
SetOsFirmwareVersion(){ if [[ ${r_nas_firmware_version:-unset} = unset ]];then r_nas_firmware_version=$(GetOsFirmwareVersion).$(GetOsFirmwareBuild)
readonly r_nas_firmware_version;fi;}
SetOsFirmwareVer(){ if [[ ${r_nas_firmware_ver:-unset} = unset ]];then r_nas_firmware_ver=$(GetOsFirmwareVer)
readonly r_nas_firmware_ver;fi;}
SetOsFirmwareDate(){ if [[ ${r_nas_firmware_date:-unset} = unset ]];then r_nas_firmware_date=$(GetOsFirmwareDate)
readonly r_nas_firmware_date;fi;}
SetNasArch(){ if [[ ${r_nas_arch:-unset} = unset ]];then r_nas_arch=$(GetNasArch)
readonly r_nas_arch;fi;}
SetQpkgArch(){ if [[ ${r_nas_qpkg_arch:-unset} = unset ]];then r_nas_qpkg_arch=$(GetQpkgArch)
readonly r_nas_qpkg_arch;fi;}
UpdateOsSedRegexSupport(){ unset sed_ext_regex_supported
SetOsSedRegexSupport;}
HideCursor(){ [[ ${useropt_verbose:=false} = false ]]&&printf '\033[?25l';}
ShowCursor(){ printf '\033[?25h';}
HideKeystrokes(){ [[ ${useropt_verbose:=false} = false ]]&&IsInTerminal &&/usr/bin/which stty &&stty '-echo';} &>/dev/null
ShowKeystrokes(){ IsInTerminal&&/usr/bin/which stty&&stty 'echo';} &>/dev/null
SetOsPauseMethod(){ [[ ${_pause_method:=unset} = unset ]]||return 0
if [[ -x /bin/usleep ]];then _pause_method='/bin/usleep'
elif /bin/sleep 0.001;then _pause_method='/bin/sleep';fi;[[ $_pause_method != unset ]]||return;} &>/dev/null
Pause(){ SetOsPauseMethod||exit
[[ $_pause_method != unset ]]||return
[[ -n ${1:-} ]]||return
if [[ $1 != "${_pause_previous_duration:=0}" ]];then if [[ $_pause_method = /bin/usleep ]];then _pause_translated_duration=$(ConvertDecimalSecondsToMicroseconds "$1");else _pause_translated_duration=$1;fi;_pause_previous_duration=$1;fi;eval $_pause_method ${_pause_translated_duration:=0};}
ConvertDecimalSecondsToMicroseconds(){ local -i a
local b
a=${1%.*}
b=${1#*.}
[[ $a != "$1" ]]||b=0
b=${b}000000
printf '%s' "$(( a * ( 10 ** 6 ) + 10#${b:0:6} ))";}
RefreshArchive(){ ConfirmVarIsDefined archive_name "${archive_name:-}" "$e_nonam"||return
ConfirmVarIsDefined archive_pathfile "${archive_pathfile:-}" "$e_nopfi"||return
ConfirmVarIsDefined archive_url "${archive_url:-}" "$e_nourl"||return
ConfirmVarIsDefined dont_refresh_pathfile "${dont_refresh_pathfile:-}" "$e_nopfi"||return
ConfirmVarIsDefined target_pathfile "${target_pathfile:-}" "$e_nopfi"||return
FuncInit;local curl_insecure_opt
local download
local downloaded
local extract
local new_archive_checksum
local orig_archive_checksum
curl_insecure_opt=''
download=false
downloaded=false
extract=false
extracted=false
new_archive_checksum=''
orig_archive_checksum=''
if IsFile "$target_pathfile";then DebugAsDetect "'$archive_name' file found";else DebugAsWarn "'$archive_name' file missing";fi;if IsFile "$archive_pathfile";then DebugAsDetect "'$archive_name' archive file found"
orig_archive_checksum=$(GenerateMD5 "$archive_pathfile")
if IsFileRecent "$archive_pathfile" "$r_file_change_threshold_minutes";then DebugAsDetect "'$archive_name' archive file is recent (updated within the last $r_file_change_threshold_minutes minutes)";else DebugAsDetect "'$archive_name' archive file is not recent (has not been updated within the last $r_file_change_threshold_minutes minutes)"
download=true;fi;else DebugAsWarn "'$archive_name' archive file missing ($archive_pathfile)"
download=true;fi;if [[ $download = true &&-e $dont_refresh_pathfile ]];then DebugAsInfo "ignoring request to download because '$dont_refresh_pathfile' exists"
download=false;fi;if [[ $download = true ]];then DebugAsProc "download '$archive_name' archive file ..."
IsOsCanSecureDownload||curl_insecure_opt=' --insecure'
/sbin/curl --silent --location --fail $curl_insecure_opt "$archive_url">"$archive_pathfile" 2>/dev/null
if IsFile "$archive_pathfile";then DebugAsDone 'downloaded OK'
downloaded=true;else DebugAsWarn "download failed ($archive_url)"
IsNtUrl "$archive_url"&&DebugAsWarn "$e_inurl";fi;fi
if IsFile "$archive_pathfile";then new_archive_checksum=$(GenerateMD5 "$archive_pathfile")
if [[ $downloaded = true ]];then if [[ $orig_archive_checksum = "$new_archive_checksum" ]];then DebugAsDetect "downloaded '$archive_name' archive file is same as previous archive";else DebugAsDetect "downloaded '$archive_name' archive file is different to previous archive"
extract=true;fi;else
if [[ $orig_archive_checksum = "$new_archive_checksum" ]];then DebugAsDetect "'$archive_name' archive file is unchanged";else DebugAsDetect "'$archive_name' archive file is different"
extract=true;fi;fi;else DebugAsWarn "'$archive_name' archive file missing ($archive_pathfile)";fi;IsNtFile "$target_pathfile"&&extract=true
if [[ $extract = true &&-e $dont_refresh_pathfile ]];then DebugAsInfo "ignoring request to extract because '$dont_refresh_pathfile' exists"
extract=false;fi;if [[ $extract = true ]];then if IsFile "$archive_pathfile";then DebugAsProc "extract '$archive_name' file from archive file ..."
/bin/tar --extract --gzip --no-same-owner --file="$archive_pathfile" --directory="$r_cache_path"
if IsFile "$target_pathfile";then DebugAsDone 'extracted OK'
extracted=true;else DebugAsWarn 'extraction failed';fi;else DebugAsWarn "no '$archive_name' archive file exists to extract from";fi;fi
if IsNtFile "$target_pathfile";then ShowAsAbort "'$archive_name' file missing, can't continue"
FuncExit 1;exit;fi;if [[ $extracted = true ]];then DebugAsInfo "continue with extracted '$archive_name' file";else DebugAsInfo "continue with original '$archive_name' file";fi;FuncExit;}
LoadObjects(){ [[ ${objects_loaded:=false} = false ]]||return 0
FuncInit;LoadLists
PauseSpinner
ShowAsProc objects
ResumeSpinner
local archive_name
local archive_pathfile
local archive_url
local dont_refresh_pathfile
local extracted
local target_pathfile
archive_name=objects
archive_pathfile=$r_objects_archive_pathfile
archive_url=$r_objects_archive_url
dont_refresh_pathfile=$PWD/dont-refresh-objects
extracted=false
r_objects_epoch=undefined
target_pathfile=$r_objects_pathfile
if ! RefreshArchive;then FuncExit 1;exit;fi;source "$r_objects_pathfile"
objects_loaded=true
readonly r_objects_epoch
DebugVar r_objects_epoch
FuncExit;}
LoadDatabase(){ [[ ${packages_loaded:=false} = false ]]||return 0
FuncInit;LoadObjects
PauseSpinner
ShowAsProc database
ResumeSpinner
local archive_name
local archive_pathfile
local archive_url
local dont_refresh_pathfile
local extracted
local target_pathfile
archive_name=database
archive_pathfile=$r_packages_archive_pathfile
archive_url=$r_packages_archive_url
dont_refresh_pathfile=$PWD/dont-refresh-database
extracted=false
target_pathfile=$r_packages_pathfile
if ! RefreshArchive;then FuncExit 1;exit;fi;[[ $extracted = true ]]&&InitQPKGsStates
r_packages_epoch=undefined
r_qpkg_abbrvs+=('')
r_qpkg_appl_author+=('')
r_qpkg_appl_author_email+=('')
r_qpkg_appl_version+=('')
r_qpkg_author+=('')
r_qpkg_author_email+=('')
r_qpkg_can_backup+=('')
r_qpkg_can_clean+=('')
r_qpkg_can_restart_to_update+=('')
r_qpkg_conflicts_with+=('')
r_qpkg_depends_on+=('')
r_qpkg_description+=('')
r_qpkg_hash+=('')
r_qpkg_is_sherpa_compatible+=('')
r_qpkg_is_unique_unpack+=('')
r_qpkg_max_os_version+=('')
r_qpkg_min_os_version+=('')
r_qpkg_min_ram_kb+=('')
r_qpkg_name+=('')
r_qpkg_opt_depends_on+=('')
r_qpkg_requires_ipks+=('')
r_qpkg_test_for_active+=('')
r_qpkg_url+=('')
r_qpkg_version+=('')
r_qpkg_will_log+=('')
source "$r_packages_pathfile"
packages_loaded=true
readonly r_base_pips
readonly r_base_qpkg_conflicts_with
readonly r_base_qpkg_warnings
readonly r_essential_ipks
readonly r_exclusion_pips
readonly r_packages_epoch
readonly r_qpkg_abbrvs
readonly r_qpkg_appl_author
readonly r_qpkg_appl_author_email
readonly r_qpkg_appl_version
readonly r_qpkg_author
readonly r_qpkg_author_email
readonly r_qpkg_can_backup
readonly r_qpkg_can_clean
readonly r_qpkg_can_restart_to_update
readonly r_qpkg_conflicts_with
readonly r_qpkg_depends_on
readonly r_qpkg_description
readonly r_qpkg_hash
readonly r_qpkg_is_sherpa_compatible
readonly r_qpkg_is_unique_unpack
readonly r_qpkg_max_os_version
readonly r_qpkg_min_os_version
readonly r_qpkg_min_ram_kb
readonly r_qpkg_name
readonly r_qpkg_names_all
readonly r_qpkg_names_dependent
readonly r_qpkg_names_independent
readonly r_qpkg_names_optional
readonly r_qpkg_names_prohibited
readonly r_qpkg_opt_depends_on
readonly r_qpkg_requires_ipks
readonly r_qpkg_test_for_active
readonly r_qpkg_url
readonly r_qpkg_version
readonly r_qpkg_will_log
readonly r_websites
DebugVar r_packages_epoch
QPKGs-GRall:Add "${r_qpkg_names_all[*]}"
QPKGs-GRdependent:Add "${r_qpkg_names_dependent[*]}"
QPKGs-GRindependent:Add "${r_qpkg_names_independent[*]}"
QPKGs-GRoptional:Add "${r_qpkg_names_optional[*]}"
FuncExit;}
StartSpinner(){ IsNtDebug||return
[[ ! -e $r_ani_pid_pathfile ]]||return
ClearAnimationFiles
/bin/touch "$r_ani_pid_pathfile"
_Animator_ &
:;}
PauseSpinner(){ [[ -s ${r_ani_pid_pathfile:-} ]]||return
/bin/touch "$r_ani_end_pathfile"
wait $(<"$r_ani_pid_pathfile") 2>/dev/null
ClearAnimationFiles
/bin/touch "$r_ani_resume_pathfile";}
ResumeSpinner(){ IsNtDebug||return
[[ ! -e $r_ani_pid_pathfile ]]||return
[[ -e $r_ani_resume_pathfile ]]||return
ClearAnimationFiles
/bin/touch "$r_ani_pid_pathfile"
_Animator_ &
:;}
EndSpinner(){ [[ -s ${r_ani_pid_pathfile:-} ]]||return
/bin/touch "$r_ani_end_pathfile"
wait $(<"$r_ani_pid_pathfile") 2>/dev/null
ClearAnimationFiles;}
ClearAnimationFiles(){ /bin/rm -f "$r_ani_end_pathfile" "$r_ani_frame_pathfile" "$r_ani_pid_pathfile" "$r_ani_resume_pathfile";}
ShowAniFrameInColour(){ printf "${r_ani_colour}%s\033[0m" "${1:-$(printf '%*s' "${r_ani_width:=1}" '')}"
printf '%.0s\b' $(eval echo -n "{1..${r_ani_width}}");}
_Animator_(){ [[ -n $r_ani_end_pathfile ]]||exit
(( r_ani_first_frame>0 ))||exit
(( r_ani_last_frame>0 ))||exit
(( 10#${r_ani_frame_duration/./}>0 ))||exit
(( ${#r_ani_chars[@]}>2 ))||exit
(( r_ani_frame_step>0 ))||exit
local -i ani_start_frame
local -i n
ani_start_frame=1
SaveAniPid
if [[ -e $r_ani_frame_pathfile ]];then ani_start_frame=$(<"$r_ani_frame_pathfile")
/bin/rm -f "$r_ani_frame_pathfile";fi;while true;do for(( n = r_ani_first_frame;r_ani_frame_step>0 ? n<= r_ani_last_frame : n>= r_ani_last_frame;n += r_ani_frame_step ));do if(( ani_start_frame>= 2 ));then n=$ani_start_frame
ani_start_frame=1;fi;if [[ -e $r_ani_end_pathfile ]];then echo "$n">"$r_ani_frame_pathfile"
ShowAniFrameInColour ''
exit;fi;ShowAniFrameInColour "${r_ani_chars[n-1]}"
Pause "$r_ani_frame_duration";done;done;}
SaveAniPid(){ [[ -n $r_ani_pid_pathfile ]]||return
GetSubshellPid>"$r_ani_pid_pathfile"
[[ -s $r_ani_pid_pathfile ]]||return;}
GetSubshellPid(){ (exec /bin/sh -c 'echo "$PPID"');}
IsSiteUp(){ ConfirmVarIsDefined 1 "${1:-}" "$e_nourl"||return
local -i n
local a
a=$(/usr/bin/cut -d'/' -f3<<<"$1"|/usr/bin/cut -d':' -f1)
ConfirmVarIsDefined a "${a:-}" "$e_nourl"||return
for(( n = 0;n<= 2;n++ ));do /bin/ping -c 1 -w 1 "$a"&&return 0
Pause 0.5;done;return 1;} &>/dev/null
LoadQpkgDbCertDetails(){ db_qpkg_cert=$(GetQpkgDbCert)||return
db_qpkg_cert_startdate_epoch=$(GetQpkgDbCertStartDateEpoch)
db_qpkg_cert_enddate_epoch=$(GetQpkgDbCertEndDateEpoch)
db_qpkg_cert_startdate=$(GetQpkgDbCertStartDate)
db_qpkg_cert_enddate=$(GetQpkgDbCertEndDate)
db_qpkg_cert_issuer=$(GetQpkgDbCertIssuer);}
PrintCertValidStatus(){ IsQpkgDbCertValid&&printf yes||printf no;}
IsQpkgDbCertValid(){ local -i now_epoch
now_epoch=$(ConvertNowToSeconds)
(( ${db_qpkg_cert_startdate_epoch:=0}>0 ))||return
(( ${db_qpkg_cert_enddate_epoch:=0}>0 ))||return
(( ${now_epoch:=0}>0 ))||return
(( db_qpkg_cert_startdate_epoch<= now_epoch&&now_epoch<db_qpkg_cert_enddate_epoch ));}
GetQpkgDbCertStartDate(){ (( ${db_qpkg_cert_startdate_epoch:=0}>0 ))||return
/bin/date -d @$db_qpkg_cert_startdate_epoch;}
GetQpkgDbCertEndDate(){ (( ${db_qpkg_cert_enddate_epoch:=0}>0 ))||return
/bin/date -d @$db_qpkg_cert_enddate_epoch;}
GetQpkgDbCertStartDateEpoch(){ [[ -n $db_qpkg_cert ]]||return
/usr/bin/openssl x509 -startdate -noout<<<"$db_qpkg_cert"|/usr/bin/cut -d= -f2-|/bin/date -f - +%s;}
GetQpkgDbCertEndDateEpoch(){ [[ -n $db_qpkg_cert ]]||return
/usr/bin/openssl x509 -enddate -noout<<<"$db_qpkg_cert"|/usr/bin/cut -d= -f2-|/bin/date -f - +%s;}
GetQpkgDbCertIssuer(){ [[ -n $db_qpkg_cert ]]||return
/usr/bin/openssl x509 -issuer -noout<<<"$db_qpkg_cert"|/bin/sed -n 's/.*O=\([^,]*\).*/\1/p';}
GetQpkgDbCert(){ [[ -s $r_cert_db_pathfile ]]||return
[[ -n $qpkg_name ]]||return
local match_column
local pysqlite_command
local query
local select_column
local table
local uri
match_column=QpkgName
select_column=Cert
table=Certificate
query="SELECT $select_column FROM $table WHERE $match_column = ?"
uri="file:$r_cert_db_pathfile?mode=ro"
read -r -d '' pysqlite_command<<EOB
import sqlite3
import sys
import ctypes
from ctypes import util
sqlite_path = ctypes.util.find_library('sqlite3')
if sqlite_path:
    sqlite3_lib = ctypes.CDLL(sqlite_path)
    sqlite3_lib.sqlite3_config(17, 1)
conn = sqlite3.connect('$uri')
cursor = conn.cursor()
cursor.execute("""$query""", ('$qpkg_name',))
record = cursor.fetchone()
cursor.close()
conn.close()
if record:
    print record[0]
else:
    sys.exit(1)
EOB
/usr/local/bin/python2 -c "$pysqlite_command";}
CaughtSIGINT(){ trap - SIGINT
[[ -n ${r_inhibit_display_pathfile:-} ]]&&/bin/touch "$r_inhibit_display_pathfile"
[[ -n ${r_abort_actions_pathfile:-} ]]&&/bin/touch "$r_abort_actions_pathfile"
EndSpinner;EraseThisLine;ShowAsAbort 'caught SIGINT'
CloseMsgPipe
exit;}
CaughtEXIT(){ trap - EXIT
CloseIpkArchive
ReleaseLockfile
EndSpinner
ShowKeystrokes
ShowCursor;}
Init||exit
ProcActions
ShowResults
