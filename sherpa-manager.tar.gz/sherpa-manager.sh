#!/usr/bin/env bash
#* Please don't edit this file directly, it was built/modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#* sherpa-manager.sh
#* Copyright (C) 2017-2025 OneCD.
#* Contact:
#*   one.cd.only@gmail.com
#* Description:
#*   This is the management script for the sherpa mini-package-manager.
#*   It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#* Project:
#*	 https://git.io/sherpa
#* Support forums:
#*	 https://community.qnap.com/t/qpkg-sherpa-a-mini-package-manager-cli/1081
#*	 https://forum.qnap.com/viewtopic.php?t=132373
#* Tested on:
#*	 GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	 GNU bash, version 3.2.57(1)-release (x86_64-QNAP-linux-gnu)
#*	 GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	   Copyright (C) 2007 Free Software Foundation, Inc.
#*   ... and periodically on:
#*	 GNU bash, version 5.0.17(1)-release (aarch64-openwrt-linux-gnu)
#*	   Copyright (C) 2019 Free Software Foundation, Inc.
#*	 All scripts are optimised for compatibility with bash 3.2 (via QTS BusyBox). Be-careful reusing code in other shells, as these scripts contain syntax quirks often compatible only with bash.
#* License:
#*   This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
set -o nounset -o pipefail
shopt -s extglob
[[ $- != *m* ]]||set +m
[[ -L /dev/fd ]]||ln -fns /proc/self/fd /dev/fd
readonly r_args_raw=$*
Init(){
HideCursor
HideKeystrokes
LoadConsts
LoadDefaults
ShowAsProc init
IsOsOk||return
IsUserOk||return
SetCapabilities
LoadCMDs
IsCMDsOk||return
LoadEnv||return
ClaimLockfile||return
CreatePaths||return
PrepareArgs
ParseManagementArgs||return
ParseHelpArgs||return
ArchivePriorSessLogs
DebugLogInit
ParseShowArgs||return
ParseListArgs||return
ParseActionArgs||return
ShowTitle
ShowArgSuggestions
CheckQPKGsConflicts||return
CheckQPKGsWarnings
DebugLogEnv
CheckTasks
CheckEnv
AssignQpkgsToActions
return 0;}
ShowResults(){
FuncInit
if [[ $generate_show_report = true ]];then
if [[ $useropt_show_log_last = true ]];then
ReleaseLockfile
ViewLogLast
elif [[ $useropt_show_log_tail = true ]];then
ReleaseLockfile
ViewLogTail
elif [[ $useropt_show_backups = true ]];then
ReleaseLockfile
ReportBackups
elif [[ $useropt_show_dependencies = true ]];then
ReportDependencies
elif [[ $useropt_show_features = true ]];then
ReportFeatures
elif [[ $useropt_show_packages = true ]];then
ReportPackages
elif [[ $useropt_show_repos = true ]];then
ReportRepos
elif [[ $useropt_show_status = true ]];then
ReportStatuses
show_action_results_report=false
fi
fi
if [[ $generate_list_report = true ]];then
if [[ $useropt_list_versions = true ]];then
ReleaseLockfile
ShowVersionsList
else
ShowQPKGLists
fi
fi
if [[ $useropt_paste_log_last = true ]];then
PasteLogLast
elif [[ $useropt_paste_log_tail = true ]];then
PasteLogTail
fi
if [[ $useropt_help_basic = true ]];then
ShowHelpBasic
ShowHelpBasicExamples
fi
if [[ $generate_help_report = true ]];then
ReleaseLockfile
! IsAnsiStrippingSupported&&colourful=false
if [[ $useropt_help_tips = true ]];then
ShowHelpTips
elif [[ $useropt_help_abbreviations = true ]];then
HelpAbbreviations
elif [[ $useropt_help_actions = true ]];then
ShowHelpActions
elif [[ $useropt_help_actions_all = true ]];then
ShowHelpActionsAll
elif [[ $useropt_help_lists = true ]];then
ShowHelpLists
elif [[ $useropt_help_options = true ]];then
ShowHelpOptions
elif [[ $useropt_help_packages = true ]];then
ShowHelpPackages
elif [[ $useropt_help_show = true ]];then
ShowHelpShow
elif [[ $useropt_help_problems = true ]];then
ShowHelpProblems
elif [[ $useropt_help_upgrades = true ]];then
ShowHelpUpgrades
elif [[ $useropt_help_groups = true ]];then
ShowHelpGroups
fi
fi
if [[ $show_action_results_report = true ]];then
ReportAllActionResults
fi
[[ $show_backuploc = true ]]&&ShowHelpBackupLocation
[[ $show_suggest_raise_issue = true ]]&&ShowHelpIssue
DebugInfoMinSepr
DebugScript finished "$(ConvertNowToFullDate)"
DebugScript 'elapsed time' "$(ConvertSecondsToDuration "$(($(ConvertNowToSeconds)-r_script_startseconds))")"
DebugInfoMajSepr
FuncExit
[[ $archive_debug_afterward = true ]]&&ArchiveActiveSessLog
ResetActiveSessLog;}
DebugLogInit(){
DebugInfoMajSepr
DebugScript started "$(ConvertSecondsToFullDate "$r_script_startseconds")"
DebugScript PID "$$"
DebugInfoMinSepr
DebugInfo "Markers: $(Parenthesise '**') detected, $(Parenthesise II) information, $(Parenthesise WW) warning, $(Parenthesise EE) error, $(Parenthesise LL) log file, $(Parenthesise '--') processing,"
DebugInfo "$(Parenthesise '==') done, $(Parenthesise '>>') f entry, $(Parenthesise '<<') f exit, $(Parenthesise aa) array name & values, $(Parenthesise vv) variable name & value,"
DebugInfo "$(Parenthesise '$1') positional argument value"
DebugInfoMinSepr
DebugVar r_this_package_ver
DebugVar r_this_script_ver;}
LoadConsts(){
readonly r_qpkg_disable_timeout_seconds=10
readonly r_qpkg_enable_timeout_seconds=10
readonly r_qpkg_restart_timeout_seconds=1800
readonly r_qpkg_start_timeout_seconds=1500
readonly r_qpkg_status_check_timeout_seconds=15
readonly r_qpkg_stop_timeout_seconds=300
readonly r_report_qpkg_abbreviations_column_width=84
readonly r_report_qpkg_action_column_width=27
readonly r_report_qpkg_active_test_builtin_column_width=9
readonly r_report_qpkg_appl_version_column_width=22
readonly r_report_qpkg_arch_column_width=15
readonly r_report_qpkg_auto_update_column_width=8
readonly r_report_qpkg_can_backup_column_width=8
readonly r_report_qpkg_can_clean_column_width=9
readonly r_report_qpkg_can_start_to_update_column_width=9
readonly r_report_qpkg_dependencies_column_width=29
readonly r_report_qpkg_description_column_width=10
readonly r_report_qpkg_install_date_column_width=20
readonly r_report_qpkg_is_compatible_column_width=11
readonly r_report_qpkg_is_complete_column_width=8
readonly r_report_qpkg_is_enabled_column_width=8
readonly r_report_qpkg_is_installed_column_width=10
readonly r_report_qpkg_is_managed_column_width=8
readonly r_report_qpkg_max_os_version_column_width=8
readonly r_report_qpkg_min_os_version_column_width=8
readonly r_report_qpkg_min_ram_column_width=13
readonly r_report_qpkg_name_column_width=21
readonly r_report_qpkg_opt_dependencies_column_width=29
readonly r_report_qpkg_path_column_width=48
readonly r_report_qpkg_repo_column_width=42
readonly r_report_qpkg_status_column_width=23
readonly r_report_qpkg_tier_column_width=12
readonly r_report_qpkg_version_column_width=19
readonly r_report_lazy_column_width=28
readonly r_debug_log_full_width=100
readonly r_debug_log_first_column_width=9
readonly r_debug_log_second_column_width=24
readonly r_help_desc_indent=3
readonly r_help_syntax_indent=6
readonly r_report_action_result_indent=4
readonly r_report_column_spacing=2
readonly r_report_file_bytes_column_width=14
readonly r_report_file_change_date_column_width=60
readonly r_report_file_name_column_width=35
readonly r_report_footer_name_column_width=14
readonly r_report_highlight_backups_older_than='2 weeks ago'
readonly r_chars_alert='! '
readonly r_chars_attention='* '
readonly r_chars_blank='  '
readonly r_chars_bullet='• '
readonly r_chars_dropend='└─ '
readonly r_chars_normal='- '
readonly r_chars_note='* '
readonly r_chars_regular_prompt='$ '
readonly r_chars_sudo_prompt=$r_chars_regular_prompt'sudo '
readonly r_chars_results='= '
readonly r_chars_super_prompt='# '
readonly r_extended_datetime_format='+%a %-d %b %Y'
readonly r_full_datetime_format=$r_extended_datetime_format' %-I:%M:%S %p %Z'
readonly r_nofile='undefined filename'
readonly r_noname='undefined name'
readonly r_nopackname='undefined package name'
readonly r_nopacktype='undefined package type'
readonly r_nopfile='undefined pathfile'
if IsOsCanSudo;then
if [[ $(GetUserSudoUID) = undefined ]];then
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
else
readonly r_help_syntax_prefix=$r_chars_regular_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_sudo_prompt
fi
else
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
fi
readonly r_entware_packages_last_updated=20250116
readonly r_file_change_threshold_minutes=60
readonly r_log_tail_lines=5000;}
LoadDefaults(){
if IsInTerminal;then
readonly r_colourful_default=true
else
readonly r_colourful_default=false
fi
archive_debug_afterward=false
colourful=$r_colourful_default
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_extended_states=false
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
run_package_actions=false
show_action_results_failed=false
show_action_results_ok=false
show_action_results_report=false
show_action_results_skipped=false
show_action_results_zero=false
show_backuploc=false
show_suggest_raise_issue=false
show_title=true
switch_branch=false
switch_colour=false
switch_report_footer=false
switch_terse=false
title_shown=false
action_msg_pipe_fd=none
backup_stdin_fd=none
proc_counts_path=''
user_branch_value=''
user_report_footer_value=''
user_terse_value=''
useropt_check=false
useropt_debug=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_show=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_list_versions=false
useropt_paste_log_last=false
useropt_paste_log_tail=false
useropt_report_footer=$(LoadSetting ReportFooter true)
useropt_show_about=false
useropt_show_aboutall=false
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_features=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_previous_action_results_report=false
useropt_show_repos=false
useropt_show_status=false
useropt_terse=$(LoadSetting Terse true)
useropt_verbose=false
useropt_branch=$(LoadSetting Git_Branch stable);}
LoadCMDs(){
readonly r_gnu_awk_cmd=/opt/bin/awk
readonly r_gnu_dd_cmd=/opt/bin/dd
readonly r_gnu_find_cmd=/opt/bin/find
readonly r_gnu_grep_cmd=/opt/bin/grep
readonly r_gnu_less_cmd=/opt/bin/less
readonly r_gnu_nice_cmd=/opt/bin/nice
readonly r_gnu_sleep_cmd=/opt/bin/sleep
readonly r_gnu_stty_cmd=/opt/bin/stty
readonly r_gnu_timeout_cmd=/opt/bin/timeout
readonly r_opkg_cmd=/opt/bin/opkg
readonly r_python_cmd=/opt/bin/python
readonly r_python3_cmd=/opt/bin/python3
readonly r_pip_cmd=$r_python3_cmd' -m pip';}
IsCMDsOk(){
IsCriticalFile /bin/awk||return
IsCriticalFile /usr/bin/basename||return
IsCriticalFile /bin/cat||return
IsCriticalFile /sbin/curl||return
IsCriticalFile /bin/df||return
IsCriticalFile /usr/bin/dirname||return
IsCriticalFile /usr/bin/du||return
IsCriticalFile /bin/grep||return
IsCriticalFile /bin/md5sum||return
IsCriticalFile /bin/mknod||return
IsCriticalFile /bin/mktemp||return
IsCriticalFile /bin/ps||return
IsCriticalFile /usr/bin/readlink||return
IsCriticalFile /usr/sbin/screen||return
IsCriticalFile /bin/sh||return
IsCriticalFile /bin/sha1sum||return
[[ ! -e /usr/bin/sort ]]&&ln -s /bin/busybox /usr/bin/sort
IsCriticalFile /usr/bin/tail||return
IsCriticalFile /bin/tar||return
IsCriticalFile /usr/bin/tee||return
IsCriticalFile /bin/uname||return
IsCriticalFile /bin/uniq||return
IsCriticalFile /usr/bin/unzip||return
IsCriticalFile /usr/bin/uptime||return
return 0;}
LoadEnv(){
qpkg_name=sherpa
readonly r_cert_db_pathfile=/etc/config/nas_sign_qpkg.db
SetHardwareCPUCores
SetHardwareInstalledRAM
readonly r_concurrency=$r_cpu_cores
readonly r_entware_type=$(GetQpkgEntwareType)
readonly r_this_package_ver=$(GetQpkgInstalledVer)
args=()
args_incomplete=()
qpkg_default_index=0
qpkg_index=0
readonly r_script_built_epoch='1746595994'
local script_epoch=0
IsNumber $r_script_built_epoch&&script_epoch=$r_script_built_epoch
useropt_branch=$(GetUserGitBranch)
readonly r_objects_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
readonly r_packages_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa.packages'/$useropt_branch/packages.tar.gz
readonly r_this_script_ver=$(ConvertSecondsToDatecode $script_epoch)-$useropt_branch
readonly r_qpkg_bu_path=$(GetUserDefVol)/.qpkg_config_backup
readonly r_this_package_path=$(GetQpkgInstalledPath)
if [[ -z $r_this_package_path||$r_this_package_path = undefined||! -d $r_this_package_path ]];then
ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1
fi
readonly r_cache_path=$r_this_package_path/cache
readonly r_action_times_path=$r_cache_path/action.times
readonly r_ipk_cache_path=$r_cache_path/IPKs
readonly r_ipk_downgrade_path=$r_ipk_cache_path/downgrade
readonly r_ipk_download_path=$r_ipk_cache_path/downloads
readonly r_pip_cache_path=$r_cache_path/PIPs
readonly r_qpkg_cache_path=$r_cache_path/QPKGs
readonly r_qpkg_download_path=$r_qpkg_cache_path/downloads
readonly r_logs_path=$r_this_package_path/logs
readonly r_dependent_qpkgs_list_pathfile=$r_cache_path/dependents
readonly r_independent_qpkgs_list_pathfile=$r_cache_path/independents
readonly r_inhibit_display_pathfile=$r_cache_path/display.inhibit
readonly r_objects_archive_pathfile=$r_cache_path/objects.tar.gz
readonly r_objects_pathfile=$r_cache_path/objects
readonly r_optional_qpkgs_list_pathfile=$r_cache_path/optionals
readonly r_packages_archive_pathfile=$r_cache_path/packages.tar.gz
readonly r_packages_pathfile=$r_cache_path/packages
readonly r_prev_ipk_list_pathfile=$r_ipk_cache_path/ipk.list.save
readonly r_prev_pip_list_pathfile=$r_pip_cache_path/pip.list.save
readonly r_oom_log_pathfile=$r_logs_path/oom.log
readonly r_ram_freeused_pathfile=$r_logs_path/ram.freeused
readonly r_ramfs_freespace_pathfile=$r_logs_path/ramfs.freespace
readonly r_screen_sessions_pathfile=$r_logs_path/screen.sessions
readonly r_session_action_results_pathfile=$r_logs_path/session.action.results.log
readonly r_session_archive_pathfile=$r_logs_path/session.archive.log
readonly r_session_last_pathfile=$r_logs_path/session.last.log
readonly r_session_tail_pathfile=$r_logs_path/session.tail.log
sess_active_pathfile=$r_this_package_path/session.$$.active.log
readonly r_action_counts_path=/var/run/sherpa/actions/counts
readonly r_action_logs_path=/var/log/sherpa/actions/logs
readonly r_async_procs_path=/var/run/sherpa/procs
readonly r_qpkg_states_path=/var/run/sherpa/packages/states
readonly r_report_columns_path=/var/run/sherpa/report/columns
readonly r_report_flags_path=/var/run/sherpa/report/flags
readonly r_reports_path=/var/log/sherpa/reports
readonly r_run_logs_path=/var/run/sherpa/logs
readonly r_abort_actions_pathfile=$r_qpkg_states_path/abort.action
readonly r_action_msg_pipe=$r_qpkg_states_path/action.messages.pipe
readonly r_report_output_pathfile=$r_reports_path/report.ansi
readonly r_external_packages_archive_pathfile=/opt/var/opkg-lists/entware
readonly r_external_packages_pathfile=$r_cache_path/Packages
[[ -e $r_python3_cmd&&! -L $r_python_cmd ]]&&ln -s "$r_python3_cmd" "$r_python_cmd"
rm -f "$r_report_output_pathfile" "$r_ramfs_freespace_pathfile" "$r_inhibit_display_pathfile" 2>/dev/null
if [[ -e $r_gnu_stty_cmd ]]&&IsInTerminal;then
local terminal_dimensions=$($r_gnu_stty_cmd size)
readonly r_sess_rows=${terminal_dimensions% *}
readonly r_sess_columns=${terminal_dimensions#* }
else
readonly r_sess_rows=40
readonly r_sess_columns=156
fi;}
LoadLists(){
[[ ${lists_loaded:=false} = false ]]||return 0
unset r_package_tiers
unset r_qpkg_tiers
unset r_qpkg_basic_states
unset r_qpkg_extended_states
unset r_qpkg_is_groups
unset r_qpkg_is_states
unset r_qpkg_isnt_groups
unset r_qpkg_isnt_states
unset r_qpkg_service_results
unset r_qpkg_transient_states
unset r_qpkg_actions
unset r_ipk_actions
unset r_pip_actions
unset r_user_qpkg_actions
r_package_tiers=(independent auxiliary optional dependent)
r_qpkg_tiers=(independent optional dependent)
r_qpkg_basic_states=(complete enabled installed)
r_qpkg_extended_states=(active backedup downloaded installable missing signed upgradable)
r_qpkg_transient_states=(restarting slow starting stopping unknown)
r_qpkg_is_states=(${r_qpkg_basic_states[*]} ${r_qpkg_extended_states[*]} ${r_qpkg_transient_states[*]})
r_qpkg_isnt_states=(${r_qpkg_basic_states[*]} ${r_qpkg_extended_states[*]} ${r_qpkg_transient_states[*]})
r_qpkg_is_groups=(all canbackup canclean canrestarttoupdate dependent hasdependents independent optional)
r_qpkg_isnt_groups=(canclean)
r_qpkg_service_results=(failed ok)
r_qpkg_actions=(status list rebuild reassign download backup deactivate disable uninstall upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
r_ipk_actions=(downgrade download uninstall upgrade install)
r_pip_actions=(uninstall upgrade install)
r_user_qpkg_actions=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall restore sign status uninstall upgrade)
readonly r_package_tiers
readonly r_qpkg_tiers
readonly r_qpkg_basic_states
readonly r_qpkg_extended_states
readonly r_qpkg_is_groups
readonly r_qpkg_is_states
readonly r_qpkg_isnt_groups
readonly r_qpkg_isnt_states
readonly r_qpkg_service_results
readonly r_qpkg_transient_states
readonly r_qpkg_actions
readonly r_ipk_actions
readonly r_pip_actions
readonly r_user_qpkg_actions
local action=''
for action in "${r_qpkg_actions[@]}" check debug downgrade update;do
readonly r_"$(Lowercase "$action")"_log_file=$action.log
done
lists_loaded=true;}
CreatePaths(){
ClearPath /var/run/sherpa "$r_async_procs_path"
ClearPath "$r_cache_path" "$r_ipk_cache_path"
ClearPath "$r_cache_path" "$r_ipk_download_path"
ClearPath "$r_cache_path" "$r_pip_cache_path"
ClearPath /var/run/sherpa/report "$r_report_columns_path"
ClearPath /var/run/sherpa/report "$r_report_flags_path"
MakePath "$r_action_counts_path" 'action counts'||return
MakePath "$r_action_logs_path" 'action logs'||return
MakePath "$r_action_times_path" 'action times'||return
MakePath "$r_async_procs_path" 'asynchronous process tracking'||return
MakePath "$r_cache_path" cache||return
MakePath "$r_ipk_cache_path" 'IPK cache'||return
MakePath "$r_ipk_downgrade_path" 'IPK downgrade'||return
MakePath "$r_ipk_download_path" 'IPK download'||return
MakePath "$r_logs_path" logs||return
MakePath "$r_pip_cache_path" 'PIP cache'||return
MakePath "$r_qpkg_bu_path" 'QPKG backup'||return
MakePath "$r_qpkg_cache_path" 'QPKG cache'||return
MakePath "$r_qpkg_download_path" 'QPKG download'||return
MakePath "$r_qpkg_states_path" states||return
MakePath "$r_report_columns_path" 'report columns'||return
MakePath "$r_report_flags_path" 'report flags'||return
MakePath "$r_reports_path" reports||return
MakePath "$r_run_logs_path" 'run logs'||return;}
DebugLogEnv(){
if [[ $useropt_show_about = false&&$useropt_show_aboutall = false ]];then
[[ $run_package_actions = true ]]||return 0
[[ $useropt_debug = true ]]||return 0
fi
FuncInit
ShowAsProc 'log env'
if [[ $useropt_show_about = true||$useropt_show_aboutall = true ]];then
useropt_debug=true
useropt_verbose=true
fi
DebugInfoMinSepr
SetNasArch
DebugHardware ok 'NAS model' "$(get_display_name)"
DebugHardware ok CPU "$(GetHardwareCPUInfo)"
DebugHardware ok 'CPU cores' "$r_cpu_cores"
DebugHardware ok 'CPU architecture' "$r_nas_arch"
DebugHardware ok 'basic CPU SHA1 benchmark' "$(GetHardwareCPUBenchmark)"
DebugHardware ok RAM "$(FormatAsThous "$r_nas_ram_kb")kiB"
DebugKernel ok name "$(GetOsKernelName)"
DebugKernel ok version "$(GetOsKernelVersion)"
if IsOsStdKernelPageSize;then
DebugKernel ok 'page size' "$r_kernel_page_size"
else
DebugKernel warning 'page size' "$r_kernel_page_size"
fi
DebugFirmware ok OS "$(GetOsName)"
SetOsFirmwareVersion
SetOsFirmwareBuild
if IsOsSupported;then
DebugFirmware ok version "$r_nas_firmware_version.$r_nas_firmware_build"
else
DebugFirmware warning version "$r_nas_firmware_version"
fi
SetOsFirmwareDate
if IsOsCompatibleWithSigned;then
DebugFirmware ok 'build date' "$(ConvertAsSmartDate "$r_nas_firmware_date")"
else
DebugFirmware warning 'build date' "$(ConvertAsSmartDate "$r_nas_firmware_date")"
fi
SetHardwarePlatform
DebugFirmware ok platform "$r_nas_platform"
if IsOsOnline;then
DebugOS ok state online
else
DebugOS warning state "$(GetOsState)"
fi
DebugOS ok uptime "$(GetOsUptime)"
if IsOsLoadAverageElevated;then
DebugOS warning 'load averages' "$(GetOsSysLoadAverages)"
else
DebugOS ok 'load averages' "$(GetOsSysLoadAverages)"
fi
DebugStorage ok 'default volume mounted' "$(GetUserDefVol)"
DebugStorage ok 'basic write benchmark' "$(GetHardwareVolumeBenchmark)"
DebugStorage ok /opt "$(/usr/bin/readlink /opt 2>/dev/null||printf 'not present')"
local public_share_name=$(/sbin/getcfg SHARE_DEF defPublic -d Qpublic -f /etc/config/def_share.info)
if [[ -L /share/$public_share_name ]];then
DebugStorage ok "'$public_share_name' share" /share/$public_share_name
else
DebugStorage warning "'$public_share_name' share" 'not present'
fi
DebugUserspace ok libc "$(GetUserLIBC)"
DebugUserspace ok 'libc copyright' "$(GetUserLIBCCopyright)"
if IsOsCanSudo;then
DebugUserspace ok '$SUDO_UID' "$(GetUserSudoUID)"
else
DebugUserspace ok '$SUDO_UID' N/A
fi
DebugUserspace ok '$EUID' "$EUID"
DebugUserspace ok '$SHELL' "$(GetShell)"
DebugShell ok version "$(GetShellVersion)"
DebugShell ok copyright "$(GetShellCopyright)"
DebugShell ok options "$-"
DebugShell ok 'time in shell' "$(GetShellTimeIn)"
DebugScript 'QPKG version' "$(ConvertAsSmartDate "$r_this_package_ver")"
DebugScript 'manager version' "$r_this_script_ver"
DebugScript 'manager epoch' "$(ConvertAsSmartDate "$r_script_built_epoch")"
DebugScript 'objects epoch' "$(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
DebugScript 'packages epoch' "$(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
DebugScript 'logs path' "$r_logs_path"
LocateSQLiteBinary
DebugScript "'sqlite3' binary" "$sqlite_cmd"
if IsOsCanUnofficialPackages;then
if IsOsAllowUnofficialPackages;then
DebugQpkg detect 'allow unofficial' yes
else
DebugQpkg warning 'allow unofficial' no
fi
else
DebugQpkg detect 'allow unofficial' N/A
fi
if IsOsCanSignedPackages;then
if IsOsAllowUnsignedPackages;then
DebugQpkg detect 'allow unsigned' yes
else
DebugQpkg detect 'allow unsigned' no
fi
else
DebugQpkg detect 'allow unsigned' N/A
fi
SetQpkgArch
DebugQpkg detect architecture "$r_nas_qpkg_arch"
DebugQpkg detect "$(FormatPackageName Entware) type" "$r_entware_type"
if ! IsEntwareUpgradable;then
DebugQpkg detect "$(FormatPackageName Entware) install date" "$(ConvertAsSmartDate "$(GetQpkgInstalledDate Entware)")"
else
DebugQpkg warning "$(FormatPackageName Entware) install date" "$(ConvertAsSmartDate "$(GetQpkgInstalledDate Entware)")"
fi
SetOsFirmwareVer
if IsQpkgInstalled SortMyQPKGs;then
DebugQpkg detect "$(FormatPackageName SortMyQPKGs)" installed
else
if [[ $r_nas_firmware_ver -lt 400||$r_nas_firmware_ver -ge 520 ]];then
DebugQpkg detect "$(FormatPackageName SortMyQPKGs)" 'not installed'
else
DebugQpkg warning "$(FormatPackageName SortMyQPKGs)" 'not installed'
fi
fi
if IsOsCanQpkgTimeout;then
if IsQpkgInstalled IncreaseTimeouts;then
if IsQpkgTimeoutsIncreased;then
DebugQpkg detect "$(FormatPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(FormatPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg warning "$(FormatPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(FormatPackageName IncreaseTimeouts)" N/A
fi
DebugInfoMinSepr
if [[ $useropt_show_about = true ]];then
useropt_debug=false
useropt_verbose=false
return
fi
RunAndLog "/bin/df -h | /bin/grep -iE '^(filesystem|none|tmpfs|devtmpfs|/dev/ram)'" "$r_ramfs_freespace_pathfile"
DebugInfoMinSepr
RunAndLog "/usr/sbin/screen -ls | /bin/sed '/^[[:space:]]*$/d'" "$r_screen_sessions_pathfile" '' 1
DebugInfoMinSepr
RunAndLog '/usr/bin/free' "$r_ram_freeused_pathfile" '' 1
DebugInfoMinSepr
RunAndLog "/bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg" "$r_oom_log_pathfile" '' 1
DebugInfoMinSepr
if [[ $useropt_show_aboutall = true ]];then
useropt_debug=false
useropt_verbose=false
return
fi
FuncExit;}
CheckTasks(){
if [[ $arg_problem = true||$useropt_help_basic = true ]];then
show_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_extended_states=false
run_package_actions=false
fi
[[ $get_qpkg_extended_states = true ]]||return 0
FuncInit
local action=''
local build_extended_states=false
local group=''
local state=''
if [[ $useropt_check = true||$useropt_show_status = true ]];then
build_extended_states=true
elif [[ $useropt_help_abbreviations = true||$useropt_show_backups = true||$useropt_show_dependencies = true||$useropt_show_features = true||$useropt_show_packages = true||$useropt_show_repos = true ]];then
build_extended_states=true
elif [[ $useropt_help_actions = true||$useropt_help_actions_all = true||$useropt_help_basic = true||$useropt_help_groups = true||$useropt_help_lists = true||$useropt_help_options = true||$useropt_help_packages = true||$useropt_help_problems = true||$useropt_help_show = true||$useropt_help_tips = true||$useropt_help_upgrades = true||$useropt_list_versions = true||$useropt_paste_log_last = true||$useropt_paste_log_tail = true||$useropt_show_about = true||$useropt_show_about = true||$useropt_show_previous_action_results_report = true||$useropt_show_log_last = true||$useropt_show_log_tail = true||$switch_branch = true||$switch_colour = true||$switch_report_footer = true||$switch_terse = true ]];then
:
else
LoadDatabase
for action in "${r_user_qpkg_actions[@]}";do
if QPKGs-AC${action}-to.IsAny;then
build_extended_states=true
break
fi
for state in "${r_qpkg_extended_states[@]}";do
case $state in
downloaded)
continue;;
*)if QPKGs.AC${action}IS${state}.IsSet;then
build_extended_states=true
break 2
fi
esac
done
for state in "${r_qpkg_extended_states[@]}";do
case $state in
downloaded)
continue;;
*)if QPKGs.AC${action}ISNT${state}.IsSet;then
build_extended_states=true
break 2
fi
esac
done
done
fi
[[ $build_extended_states = true ]]&&BuildExtendedQPKGsStates
FuncExit;}
CheckEnv(){
[[ $run_package_actions = true ]]||return 0
FuncInit
ShowAsProc 'check env'
local installed_version=''
local target_packages=''
if [[ $(/bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg | /usr/bin/wc -l) -gt 0 ]];then
ShowAsWarn "the $(TextBrightRed 'Out-Of-Memory killer') has been triggered, check for $(TextBrightRed inactive) QPKGs"
fi
SetNasArch
if IsValidQpkgInstalled Entware;then
if [[ $r_entware_type != none ]];then
_UpdateEntwarePackageList_ &
else
DebugAsWarn "$(FormatPackageName Entware) appears to be installed but is inactive. Please consider starting the $(FormatPackageName Entware) QPKG."
fi
if [[ $useropt_check = true ]]||QPKGs-ACupgrade-to.Exist Entware;then
ipks_install=true
ipks_upgrade=true
pips_install=true
fi
SetQpkgArch
case $r_nas_qpkg_arch in
a41)
if IsOsNonStdKernelPageSize;then
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($r_opkg_cmd list-installed | /bin/grep "^${target_packages%% *} *" | head -n1 | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]];then
ipks_downgrade=true
ShowAsNote "various IPKs will be downgraded to suit $r_kernel_page_size kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
fi
esac
fi
BuildQPKGsIsCanBackup
BuildQPKGsIsCanRestartToUpdate
BuildQPKGsIsCanClean
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-ISupgradable.Exist sherpa;then
ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded"
QPKGs-ACupgrade-to:Add sherpa
fi
wait 2>/dev/null
FuncExit;}
AssignQpkgsToActions(){
[[ $run_package_actions = true ]]||return 0
FuncInit
ShowAsProc 'QPKG assignment'
local action=''
local prospect=''
if IsValidQpkgInstalled Entware&&IsOsOnline;then
if IsEntwareUpgradable;then
ShowAsNote "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were last updated in $(ConvertLongDateAsHuman $r_entware_packages_last_updated))"
QPKGs-ACreinstall-to:Add Entware
fi
fi
if QPKGs-ACrebuild-to.IsAny;then
for qpkg_name in $(QPKGs-ACrebuild-to:Array);do
SetQpkgIndex
if IsNtValidQpkgInstalled "$qpkg_name"&&IsQpkgBackupExist;then
QPKGs-ACinstall-to:Add "$qpkg_name"
QPKGs-ACrestore-to:Add "$qpkg_name"
fi
done
fi
for qpkg_name in $(QPKGs-ACinstall-to:Array) $(QPKGs-ACreinstall-to:Array);do
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do
[[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect"&&QPKGs-ACinstall-to:Add "$prospect"
done
done
for qpkg_name in $(GetQpkgsIsValidInstalled);do
if [[ $useropt_check = true ]]||QPKGs-ACactivate-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do
[[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect"&&QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for action in activate deactivate disable enable install reinstall reactivate uninstall upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do
if IsQpkgEnabled "$prospect";then
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACreactivate-to:Add "$prospect"
fi
done
fi
done
done
for action in deactivate uninstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
IsValidQpkgInstalled "$prospect"&&QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
done
if QPKGs-ACreinstall-to.Exist Entware;then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in reinstall reactivate upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
done
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect"&&! QPKGs-ACinstall-to.Exist "$prospect"&&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in backup restore upgrade reinstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if IsQpkgEnabled "$qpkg_name";then
QPKGs-ACdeactivate-to:Add "$qpkg_name"
! QPKGs-ACuninstall-to.Exist "$qpkg_name"&&! QPKGs-ACinstall-to.Exist "$qpkg_name"&&QPKGs-ACactivate-to:Add "$qpkg_name"
fi
done
done
for action in reinstall install activate reactivate;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies) $(GetQpkgDbOptionals);do
IsValidQpkgInstalled "$prospect"&&QPKGs-ACreactivate-to:Add "$prospect"
done
done
done
if QPKGs.ACuninstallGRall.IsSet;then
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
QPKGs-ACactivate-to:Remove "$(QPKGs-ACreactivate-to:Array)"
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACinstall-to.Exist "$qpkg_name";then
QPKGs_were_installed_name+=("$qpkg_name")
SetQpkgIndex
QPKGs_were_installed_path+=("$(/usr/bin/dirname "$(GetQpkgInstalledPath)")")
fi
QPKGs-ACdeactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdownload-to:Add "$(QPKGs-ACinstall-to:Array)"
for qpkg_name in $(QPKGs-ACreinstall-to:Array);do
IsValidQpkgInstalled "$qpkg_name"&&QPKGs-ACdownload-to:Add "$qpkg_name"
done
for qpkg_name in $(QPKGs-ACupgrade-to:Array);do
QPKGs-ISupgradable.Exist "$qpkg_name"&&QPKGs-ACdownload-to:Add "$qpkg_name"
done
if [[ $useropt_check = true ]];then
IsOsCanSignedPackages&&QPKGs-ACsign-to:Add "$(GetQpkgsIsValidInstalled)"
for qpkg_name in $(QPKGs-GRdependent:Array);do
IsQpkgEnabled "$qpkg_name"&&QPKGs-ACreactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdeactivate-to:Remove sherpa
QPKGs-ACuninstall-to:Remove sherpa
if QPKGs-ACsign-to.IsAny||QPKGs-ACinstall-to.IsAny;then
LocateSQLiteBinary
LoadQpkgSigningCertDetails
fi
FuncExit;}
ProcActions(){
[[ $run_package_actions = true ]]||return
FuncInit
ShowAsProc 'package actions'
local action=''
local state=''
local tier=''
local -i tier_index=0
rm -f "$r_session_action_results_pathfile" 2>/dev/null
ProcAction status all QPKG 'live status'
if [[ $useropt_show_status = false ]];then
ShowAsProc 'assign QPKGs by state'
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
case $state in
downloaded|installed)
continue;;
*)QPKGs.AC${action}IS${state}.IsSet&&QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
esac
done
for state in "${r_qpkg_isnt_states[@]}";do
case $state in
enabled|downloaded)
continue;;
*)QPKGs.AC${action}ISNT${state}.IsSet&&QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
esac
done
done
fi
ProcAction rebuild all QPKG meta-rebuild
ProcAction reassign all QPKG reassign
ProcAction download all QPKG download
if QPKGs-ACdownload-er.IsNone&&QPKGs-ACdownload-se.IsNone&&QPKGs-ACdownload-sa.IsNone;then
for((tier_index=${#r_package_tiers[@]}-1;tier_index>=0;tier_index--));do
tier=${r_package_tiers[$tier_index]}
if [[ $tier != auxiliary ]];then
ProcAction deactivate $tier QPKG deactivate
ProcAction disableau $tier QPKG 'disable auto-update'
ProcAction backup $tier QPKG backup
ProcAction disable $tier QPKG disable
ProcAction uninstall $tier QPKG uninstall
elif IsQpkgEnabled Entware;then
ModPathToEntware
PIPs:uninstall
IPKs:uninstall
fi
done
for tier in "${r_package_tiers[@]}";do
if [[ $tier != auxiliary ]];then
ProcAction upgrade $tier QPKG upgrade
ProcAction reinstall $tier QPKG reinstall
ProcAction install $tier QPKG install
ProcAction restore $tier QPKG restore
ProcAction enableau $tier QPKG 'enable auto-update'
ProcAction clean $tier QPKG clean
[[ $tier != independent ]]&&ProcAction sign $tier QPKG '"sign"'
ProcAction enable $tier QPKG enable
ProcAction reactivate $tier QPKG reactivate
ProcAction activate $tier QPKG activate
else
for action in status install reinstall upgrade activate;do
if QPKGs-ACinstall-ok.Exist Entware||QPKGs-AC${action}-to.IsAny;then
ipks_downgrade=true
ipks_install=true
ipks_upgrade=true
pips_install=true
break
fi
done
if IsQpkgEnabled Entware;then
ModPathToEntware
IPKs:upgrade
IPKs:install
IPKs:downgrade
PIPs:upgrade
PIPs:install
fi
QPKGs-ACinstall-ok.Exist Entware&&[[ $sqlite_pathfile = /opt/bin/sqlite3&&-e $sqlite_pathfile ]]&&IsOsCanSignedPackages&&QPKGs-ACsign-to:Add "$(GetQpkgsIsValidInstalled)"
ProcAction sign independent QPKG '"sign"'
fi
done
fi
if [[ $useropt_debug = true ]];then
ListQPKGsActions
ListIPKsActions
ListPIPsActions
fi
if [[ $title_shown = true ]];then
if IsNtError;then
ShowAsDone 'actions complete'
else
ShowAsFail 'actions complete with errors'
fi
fi
show_action_results_report=true
FuncExit;}
ProcAction(){
FuncInit
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local package=''
local -i package_index=0
local -r r_action=${1:?${FUNCNAME[0]}'()': undefined action}
local -r r_action_intransitive_msg=${4:?${FUNCNAME[0]}'()': undefined action message}
local -r r_package_type=${3:?${FUNCNAME[0]}'()': $r_nopacktype}
local -r r_tier=${2:?${FUNCNAME[0]}'()': undefined tier}
local re=''
local state=''
local target_object_name=''
local -a target_packages=()
total_count=0
DebugVar r_action
DebugVar r_tier
DebugVar r_package_type
case $r_package_type in
QPKG)
target_object_name=AC${r_action}-to
if [[ $r_tier = all ]];then
target_packages=($(${r_package_type}s-$target_object_name:Array))
else
for package in $(${r_package_type}s-$target_object_name:Array);do
${r_package_type}s-GR${r_tier}.Exist "$package"&&target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]];then
DebugInfo 'nothing to process'
FuncExit;return
fi
if [[ $total_count -eq 1 ]];then
fork_progress_prefix="$r_action_intransitive_msg $(TextBrightOrange "${target_packages[0]}") $r_package_type"
else
fork_progress_prefix="$r_action_intransitive_msg $([[ $r_tier != all ]]&&TextBrightOrange "$r_tier ")$(Uppercase "$r_package_type")$(Pluralise "$total_count")"
fi
SetMaxForks "$r_action"
InitActionForkCounters
OpenActionMsgPipe
re=\\bEntware\\b
if [[ $r_action = uninstall&&${target_packages[*]} =~ $re ]];then
ShowKeystrokes
fi
CreatePidFile
_ExecOneActionWithManyForks_ "_${r_package_type}:${r_action}_" "${target_packages[@]}" &
WritePidFile "$!"
while [[ ${#target_packages[@]} -gt 0&&! -e $r_abort_actions_pathfile ]];do
ReadFromActionMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
env)
eval "$msg1_value";;
change)
while true;do
for state in "${r_qpkg_is_states[@]}";do
case $msg1_value in
"IS${state}")
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]]&&QPKGs-ISNT${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-IS${state}:Init) = function ]]&&QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${r_qpkg_isnt_states[@]}";do
case $msg1_value in
"ISNT${state}")
[[ $(type -t QPKGs-IS${state}:Init) = function ]]&&QPKGs-IS${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]]&&QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_is_groups[@]}";do
case $msg1_value in
"GR${group}")
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]]&&QPKGs-GRNT${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GR${group}:Init) = function ]]&&QPKGs-GR${group}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_isnt_groups[@]}";do
case $msg1_value in
"GRNT${group}")
[[ $(type -t QPKGs-GR${group}:Init) = function ]]&&QPKGs-GR${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]]&&QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break
done;;
status)
case $msg1_value in
ok)
[[ $r_action != status ]]&&((ok_count++));;
so)
((skip_ok_count++));;
sk)
((skip_count++));;
se)
((skip_error_count++));;
sa)
((skip_abort_count++))
/bin/touch "$r_abort_actions_pathfile";;
er)
((fail_count++))
esac
case $msg1_value in
ok|so|sk|se|sa|er)
[[ $(type -t QPKGs-AC${r_action}-to:Init) = function ]]&&QPKGs-AC${r_action}-to:Remove "$msg2_value"
[[ $(type -t QPKGs-AC${r_action}-${msg1_value}:Init) = function ]]&&QPKGs-AC${r_action}-${msg1_value}:Add "$msg2_value"
[[ $(type -t QPKGs-AC${r_action}-dn:Init) = function ]]&&QPKGs-AC${r_action}-dn:Add "$msg2_value";;
ex)
for package_index in "${!target_packages[@]}";do
if [[ ${target_packages[package_index]} = "$msg2_value" ]];then
unset 'target_packages[package_index]'
break
fi
done;;
*)DebugAsWarn "unidentified status in message queue: '$msg1_value'"
esac;;
*)DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
[[ -e $r_abort_actions_pathfile ]]&&break
done
[[ $fail_count -gt 0 ]]&&show_action_results_failed=true
[[ $ok_count -gt 0 ]]&&show_action_results_ok=true
[[ $skip_count -gt 0||$skip_ok_count -gt 0||$skip_error_count -gt 0||$skip_abort_count -gt 0 ]]&&show_action_results_skipped=true
wait 2>/dev/null
CloseActionMsgPipe
[[ ${useropt_terse:=true} = false&&$useropt_verbose = false ]]&&echo;;
IPK|PIP)
if [[ $ipks_downgrade = true||$ipks_install = true||$ipks_upgrade = true||$pips_install = true ]];then
InitActionForkCounters
${r_package_type}s:${r_action}
fi
esac
EraseForkCountPaths
FuncExit
IsNtError;}
OpenActionMsgPipe(){
[[ -p $r_action_msg_pipe ]]&&rm -f "$r_action_msg_pipe"
[[ ! -d $(/usr/bin/dirname "$r_action_msg_pipe") ]]&&mkdir -p "$(/usr/bin/dirname "$r_action_msg_pipe")"
[[ ! -p $r_action_msg_pipe ]]&&/bin/mknod "$r_action_msg_pipe" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd<>$r_action_msg_pipe"
} 2>/dev/null
CloseActionMsgPipe(){
if [[ -n ${backup_stdin_fd:-} ]];then
[[ $backup_stdin_fd != none ]]&&eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]]&&eval "exec $backup_stdin_fd>&-"
fi
[[ -n ${action_msg_pipe_fd:-}&&$action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd>&-"
[[ -n ${r_action_msg_pipe:-}&&-p $r_action_msg_pipe ]]&&rm -f "$r_action_msg_pipe"
} 2>/dev/null
SetMaxForks(){
local default_forks=$r_concurrency
max_forks=$default_forks
[[ -n ${1:-} ]]||return
local reason=''
if [[ $useropt_verbose = true ]];then
max_forks=1
reason='verbose mode is active'
elif [[ $useropt_debug = true ]];then
max_forks=1
reason='debug mode is active'
else
case $1 in
?(re)install|upgrade)
max_forks=1;;
sign)
max_forks=1;;
clean)
max_forks=$(((r_concurrency+1)/2));;
backup|deactivate|download|uninstall)
max_forks=4;;
@(dis|en)able?(au)|rebuild|status)
max_forks=8
esac
[[ $max_forks -ne $default_forks ]]&&reason="'$1' was requested"
fi
[[ -n $reason ]]&&DebugInfo "setting \$max_forks to $max_forks because $reason";}
PrepareArgs(){
ShowAsProc args
local a=$(Lowercase "${r_args_raw//,/ }")
args=(${a/--/})
arg_problem=false
[[ -z $r_args_raw ]]&&useropt_help_basic=true;}
ParseManagementArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
check)
generate_show_report=true
get_qpkg_extended_states=true
requires_group=false
run_package_actions=true
user_action=$arg
useropt_check=true;;
follow|paste|report-footer|terse)
requires_group=true
user_action=$arg;;
debug|verbose)
requires_group=false
user_action=$arg
EnableVerbose
EnableDebugToArchiveAndFile;;
reset)
DeleteSetting Git_Branch
DeleteSetting Terse
Reset
esac
if [[ -n $user_action&&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
if [[ -n $action&&-n $group ]];then
case $action in
follow)
case $group in
?(un)stable)
action=''
awaiting_group=false
run_package_actions=false
switch_branch=true
user_branch_value=$group
WriteBranch;;
*)args_remaining+=("$action")
esac;;
paste)
case $group in
last)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_last=true;;
tail)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_tail=true;;
*)args_remaining+=("$action")
esac;;
report-footer)
case $group in
true|false)
action=''
awaiting_group=false
switch_report_footer=true
user_report_footer_value=$group
WriteReportFooter;;
*)args_remaining+=("$action")
esac;;
terse)
case $group in
true|false)
action=''
awaiting_group=false
switch_terse=true
user_terse_value=$group
WriteTerse;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true&&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit;}
ParseHelpArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
help)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action&&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs|actions|all|all-actions|groups|lists|options|packages|problems|show|tips|upgrades)
[[ -z $action ]]&&action=help
esac
if [[ -n $action&&-n $group ]];then
case $action in
help)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true;;
actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true;;
all|all-actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true;;
groups)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true;;
lists)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true;;
options)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true;;
packages)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true;;
problems)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true;;
show)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_show=true;;
tips)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true;;
upgrades)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true&&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
case $arg in
help)
run_package_actions=false
useropt_help_basic=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]]&&tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit;}
ParseShowArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
show)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action&&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
about|about-all|abs|backups|dependent|features|last|packages|repositories|results|status|tail)
[[ -z $action ]]&&action=show
esac
if [[ -n $action&&-n $group ]];then
case $action in
show)
case $group in
about)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_about=true;;
about-all)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_aboutall=true;;
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_help_abbreviations=true;;
backups)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_backups=true;;
dependent)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true;;
features)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_features=true;;
last)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_last=true;;
packages)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_packages=true;;
repositories)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true;;
results)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_previous_action_results_report=true
show_action_results_report=true;;
status)
LoadObjects
QPKGs.ACstatusGRall:Set
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
useropt_show_status=true;;
tail)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_tail=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true&&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit;}
ParseListArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
list)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action&&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
?(NT)installed|upgradable|versions)
[[ -z $action ]]&&action=list
esac
if [[ -n $action&&-n $group ]];then
case $action in
list)
case $group in
all|?(in)dependent|optional)
LoadObjects
QPKGs.AClistGR${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;
?(NT)active)
LoadObjects
QPKGs.AClistIS${group}:Set
QPKGs.ACstatusISinstalled:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=true
show_title=false;;
?(NT)backedup|?(NT)complete|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AClistIS${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;
versions)
LoadDatabase
action=''
awaiting_group=false
generate_list_report=true
show_title=false
useropt_list_versions=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true&&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit;}
ParseActionArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
[[ -n ${args[*]:-} ]]&&LoadDatabase
for arg in "${args[@]:-}";do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|rebuild|?(re|un)install|restore|sign|upgrade)
requires_group=true
user_action=$arg;;
status)
generate_show_report=true
get_qpkg_extended_states=true
requires_group=true
user_action=$arg
useropt_show_status=true
esac
if [[ -n $user_action&&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg");DebugVar group
if [[ -n $action&&-n $group ]];then
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|@(re|un)install|restore|sign|upgrade)
case $group in
?(NT)active)
LoadObjects
QPKGs.AC${action}IS${group}:Set
QPKGs.ACstatusISinstalled:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac
esac
case $group in
all|canbackup|?(NT)canclean|canrestarttoupdate|?(in)dependent|hasdependents)
LoadObjects
QPKGs.AC${action}GR${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AC${action}IS${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;
*)[[ $action != show ]]||continue
LoadObjects
QPKGs-AC${action}-to:Add "$group"
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true&&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
action=$(MatchVerb "$arg")
case $action in
status)
LoadObjects
QPKGs.ACstatusISinstalled:Set
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]]&&tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit;}
MatchVerb(){
local a=${1:-}
case $a in
activate|start)
printf activate;;
add|install)
printf install;;
backup|clean|@(dis|en)able|follow|help|list|paste|reassign|rebuild|reinstall|reset|restore|sign|terse)
printf '%s' "$a";;
report-footer?(s))
printf report-footer;;
c|check)
printf check;;
deactivate|stop)
printf deactivate;;
d?(e)bug)
printf debug;;
disable-auto-update)
printf disableau;;
enable-auto-update)
printf enableau;;
reactivate|restart)
printf reactivate;;
remove|rm|uninstall)
printf uninstall;;
s|status?(es))
printf status;;
show|view)
printf show;;
update|upgrade)
printf upgrade;;
v|verbose)
printf verbose
esac;}
MatchNoun(){
local a=${1:-}
case $a in
a|abs|abbreviations)
printf abs;;
about|about-all|backedup|canbackup|complete|installable|installed|missing|results|show|?(un)stable)
printf '%s' "$a";;
action?(s))
printf actions;;
action?(s)-all|all-action?(s))
printf all-actions;;
active|n?(o)@(n|t)?(-)inactive|n?(o)@(n|t)?(-)stopped|started)
printf active;;
all|entire|everything)
printf all;;
b|backups)
printf backups;;
d|deps|dependencies|dependent?(s))
printf dependent;;
disable|false|no|off|unset)
printf false;;
disabled|n?(o)@(n|t)?(-)enabled)
printf NTenabled;;
enable|on|set|true|yes)
printf true;;
enabled|n?(o)@(n|t)?(-)disabled)
printf enabled;;
f|features)
printf features;;
group?(s))
printf groups;;
inactive|n?(o)@(n|t)?(-)active|n?(o)@(n|t)?(-)started|stopped)
printf NTactive;;
indep?(endent)?(s))
printf independent;;
l|last)
printf last;;
list?(s))
printf lists;;
log|tail)
printf tail;;
me|problem?(s))
printf problems;;
new|updat?(e)able|upgrad@(a|e)ble)
printf upgradable;;
no@(n|t)-back?(ed)up)
printf NTbackedup;;
n?(o)@(n|t)?(-)installable)
printf NTinstallable;;
n?(o)@(n|t)?(-)installed)
printf NTinstalled;;
n?(o)@(n|t)?(-)missing)
printf NTmissing;;
n?(o)@(n|t)?(-)upgradable)
printf NTupgradable;;
@(in|nt|not)?(-)complete)
printf NTcomplete;;
o|option?(s))
printf options;;
optional?(s))
printf optional;;
p|package?(s)|qpkg?(s))
printf packages;;
r|repos|repositories)
printf repositories;;
s|status?(es))
printf status;;
tip?(s))
printf tips;;
upgrade?(s)|upgrading)
printf upgrades;;
version?(s))
printf versions;;
*)QpkgMatchAbbrv "$a"
esac;}
ShowArgSuggestions(){
FuncInit
local arg=''
local -a args_remaining=()
ResetReportsPath &>/dev/null
if [[ ${#args_incomplete[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args_incomplete[@]}";do
case $arg in
?(de|re)activate|backup|clean|@(dis|en)able|@(dis|en)able-auto-update|reassign|@(re|un)install|?(re)start|restore|rm|sign|stop)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false;;
terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
DisplayAsProjSynIndentExam '' "$arg enable"
DisplayAsProjSynIndentExam '' "$arg disable"
arg_problem=true
useropt_help_basic=false;;
follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to '$arg' like" "$arg stable"
DisplayAsProjSynIndentExam '' "$arg unstable"
arg_problem=true
useropt_help_basic=false;;
install|rebuild)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg all"
arg_problem=true
useropt_help_basic=false;;
list)
DisplayAsProjSynExam "please provide a valid source to '$arg' like" "$arg installable"
DisplayAsProjSynIndentExam '' "$arg new"
arg_problem=true
useropt_help_basic=false;;
paste)
DisplayAsProjSynExam "please provide a valid source to '$arg' online like" "$arg log"
DisplayAsProjSynIndentExam '' "$arg last"
arg_problem=true
useropt_help_basic=false;;
show)
DisplayAsProjSynExam "please provide a valid source after '$arg' like" "$arg abs"
DisplayAsProjSynIndentExam '' "$arg log"
DisplayAsProjSynIndentExam '' "$arg packages"
DisplayAsProjSynIndentExam '' "$arg results"
arg_problem=true
useropt_help_basic=false;;
upgrade)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg new"
arg_problem=true
useropt_help_basic=false;;
*)arg_problem=true
args_remaining+=("$arg")
esac
done>"$r_report_output_pathfile"
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
ShowAsError "incomplete argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
args_remaining=()
fi
fi
if [[ ${#args[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args[@]}";do
case $arg in
active|all|@(dis|en)abled|started)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "deactivate $arg"
arg_problem=true
useropt_help_basic=false;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all QPKGs, use' 'activate all'
arg_problem=true
useropt_help_basic=false;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed QPKG configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false;;
all-deactivate|deactivate-all)
DisplayAsProjSynExam 'to deactivate all QPKGs, use' 'deactivate all'
arg_problem=true
useropt_help_basic=false;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all QPKGs, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed QPKG configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all QPKGs, use' 'stop all'
arg_problem=true
useropt_help_basic=false;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all QPKGs, use' 'uninstall all'
arg_problem=true
useropt_help_basic=false;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all QPKGs, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false;;
@(dis|en)able|false|off|no|on|true|yes)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "terse $arg"
arg_problem=true
useropt_help_basic=false;;
download)
ShowAsError "'$arg' is not a manual action"
arg_problem=true
useropt_help_basic=false;;
@(in|not-)active|?(in)dependent?(s)|stopped)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "activate $arg"
arg_problem=true
useropt_help_basic=false;;
?(un)stable)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "follow $arg"
arg_problem=true
useropt_help_basic=false;;
*)arg_problem=true
args_remaining+=("$arg")
esac
done>>"$r_report_output_pathfile"
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
ShowAsError "unknown argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
useropt_help_basic=false
fi
fi
[[ -e $r_report_output_pathfile ]]&&/bin/cat "$r_report_output_pathfile"
DebugArray args_incomplete "${args_incomplete[*]:-}"
DebugArray args_remaining "${args_remaining[*]:-}"
FuncExit;}
AllocPackGroupsToAcs(){
FuncInit
ShowAsProc 'match QPKG groups to actions'
local action=''
local group=''
for action in "${r_user_qpkg_actions[@]}";do
for group in "${r_qpkg_is_groups[@]}";do
if QPKGs.AC${action}GR${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GR${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GR$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for group in "${r_qpkg_isnt_groups[@]}";do
if QPKGs.AC${action}GRNT${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GRNT$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit;}
AllocPackStatesToAcs(){
FuncInit
ShowAsProc 'match QPKG states to actions'
local action=''
local check_later=false
local state=''
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
check_later=false
[[ $state = downloaded ]]&&continue
if QPKGs.AC${action}IS${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
elif [[ $state = installed ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsIsInstalled)"
elif [[ $state = enabled ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsIsEnabled)"
else
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any '$state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for state in "${r_qpkg_isnt_states[@]}";do
check_later=false
[[ $state = downloaded ]]&&continue
if QPKGs.AC${action}ISNT${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
elif [[ $state = installed ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsNtInstalled)"
elif [[ $state = enabled ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsNtEnabled)"
else
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any 'not $state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit;}
ResetArchivedLogs(){
if [[ -n $r_logs_path&&-d $r_logs_path ]];then
ClearPath "$r_this_package_path" "$r_logs_path"
echo 'log reset'>"$sess_active_pathfile"
ShowAsDone 'logs cleared'
fi
return 0;}
ResetCachePath(){
if [[ -n $r_cache_path&&-d $r_cache_path ]];then
ClearPath "$r_this_package_path" "$r_cache_path"
ShowAsDone 'package cache cleared'
fi
return 0;}
ResetReportsPath(){
if [[ -n $r_reports_path&&-d $r_reports_path ]];then
ClearPath /var/log/sherpa "$r_reports_path"
ShowAsDone 'reports cleared'
fi
return 0;}
Quiz(){
local a=${1:?${FUNCNAME[0]}'()': undefined prompt}
local b=''
ShowAsQuiz "$a"
[[ -e $r_gnu_stty_cmd ]]&&IsInTerminal&&$r_gnu_stty_cmd igncr
read -rn1 b
[[ -e $r_gnu_stty_cmd ]]&&IsInTerminal&&$r_gnu_stty_cmd -igncr
DebugVar b
ShowAsQuizDone "$a: $b"
case ${b:0:1} in
y|Y)
return 0;;
*)return 1
esac;}
PatchEntwareService(){
local -r r_tab_char=$'\t'
local -r r_prefix='# the following line was inserted by sherpa: https://git.io/sherpa'
local -r r_package_init_pathfile=$(GetQpkgServicePathFile Entware)
local find=''
local insert=''
if /bin/grep -q 'opt.orig' "$r_package_init_pathfile";then
DebugInfo 'patch: do the "/opt shuffle" - already done'
else
find='# sym-link $QPKG_DIR to /opt'
insert='opt_path="/opt";opt_backup_path="/opt.orig";[[ -d "$opt_path" \&\& ! -L "$opt_path" \&\& ! -e "$opt_backup_path" ]] \&\& mv "$opt_path" "$opt_backup_path"'
/bin/sed -i "s|$find|$find\n\n${r_tab_char}${r_prefix}\n${r_tab_char}${insert}\n|" "$r_package_init_pathfile"
find='/bin/ln -sf $QPKG_DIR /opt'
insert='[[ -L "$opt_path" \&\& -d "$opt_backup_path" ]] \&\& cp "$opt_backup_path"/* --target-directory "$opt_path" \&\& rm -r "$opt_backup_path"'
/bin/sed -i "s|$find|$find\n\n${r_tab_char}${r_prefix}\n${r_tab_char}${insert}\n|" "$r_package_init_pathfile"
DebugAsDone 'patch: do the "opt shuffle"'
fi
return 0;}
_UpdateEntwarePackageList_(){
if IsNtCriticalFile $r_opkg_cmd;then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${r_entware_package_list_uptodate:-false} = false ]]||return
local -i z=0
if ! IsFileRecent "$r_external_packages_archive_pathfile" "$r_file_change_threshold_minutes"||[[ ! -f $r_external_packages_archive_pathfile||$useropt_check = true ]];then
DebugAsProc "updating $(FormatPackageName Entware) package list"
RunAndLog "$r_opkg_cmd update" "$r_logs_path/Entware.$r_update_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
DebugAsDone "updated $(FormatPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(FormatPackageName Entware) package list $(FormatExitcode "$z")"
fi
else
DebugInfo "$(FormatPackageName Entware) package list was updated less-than $r_file_change_threshold_minutes minutes ago: skipping update"
fi
IsFile "$r_external_packages_archive_pathfile"&&IsNtFile "$r_external_packages_pathfile"&&OpenIpkArchive
readonly r_entware_package_list_uptodate=true
return 0;}
SaveIpkAndPipList(){
$r_pip_cmd freeze | cut -d'=' -f1>"$r_prev_pip_list_pathfile"
[[ -e $r_prev_pip_list_pathfile ]]&&DebugAsDone "saved current PIP list to $(FormatFileName "$r_prev_pip_list_pathfile")"
$r_opkg_cmd list-installed>"$r_prev_ipk_list_pathfile"
[[ -e $r_prev_ipk_list_pathfile ]]&&DebugAsDone "saved current $(FormatPackageName Entware) IPK list to $(FormatFileName "$r_prev_ipk_list_pathfile")"
} 2>/dev/null
LoadIpkList(){
local name=''
local separator=''
local version=''
if [[ -e $r_prev_ipk_list_pathfile ]];then
DebugInfo "IPKs are being loaded from $(FormatFileName "$r_prev_ipk_list_pathfile")"
while read -r name separator version;do
name=$(Lowercase "$name")
IPKs-ACinstall-to:Add "$name"
done<"$r_prev_ipk_list_pathfile"
fi;}
LoadPipList(){
local name=''
local re=''
if [[ -e $r_prev_pip_list_pathfile ]];then
DebugInfo "PIPs are being loaded from $(FormatFileName "$r_prev_pip_list_pathfile")"
while read -r name;do
name=$(Lowercase "$name")
re=\\b$name\\b
[[ ${r_exclusion_pips[*]} =~ $re ]]||PIPs-ACinstall-to:Add "$name"
done<"$r_prev_pip_list_pathfile"
fi;}
CalcIpkDepsToInstall(){
IsCriticalFile $r_gnu_grep_cmd||return
FuncInit
local complete=false
local -a dep_acc=()
local element=''
local ipk_titles=''
local -i iterations=0
local -r r_iteration_limit=20
local -i pre_exclude_count=0
local pre_exclude_list=''
local req_list=''
local -i requested_count=0
local -a this_list=()
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$(/usr/bin/wc -w<<<"$req_list")
if [[ $requested_count -eq 0 ]];then
DebugAsWarn 'no IPKs requested'
FuncExit 1;return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while [[ $iterations -le $r_iteration_limit ]];do
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
((iterations++))
printf -v ipk_titles '^Package: %s$\|' "${this_list[@]}"
ipk_titles=${ipk_titles%??}
this_list=($($r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$r_external_packages_pathfile" | $r_gnu_grep_cmd -vG '^Section:\|^Version:' | $r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator "$ipk_titles" | $r_gnu_grep_cmd -vG "$ipk_titles" | $r_gnu_grep_cmd -vG '^Package: ' | /bin/sed 's/^Depends: //;s/, /\n/g' | /usr/bin/sort | /bin/uniq))
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
if [[ ${#this_list[@]} -eq 0 ]];then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
if [[ $complete = true ]];then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$r_iteration_limit [$r_iteration_limit]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$(/usr/bin/wc -w<<<"$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]];then
ShowAsProc 'exclude IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do
if [[ $element != 'ca-certs'&&$element != 'python3-gdbm' ]];then
if [[ $element != 'libjpeg' ]];then
if ! $r_opkg_cmd status "$element" | /bin/grep -q "Status:.*installed";then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $r_opkg_cmd status 'libjpeg-turbo' | /bin/grep -q "Status:.*installed";then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
FuncExit;}
CalcIpkDownloadSize(){
FuncInit
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]];then
ShowAsProc "calculate size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($r_gnu_grep_cmd -w '^Package:\|^Size:' "$r_external_packages_pathfile" | $r_gnu_grep_cmd --after-context 1 --no-group-separator ": $(/bin/sed 's/ /$ /g;s/\$ /\$\\\|: /g'<<<"$(IPKs-ACdownload-to:List)")" | /bin/grep '^Size:' | /bin/sed 's/^Size: //'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$((${size_array[*]:-}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
FuncExit;}
IPKs:upgrade(){
[[ $ipks_upgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local desc=''
local fork_pid=''
local -i total_count=0
local -i z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($r_opkg_cmd list-upgradable | cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
dir_size_progress_prefix="upgrade $desc"
_DirSizeMonitor_ &
fork_pid=$!
RunAndLog "$r_opkg_cmd upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$r_logs_path/ipks.$r_upgrade_log_file" log:failure-only
z=$?
KillPID "$fork_pid"
UpdateDirSizeProgress final
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultToLog IPK auxiliary upgrade "$total_count" ok
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultToLog IPK auxiliary upgrade "$total_count" failed "$z"
fi
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:install(){
[[ $ipks_install = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local desc=''
local fork_pid=''
local -i i=0
local previous=''
local -i total_count=0
local -i z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware||([[ $useropt_check = true ]]&&IsValidQpkgInstalled Entware);then
IPKs-ACinstall-to:Add "$r_essential_ipks"
if [[ -e $r_prev_ipk_list_pathfile&&$useropt_check = false ]];then
LoadIpkList
mv -f "$r_prev_ipk_list_pathfile" "$r_prev_ipk_list_pathfile.installing"
fi
fi
if QPKGs.ACinstallGRall.IsSet;then
for qpkg_name in $(QPKGs-GRall:Array);do
SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)"
done
else
for qpkg_name in $(QPKGs-GRall:Array);do
if QPKGs-ACinstall-to.Exist "$qpkg_name"||IsValidQpkgInstalled "$qpkg_name"||(QPKGs-ACreinstall-to.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name");then
SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
dir_size_progress_prefix="install $desc"
_DirSizeMonitor_ &
fork_pid=$!
RunAndLog "$r_opkg_cmd install --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$r_logs_path/ipks.$r_install_log_file" log:failure-only
z=$?
KillPID "$fork_pid"
UpdateDirSizeProgress final
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultToLog IPK auxiliary install "$total_count" ok
HideKeystrokes
SetCapabilities
rm -f "$r_prev_ipk_list_pathfile.installing" 2>/dev/null
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultToLog IPK auxiliary install "$total_count" failed "$z"
if [[ -e $r_prev_ipk_list_pathfile.installing ]];then
mv -f "$r_prev_ipk_list_pathfile.installing" "$r_prev_ipk_list_pathfile"
fi
fi
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:downgrade(){
[[ $ipks_downgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local curl_options=''
local desc=''
local -i fail_count=0
local log_pathfile=''
local name=''
local -i ok_count=0
local package_type=''
local remote_url=''
local -i total_count=0
local url_prefix=''
local url_suffix=''
local -i z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
IsOsCanSecureDownload||curl_options=' --insecure'
if [[ $total_count -gt 0 ]];then
package_type=IPK
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_logs_path/ipks.$r_download_log_file
ShowAsProc "download $desc"
SetQpkgArch
case $r_nas_qpkg_arch in
a41)
if IsOsNonStdKernelPageSize;then
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.38-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$(/usr/bin/basename "$remote_url")
RunAndLog "/sbin/curl${curl_options} --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.39.2-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$(/usr/bin/basename "$remote_url")
RunAndLog "/sbin/curl${curl_options} --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
esac
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
total_count=1
ok_count=0
fail_count=0
desc="$total_count auxiliary ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_logs_path/ipks.$r_downgrade_log_file
ShowAsProc "downgrade $desc"
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
RunAndLog "$r_opkg_cmd install --force-downgrade --cache $r_ipk_cache_path --tmp-dir $r_ipk_downgrade_path $r_ipk_downgrade_path/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultToLog IPK auxiliary downgrade "$ok_count" ok
else
((fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultToLog IPK auxiliary downgrade "$fail_count" failed "$z"
fi
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:uninstall(){
:;}
PIPs:upgrade(){
:;}
PIPs:install(){
[[ $pips_install = true ]]||return
IsQpkgEnabled Entware||return
$r_opkg_cmd status python3-pip | /bin/grep -q "Status:.*installed"||return
IsNtError||return
FuncInit
local desc=''
local exec_cmd=''
local -i fail_count=0
local log_pathfile=$r_logs_path/pips.$r_install_log_file
local -i ok_count=0
local package_type=PIP
local -i total_count=0
local -i z=0
if [[ $useropt_check = true ]]||IPKs-ACinstall-ok.Exist python3-pip;then
PIPs-ACinstall-to:Add "$r_essential_pips"
if [[ -e $r_prev_pip_list_pathfile&&$useropt_check = false ]];then
LoadPipList
mv -f "$r_prev_pip_list_pathfile" "$r_prev_pip_list_pathfile.installing"
fi
((total_count++))
exec_cmd="$r_pip_cmd install --upgrade --no-input $(PIPs-ACinstall-to:List) --cache-dir $r_pip_cache_path --root-user-action=ignore"
desc="$total_count auxiliary PIP$(Pluralise "$total_count")"
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 0 "$total_count"
RunAndLog "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
DebugAsDone "installed $desc"
SaveActionResultToLog PIP auxiliary install "$ok_count" ok
rm -f "$r_prev_pip_list_pathfile.installing" 2>/dev/null
else
((fail_count++))
SaveActionResultToLog PIP auxiliary install "$fail_count" failed "$z"
if [[ -e $r_prev_pip_list_pathfile.installing ]];then
mv -f "$r_prev_pip_list_pathfile.installing" "$r_prev_pip_list_pathfile"
fi
fi
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false&&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
PIPs:uninstall(){
:;}
OpenIpkArchive(){
if [[ ! -e $r_external_packages_archive_pathfile ]];then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
RunAndLog "/usr/local/sbin/7z e -o$(/usr/bin/dirname "$r_external_packages_pathfile") $r_external_packages_archive_pathfile" "$r_cache_path/ipk.archive.extract" log:failure-only
if [[ ! -e $r_external_packages_pathfile ]];then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0;}
CloseIpkArchive(){
rm -f "$r_external_packages_pathfile"
} 2>/dev/null
_ExecOneActionWithManyForks_(){
FuncForkInit
local a=${1:-function null}
shift
local -a c=("$@")
for qpkg_name in "${c[@]}";do
[[ ! -e $r_abort_actions_pathfile ]]||break
while [[ $fork_count -ge $max_forks ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break 2
sleep .2
UpdateActionForkProgress
done
MarkActionForkAsStarted
SetQpkgIndex
(
CreatePidFile
$a &
WritePidFile "$!"
)
DebugAsDone "forked $a() instance for '$qpkg_name'"
UpdateActionForkProgress
done
while [[ $fork_count -gt 0 ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break
sleep .2
UpdateActionForkProgress
done
FuncForkExit;}
_DirSizeMonitor_(){
[[ -d $dir_location&&$dir_bytes -gt 0 ]]||exit
local last_bytes=0
current_bytes=-1
last_active_epoch=0
while [[ $current_bytes -lt $dir_bytes ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break
sleep .2
UpdateDirSizeProgress
if [[ $current_bytes -ne $last_bytes ]];then
last_active_epoch=$(ConvertNowToSeconds)
last_bytes=$current_bytes
fi
done;}
KillPID(){
[[ -n ${1:-}&&$1 -gt 0&&-d /proc/$1 ]]||return
kill -9 "$1"
wait
} &>/dev/null
Reset(){
ResetCachePath
ResetReportsPath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
exit 0;}
WriteBranch(){
local a=''
if [[ $switch_branch = true&&-n $user_branch_value ]];then
for a in unstable stable;do
[[ $a != "$user_branch_value" ]]&&continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then
SaveSetting Git_Branch "$useropt_branch"
else
SaveSetting Git_Branch "$useropt_branch" announce
Reset
fi
switch_branch=false
return
done
ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1
fi;}
WriteReportFooter(){
local a=''
if [[ $switch_report_footer = true&&-n $user_report_footer_value ]];then
for a in true false;do
[[ $a != "$user_report_footer_value" ]]&&continue
useropt_report_footer=$user_report_footer_value
if [[ ${1:-} = silent ]];then
SaveSetting ReportFooter "$useropt_report_footer"
else
SaveSetting ReportFooter "$useropt_report_footer" announce
fi
switch_report_footer=false
return
done
ShowAsAbort "user setting '$user_report_footer_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi;}
WriteTerse(){
local a=''
if [[ $switch_terse = true&&-n $user_terse_value ]];then
for a in true false;do
[[ $a != "$user_terse_value" ]]&&continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then
SaveSetting Terse "$useropt_terse"
else
SaveSetting Terse "$useropt_terse" announce
fi
switch_terse=false
return
done
ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi;}
SaveSetting(){
local a=${1:?${FUNCNAME[0]}'()': $r_noname}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined value}")
case $b in
true|false)
b=$(Uppercase "$b")
esac
/sbin/setcfg sherpa "$a" "$b" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]]&&ShowAsDone "user setting '$a = $b' has been saved";}
LoadSetting(){
local a=${1:?${FUNCNAME[0]}'()': $r_noname}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined default value}")
if [[ ! -e /sbin/getcfg ]];then
printf '%s' "$b"
return
fi
Lowercase "$(/sbin/getcfg sherpa "$a" -d "$b" -f /etc/config/qpkg.conf)";}
DeleteSetting(){
local a=${1:?${FUNCNAME[0]}'()': $r_noname}
/sbin/setcfg -e sherpa "$a" -f /etc/config/qpkg.conf;}
LenANSIDiff(){
local a=${1:-}
local b=$(StripANSICodes "$a")
printf '%s' "$((${#a}-${#b}))"
return 0;}
AddSeparators(){
[[ -z ${1:-} ]]&&return
local a=''
a=$(Trim "$1")
a=${a// /, }
a=${a//!/ }
printf '%s' "$a";}
DisplayAsProjSynExam(){
printf "\n${r_chars_bullet}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf "\n%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsProjSynIndentExam(){
if [[ -n $1	]];then
printf "\n%${r_help_desc_indent}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf '\n'
fi
printf "%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsSynExam(){
printf "\n${r_chars_bullet}%s:\n%${r_help_syntax_indent}s${r_help_syntax_prefix}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}";}
DisplayAsIndentItem(){
printf "%${r_help_desc_indent}s${r_chars_bullet}%s\n" '' "$(Capitalise "${1:-}")";}
DisplayAsIndentQuotedInfoItem(){
if IsOsCanAutowidthTableColumns;then
printf "%${r_help_desc_indent}s%s|%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
else
printf "%${r_help_desc_indent}s%-$((r_report_footer_name_column_width+2+$(LenANSIDiff "${1:-}")))s%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
fi;}
GeneratePacksReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'QPKG name:|Appl. version:|Description:'
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Appl. version:' "$r_report_qpkg_appl_version_column_width"
FormatReportFieldWidth 'Description:' "$r_report_qpkg_description_column_width"
fi
printf '\n';}
_GeneratePacksReportDataLine_(){
local -a column_vars=(app_ver description name notes)
local mode=''
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
app_ver=$(GetQpkgDbApplVer)
description=$(Capitalise "$(GetQpkgDbDesc "$name")")
notes=$(GetQpkgDbNote)
[[ $notes = none ]]&&notes=''
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
if IsQpkgMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
case $mode in
mute)
app_ver_msg=$(FormatReportField "$app_ver" mute)
description_msg=$(FormatReportField "$description" normal_mute)
name_msg=$(FormatReportField "$name" mute);;
highlight)
name_msg=$(FormatReportField "$name" alert);;
*)app_ver_msg=$(FormatReportField "$app_ver")
description_msg=$(FormatReportField "$description" normal)
name_msg=$(FormatReportField "$name")
esac
notes_msg=$notes
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$app_ver_msg|$description_msg"
if [[ -n $notes ]];then
printf "\n%s|%s|%$((${#r_chars_blank}))s$(TextBrightOrange "${r_chars_dropend}${r_chars_note}")%s" '' '' '' "$notes_msg"
fi
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$app_ver_msg" "$r_report_qpkg_appl_version_column_width"
FormatReportFieldWidth "$description_msg" "$r_report_qpkg_description_column_width"
if [[ -n $notes ]];then
printf "\n%$((${#r_chars_blank}+r_report_qpkg_name_column_width+r_report_qpkg_appl_version_column_width+(r_report_column_spacing*2)))s$(TextBrightOrange "${r_chars_dropend}${r_chars_note}")%s" '' "$notes_msg"
fi
fi
printf '\n';}
GenerateStatusReportTitleLine(){
local a='QPKG version'
QPKGs-ISupgradable.IsAny&&a+=' '$(Parenthesise "$(TextBrightOrange new)")
if IsOsCanAutowidthTableColumns;then
printf '%s' "QPKG name:|Status:|Action $(Parenthesise result):|$a:|Appl. version:|Location:"
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Status:' "$r_report_qpkg_status_column_width"
FormatReportFieldWidth "Action $(Parenthesise result):" "$r_report_qpkg_action_column_width"
FormatReportFieldWidth "$a:" "$r_report_qpkg_version_column_width"
FormatReportFieldWidth 'Appl. version:' "$r_report_qpkg_appl_version_column_width"
FormatReportFieldWidth 'Location:' "$r_report_qpkg_path_column_width"
fi
printf '\n';}
_GenerateStatusReportDataLine_(){
local a=''
local -a column_vars=(action app_ver auxiliary name path status ver)
local auxiliary_column=status
local mode=''
local -i n=0
local result=''
local req_alert=false
local req_attention=false
local req_oops=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
app_ver=$(GetQpkgDbApplVer)
name=$qpkg_name
path=$(GetQpkgInstalledPath)
ver=$(GetQpkgInstalledVer)
if IsValidQpkgInstalled;then
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
elif IsQpkgMissing;then
mode=missing
/bin/touch "$r_report_flags_path"/status-missing
elif IsQpkgInstalled;then
if IsNtQpkgComplete "$name";then
mode=incomplete
/bin/touch "$r_report_flags_path"/status-incomplete
elif IsNtQpkgAuthorOk;then
mode=author
/bin/touch "$r_report_flags_path"/status-wrongauthor
fi
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
case $mode in
missing|mute|normal)
if IsQpkgDbSherpaCompatible;then
action=$(GetQpkgServiceAction)
/bin/touch "$r_report_flags_path"/action-$action
if [[ $action = not-found ]];then
if IsOsStartingPackages&&IsQpkgEnabled;then
action=$(TextBrightOrange pending)
/bin/touch "$r_report_flags_path"/action-pending
else
action=$(TextDarkGrey not-found)
fi
fi
result=$(GetQpkgServiceResult)
/bin/touch "$r_report_flags_path"/result-$result
case $result in
aborted|failed)
action+=' '$(Parenthesise "$(TextBrightRed "$result")");;
in-progress)
action+=' '$(Parenthesise "$(TextBrightOrange "$result")");;
ok)
action+=' '$(Parenthesise "$(TextBrightGreen "$(Uppercase "$result")")")
esac
else
action=unsupported
/bin/touch "$r_report_flags_path"/action-unsupported
action=$(TextDarkGrey "$action")
fi;;
*)/bin/touch "$r_report_flags_path"/na
esac
case $mode in
author)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${column_vars[@]}";do
case $a in
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField 'incompatible author' attention_highlight)
req_attention=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
done;;
incomplete)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${column_vars[@]}";do
case $a in
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField 'incomplete installation' attention_highlight)
req_attention=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
done;;
missing)
for a in "${column_vars[@]}";do
case $a in
action)
local ${a}_msg="$(FormatReportField "${!a}")";;
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField missing alert)
req_alert=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" oops)"
req_oops=true
esac
done;;
mute)
path=N/A
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbArchOK;then
auxiliary='not installable, incompatible architecture'
elif ! IsQpkgDbMinOSVerOk||! IsQpkgDbMaxOSVerOk;then
auxiliary="not installable, incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then
auxiliary='not installable, insufficient RAM installed'
fi
if [[ $auxiliary != false ]];then
auxiliary_msg=$(FormatReportField "$auxiliary" alert_mute)
else
auxiliary_msg=$(FormatReportField 'not installed' normal_mute)
fi
ver=$(GetQpkgDbVer)
for a in "${column_vars[@]}";do
case $a in
name|auxiliary|status)
:;;
*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac
done;;
*)for a in "${column_vars[@]}";do
case $a in
name|auxiliary)
:;;
status)
if IsQpkgEnabled "$qpkg_name";then
status_msg+=' '$(TextBrightGreen enabled)
/bin/touch "$r_report_flags_path"/state-enabled
else
status_msg+=' '$(TextBrightRed disabled)
/bin/touch "$r_report_flags_path"/state-disabled
fi
if QPKGs-ISactive.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightGreen active)
/bin/touch "$r_report_flags_path"/status-active
elif QPKGs-ISslow.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightOrange slow)
/bin/touch "$r_report_flags_path"/status-slow
elif QPKGs-ISNTactive.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightRed inactive)
/bin/touch "$r_report_flags_path"/status-inactive
else
status_msg+=' '$(TextBrightOrange unknown)
/bin/touch "$r_report_flags_path"/status-unknown
fi
if QPKGs-ISupgradable.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightOrange upgradable)
fi
status_msg=$(FormatReportField "$(AddSeparators "$status_msg")" normal);;
*)local ${a}_msg="$(FormatReportField "${!a}")"
esac
done
esac
if QPKGs-ISupgradable.Exist "$qpkg_name";then
ver_msg+=' '$(Parenthesise "$(TextBrightOrange "$(GetQpkgDbVer)")")
/bin/touch "$r_report_flags_path"/state-upgradable
fi
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $req_oops = true ]];then
name_msg=$(FormatReportField "$name" oops)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$status_msg|$action_msg|$ver_msg|$app_ver_msg|$path_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$status_msg" "$r_report_qpkg_status_column_width"
FormatReportFieldWidth "$action_msg" "$r_report_qpkg_action_column_width"
FormatReportFieldWidth "$ver_msg" "$r_report_qpkg_version_column_width"
FormatReportFieldWidth "$app_ver_msg" "$r_report_qpkg_appl_version_column_width"
FormatReportFieldWidth "$path_msg" "$r_report_qpkg_path_column_width"
fi
printf '\n';}
GenerateReposReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'QPKG name:|Repository:|Install date:'
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Repository:' "$r_report_qpkg_repo_column_width"
FormatReportFieldWidth 'Install date:' "$r_report_qpkg_install_date_column_width"
fi
printf '\n';}
_GenerateReposReportDataLine_(){
local a=''
local -a column_vars=(assigned_repo auxiliary install_date name)
local auxiliary_column=assigned_repo
local mode=''
local req_alert=false
local req_attention=false
local store_id=$(GetQpkgInstalledStoreID)
[[ $store_id = undefined ]]&&store_id=sherpa
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
if IsQpkgMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsValidQpkgInstalled;then
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
if [[ $store_id = sherpa ]];then
assigned_repo=sherpa
/bin/touch "$r_report_flags_path"/repo-sherpa
else
assigned_repo=$(GetRepoURLFromStoreID "$store_id")
fi
case $mode in
highlight)
auxiliary_msg=$(FormatReportField missing alert)
install_date_msg=$(FormatReportField "$(GetQpkgInstalledDate)" oops)
req_alert=true;;
mute)
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbArchOK;then
auxiliary='not installable, incompatible architecture'
elif ! IsQpkgDbMinOSVerOk;then
auxiliary="not installable, incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then
auxiliary='not installable, insufficient RAM installed'
fi
if [[ $auxiliary != false ]];then
auxiliary_msg=$(FormatReportField "$auxiliary" alert_mute)
else
auxiliary_msg=$(FormatReportField 'not installed' normal_mute)
fi
install_date_msg=$(FormatReportField N/A mute);;
*)case $assigned_repo in
sherpa)
assigned_repo_msg=$(FormatReportField "$assigned_repo" normal_ok);;
undefined)
assigned_repo_msg=N/A
/bin/touch "$r_report_flags_path"/na;;
*)assigned_repo_msg=$(FormatReportField "$assigned_repo" attention_highlight)
/bin/touch "$r_report_flags_path"/repo-other
esac
install_date_msg=$(FormatReportField "$(GetQpkgInstalledDate)")
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$assigned_repo_msg|$install_date_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$assigned_repo_msg" "$r_report_qpkg_repo_column_width"
FormatReportFieldWidth "$install_date_msg" "$r_report_qpkg_install_date_column_width"
fi
printf '\n';}
GenerateAbsReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'QPKG name:|Installed?|Acceptable QPKG name abbreviations and aliases:'
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Installed?' "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth 'Acceptable QPKG name abbreviations and aliases:' "$r_report_qpkg_abbreviations_column_width"
fi
printf '\n';}
_GenerateAbsReportDataLine_(){
local -a column_vars=(abs auxiliary installed name)
local auxiliary_column=installed
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
local mode=''
local req_alert=false
local req_attention=false
local req_notice=false
if IsQpkgMissing;then
mode=highlight
req_alert=true
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
abs=$(AddSeparators "$(GetQpkgDbAbbrvs "$qpkg_name")")
case $mode in
mute)
if ! IsQpkgDbArchOK "$qpkg_name";then
auxiliary='not installable, incompatible architecture'
elif ! IsQpkgDbMinOSVerOk "$qpkg_name";then
auxiliary="not installable, incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk "$qpkg_name";then
auxiliary='not installable, insufficient RAM installed'
fi
if [[ $auxiliary != false ]];then
auxiliary_msg=$(FormatReportField "$auxiliary" alert_mute)
else
abs_msg=$(FormatReportField "$abs" normal_mute)
fi
installed_msg=$(FormatReportField false mute);;
highlight)
abs_msg=$(FormatReportField "$abs" normal_notice)
auxiliary_msg=$(FormatReportField missing alert);;
*)abs_msg=$(FormatReportField "$abs" normal)
installed_msg=$(FormatReportField true)
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/state-notinstallable
elif [[ $req_notice = true ]];then
name_msg=$(FormatReportField "$name" notice)
/bin/touch "$r_report_flags_path"/req-notice
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$installed_msg|$abs_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$abs_msg" "$r_report_qpkg_abbreviations_column_width"
fi
printf '\n';}
GenerateDepsReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'QPKG name:|Dependencies:|Optionals:|Installed?|Enabled?|Complete?|Managed?|Min. RAM:|Min. OS:|Max. OS:|Supported arch?|Installed QPKG author:'
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Dependencies:' "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth 'Optionals:' "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth 'Installed?' "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth 'Enabled?' "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth 'Complete?' "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth 'Managed?' "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth 'Min. RAM:' "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth 'Min. OS:' "$r_report_qpkg_min_os_version_column_width"
FormatReportFieldWidth 'Max. OS:' "$r_report_qpkg_max_os_version_column_width"
FormatReportFieldWidth 'Supported arch?' "$r_report_qpkg_arch_column_width"
FormatReportFieldWidth 'Installed QPKG author:' "$r_report_lazy_column_width"
fi
printf '\n';}
_GenerateDepsReportDataLine_(){
local a=''
local -a column_vars=(author arch auxiliary deps enabled installed complete managed max_os min_os min_ram name opt_deps)
local auxiliary_column=deps
local dep_name=''
local deps_raw=$(GetQpkgDbDependencies "$qpkg_name")
local opt_deps_raw=$(GetQpkgDbOptDependencies "$qpkg_name")
local mode=''
local req_alert=false
local req_attention=false
local req_notice=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
author=$(GetQpkgAuthor)
max_os=$(GetQpkgDbMaxOSVer "$name")
min_os=$(GetQpkgDbMinOSVer "$name")
min_ram=$(GetQpkgDbMinRAM "$name")
IsQpkgDbArchOK&&arch=true
IsQpkgRepoSelfManaged&&managed=true
IsQpkgEnabled "$name"&&enabled=true
IsQpkgComplete "$name"&&complete=true
[[ -z $deps_raw ]]&&deps_raw=none
[[ -z $opt_deps_raw ]]&&opt_deps_raw=none
[[ -n $max_os&&$max_os != none&&${#max_os} -eq 3 ]]&&max_os=${max_os:0:1}.${max_os:1:1}.${max_os:2:1}
[[ -n $min_os&&$min_os != none&&${#min_os} -eq 3 ]]&&min_os=${min_os:0:1}.${min_os:1:1}.${min_os:2:1}
[[ $min_ram != none ]]&&min_ram=$(FormatAsThous "$min_ram")kB
/bin/touch "$r_report_flags_path"/deps
if IsQpkgMissing;then
mode=missing
req_alert=true
elif IsValidQpkgInstalled;then
mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
mode=author
req_attention=true
/bin/touch "$r_report_flags_path"/status-wrongauthor
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
case $mode in
author)
for a in "${column_vars[@]}";do
case $a in
author)
author_msg=$(FormatReportField "$author" attention_highlight);;
auxiliary)
auxiliary_msg=$(FormatReportField 'incompatible author' attention_highlight);;
name)
:;;
*)local ${a}_msg="$(FormatReportField N/A highlight)"
esac
done;;
missing)
auxiliary_msg=$(FormatReportField missing alert);;
mute)
deps=''
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]]&&deps+=' '
deps+=$dep_name
done
else
deps=$deps_raw
fi
opt_deps=''
if [[ $opt_deps_raw != none ]];then
for dep_name in $opt_deps_raw;do
[[ -n $opt_deps ]]&&opt_deps+=' '
opt_deps+=$dep_name
done
else
opt_deps=$opt_deps_raw
fi
/bin/touch "$r_report_flags_path"/na
if IsQpkgDbArchOK;then
arch_msg=$(FormatReportField "$arch" mute)
else
arch_msg=$(FormatReportField "$arch" attention_highlight)
req_attention=true
fi
author_msg=$(FormatReportField N/A mute)
deps_msg=$(FormatReportField "${deps// /, }" mute)
opt_deps_msg=$(FormatReportField "${opt_deps// /, }" mute)
enabled_msg=$(FormatReportField N/A mute)
installed_msg=$(FormatReportField "$installed" mute)
complete_msg=$(FormatReportField N/A mute)
managed_msg=$(FormatReportField N/A mute)
if IsQpkgDbMaxOSVerOk "$qpkg_name";then
max_os_msg=$(FormatReportField "$max_os" mute)
else
max_os_msg=$(FormatReportField "$max_os" attention_highlight)
req_attention=true
fi
if IsQpkgDbMinOSVerOk "$qpkg_name";then
if [[ $min_os != none ]];then
min_os_msg=$(FormatReportField "$min_os" mute)
else
min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true
fi
else
min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true
fi
if IsQpkgDbMinRAMOk "$qpkg_name";then
min_ram_msg=$(FormatReportField "$min_ram" mute)
else
min_ram_msg=$(FormatReportField "$min_ram" attention_highlight)
req_attention=true
fi;;
*)if IsQpkgDbArchOK;then
arch_msg=$(FormatReportField "$arch" ok)
else
arch_msg=$(FormatReportField "$arch" alert)
req_alert=true
fi
author_msg=$(FormatReportField "$author" ok)
deps=''
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]]&&deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
req_notice=true
fi
done
else
deps=$deps_raw
fi
deps_msg=$(FormatReportField "${deps// /, }")
opt_deps=''
if [[ $opt_deps_raw != none ]];then
for dep_name in $opt_deps_raw;do
[[ -n $opt_deps ]]&&opt_deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then
opt_deps+=$(TextBrightGreen "$dep_name")
else
opt_deps+=$dep_name
fi
done
else
opt_deps=$opt_deps_raw
fi
opt_deps_msg=$(FormatReportField "${opt_deps// /, }")
if IsQpkgEnabled;then
enabled_msg=$(FormatReportField "$enabled" ok)
else
enabled_msg=$(FormatReportField "$enabled" notice)
req_notice=true
fi
installed_msg=$(FormatReportField true ok)
if IsQpkgComplete;then
complete_msg=$(FormatReportField "$complete" ok)
else
complete_msg=$(FormatReportField "$complete" notice)
req_notice=true
fi
if IsQpkgRepoSelfManaged;then
managed_msg=$(FormatReportField "$managed" ok)
else
managed_msg=$(FormatReportField "$managed" highlight)
fi
if IsQpkgDbMaxOSVerOk;then
if [[ $max_os != none ]];then
max_os_msg=$(FormatReportField "$max_os" ok)
else
max_os_msg=$(FormatReportField "$max_os")
fi
else
max_os_msg=$(FormatReportField "$max_os" alert)
req_alert=true
fi
if IsQpkgDbMinOSVerOk;then
if [[ $min_os != none ]];then
min_os_msg=$(FormatReportField "$min_os" ok)
else
min_os_msg=$(FormatReportField "$min_os")
fi
else
min_os_msg=$(FormatReportField "$min_os" alert)
req_alert=true
fi
if IsQpkgDbMinRAMOk;then
if [[ $min_ram != none ]];then
min_ram_msg=$(FormatReportField "$min_ram" ok)
else
min_ram_msg=$(FormatReportField "$min_ram")
fi
else
min_ram_msg=$(FormatReportField "$min_ram" alert)
req_alert=true
fi
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/state-notinstallable
elif [[ $req_notice = true ]];then
name_msg=$(FormatReportField "$name" notice)
/bin/touch "$r_report_flags_path"/req-notice
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$deps_msg|$opt_deps_msg|$installed_msg|$enabled_msg|$complete_msg|$managed_msg|$min_ram_msg|$min_os_msg|$max_os_msg|$arch_msg|$author_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$deps_msg" "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth "$opt_deps_msg" "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$enabled_msg" "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth "$complete_msg" "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth "$managed_msg" "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth "$min_ram_msg" "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth "$min_os_msg" "$r_report_qpkg_min_os_version_column_width"
FormatReportFieldWidth "$max_os_msg" "$r_report_qpkg_max_os_version_column_width"
FormatReportFieldWidth "$arch_msg" "$r_report_qpkg_arch_column_width"
FormatReportFieldWidth "$author_msg" "$r_report_lazy_column_width"
fi
printf '\n';}
GenerateFeaturesReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'QPKG name:|Indep?|Opt?|Dep?|Enh?|CanBack?|CanClean?|StartUpd?|AutUpd?|LiveTest?|ArchCompat?|UniqUnpack?'
else
FormatReportFieldWidth 'QPKG name:' "$r_report_qpkg_name_column_width"
FormatReportFieldWidth 'Indep?' "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth 'Opt?' "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth 'Dep?' "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth 'Enh?' "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth 'CanBack?' "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth 'CanClean?' "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth 'StartUpd?' "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth 'AutUpd?' "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth 'LiveTest?' "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth 'ArchCompat?' "$r_report_qpkg_is_compatible_column_width"
FormatReportFieldWidth 'UniqUnpack?' "$r_report_lazy_column_width"
fi
printf '\n';}
_GenerateFeaturesReportDataLine_(){
local a=''
local -a column_vars=(active_test arch_compatible autoupdate auxiliary backup clean independent dependent optional name restart_to_update compatible uniqueunpack)
local auxiliary_column=independent
local mode=''
local req_alert=false
local req_attention=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
if IsQpkgMissing;then
mode=missing
req_alert=true
elif IsValidQpkgInstalled;then
mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
mode=author
req_attention=true
else
mode=mute
fi
case $mode in
author)
auxiliary='incompatible author'
auxiliary_msg=$(FormatReportField "$auxiliary" attention_highlight);;
missing)
auxiliary=missing
auxiliary_msg=$(FormatReportField "$auxiliary" alert);;
mute)
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
IsQpkgDbArchOK&&arch_compatible=true
autoupdate=N/A
IsQpkgDbCanBackup&&backup=true
IsQpkgDbCanClean&&clean=true
IsQpkgDbIndependent&&independent=true
IsQpkgDbDependent&&dependent=true
IsQpkgDbOptional&&optional=true
if IsQpkgDbCanRestartToUpdate;then
restart_to_update=true
elif [[ $name = sherpa ]];then
restart_to_update=true
fi
IsQpkgDbSherpaCompatible&&compatible=true
IsQpkgDbUniqueUnpack&&uniqueunpack=true
for a in "${column_vars[@]}";do
case $a in
auxiliary)
:;;
*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac
done;;
*)auxiliary=''
auxiliary_msg=''
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
IsQpkgDbArchOK&&arch_compatible=true
if IsValidQpkgInstalled&&IsQpkgDbCanRestartToUpdate;then
IsQpkgAutoUpdate&&autoupdate=true
elif [[ $name = sherpa ]];then
autoupdate=true
else
autoupdate=N/A
/bin/touch "$r_report_flags_path"/na
fi
IsQpkgDbCanBackup&&backup=true
IsQpkgDbCanClean&&clean=true
IsQpkgDbIndependent&&independent=true
IsQpkgDbDependent&&dependent=true
IsQpkgDbOptional&&optional=true
if IsQpkgDbCanRestartToUpdate;then
restart_to_update=true
elif [[ $name = sherpa ]];then
restart_to_update=true
fi
IsQpkgDbSherpaCompatible&&compatible=true
IsQpkgDbUniqueUnpack&&uniqueunpack=true
for a in "${column_vars[@]}";do
case $a in
auxiliary)
:;;
*)case ${!a} in
true|N/A)
local ${a}_msg="$(FormatReportField "${!a}")";;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
esac
done
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$independent_msg|$optional_msg|$dependent_msg|$compatible_msg|$backup_msg|$clean_msg|$restart_to_update_msg|$autoupdate_msg|$active_test_msg|$arch_compatible_msg|$uniqueunpack_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$independent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$optional_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$dependent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$compatible_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$backup_msg" "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth "$clean_msg" "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth "$restart_to_update_msg" "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth "$autoupdate_msg" "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth "$active_test_msg" "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth "$arch_compatible_msg" "$r_report_qpkg_is_compatible_column_width"
FormatReportFieldWidth "$uniqueunpack_msg" "$r_report_lazy_column_width"
fi
printf '\n';}
GenerateBacksReportTitleLine(){
if IsOsCanAutowidthTableColumns;then
printf 'Backup file:|Size in bytes:|Backup date:'
else
FormatReportFieldWidth 'Backup file:' "$r_report_file_name_column_width"
FormatReportFieldWidth 'Size in bytes:' "$r_report_file_bytes_column_width"
FormatReportFieldWidth 'Backup date:' "$r_report_file_change_date_column_width"
fi
printf '\n';}
_GenerateBacksReportItemLine_(){
local -a column_vars=(epoch_time file_bytes file_name)
local mode=''
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
epoch_time=${1:-0}
file_name=${2:-}
file_bytes=$(FormatAsThous "${3:-0}")
if [[ ${epoch_time%.*} -lt $(/bin/date --date="${4:-'1 week ago'}" +%s) ]];then
mode=highlight
/bin/touch "$r_report_flags_path"/backup-file-old
else
mode=normal
/bin/touch "$r_report_flags_path"/backup-file-ok
fi
case $mode in
normal)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")")
file_bytes_msg=$(FormatReportField "$file_bytes")
file_name_msg=$(FormatReportField "$file_name" normal);;
highlight)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")" notice)
file_bytes_msg=$(FormatReportField "$file_bytes" oops)
file_name_msg=$(FormatReportField "$file_name" notice)
esac
if IsOsCanAutowidthTableColumns;then
printf '%s' "$file_name_msg|$file_bytes_msg|$epoch_time_msg"
else
FormatReportFieldWidth "$file_name_msg" "$r_report_file_name_column_width"
FormatReportFieldWidth "$file_bytes_msg" "$r_report_file_bytes_column_width"
FormatReportFieldWidth "$epoch_time_msg" "$r_report_file_change_date_column_width"
fi
printf '\n';}
FormatReportField(){
local a=''
local b=''
case ${2:-blank} in
alert)
a=$(TextBrightRedBlink "$r_chars_alert")
b=$(TextBrightRedBlink "$1");;
notice)
a=$(TextBrightRed "$r_chars_alert")
b=$(TextBrightRed "$1");;
normal_notice)
a=$(TextBrightRed "$r_chars_normal")
b=$(TextBrightRed "$1");;
oops)
a=$r_chars_blank
b=$(TextBrightRed "$1");;
attention_highlight)
a=$(TextBrightOrange "$r_chars_attention")
b=$(TextBrightOrange "$1");;
highlight)
a=$r_chars_blank
b=$(TextBrightOrange "$1");;
normal_ok)
a=$r_chars_normal
b=$(TextBrightGreen "$1");;
ok)
a=$r_chars_blank
b=$(TextBrightGreen "$1");;
normal_mute)
a=$(TextDarkGrey "$r_chars_normal")
b=$(TextDarkGrey "$1");;
alert_mute)
a=$(TextDarkGrey "$r_chars_alert")
b=$(TextDarkGrey "$1");;
mute)
a=$r_chars_blank
b=$(TextDarkGrey "$1");;
normal)
a=$r_chars_normal
b=$1;;
*)a=$r_chars_blank
b=$1
esac
printf '%s' "${a}${b}";}
FormatReportFieldWidth(){
[[ -n ${1:-}&&-n ${2:-} ]]||return
[[ $2 -ge 0 ]]||return
printf "%-$(($(LenANSIDiff "$1")+$2+r_report_column_spacing))s" "$1";}
DisplayAsHelpTitle(){
printf '\n%s\n' "${r_chars_bullet}$(Capitalise "${1:-}" | tr -s ' ')";}
DisplayAsHelpTitleHighlighted(){
printf '\n%s\n' "$(TextBrightOrange "${r_chars_bullet}$(Capitalise "${1:-}")")";}
DisplayAsIndentActionResultDurationReason(){
[[ -n ${1:-}&&-n ${2:-} ]]||return
local action=''
local duration=''
case $1 in
disableau)
action='disable auto-update';;
enableau)
action='enable auto-update';;
*)action=$1
esac
[[ -n ${3:-} ]]&&duration=$(ConvertMillisecondsToDuration "$3")
printf "%${r_report_action_result_indent}s" ''
if [[ -z ${4:-} ]];then
printf '%s %s%s' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")"
else
printf '%s %s%s (%s)' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")" "$4"
fi
printf '\n';}
EraseThisLine(){
[[ ${useropt_verbose:=false} = false ]]&&printf '\033[2K\r'
}>&2
Display(){
if [[ -z ${1:-} ]];then
printf '\n'
else
printf '%s\n' "$1"
fi;}
DisplayWait(){
printf '%s' "${1:-}";}
ShowHelpActions(){
DisableDebugToArchiveAndFile
DisplayProcReport actions
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these packages (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'check all application dependencies are installed' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clean local repository files from these packages (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these packages' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these packages. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these packages. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'install these packages' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'reactivate these packages (this will upgrade internal applications where-supported)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign packages to $(ShowAsTitleName). Detach packages previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these packages ('install' packages, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these packages' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'digitally "sign" these QPKGs' "sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these packages' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these packages (this will upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all packages can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpActionsAll(){
DisableDebugToArchiveAndFile
DisplayProcReport 'all actions'
{
ShowHelpBasic
DisplayAsHelpTitle "the 'all' group applies to all QPKGs. If $(ShowAsAction) is 'install all' then all available QPKGs will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all QPKGs (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all QPKGs (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all QPKGs' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all QPKGs. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on QPKG activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all QPKGs. QPKGs must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on QPKG activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (this will upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all QPKGs where backup files exist ('install' QPKGs and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all QPKGs' 'reinstall all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'digitally "sign" all QPKGs' 'sign all'
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'status all'
DisplayAsProjSynIndentExam 'uninstall all QPKGs' 'uninstall all'
DisplayAsProjSynIndentExam 'upgrade all QPKGs (and internal applications where-supported)' 'upgrade all'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpBackupLocation(){
DisplayAsSynExam 'the backup location can be accessed by running' "cd $r_qpkg_bu_path"
return 0;}
ShowHelpBasic(){
DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0;}
ShowHelpBasicExamples(){
{
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show packages'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')"
}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpGroups(){
DisableDebugToArchiveAndFile
DisplayProcReport groups
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only active QPKGs' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only disabled QPKGs' "$(ShowAsAction) disabled"
DisplayAsProjSynIndentExam 'select only enabled QPKGs' "$(ShowAsAction) enabled"
DisplayAsProjSynIndentExam 'select only inactive QPKGs' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installable QPKGs' "$(ShowAsAction) installable"
DisplayAsProjSynIndentExam 'select only installed QPKGs' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing QPKGs (these are partly-installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpIssue(){
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://forum.qnap.com/viewtopic.php?f=320&t=132373')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
Display
return 0;}
ShowHelpLists(){
DisableDebugToArchiveAndFile
DisplayProcReport lists
{
ShowHelpBasic
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available QPKGs' 'list all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed QPKGs' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only QPKGs that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam '' new
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
DisplayAsProjSynIndentExam '' versions
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpShow(){
DisableDebugToArchiveAndFile
DisplayProcReport show
{
ShowHelpBasic
DisplayAsHelpTitle "'show' usage examples:"
DisplayAsProjSynIndentExam 'show QPKG abbreviations' 'show abbreviations'
DisplayAsProjSynIndentExam '' 'show abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'show QPKG dependency report' 'show dependencies'
DisplayAsProjSynIndentExam '' 'show deps'
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'show QPKG repository assignments report' 'show repositories'
DisplayAsProjSynIndentExam '' 'show repos'
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show last session action results' 'show results'
DisplayAsProjSynIndentExam '' results
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpOptions(){
DisableDebugToArchiveAndFile
DisplayProcReport options
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpPackages(){
DisableDebugToArchiveAndFile
DisplayProcReport packages
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for QPKGs will go here:'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpProblems(){
DisableDebugToArchiveAndFile
DisplayProcReport problems
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'activate these QPKGs' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all dependencies exist for installed QPKGs' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clear local repository files from these QPKGs' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'find the live status of each application in these QPKGs' "status $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "s $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpUpgrades(){
DisableDebugToArchiveAndFile
DisplayProcReport upgrades
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for upgrading your QPKGs:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable QPKGs' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'find the live application status of upgradable QPKGs' 'status upgradable'
DisplayAsProjSynIndentExam '' 's upgradable'
DisplayAsProjSynIndentExam '' 's new'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpTips(){
DisableDebugToArchiveAndFile
DisplayProcReport tips
{
ShowHelpBasic
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) QPKGs" 'install all'
DisplayAsProjSynIndentExam "install all installable $(ShowAsTitleName) QPKGs" 'install installable'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive QPKGs' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
ShowHelpBackupLocation
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ViewLogLast(){
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
EraseThisLine
if [[ -e $r_session_last_pathfile ]];then
DisplayFileInViewport "$r_session_last_pathfile" linenumbers
Display
else
ShowAsError 'no last session log to display'
fi
return 0;}
ViewLogTail(){
DisableDebugToArchiveAndFile
ExtractTailFromLog
EraseThisLine
if [[ -e $r_session_tail_pathfile ]];then
DisplayFileInViewport "$r_session_tail_pathfile" linenumbers
Display
else
ShowAsError 'no session log tail to display'
fi
return 0;}
DisplayFileInViewport(){
local filename=${1:-}
local jumptoend=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local showlinenumbers=false
local wraplines=false
if [[ ! -e $filename ]];then
echo "filename $(FormatFileName "$filename") not found"
return 1
fi
case 'linenumbers' in
${2:-}|${3:-}|${4:-})
showlinenumbers=true
esac
case 'jumptoend' in
${2:-}|${3:-}|${4:-})
jumptoend=true
esac
case 'wrap' in
${2:-}|${3:-}|${4:-})
wraplines=true
esac
if [[ $useropt_verbose = true ]];then
if [[ -e /bin/cat ]];then
/bin/cat "$filename"
return
else
echo "$(<$1)"
return
fi
fi
if [[ $(/usr/bin/wc -l<"$filename") -ge $r_sess_rows||$(/usr/bin/wc -L<"$filename") -ge $r_sess_columns ]];then
if [[ -e $r_gnu_less_cmd ]];then
options='--quit-on-intr --tilde --mouse --RAW-CONTROL-CHARS --shift=4 --redraw-on-quit --quit-if-one-screen'
[[ $wraplines = false ]]&&options+=' --chop-long-lines'
[[ $showlinenumbers = true ]]&&options+=' --LINE-NUMBERS'
[[ $jumptoend = true ]]&&options+=' +G'
LESSSECURE=1 $r_gnu_less_cmd "$options" --prompt "$prompt" "$filename"
return
fi
if [[ -e /bin/less ]];then
options='-~'
[[ $wraplines = false ]]&&options+='S'
[[ $showlinenumbers = true ]]&&options+='N'
/bin/less "$options" "$filename"
return
fi
fi
if [[ -e /bin/cat ]];then
[[ $showlinenumbers = true ]]&&options='--number'
/bin/cat "$options" "$filename"
return
elif [[ -e /bin/more ]];then
/bin/more "$filename"
return
fi
echo "$(<$1)"
} 2>/dev/null
PasteLogLast(){
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $r_session_last_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$(/bin/cat --number "$r_session_last_pathfile" | (exec 3<>/dev/tcp/termbin.com/9999;/bin/cat>&3;/bin/cat<&3;exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no last session log found'
fi
return 0;}
PasteLogTail(){
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $r_session_tail_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$(/bin/cat --number "$r_session_tail_pathfile" | (exec 3<>/dev/tcp/termbin.com/9999;/bin/cat>&3;/bin/cat<&3;exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no session log tail found'
fi
return 0;}
GetLogSessStartLine(){
local -i linenum=$(($(/bin/grep -n 'SCRIPT:.*started:' "$r_session_tail_pathfile" | /usr/bin/tail -n${1:-1} | head -n1 | cut -d':' -f1)-1))
[[ $linenum -lt 1 ]]&&linenum=1
printf '%s' "$linenum";}
GetLogSessFinishLine(){
local -i linenum=$(($(/bin/grep -n 'SCRIPT:.*finished:' "$r_session_tail_pathfile" | /usr/bin/tail -n${1:-1} | cut -d':' -f1)+2))
[[ $linenum -eq 2 ]]&&linenum=3
printf '%s' "$linenum";}
ArchiveActiveSessLog(){
[[ -n ${sess_active_pathfile:-}&&-e $sess_active_pathfile ]]&&/bin/cat "$sess_active_pathfile">>"$r_session_archive_pathfile";}
ArchivePriorSessLogs(){
local f=''
for f in "$r_this_package_path"/session.*.active.log;do
if [[ -f $f&&$f != "$sess_active_pathfile" ]];then
/bin/cat "$f">>"$r_session_archive_pathfile"
rm -f "$f"
fi
done
} 2>/dev/null
ResetActiveSessLog(){
rm -f "$sess_active_pathfile"
} 2>/dev/null
ExtractPrevSessFromTail(){
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
local -i start_line=0
ExtractTailFromLog
if [[ -e $r_session_tail_pathfile ]];then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]];do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]]&&break
done
/bin/sed "$start_line,$end_line!d" "$r_session_tail_pathfile">"$r_session_last_pathfile"
else
rm -f "$r_session_last_pathfile"
fi
return 0
} 2>/dev/null
ExtractTailFromLog(){
if [[ -e $r_session_archive_pathfile ]];then
/usr/bin/tail -n${r_log_tail_lines} "$r_session_archive_pathfile">"$r_session_tail_pathfile"
else
rm -f "$r_session_tail_pathfile"
fi
return 0
} 2>/dev/null
InitActionForkCounters(){
MakePath "$r_action_counts_path" 'action fork counters'
proc_counts_path=$(/bin/mktemp -d "$r_action_counts_path"/"${FUNCNAME[1]}"_XXXXXX)
[[ -n ${proc_counts_path:?undefined proc counts path} ]]||return
EraseForkCountPaths
proc_fail_count_path=$proc_counts_path/fail.count
proc_fork_count_path=$proc_counts_path/fork.count
proc_ok_count_path=$proc_counts_path/ok.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_skip_count_path=$proc_counts_path/skip.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
MakePath "$proc_fail_count_path" 'forks failed count'
MakePath "$proc_fork_count_path" 'fork count'
MakePath "$proc_ok_count_path" 'forks completed OK count'
MakePath "$proc_skip_abort_count_path" 'forks skipped-aborted count'
MakePath "$proc_skip_count_path" 'forks skipped count'
MakePath "$proc_skip_error_count_path" 'forks skipped-error count'
MakePath "$proc_skip_ok_count_path" 'forks skipped-OK count'
InitProgress;}
IncrementActionForkIndex(){
local a
((fork_index++))
printf -v a '%02d' "$fork_index"
proc_fail_pathfile=$proc_fail_count_path/$a
proc_fork_pathfile=$proc_fork_count_path/$a
proc_ok_pathfile=$proc_ok_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_skip_pathfile=$proc_skip_count_path/$a;}
RefreshActionForkCounts(){
fork_count=$(FileCountAll "$proc_fork_count_path")
ok_count=$(FileCountAll "$proc_ok_count_path")
skip_count=$(FileCountAll "$proc_skip_count_path")
skip_ok_count=$(FileCountAll "$proc_skip_ok_count_path")
skip_error_count=$(FileCountAll "$proc_skip_error_count_path")
skip_abort_count=$(FileCountAll "$proc_skip_abort_count_path")
fail_count=$(FileCountAll "$proc_fail_count_path")
} &>/dev/null
RefreshDirSizeCount(){
[[ -d $dir_location ]]||exit
IsCriticalFile $r_gnu_find_cmd||exit
current_bytes=$($r_gnu_find_cmd "$dir_location" -type f -name '*.ipk' -exec /usr/bin/du --bytes --total --apparent-size {} + 2>/dev/null | /bin/grep total$ | cut -f1)
[[ -z $current_bytes ]]&&current_bytes=0
} &>/dev/null
EraseForkCountPaths(){
ClearPath "$r_action_counts_path" "$proc_counts_path"
[[ -e $r_abort_actions_pathfile ]]&&rm -f "$r_abort_actions_pathfile"
} &>/dev/null
InitProgress(){
fork_index=0
RefreshActionForkCounts;}
UpdateActionForkProgress(){
local a=''
local b=''
RefreshActionForkCounts
[[ $useropt_verbose = false&&! -e $r_inhibit_display_pathfile ]]||return
a=$((skip_count+skip_ok_count+skip_error_count+skip_abort_count))
b=$(PercFrac "$ok_count" "$a" "$fail_count" "$total_count")
if [[ $ok_count -gt 0 ]];then
[[ -n $b ]]&&b+=', '
b+=$(TextBrightGreen "$ok_count")' OK'
fi
if [[ $a -gt 0 ]];then
[[ -n $b ]]&&b+=', '
b+=$(TextBrightOrange "$a")' skipped'
fi
if [[ $fail_count -gt 0 ]];then
[[ -n $b ]]&&b+=', '
b+=$(TextBrightRed "$fail_count")' failed'
fi
if [[ $fork_count -gt 0 ]];then
[[ -n $b ]]&&b+=', '
b+=$(TextBrightYellow "$fork_count")' in-progress'
fi
[[ -n $b ]]&&ShowAsProc "${fork_progress_prefix:-}" "$b"
return 0
}>&2
UpdateDirSizeProgress(){
[[ $dir_bytes -gt 0 ]]||return
local perc_msg=''
local progress_msg=''
local -i stalled_seconds=0
local stalled_msg=''
local stalled_seconds_threshold=4
if [[ ${1:-} = final ]];then
current_bytes=$dir_bytes
else
RefreshDirSizeCount
[[ ${last_active_epoch:=0} -ne 0 ]]&&stalled_seconds=$(CalcAmountDiff "$(ConvertNowToSeconds)" "$last_active_epoch")
fi
perc_msg=$((200*(current_bytes)/(dir_bytes)%2+100*(current_bytes)/(dir_bytes)))%
[[ $current_bytes -lt $dir_bytes&&$perc_msg = '100%' ]]&&perc_msg=99%
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$dir_bytes")"))"
if [[ $stalled_seconds -ge $stalled_seconds_threshold ]];then
stalled_msg=' stalled for '
if [[ $stalled_seconds -lt 60 ]];then
stalled_msg+=$stalled_seconds' seconds'
else
stalled_msg+=$(ConvertSecondsToDuration "$stalled_seconds")
fi
if [[ $stalled_seconds -ge 90 ]];then
stalled_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stalled_seconds -ge 90 ]];then
stalled_msg=$(TextBrightRed "$stalled_msg")
elif [[ $stalled_seconds -ge 45 ]];then
stalled_msg=$(TextBrightOrange "$stalled_msg")
elif [[ $stalled_seconds -ge 20 ]];then
stalled_msg=$(TextBrightYellow "$stalled_msg")
fi
progress_msg+=$stalled_msg
fi
[[ ! -e $r_inhibit_display_pathfile ]]||return
ShowAsProc "$dir_size_progress_prefix" "$progress_msg"
return 0
}>&2
ShowQPKGsMissing(){
! QPKGs.AClistISmissing.IsSet||return 0
! QPKGs.ACreinstallISmissing.IsSet||return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for((i=0;i<=(${#packages[@]}-1);i++));do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit&&$((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b=' is'
c='it'
else
b='s are'
c='them'
fi
ShowAsNote "the $a QPKG${b} missing or broken. Please reinstall $c"
return 1;}
ShowQPKGsNewVers(){
! QPKGs.AClistISupgradable.IsSet||return 0
! QPKGs.ACupgradeISupgradable.IsSet||return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISupgradable:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISupgradable:Array))
fi
for((i=0;i<=(${#packages[@]}-1);i++));do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit&&$((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b='a '
c='version is'
else
c='versions are'
fi
ShowAsNote "${b}new QPKG $c available for $a"
return 1;}
CheckQPKGsConflicts(){
[[ $run_package_actions = false ]]||return 0
local a=''
if [[ -n ${r_base_qpkg_conflicts_with:-} ]];then
for a in "${r_base_qpkg_conflicts_with[@]}";do
if IsQpkgEnabled "$a";then
ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
return 1
fi
done
fi
return 0;}
CheckQPKGsWarnings(){
local a=''
if [[ -n ${r_base_qpkg_warnings:-} ]];then
for a in "${r_base_qpkg_warnings[@]}";do
if IsQpkgEnabled "$a";then
ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
return 1
fi
done
fi
return 0;}
ListQPKGsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
local b=''
local border_shown=false
for a in "${r_qpkg_actions[@]}";do
for b in ok er sk so se sa;do
if QPKGs-AC${a}-${b}.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
case $b in
ok|sk|so)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;
se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;
er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListIPKsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
local border_shown=false
for a in "${r_ipk_actions[@]}";do
if IPKs-AC${a}-ok.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) "
fi
if IPKs-AC${a}-er.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) "
fi
done
[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListPIPsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
DebugInfoMinSepr
for a in "${r_pip_actions[@]}";do
PIPs-AC${a}-ok.IsAny&&DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny&&DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) "
done
DebugInfoMinSepr
FuncExit;}
ListQPKGsStates(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
BuildExtendedQPKGsStates
DebugInfoMinSepr
for a in "${r_qpkg_is_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]]&&continue
if [[ $a = unknown ]];then
QPKGs-IS${a}.IsAny&&DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
else
QPKGs-IS${a}.IsAny&&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
fi
done
for a in "${r_qpkg_isnt_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]]&&continue
if [[ $a = ok ]];then
QPKGs-ISNT${a}.IsAny&&DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then
QPKGs-ISNT${a}.IsAny&&DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
else
QPKGs-ISNT${a}.IsAny&&DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
fi
done
for a in "${r_qpkg_transient_states[@]}";do
QPKGs-IS${a}.IsAny&&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
done
DebugInfoMinSepr
FuncExit;}
BuildQPKGsTiers(){
FuncInit
CheckQPKGsTiers
if [[ $qpkgs_tiers_built = true ]];then
DebugAsDetect 'tiers are already built'
else
ShowAsProc tiers
GenerateQPKGsTiers
fi
LoadQPKGsTiers
FuncExit;}
InitQPKGsTiers(){
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ ! -e ${!b} ]]&&continue
rm -f "${!b}" 2>/dev/null
done
qpkgs_tiers_built=false;}
CheckQPKGsTiers(){
qpkgs_tiers_built=true
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ -e ${!b} ]]&&continue
qpkgs_tiers_built=false
break
done;}
GenerateQPKGsTiers(){
local previous=''
local qpkg_name=''
InitQPKGsTiers
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]]&&continue||previous=$qpkg_name
SetQpkgIndex
if IsQpkgDbOptional;then
echo "$qpkg_name">>"$r_optional_qpkgs_list_pathfile"
elif IsQpkgDbDependent;then
echo "$qpkg_name">>"$r_dependent_qpkgs_list_pathfile"
else
echo "$qpkg_name">>"$r_independent_qpkgs_list_pathfile"
fi
done
qpkgs_tiers_built=true;}
LoadQPKGsTiers(){
[[ $qpkgs_tiers_built = true ]]||return
local a=''
local b=''
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ ! -e ${!b} ]]&&continue
QPKGs-GR${a}:Add "$(<${!b})"
done;}
BuildExtendedQPKGsStates(){
FuncInit
if [[ ${qpkgs_states_built:=false} = true ]];then
DebugAsDetect 'states are already built'
FuncExit;return
fi
if IsOsStartingPackages;then
ShowAsNote "$(GetOsName) is starting QPKGs, check again in a few minutes"
elif IsOsStarting;then
ShowAsNote "$(GetOsName) is still booting, check again in a few minutes"
elif IsOsStopping;then
ShowAsNote "$(GetOsName) is shutting-down"
elif IsOsStoppingPackages;then
ShowAsNote "$(GetOsName) is stopping QPKGs"
fi
if IsOsLoadAverageInsane;then
ShowAsWarn 'the NAS has an exceptionally-high system-load, recommend aborting and trying again later'
elif IsOsLoadAverageHigh;then
ShowAsWarn 'the NAS has an unusually-high system-load, so this may take a while'
elif IsOsLoadAverageElevated;then
ShowAsNote 'the NAS has an elevated system-load, so this may take a little longer than usual'
fi
LoadDatabase
InitQPKGsStates
GetQpkgStates
StoreQpkgStates
ShowQPKGsMissing
ShowQPKGsNewVers
FuncExit;}
GetQpkgStates(){
FuncInit
qpkg_name=''
ShowAsProc 'get QPKG states'
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgUpgradable;then
echo upgradable
else
echo notupgradable
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgInstallable;then
echo installable
else
echo notinstallable
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgMissing;then
echo missing
else
echo notmissing
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgBackupExist;then
echo backedup
else
echo notbackedup
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
wait 2>/dev/null
FuncExit;}
StoreQpkgStates(){
FuncInit
local a=''
local b=''
qpkg_name=''
ShowAsProc 'store QPKG states'
for qpkg_name in $(QPKGs-GRall:Array);do
a=/var/log/$qpkg_name.action
b=/var/log/$qpkg_name.result
if [[ -e $a&&-e $b ]];then
case $(<$b) in
in-progress)
case $(<$a) in
start)
QPKGs-ISstarting:Add "$qpkg_name";;
restart)
QPKGs-ISrestarting:Add "$qpkg_name";;
stop)
QPKGs-ISstopping:Add "$qpkg_name"
esac;;
ok)
QPKGs-ISok:Add "$qpkg_name";;
failed)
QPKGs-ISNTok:Add "$qpkg_name"
esac
fi
a=$r_qpkg_states_path/$qpkg_name
[[ -e $a ]]||continue
for b in $(<$a);do
case $b in
backedup)
QPKGs-ISbackedup:Add "$qpkg_name";;
backupable)
:;;
installable)
QPKGs-ISinstallable:Add "$qpkg_name";;
missing)
QPKGs-ISmissing:Add "$qpkg_name"
QPKGs-ISok:Remove "$qpkg_name"
QPKGs-ISNTok:Add "$qpkg_name";;
notbackedup)
QPKGs-ISNTbackedup:Add "$qpkg_name";;
notbackupable)
:;;
notinstallable)
QPKGs-ISNTinstallable:Add "$qpkg_name";;
notmissing)
QPKGs-ISNTmissing:Add "$qpkg_name";;
notupgradable)
QPKGs-ISNTupgradable:Add "$qpkg_name";;
upgradable)
QPKGs-ISupgradable:Add "$qpkg_name"
esac
done
done
qpkgs_states_built=true
FuncExit;}
InitQPKGsStates(){
LoadObjects||return
FuncInit
local a=''
DebugAsProc 'initialising state lists'
for a in "${r_qpkg_is_states[@]:-}";do
[[ $a = active ]]&&continue
[[ $(type -t QPKGs-IS${a}:Init) = function ]]&&QPKGs-IS${a}:Init
done
for a in "${r_qpkg_isnt_states[@]:-}";do
[[ $a = active ]]&&continue
[[ $(type -t QPKGs-ISNT${a}:Init) = function ]]&&QPKGs-ISNT${a}:Init
done
ClearPath /var/run/sherpa/packages "$r_qpkg_states_path"
DebugAsDone 'initialised state lists'
qpkgs_states_built=false
FuncExit;}
BuildQPKGsIsCanBackup(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanBackup "$qpkg_name"&&QPKGs-GRcanbackup:Add "$qpkg_name"
done
FuncExit;}
BuildQPKGsIsCanRestartToUpdate(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanRestartToUpdate "$qpkg_name"&&QPKGs-GRcanrestarttoupdate:Add "$qpkg_name"
done
FuncExit;}
BuildQPKGsIsCanClean(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanClean "$qpkg_name"&&QPKGs-GRcanclean:Add "$qpkg_name"
done
FuncExit;}
HelpAbbreviations(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
LoadDatabase
DisableDebugToArchiveAndFile
DisplayProcReport abbreviations
ResetReportsPath &>/dev/null
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages)."
}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GenerateAbsReportTitleLine)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateAbsReportDataLine_>"$r_reports_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>>"$r_report_output_pathfile"
fi
DisplayAsProjSynExam "example: to install $(FormatPackageName SABnzbd), $(FormatPackageName Mylar3) and $(FormatPackageName nzbToMedia) all-at-once" 'install sab my nzb2'>>"$r_report_output_pathfile"
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportBackups(){
FuncInit
local a=''
local b=''
local epoch_time=0
local -i file_bytes=0
local file_date=''
local file_name=''
local file_time=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport backups
ResetReportsPath &>/dev/null
printf -v a '\n%s\n' "$(GenerateBacksReportTitleLine)"
if [[ -e $r_gnu_find_cmd ]];then
while read -r epoch_time file_name file_bytes;do
[[ -z $epoch_time||-z $file_name ]]&&break
((n++))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than">"$r_reports_path/$n" &
done<<<"$($r_gnu_find_cmd "$r_qpkg_bu_path"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2>/dev/null | /usr/bin/sort)"
else
while read -r file_date file_time file_name file_bytes;do
[[ -z $file_date||-z $file_name ]]&&break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$(/usr/bin/basename "$file_name")
((n++))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than">"$r_reports_path/$n" &
done<<<"$(cd "$r_qpkg_bu_path"&&ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2>/dev/null | /bin/awk '{print $6" "$7" "$8" "$5}')"
fi
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportFooter>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
FuncExit;}
ReportDependencies(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport dependency
ResetReportsPath &>/dev/null
! IsAnsiStrippingSupported&&colourful=false
printf -v a '\n%s\n' "$(GenerateDepsReportTitleLine)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateDepsReportDataLine_>"$r_reports_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportFooter>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportFeatures(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport features
ResetReportsPath &>/dev/null
! IsAnsiStrippingSupported&&colourful=false
printf -v a '\n%s\n' "$(GenerateFeaturesReportTitleLine)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateFeaturesReportDataLine_>"$r_reports_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportHeadingsFooter>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportPackages(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport package
! IsAnsiStrippingSupported&&colourful=false
{
ShowHelpBasic
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once."
}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GeneratePacksReportTitleLine)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GeneratePacksReportDataLine_ "$qpkg_name">"$r_reports_path/$n" &
done
m=$n
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>>"$r_report_output_pathfile"
GenerateReportFooter>>"$r_report_output_pathfile"
fi
{
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
}>>"$r_report_output_pathfile"
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportRepos(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport repository
ResetReportsPath &>/dev/null
! IsAnsiStrippingSupported&&colourful=false
printf -v a '\n%s\n' "$(GenerateReposReportTitleLine)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateReposReportDataLine_>"$r_reports_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportFooter>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportStatuses(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport status
ResetReportsPath &>/dev/null
! IsAnsiStrippingSupported&&colourful=false
for qpkg_name in $(QPKGs-GRall:Array);do
QPKGs-ACstatus-dn.Exist "$qpkg_name"||continue
((n++))
SetQpkgIndex
_GenerateStatusReportDataLine_>"$r_reports_path/$n" &
done
printf -v a '\n%s\n' "$(GenerateStatusReportTitleLine)"
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_reports_path/$n
[[ -e $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportFooter>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_failed=false
FuncExit;}
ReportAllActionResults(){
local -i a=0
local action=''
local -i b=0
local -i c=0
local -i d=0
local -i datetime=0
local -i duration=0
local -i e=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ $useropt_show_previous_action_results_report = true ]];then
show_action_results_failed=true
show_action_results_ok=true
show_action_results_skipped=true
fi
if [[ -e $r_session_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $datetime -gt 0&&$duration -gt 0 ]];then
[[ $a -eq 0 ]]&&a=$datetime
b=$datetime
c=$duration
((d++))
fi
done<"$r_session_action_results_pathfile"
a=$(ConvertMillisecondsToSeconds "$a")
b=$(ConvertMillisecondsToSeconds "$b")
c=$(ConvertMillisecondsToSeconds "$c")
[[ $b -gt 0 ]]&&e=$((b+c+1))
if [[ $show_action_results_ok = true||$show_action_results_skipped = true||$show_action_results_failed = true||$show_action_results_zero = true ]];then
{
DisplayAsHelpTitle "package action$(Pluralise "$d") started @ $(ConvertSecondsToTime "$a"), ended @ $(ConvertSecondsToTime "$e"), elapsed = $(ConvertSecondsToDuration "$(CalcAmountDiff "$a" "$e")")"
[[ $show_action_results_ok = true ]]&&ReportActionResults ok
[[ $show_action_results_skipped = true ]]&&ReportActionResults skipped
[[ $show_action_results_failed = true ]]&&ReportActionResults failed
[[ $show_action_results_zero = true ]]&&ShowZeroQpkgs
}>"$r_report_output_pathfile"
ShowReport
fi
else
ShowAsDone 'no action results to report'
fi;}
ReportActionResults(){
local action=''
local -i count=0
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ -e $r_session_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]]||[[ $1 = skipped&&($result = 'skipped-ok'||$result = 'skipped-error'||$result = 'skipped-abort') ]];then
[[ $action = status&&$useropt_show_previous_action_results_report = false ]]&&continue
((count++))
[[ $count -gt 1 ]]&&break
fi
done<"$r_session_action_results_pathfile"
if [[ $count -eq 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "this package action completed $(TextBrightGreen OK):";;
skipped)
DisplayAsHelpTitle "this package action was $(TextBrightOrange skipped) $(Parenthesise 'and why'):";;
failed)
DisplayAsHelpTitle "this package action $(TextBrightRed failed) $(Parenthesise 'and why'):"
esac
elif [[ $count -gt 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "these package actions completed $(TextBrightGreen OK):";;
skipped)
DisplayAsHelpTitle "these package actions were $(TextBrightOrange skipped) $(Parenthesise 'and why'):";;
failed)
DisplayAsHelpTitle "these package actions $(TextBrightRed failed) $(Parenthesise 'and why'):"
esac
fi
if [[ $count -ge 1 ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]]||[[ $1 = skipped&&($result = 'skipped-ok'||$result = 'skipped-error'||$result = 'skipped-abort') ]];then
[[ $action = status&&$useropt_show_previous_action_results_report = false ]]&&continue
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason" "$package_type" "$quantity"
fi
done<"$r_session_action_results_pathfile"
fi
fi
if [[ $count -eq 0 ]];then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK).";;
skipped)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped).";;
failed)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
return 0;}
GenerateReportFooter(){
[[ $useropt_report_footer = true ]]||return
DisplayAsHelpTitle 'report information:'
local a=''
a=$({
if [[ -e "$r_report_flags_path"/status-missing ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed missing)" 'QPKG is missing from its installation path. Please reinstall it'
fi
if [[ -e "$r_report_flags_path"/req-alert ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" 'QPKG is prevented from working correctly'
fi
if [[ -e "$r_report_flags_path"/state-disabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed disabled)" "QPKG won't start at bootup. Enable it first, then start it"
fi
if [[ -e "$r_report_flags_path"/result-aborted ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed aborted))" 'previous action was aborted'
fi
if [[ -e "$r_report_flags_path"/result-failed ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed failed))" 'previous action failed'
fi
if [[ -e "$r_report_flags_path"/status-inactive ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed inactive)" 'application process is dead or not-started. Try starting it'
fi
if [[ -e "$r_report_flags_path"/backup-file-old ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" "QPKG backup file was updated more-than $r_report_highlight_backups_older_than."
fi
if [[ -e "$r_report_flags_path"/state-upgradable ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange upgradable)" 'a new QPKG version is available'
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange new))" 'the new QPKG version'
fi
if [[ -e "$r_report_flags_path"/status-wrongauthor ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange 'incompatible author')" "QPKG is a non-compatible, identically-named duplicate of a $(ShowAsTitleName) QPKG"
fi
if [[ -e "$r_report_flags_path"/req-attention ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" "QPKG cannot be managed with $(ShowAsTitleName)"
fi
if [[ -e "$r_report_flags_path"/state-notinstallable ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" 'QPKG cannot be installed'
fi
if [[ -e "$r_report_flags_path"/action-pending ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange pending)" 'QPKG is waiting to run an action. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-stopping ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange stopping)" 'QPKG is stopping. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-slow ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange slow)" 'application is alive, but was slow to respond to the status request. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-starting ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange starting)" 'QPKG is starting. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/result-in-progress ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange in-progress))" 'an action is in-progress. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-unknown ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange unknown)" 'application status could not be determined'
fi
if [[ -e "$r_report_flags_path"/repo-other ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '* URL')" 'another repository is managing this QPKG'
fi
if [[ -e "$r_report_flags_path"/state-enabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen enabled)" 'QPKG will be started at bootup'
fi
if [[ -e "$r_report_flags_path"/result-ok ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightGreen OK))" 'previous action was successful'
fi
if [[ -e "$r_report_flags_path"/status-active ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen active)" 'application is alive (and responsive if a daemon)'
fi
if [[ -e "$r_report_flags_path"/repo-sherpa ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen sherpa)" "$(ShowAsTitleName) is managing this QPKG"
fi
if [[ -e "$r_report_flags_path"/app-dynamic ]];then
DisplayAsIndentQuotedInfoItem dynamic 'application version is the latest available'
fi
if [[ -e "$r_report_flags_path"/app-static ]];then
DisplayAsIndentQuotedInfoItem static 'application version auto-update is disabled or unsupported'
fi
if [[ -e "$r_report_flags_path"/app-final ]];then
DisplayAsIndentQuotedInfoItem final 'application version is the last available'
fi
if [[ -e "$r_report_flags_path"/na ]];then
DisplayAsIndentQuotedInfoItem N/A 'not applicable'
fi
if [[ -e "$r_report_flags_path"/action-not-found ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey not-found)" 'action tracking files were not found'
fi
if [[ -e "$r_report_flags_path"/action-unsupported ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey unsupported)" 'action tracking is unsupported by this QPKG'
fi
})
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi
if [[ -e "$r_report_flags_path"/deps ]];then
DisplayAsHelpTitle "QPKG dependencies are automatically installed/started/stopped/restarted as-required by $(ShowAsTitleName)."
fi
if [[ $(FileCountSpec "$r_report_flags_path/backup-file-*") -gt 0 ]];then
DisplayAsIndentItem "backups are listed oldest-first."
DisplayAsIndentItem "all $(ShowAsTitleName) backup files are stored here: $r_qpkg_bu_path"
fi;}
GenerateReportHeadingsFooter(){
[[ $useropt_report_footer = true ]]||return
DisplayAsHelpTitle 'column headings:'
local a=''
a=$({
DisplayAsIndentQuotedInfoItem 'Indep?' 'is independent of other QPKGs'
DisplayAsIndentQuotedInfoItem 'Opt?' 'is an optional addon for another QPKG'
DisplayAsIndentQuotedInfoItem 'Dep?' 'is dependent on other QPKGs'
DisplayAsIndentQuotedInfoItem 'Enh?' "$(ShowAsTitleName) enhanced service actions are supported"
DisplayAsIndentQuotedInfoItem 'CanBack?' "application config 'backup' and 'restore' are supported"
DisplayAsIndentQuotedInfoItem 'CanClean?' "application 'clean' is supported"
DisplayAsIndentQuotedInfoItem 'StartUpd?' 'application restart-to-update is supported'
DisplayAsIndentQuotedInfoItem 'AutUpd?' 'application restart-to-update is enabled'
DisplayAsIndentQuotedInfoItem 'LiveTest?' "has a built-in 'status' check, and can test for daemon live status"
DisplayAsIndentQuotedInfoItem 'ArchCompat?' 'has a release compatible with this NAS architecture'
DisplayAsIndentQuotedInfoItem 'UniqUnpack?' 'QPKG unpacks itself to a unique path'
})
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi;}
ShowReport(){
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
Display
else
ShowAsError 'report not found'
fi;}
ShowVersionsList(){
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: $(ConvertAsSmartDate "$r_this_package_ver")"
Display "manager: $(ConvertAsSmartDate "$r_script_built_epoch")"
Display "objects: $(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
Display "packages: $(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
return 0;}
ShowQPKGLists(){
[[ ${packages_loaded:=false} = true ]]||return
local a=''
for a in "${r_qpkg_basic_states[@]}";do
case $a in
complete)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsComplete)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtComplete)"
ShowQPKGList AClist-to
return
fi;;
enabled)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsEnabled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtEnabled)"
ShowQPKGList AClist-to
return
fi;;
installed)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsValidInstalled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtInstalled)"
ShowQPKGList AClist-to
return
fi
esac
done
for a in "${r_qpkg_extended_states[@]}";do
case $a in
downloaded|signed)
:;;
*)if QPKGs.AClistIS${a}.IsSet;then
ShowQPKGList IS${a}
return
elif QPKGs.AClistISNT${a}.IsSet;then
ShowQPKGList ISNT${a}
return
fi
esac
done
for a in "${r_qpkg_is_groups[@]}";do
case $a in
canbackup|canrestarttoupdate)
:;;
*)if QPKGs.AClistGR${a}.IsSet;then
ShowQPKGList GR${a}
return
fi
esac
done
for a in "${r_qpkg_isnt_groups[@]}";do
case $a in
all|canbackup|canrestarttoupdate)
:;;
*)if QPKGs.AClistGRNT${a}.IsSet;then
ShowQPKGList GRNT${a}
return
fi
esac
done;}
ShowQPKGList(){
[[ -n ${1:-} ]]||return
local qpkg_name=''
DisableDebugToArchiveAndFile
EraseThisLine
if [[ $(type -t QPKGs-$1.IsAny) = function ]]&&QPKGs-$1.IsAny;then
for qpkg_name in $(QPKGs-$1:Array);do
Display "$qpkg_name"
done
else
ShowAsError 'unable to find any matching QPKGs'
fi
return 0;}
SendParentChangeEnv(){
WriteToActionMsgPipe env "$1" '' '';}
SendPackageStateChange(){
WriteToActionMsgPipe change "$1" package "$qpkg_name";}
SendActionStatus(){
WriteToActionMsgPipe status "$1" package "$qpkg_name";}
WriteToActionMsgPipe(){
[[ $action_msg_pipe_fd != none&&-e /proc/$$/fd/$action_msg_pipe_fd ]]&&echo "$1|$2|$3|$4">&$action_msg_pipe_fd
return 0;}
ReadFromActionMsgPipe(){
local _msg1_key
local _msg1_value
local _msg2_key
local _msg2_value
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value<&$action_msg_pipe_fd
eval "$1='$_msg1_key' $2='$_msg1_value' $3='$_msg2_key' $4='$_msg2_value'"
return 0;}
FindNextFD(){
local -i fd=-1
for fd in {10..100};do
if [[ ! -e /proc/$$/fd/$fd ]];then
printf '%s' "$fd"
return 0
fi
done
return 1;}
MarkActionForkAsStarted(){
IncrementActionForkIndex
[[ -n $proc_fork_pathfile ]]&&/bin/touch "$proc_fork_pathfile";}
MarkActionForkAsOk(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_ok_pathfile"
SendActionStatus ok;}
MarkActionForkAsSkippedOk(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_skip_ok_pathfile"
SendActionStatus so;}
MarkActionForkAsSkipped(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_skip_pathfile"
SendActionStatus sk;}
MarkActionForkAsSkippedError(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_skip_error_pathfile"
SendActionStatus se;}
MarkActionForkAsSkippedAbort(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_skip_abort_pathfile"
SendActionStatus sa;}
MarkActionForkAsError(){
[[ -n $proc_fork_pathfile&&-e $proc_fork_pathfile ]]&&mv "$proc_fork_pathfile" "$proc_fail_pathfile"
SendActionStatus er;}
#WriteThisAcForkPid()
NoteIpkAcAsOk(){
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-ok:Add "$1"
return 0;}
NoteIpkAcAsEr(){
local a="failing request to $2 $(FormatPackageName "$1")"
[[ -n ${3:-} ]]&&a+=' as '$3
DebugAsError "$a">&2
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-er:Add "$1"
return 0;}
ModPathToEntware(){
local a=''
local b=/opt/bin:/opt/sbin
if IsQpkgEnabled Entware;then
! [[ $PATH =~ $b ]]||return
a=$(/bin/sed "s|${b}:||"<<<"$PATH:")
export PATH=$b:${a%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $b ]]||return
a=$(/bin/sed "s|${b}:||"<<<"$PATH:")
export PATH=${a%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0;}
GetHardwareCPUInfo(){
if /bin/grep -q '^model name' /proc/cpuinfo;then
/bin/grep '^model name' /proc/cpuinfo | head -n1 | /bin/sed 's/^.*: //' | tr -s ' '
elif /bin/grep -q '^Processor name' /proc/cpuinfo;then
/bin/grep '^Processor name' /proc/cpuinfo | head -n1 | /bin/sed 's/^.*: //' | tr -s ' '
else
printf unknown
return 1
fi
return 0;}
GetHardwareCPUBenchmark(){
local a=''
local -i b=16
local -i c=-20
if [[ -e $r_gnu_dd_cmd ]];then
if [[ -e $r_gnu_nice_cmd ]];then
a=$({ $r_gnu_nice_cmd -$c $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b | /bin/sha1sum>/dev/null;} 2>&1)
elif [[ -e /bin/renice ]];then
/bin/renice $c $$ &>/dev/null
a=$({ $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b | /bin/sha1sum>/dev/null;} 2>&1)
/bin/renice 0 $$ &>/dev/null
fi
fi
a=$(/bin/grep copied<<<"$a" | cut -d, -f4)
a=${a//[[:blank:]]/}
[[ -n $a ]]||a=undefined
printf '%s' "$a"
return 0;}
GetHardwareVolumeBenchmark(){
local a=''
local b=10k
local -i c=-20
local d=$(GetUserDefVol)/zero
if [[ -d $(/usr/bin/dirname "$d") ]];then
[[ -e $d ]]&&rm -f "$d"
if [[ -e $r_gnu_dd_cmd ]];then
if [[ -e $r_gnu_nice_cmd ]];then
a=$($r_gnu_nice_cmd -$c $r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$b 2>&1)
elif [[ -e /bin/renice ]];then
/bin/renice $c $$ &>/dev/null
a=$($r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$b 2>&1)
/bin/renice 0 $$ &>/dev/null
fi
fi
[[ -e $d ]]&&rm -f "$d"
fi
a=$(/bin/grep copied<<<"$a" | cut -d, -f4)
a=${a//[[:blank:]]/}
[[ -n $a ]]||a=undefined
printf '%s' "$a"
return 0;}
GetNasArch(){
/bin/uname -m;}
GetOsKernelName(){
/bin/uname -o||/bin/uname
} 2>/dev/null
GetOsKernelVersion(){
/bin/uname -r;}
GetOsKernelPageSize(){
if [[ -e /sbin/hal_app ]];then
echo -n "$(/sbin/hal_app --get_pagesize)B"
else
/bin/grep KernelPageSize /proc/1/smaps | head -n1 | cut -f2 -d':' | tr -d ' ' | /bin/sed 's/kB/kiB/'
fi;}
GetHardwarePlatform(){
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf;}
GetUserDefVol(){
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info;}
#GetThisBinPath()
GetRepoURLFromStoreID(){
[[ -n ${1:-} ]]||return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf;}
GetOsUptime(){
local n=$(</proc/uptime)
ConvertSecondsToDuration "${n%%.*}";}
GetUserLIBC(){
local a=$(/sbin/ldd --version | head -n1)
printf '%s' "${a:4}";}
GetUserLIBCCopyright(){
/sbin/ldd --version | /bin/grep -i copyright | /bin/sed 's/\$//';}
GetShell(){
printf '%s' "${SHELL:-undefined}";}
GetShellVersion(){
if [[ -z ${SHELL:-} ]];then
printf undefined
else
$SHELL --version | head -n1
fi;}
GetShellCopyright(){
if [[ -z ${SHELL:-} ]];then
printf undefined
else
$SHELL --version | /bin/grep -i copyright | /bin/sed 's/\$//'
fi;}
GetShellTimeIn(){
local n=''
[[ -n ${LOADER_SCRIPT_PPID:-} ]]&&n=$(/bin/ps -o pid,etime | /bin/grep $LOADER_SCRIPT_PPID | head -n1)
FormatAsLongMinutesSecs "${n:6}";}
GetOsSysLoadAverages(){
/usr/bin/uptime | /bin/sed 's/.*load average: //' | /bin/awk -F', ' '{print "1m:"$1", 5m:"$2", 15m:"$3}';}
GetOsSysLoad1MinAverage(){
/usr/bin/uptime | /bin/sed 's/.*load average: //' | /bin/awk -F', ' '{print $1}';}
GetHardwareCPUCores(){
local n=$(/bin/grep -c '^processor' /proc/cpuinfo)
[[ $n -eq 0 ]]&&n=$(/bin/grep -c '^Processor' /proc/cpuinfo)
printf '%s' "$n";}
GetHardwareInstalledRAM(){
/bin/grep MemTotal /proc/meminfo | /bin/sed 's/.*: //;s/kB//;s/ //g';}
GetOsFirmwareVersion(){
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf;}
GetOsFirmwareVer(){
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf | tr -d '.';}
GetOsFirmwareBuild(){
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf;}
GetOsFirmwareDate(){
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf;}
GetOsName(){
if IsQuTS;then
printf 'QuTS hero'
else
printf QTS
fi;}
GetQpkgArch(){
if [[ $(get_display_name) = 'TS-269H' ]];then
printf i53
return
fi
SetNasArch
SetOsFirmwareVer
SetHardwarePlatform
case $r_nas_arch in
x86_64)
[[ $r_nas_firmware_ver -ge 430 ]]&&printf i64||printf i86;;
i686|x86)
printf i86;;
armv5tel)
printf a19;;
armv7l)
case $r_nas_platform in
ARM_MS)
printf a31;;
ARM_AL)
printf a41;;
*)printf unknown
esac;;
aarch64)
printf a64;;
*)printf unknown
esac;}
GetQpkgEntwareType(){
if IsQpkgInstalled Entware;then
if [[ -e /opt/etc/passwd ]];then
if [[ -L /opt/etc/passwd ]];then
printf std
else
printf alt
fi
else
printf none
fi
else
printf 'not-installed'
fi
} 2>/dev/null
GetUserSudoUID(){
printf '%s' "${SUDO_UID:-undefined}";}
GetOsState(){
local a=''
if IsOsStarting;then
a=booting
fi
if IsOsStartingPackages;then
[[ -n $a ]]&&a+=', '
a+='starting QPKGs'
fi
if IsOsStopping;then
a='shutting-down'
fi
if IsOsStoppingPackages;then
[[ -n $a ]]&&a+=', '
a+='stopping QPKGs'
fi
[[ -z $a ]]&&a=online
printf '%s' "$a";}
GetUserGitBranch(){
/sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf;}
ShowZeroQpkgs(){
[[ ${packages_loaded:=false} = true ]]||return
local a=''
local b=''
for a in "${r_qpkg_is_states[@]:-}";do
for b in "${r_user_qpkg_actions[@]:-}";do
[[ $b = list ]]&&continue
QPKGs.AC${b}IS${a}.IsSet&&QPKGs-AC${b}-ok.IsNone&&ShowAsWarn "no QPKGs were able to $(Lowercase "$b")"
done
done
return 0;}
ClaimLockfile(){
local a=''
readonly r_lock_pathfile=/var/run/sherpa.lock
for a in sherpa-manager.sh sherpa-manager.source;do
if [[ -e $r_lock_pathfile&&-d /proc/$(<$r_lock_pathfile)&&$(</proc/"$(<$r_lock_pathfile)"/cmdline) =~ $a ]];then
ShowAsAbort "a running $(ShowAsTitleName) instance was found $(Parenthesise "PID:$(<"$r_lock_pathfile")"), can't continue"
return 1
fi
done
echo "$$">"$r_lock_pathfile"
return 0;}
ReleaseLockfile(){
[[ -n ${r_lock_pathfile:-} ]]&&rm -f "$r_lock_pathfile" 2>/dev/null;}
EnableVerbose(){
useropt_verbose=true
DebugVar useropt_verbose
useropt_terse=false
ShowKeystrokes
ShowCursor;}
EnableDebugToArchiveAndFile(){
useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward;}
DisableDebugToArchiveAndFile(){
archive_debug_afterward=false
useropt_debug=false;}
SaveActionResultToLog(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_};var_safe_name=${var_safe_name//:/_}
local -r r_package_type=${1:?${FUNCNAME[0]}'()': $r_nopacktype}
local -r r_name=${2:?${FUNCNAME[0]}'()': $r_nopackname}
local -r r_action=${3:?${FUNCNAME[0]}'()': undefined action}
local -r r_qty=${4:-1}
local -r r_clean_action=${r_action//\"/}
local -r r_result=${5:?${FUNCNAME[0]}'()': undefined result}
local -r r_reason=${6:-}
local -r r_starttime=$(ConvertNanosecondsToMilliseconds "${!var_safe_name}")
local -r r_duration=$(CalcAmountDiff "$r_starttime" "$(ConvertNowToMilliseconds)")
local -r r_action_times_pathfile=$r_action_times_path/$r_clean_action.milliseconds
if [[ $2 = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
echo "$r_starttime|$r_action|$r_qty|$r_name|$r_package_type|$r_result|$r_duration|$r_reason">>"$r_session_action_results_pathfile"
if [[ -e $r_action_times_pathfile ]]&&/bin/grep -q "^$r_name|"<"$r_action_times_pathfile";then
/bin/sed -i "/^$r_name|/d" "$r_action_times_pathfile"
fi
echo "$r_name|$r_duration">>"$r_action_times_pathfile"
case $4 in
ok|skipped-ok)
DebugAsInfo "$r_reason";;
skipped)
DebugAsWarn "$r_reason";;
failed|skipped-@(error|abort))
DebugAsError "$r_reason"
esac
return 0;}
_QPKG:reassign_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif [[ $(GetQpkgInstalledStoreID) = sherpa||$(GetQpkgInstalledStoreID) = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'already assigned to sherpa'
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "reassigning $(FormatPackageName)"
RunAndLog "/sbin/setcfg -e $qpkg_name store -f /etc/config/qpkg.conf" "$r_logs_path/$qpkg_name.$r_reassign_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' ok
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reassign '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:download_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local curl_options=''
local -r r_remote_hash=$(GetQpkgDbHash)
local -r r_remote_url=$(GetQpkgDbURL)
local -r r_remote_filename=$(/usr/bin/basename "$r_remote_url")
local -r r_local_pathfile=$r_qpkg_download_path/$r_remote_filename
local -r r_local_filename=$(/usr/bin/basename "$r_local_pathfile")
local -r r_log_pathfile=$r_logs_path/$r_local_filename.$r_download_log_file
local -i z=0
IsOsCanSecureDownload||curl_options=' --insecure'
if [[ -z $r_remote_url||-z $r_remote_hash ]];then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped 'NAS arch is incompatible'
MarkActionForkAsSkipped
z=1
elif IsFile "$r_local_pathfile";then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped-ok "existing file $(FormatFileName "$r_local_filename") checksum is correct"
MarkActionForkAsSkippedOk
z=2
else
DebugInfo "deleting $(FormatFileName "$r_local_filename") as checksum is incorrect"
rm -f "$r_local_pathfile" 2>/dev/null
fi
fi
[[ $z -eq 0 ]]||FuncForkExit $z
if IsNtFile "$r_local_pathfile";then
DebugAsProc "downloading $(FormatFileName "$r_remote_filename")"
rm -f "$r_log_pathfile" 2>/dev/null
RunAndLog "/sbin/curl${curl_options} --location --output $r_local_pathfile $r_remote_url" "$r_log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
[[ $(Lowercase "${r_local_pathfile##*.}") = zip ]]&&/usr/bin/unzip -nq "$r_local_pathfile" -d "$r_qpkg_download_path"
SaveActionResultToLog QPKG "$qpkg_name" download '' ok
SendPackageStateChange ISdownloaded
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "cache file $(FormatFileName "$r_local_filename") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkActionForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "$z"
MarkActionForkAsError
z=1
fi
fi
FuncForkExit $z;}
_QPKG:install_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'already installed'
MarkActionForkAsSkipped
z=1
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbArchOK "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS arch is incompatible'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbMinOSVerOk "$qpkg_name"||! IsQpkgDbMaxOSVerOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped "$(GetOsName) version is incompatible"
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbMinRAMOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS has insufficient RAM installed'
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local local_pathfile=$(GetQpkgDbPathFilename)
if [[ -z $local_pathfile||! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped-error 'no local file found for processing: please report this issue'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
if [[ $qpkg_name = Entware ]]&&IsNtValidQpkgInstalled Entware&&QPKGs-ACinstall-to.Exist Entware;then
local -r r_opt_path=/opt
local -r r_opt_bu_path=/opt.orig
if [[ -d $r_opt_path&&! -L $r_opt_path&&! -e $r_opt_bu_path ]];then
DebugAsProc 'backup original /opt'
mv "$r_opt_path" "$r_opt_bu_path"
DebugAsDone complete
fi
fi
DebugAsProc "installing $(FormatPackageName)"
[[ ${QPKGs_were_installed_name[*]:-} = *"$qpkg_name"* ]]&&a+="QINSTALL_PATH=$(GetQpkgInstalledOriginalPath "$qpkg_name") "
RunAndLog "${a}/bin/sh $local_pathfile" "$r_logs_path/$(/usr/bin/basename "$local_pathfile").$r_install_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd&&z=1
if [[ $z -eq 0||$z -eq 10 ]];then
SaveActionResultToLog QPKG "$qpkg_name" install '' ok "v$(GetQpkgInstalledVer)"
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv _UpdateEntwarePackageList_
PatchEntwareService
if [[ -L ${r_opt_path:-}&&-d ${r_opt_bu_path:-} ]];then
DebugAsProc 'restoring original /opt'
mv "$r_opt_bu_path"/* "$r_opt_path"&&ClearPath / "$r_opt_bu_path"
DebugAsDone complete
fi
fi
IsOsCanSignedPackages&&SendParentChangeEnv "QPKGs-ACsign-to:Add $qpkg_name"
MarkActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" install '' failed "$z"
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reinstall_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a='REINSTALL_QPKG=true '
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "not already installed, please use 'install' instead."
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local local_pathfile=$(GetQpkgDbPathFilename)
if [[ -z $local_pathfile||! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped-error 'no local file found for processing, please report this issue.'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "reinstalling $(FormatPackageName)"
IsValidQpkgInstalled&&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath)") "
RunAndLog "${a}/bin/sh $local_pathfile" "$r_logs_path/$(/usr/bin/basename "$local_pathfile").$r_reinstall_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd&&z=1
if [[ $z -eq 0||$z -eq 10 ]];then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' ok "v$(GetQpkgInstalledVer)"
MarkActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' failed "$z"
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:rebuild_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local -i z=0
if IsValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "already installed, please use 'restore' instead"
MarkActionForkAsSkipped
z=1
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'does not support rebuild'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'backup file does not exist'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "meta-rebuilding $(FormatPackageName)"
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' ok
MarkActionForkAsOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:upgrade_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a='UPGRADE_QPKG=true '
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! QPKGs-ISupgradable.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'no new QPKG is available'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local local_pathfile=$(GetQpkgDbPathFilename)
if [[ -z $local_pathfile||! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped-error 'no local file found for processing, please report this issue'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local prev_ver=$(GetQpkgInstalledVer)
DebugAsProc "upgrading $(FormatPackageName)"
IsValidQpkgInstalled&&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath "$qpkg_name")") "
RunAndLog "${a}/bin/sh $local_pathfile" "$r_logs_path/$(/usr/bin/basename "$local_pathfile").$r_upgrade_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog&&! QpkgServiceResultWasOk&&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd&&z=1
if [[ $z -eq 0||$z -eq 10 ]];then
SendPackageStateChange ISNTupgradable
local current_ver=$(GetQpkgInstalledVer)
if [[ $current_ver = "$prev_ver" ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "v${current_ver}"
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "v${prev_ver} -> v${current_ver}"
fi
MarkActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' failed "$z"
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:uninstall_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "it's needed here! 😉"
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_qpkg_uninstaller_pathfile=$(GetQpkgInstalledPath)/.uninstall.sh
[[ $qpkg_name = Entware ]]&&SaveIpkAndPipList
if IsFile "$r_qpkg_uninstaller_pathfile";then
DebugAsProc "uninstalling $(FormatPackageName)"
RunAndLog "${a}/bin/sh $r_qpkg_uninstaller_pathfile" "$r_logs_path/$qpkg_name.$r_uninstall_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
[[ -e /sbin/qpkg_cli ]]&&! QPKGs-ACinstall-to.Exist "$qpkg_name"&&/sbin/qpkg_cli --remove "$qpkg_name" &>/dev/null
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' ok
/sbin/rmcfg "$qpkg_name" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISNTactive
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$z"
MarkActionForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$(FormatFileName '.uninstall.sh') not found"
MarkActionForkAsError
fi
FuncForkExit $z;}
_QPKG:activate_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgEnabled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "not enabled, please 'enable' it first"
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_activate_log_file
local timeout=''
IsOsCanQpkgTimeout&&timeout=' -t '$r_qpkg_start_timeout_seconds
local service_pathfile=$(GetQpkgServicePathFile)
DebugAsProc "activating $(FormatPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped-error 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} start" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
RunAndLog "/sbin/qpkg_service${timeout} start $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1
else
RunAndLog "$service_pathfile start" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" activate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISactive
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" activate '' failed "$z"
SendPackageStateChange ISNTactive
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reactivate_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgEnabled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "not enabled, please 'enable' it first"
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_reactivate_log_file
local timeout=''
IsOsCanQpkgTimeout&&timeout=' -t '$r_qpkg_restart_timeout_seconds
local service_pathfile=$(GetQpkgServicePathFile)
DebugAsProc "reactivating $(FormatPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped-error 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} restart" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
RunAndLog "/sbin/qpkg_service${timeout} restart $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1
else
RunAndLog "$service_pathfile restart" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' ok
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' failed "$z"
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:deactivate_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_deactivate_log_file
local timeout=''
IsOsCanQpkgTimeout&&timeout=' -t '$r_qpkg_stop_timeout_seconds
local service_pathfile=$(GetQpkgServicePathFile)
DebugAsProc "deactivating $(FormatPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped-error 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} stop" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
RunAndLog "/sbin/qpkg_service${timeout} stop $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk&&z=0||z=1
else
RunAndLog "$service_pathfile stop" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISNTactive
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' failed "$z"
MarkActionForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:enable_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsQpkgEnabled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'already enabled'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_enable_log_file
local timeout=''
IsOsCanQpkgTimeout&&timeout=' -t '$r_qpkg_enable_timeout_seconds
DebugAsProc "enabling $(FormatPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} enable $qpkg_name" "$r_log_pathfile" log:failure-only
ClearQpkgInstalledAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" enable '' ok
MarkActionForkAsOk
FuncForkExit $z;}
_QPKG:disable_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgEnabled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'already disabled'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_disable_log_file
local timeout=''
IsOsCanQpkgTimeout&&timeout=' -t '$r_qpkg_disable_timeout_seconds
DebugAsProc "disabling $(FormatPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} disable $qpkg_name" "$r_log_pathfile" log:failure-only
ClearQpkgInstalledAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" disable '' ok
MarkActionForkAsOk
FuncForkExit $z;}
_QPKG:enableau_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is always enabled'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is unsupported'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "enabling auto-update $(FormatPackageName)"
RunAndLog "${a}$(GetQpkgServicePathFile) enable-auto-update" "$r_logs_path/$qpkg_name.$r_enableau_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" enableau '' ok
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" enableau '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:disableau_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update cannot be disabled'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update is unsupported'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "disabling auto-update $(FormatPackageName)"
RunAndLog "${a}$(GetQpkgServicePathFile) disable-auto-update" "$r_logs_path/$qpkg_name.$r_disableau_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" disableau '' ok
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" disableau '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:backup_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'backup is unsupported'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "backing-up $(FormatPackageName) configuration"
RunAndLog "${a}$(GetQpkgServicePathFile) backup" "$r_logs_path/$qpkg_name.$r_backup_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" backup '' ok
SendPackageStateChange ISbackedup
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" backup '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:restore_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "not installed, try 'rebuild' instead"
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'restore is unsupported'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'backup file does not exist'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "restoring $(FormatPackageName) configuration"
RunAndLog "${a}$(GetQpkgServicePathFile) restore" "$r_logs_path/$qpkg_name.$r_restore_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" restore '' ok
SendPackageStateChange ISrestored
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" restore '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:clean_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsQpkgDbCanClean;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'clean is unsupported'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "cleaning $(FormatPackageName)"
RunAndLog "${a}$(GetQpkgServicePathFile) clean" "$r_logs_path/$qpkg_name.$r_clean_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" clean '' ok
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" clean '' failed "$z"
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:sign_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
local b=''
local -i z=0
if [[ -e $r_abort_actions_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort 'abort requested, unable to continue'
MarkActionForkAsSkippedAbort
z=3
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugVar sqlite_cmd
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'incompatible author'
MarkActionForkAsSkipped
z=1
elif ! IsOsCanSignedPackages;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not required: firmware<4.3.5'
MarkActionForkAsSkipped
z=1
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkipped
z=1
elif [[ ! -e $sqlite_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(FormatFileName sqlite3) binary not found"
MarkActionForkAsSkippedAbort
z=3
elif [[ ! -e $r_cert_db_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(GetOsName) QPKG certificate database not found"
MarkActionForkAsSkippedAbort
z=3
else
a="SELECT 1 FROM Certificate WHERE QpkgName = '$qpkg_name' LIMIT 1;"
b=$(eval "$sqlite_cmd" "$r_cert_db_pathfile" \"$a\")
if [[ $b = 1 ]];then
a="DELETE FROM Certificate WHERE QpkgName = '$qpkg_name';"
b=$(eval "$sqlite_cmd" "$r_cert_db_pathfile" \"$a\")
z=0
fi
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "\"signing\" $(FormatPackageName)"
a="INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$qpkg_name','$r_qpkg_certificate','$r_qpkg_signature');"
for((retries=0;retries<10;retries++));do
eval "$sqlite_cmd" "$r_cert_db_pathfile" "\"$a\""
z=$?
case $z in
5)
sleep 0.5;;
*)break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' ok
SendPackageStateChange ISsigned
MarkActionForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' failed "$(Parenthesise "$z") but don't know why. Please report this as a bug"
SendParentChangeEnv 'show_suggest_raise_issue=true'
MarkActionForkAsError
z=1
fi
FuncForkExit $z;}
_QPKG:status_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local a=''
local b=''
[[ $useropt_debug = true ]]&&b+='DEBUG_QPKG=true '
local -i z=0
if IsNtValidQpkgInstalled "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" status '' skipped 'not installed'
MarkActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit
DebugAsProc "status $(FormatPackageName)"
a=$(GetQpkgDbActiveTest)
if [[ $a = builtin ]];then
if [[ -e $r_gnu_timeout_cmd ]];then
$r_gnu_timeout_cmd "$r_qpkg_status_check_timeout_seconds" /bin/bash -c "${b}$(GetQpkgServicePathFile) status"
z=$?
else
RunAndLog "${b}$(GetQpkgServicePathFile) status" "$r_logs_path/$qpkg_name.$r_status_log_file" log:failure-only
z=$?
fi
elif [[ $a != none ]];then
eval "$a" &>/dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive;;
1)
SendPackageStateChange ISNTactive;;
124)
SendPackageStateChange ISslow;;
*)SendPackageStateChange ISunknown
esac
SaveActionResultToLog QPKG "$qpkg_name" status '' ok
MarkActionForkAsOk
FuncForkExit;}
ClearQpkgInstalledAppCenterNotifier(){
[[ -e /sbin/qpkg_cli ]]&&/sbin/qpkg_cli --cancel "$qpkg_name"
IsNtValidQpkgInstalled&&return
/sbin/setcfg "$qpkg_name" Status complete -f /etc/config/qpkg.conf
return 0
} &>/dev/null
LogQpkgServiceResult(){
if ! local a=$(GetQpkgServiceResult);then
DebugAsWarn "unable to get status of $(FormatPackageName) service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $a in
in-progress)
DebugInfo "$(FormatPackageName) service action is in-progress";;
ok)
DebugInfo "$(FormatPackageName) service action completed OK";;
failed)
if [[ -e /var/log/$qpkg_name.log ]];then
DebugAsError "$(FormatPackageName) service action failed. Check $(FormatFileName "/var/log/$qpkg_name.log") for more information"
AddExtLogToSessLog /var/log/$qpkg_name.log
else
DebugAsError "$(FormatPackageName) service action failed"
fi;;
*)DebugAsWarn "$(FormatPackageName) service status is unrecognised or unsupported"
esac
return 0;}
GetQpkgInstalledPath(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" Install_Path -d undefined -f /etc/config/qpkg.conf;}
GetQpkgServicePathFile(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" Shell -d undefined -f /etc/config/qpkg.conf;}
GetQpkgDbApplVer(){
local a=''
local -i i=0
if [[ $qpkg_index -gt 0 ]];then
a=${r_qpkg_appl_version[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_appl_version[$qpkg_default_index]}
[[ $a = version ]]&&a=${r_qpkg_version[$qpkg_default_index]}
[[ $a != none ]]||return
else
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$qpkg_name" ]];then
a=${r_qpkg_appl_version[$i]}
[[ $a = version ]]&&a=${r_qpkg_version[$qpkg_default_index]}
[[ $a != none ]]||return
break
fi
done
fi
[[ -n $a ]]||return
[[ $a = dynamic ]]&&IsValidQpkgInstalled&&! IsQpkgAutoUpdate&&a=static
printf '%s' "$a"
return 0;}
GetQpkgDbVer(){
local a=''
local -i i=0
a=${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}
if [[ -n $a ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$a" ]];then
printf '%s' "${r_qpkg_version[$i]}"
return 0
fi
done
fi
return 1;}
GetQpkgInstalledVer(){
/sbin/getcfg "${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}" Version -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledStoreID(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" store -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledDate(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" date -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledOriginalPath(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]];then
for i in "${!QPKGs_were_installed_name[@]}";do
[[ ${QPKGs_were_installed_name[$i]} = "$a" ]]||continue
printf '%s' "${QPKGs_were_installed_path[$i]}"
return 0
done
fi
return 1;}
GetQpkgDbPathFilename(){
local a=''
a=$(GetQpkgDbURL)
[[ -n $a ]]||return
[[ $(Lowercase "${a##*.}") != qpkg ]]&&a=${a%.*}.qpkg
printf '%s' "$r_qpkg_download_path/$(/usr/bin/basename "$a")"
return 0;}
GetQpkgDbHash(){
[[ -n $qpkg_name&&$qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
local a=''
a=${r_qpkg_hash[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_hash[$qpkg_default_index]}
[[ $a != none ]]||return
printf '%s' "$a"
return 0;}
GetQpkgDbURL(){
local a=''
local -i i=0
SetQpkgArch
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$1" ]]&&[[ ${r_qpkg_arch[$i]} = all||${r_qpkg_arch[$i]} = "$r_nas_qpkg_arch" ]];then
printf '%s' "${r_qpkg_url[$i]}"
return 0
fi
done
return 1
else
a=${r_qpkg_url[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_url[$qpkg_default_index]}
[[ -n $a ]]||a=none
printf '%s' "$a"
fi
return 0;}
GetQpkgDbMinRAM(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_min_ram_kb[$i]}
break
done
else
a=${r_qpkg_min_ram_kb[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_min_ram_kb[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMinOSVer(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_min_os_version[$i]}
break
done
else
a=${r_qpkg_min_os_version[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_min_os_version[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMaxOSVer(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_max_os_version[$i]}
break
done
else
a=${r_qpkg_max_os_version[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_max_os_version[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbAuthor(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
printf '%s' "${r_qpkg_author[$i]}"
return 0
done
return 1;}
GetQpkgAuthor(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" Author -f /etc/config/qpkg.conf;}
#GetQpkgAuthorEmail()
#GetQpkgAppAuthor()
#GetQpkgAppAuthorEmail()
GetQpkgDbDesc(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_description[$i]}
break
done
else
a=${r_qpkg_description[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_description[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbNote(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_note[$i]}
break
done
else
a=${r_qpkg_note[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_note[$qpkg_default_index]}
[[ $a = none ]]&&return 1
fi
printf '%s' "$a"
return 0;}
GetQpkgDbAbbrvs(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_abbrvs[$i]}
break
done
else
a=${r_qpkg_abbrvs[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_abbrvs[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbDependencies(){
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${r_qpkg_depends_on[$qpkg_index]}
[[ $g = none ]]&&return 1
[[ $g = default ]]&&g=${r_qpkg_depends_on[$qpkg_default_index]}
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=' '$x
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first&&-n $alt ]]&&first=$alt
if IsQpkgDbArchOK "$alt";then
out+=' '$alt
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then
out+=' '$first
first=''
fi
done
printf '%s' "$out"
return 0;}
GetQpkgDbOptDependencies(){
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${r_qpkg_opt_depends_on[$qpkg_index]}
[[ $g = none ]]&&return 1
[[ $g = default ]]&&g=${r_qpkg_opt_depends_on[$qpkg_default_index]}
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=' '$x
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first&&-n $alt ]]&&first=$alt
if IsQpkgDbArchOK "$alt";then
out+=' '$alt
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then
out+=' '$first
first=''
fi
done
printf '%s' "$out"
return 0;}
GetQpkgDbDependents(){
[[ -n $qpkg_name&&$qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRindependent.Exist "$qpkg_name";then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_depends_on[$i]} =~ $re ]];then
[[ ${ar[*]:-} != "${r_qpkg_name[$i]}" ]]&&ar+=(${r_qpkg_name[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1;}
GetQpkgDbOptionals(){
[[ -n $qpkg_name&&$qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRoptional.Exist "$qpkg_name";then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_opt_depends_on[$i]} =~ $re ]];then
[[ ${ar[*]:-} != "${r_qpkg_name[$i]}" ]]&&ar+=(${r_qpkg_name[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1;}
GetQpkgDbIPKs(){
[[ -n $qpkg_name&&$qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
local a=''
a=${r_qpkg_requires_ipks[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_requires_ipks[$qpkg_default_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgDbActiveTest(){
[[ -n $qpkg_name&&$qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
a=${r_qpkg_test_for_active[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_test_for_active[$qpkg_default_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgServiceAction(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local b=''
[[ -e /var/log/$a.action ]]&&b=$(</var/log/${a}.action)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi;}
GetQpkgServiceResult(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local b=''
[[ -e /var/log/$a.result ]]&&b=$(</var/log/${a}.result)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi;}
GetQpkgsIsInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgInstalled||continue
echo "$qpkg_name"
done;}
GetQpkgsIsValidInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsValidQpkgInstalled||continue
echo "$qpkg_name"
done;}
GetQpkgsNtInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsNtQpkgInstalled||continue
echo "$qpkg_name"
done;}
#GetQpkgsNtValidInstalled()
GetQpkgsIsEnabled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgEnabled||continue
echo "$qpkg_name"
done;}
GetQpkgsNtEnabled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsValidQpkgInstalled||continue
IsNtQpkgEnabled||continue
echo "$qpkg_name"
done;}
GetQpkgsIsComplete(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgComplete||continue
echo "$qpkg_name"
done;}
GetQpkgsNtComplete(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgInstalled||continue
IsNtQpkgComplete||continue
echo "$qpkg_name"
done;}
QpkgServiceResultWasOk(){
[[ -n ${qpkg_name:-} ]]||return
[[ $(GetQpkgServiceResult) = ok ]];}
QpkgMatchAbbrv(){
[[ -n ${1:-} ]]||return
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!r_qpkg_name[@]}";do
ar=(${r_qpkg_abbrvs[$i]})
for j in "${!ar[@]}";do
[[ ${ar[$j]} = "$1" ]]||continue
printf '%s' "${r_qpkg_name[$i]}"
z=0
break 2
done
done
return $z;}
IsUserOk(){
if ! IsUserSU;then
if IsOsCanSudo;then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${r_chars_sudo_prompt}sherpa $r_args_raw">&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again"
fi
return 1
fi
return 0;}
IsUserSU(){
[[ $EUID -eq 0 ]];}
IsCriticalFile(){
[[ -n ${1:?${FUNCNAME[0]}'()': $r_nopfile} ]]||exit
local a=${1%% *}
if ! [[ -f $a||-L $a ]];then
ShowAsAbort "a required NAS system file $(FormatFileName "$a") is missing"
return 1
fi
return 0;}
IsNtCriticalFile(){
! IsCriticalFile "${1:?${FUNCNAME[0]}'()': $r_nopfile}";}
IsFile(){
[[ -n ${1:?${FUNCNAME[0]}'()': $r_nopfile} ]]||exit
local a=${1%% *}
[[ -f $a&&-s $a ]];}
IsNtFile(){
! IsFile "${1:?${FUNCNAME[0]}'()': $r_nopfile}";}
IsFileRecent(){
[[ -e ${1:-}&&$((($(ConvertNowToSeconds)-$(/usr/bin/stat "$1" -c %Z))/60)) -le ${2:-1440} ]];}
IsEntwareUpgradable(){
local a=$(GetQpkgInstalledDate Entware)
[[ $a = undefined||${a//[!0-9]/} -le $r_entware_packages_last_updated ]]&&[[ $r_nas_arch != armv5tel ]];}
IsOsOk(){
if ! IsOsQNAP;then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0;}
IsOsQNAP(){
[[ -e /etc/init.d/functions ]]
} &>/dev/null
IsQuTS(){
/bin/grep -q zfs /proc/filesystems
} &>/dev/null
#IsQTS()
IsOsSupported(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 400 ]]
} &>/dev/null
IsOsCanAsyncQpkgActions(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 520 ]]
} &>/dev/null
IsOsCanSecureDownload(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 455 ]]
} &>/dev/null
IsOsCanQpkgTimeout(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 430 ]]
} &>/dev/null
IsOsCanSignedPackages(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 437 ]]
} &>/dev/null
IsOsCanUnofficialPackages(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -gt 426&&$r_nas_firmware_ver -le 436 ]]
} &>/dev/null
IsOsCanSudo(){
[[ -e /usr/bin/sudo ]]
} &>/dev/null
IsOsCanSedExtRegex(){
[[ $(echo -en "\033[1;97ma" | /bin/sed -r 's/\x1b\[[0-9;]*m//g' | /usr/bin/wc -c) -eq 1 ]];}
IsOsCanDecimalSleepSeconds(){
/bin/sleep .01
} &>/dev/null
IsOsCanAutowidthTableColumns(){
[[ -e $r_gnu_awk_cmd ]];}
IsOsCompatibleWithSigned(){
SetOsFirmwareDate
[[ $r_nas_firmware_date -lt 20201015||$r_nas_firmware_date -gt 20201020 ]]
} &>/dev/null
IsOsAllowUnsignedPackages(){
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert -d FALSE) = TRUE ]];}
IsOsAllowUnofficialPackages(){
[[ $(/sbin/getcfg 'QPKG Management' Check_Official -d TRUE) = FALSE ]];}
IsOsStarting(){
/bin/ps | /bin/grep '/bin/sh /etc/init.d/rcS' | /bin/grep -v grep
} &>/dev/null
IsOsStopping(){
/bin/ps | /bin/grep '/bin/sh /etc/init.d/rcK' | /bin/grep -v grep
} &>/dev/null
IsOsStartingPackages(){
if IsOsCanAsyncQpkgActions;then
/bin/ps | /bin/grep '/usr/local/sbin/qpkg_service start' | /bin/grep -v grep
else
IsOsStarting
fi
} &>/dev/null
IsOsStoppingPackages(){
if IsOsCanAsyncQpkgActions;then
/bin/ps | /bin/grep '/usr/local/sbin/qpkg_service stop' | /bin/grep -v grep
else
IsOsStopping
fi
} &>/dev/null
IsOsOnline(){
[[ $(GetOsState) = online ]];}
IsOsStdKernelPageSize(){
SetOsKernelPageSize
[[ $r_kernel_page_size = 4096B||$r_kernel_page_size = 4kiB ]];}
IsOsNonStdKernelPageSize(){
! IsOsStdKernelPageSize;}
IsOsLoadAverageElevated(){
IsOsLoadAverageAboveTrigger 2;}
IsOsLoadAverageHigh(){
IsOsLoadAverageAboveTrigger 4;}
IsOsLoadAverageInsane(){
IsOsLoadAverageAboveTrigger 8;}
IsOsLoadAverageAboveTrigger(){
local a=${1:-1}
local b=$(GetOsSysLoad1MinAverage);b=${b/./}
local c=$((r_cpu_cores*a*100))
[[ $((10#$b)) -ge $((10#$c)) ]];}
IsOsSedExtRegexSupported(){
[[ ${sed_ext_regex_supported-unset} = unset ]]&&SetOsSedRegexSupport
[[ $sed_ext_regex_supported -eq 0 ]];}
IsOsDecimalSleepSecondsSupported(){
[[ ${sleep_decimal_seconds_supported-unset} = unset ]]&&SetOsDecimalSleepSecondsSupport
[[ $sleep_decimal_seconds_supported -eq 0 ]];}
IsInTerminal(){
[[ -t 0 ]];}
IsError(){
[[ ${_script_error_flag_:=false} = true ]];}
IsNtError(){
[[ ${_script_error_flag_:=false} != true ]];}
IsQpkgRepoSelfManaged(){
local a=$(GetQpkgInstalledStoreID "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
[[ -z $a||$a = undefined||$a = sherpa ]];}
IsNtQpkgRepoSelfManaged(){
! IsQpkgRepoSelfManaged "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
IsQpkgBackupExist(){
[[ -e $r_qpkg_bu_path/${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}.config.tar.gz ]];}
IsQpkgUpgradable(){
IsValidQpkgInstalled&&IsQpkgRepoSelfManaged&&IsQpkgDbArchOK&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk&&[[ $(GetQpkgInstalledVer) != "$(GetQpkgDbVer)" ]];}
IsQpkgInstallable(){
IsNtQpkgInstalled&&IsNtValidQpkgInstalled&&IsQpkgDbArchOK&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk;}
IsQpkgDbDependent(){
[[ $qpkg_index -gt 0&&$qpkg_default_index -gt 0 ]]||return
local a=''
a=${r_qpkg_depends_on[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_depends_on[$qpkg_default_index]}
[[ $a != none ]];}
IsQpkgDbIndependent(){
! IsQpkgDbOptional&&! IsQpkgDbDependent;}
IsQpkgDbOptional(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local -i i=0
local re=\\b${a}\\b
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_opt_depends_on[$i]} =~ $re ]]||continue
return 0
done
return 1;}
IsQpkgDbArchOK(){
local a=$(GetQpkgDbURL "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
[[ -n $a&&$a != none ]];}
IsQpkgDbMinRAMOk(){
local a=$(GetQpkgDbMinRAM "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
[[ -n $a ]]&&[[ $a = none||$r_nas_ram_kb -ge $a ]];}
IsQpkgDbMinOSVerOk(){
local a=$(GetQpkgDbMinOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
SetOsFirmwareVer
[[ -n $a ]]&&[[ $a = none||$r_nas_firmware_ver -ge $a ]];}
IsQpkgDbMaxOSVerOk(){
local a=$(GetQpkgDbMaxOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
SetOsFirmwareVer
[[ -n $a ]]&&[[ $a = none||$r_nas_firmware_ver -le $a ]];}
IsQpkgDbCanBackup(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_can_backup[$i]}
break
done
else
a=${r_qpkg_can_backup[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_can_backup[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbCanRestartToUpdate(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
${r_qpkg_can_restart_to_update[$i]}&&return 0||break
done
return 1;}
IsQpkgDbCanClean(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
${r_qpkg_can_clean[$i]}&&return 0||break
done
return 1;}
IsQpkgDbSherpaCompatible(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_is_sherpa_compatible[$i]}
break
done
else
a=${r_qpkg_is_sherpa_compatible[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_is_sherpa_compatible[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbUniqueUnpack(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_is_unique_unpack[$i]}
break
done
else
a=${r_qpkg_is_unique_unpack[$qpkg_index]}
[[ $a = default ]]&&a=${r_qpkg_is_unique_unpack[$qpkg_default_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbWillLog(){
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}" ]]||continue
${r_qpkg_will_log[$i]}&&return 0||break
done
return 1;}
IsQpkgAutoUpdate(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
[[ $(/sbin/getcfg "$a" Auto_Update -u -f /etc/config/qpkg.conf) = TRUE ]];}
IsQpkgAuthorOk(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
[[ $(GetQpkgDbAuthor "$a") = "$(GetQpkgAuthor "$a")" ]];}
IsNtQpkgAuthorOk(){
! IsQpkgAuthorOk "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
IsValidQpkgInstalled(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
/bin/grep -q "^\[$a\]" /etc/config/qpkg.conf&&IsQpkgAuthorOk "$a";}
IsNtValidQpkgInstalled(){
! IsValidQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
IsQpkgInstalled(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
/bin/grep -q "^\[$a\]" /etc/config/qpkg.conf;}
IsNtQpkgInstalled(){
! IsQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
IsQpkgMissing(){
local a=$(GetQpkgInstalledPath "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}")
[[ $a != undefined&&! -d $a ]];}
IsQpkgComplete(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
[[ $(/sbin/getcfg "$a" Status -d undefined -f /etc/config/qpkg.conf) = complete ]]&&[[ $(/sbin/getcfg "$a" Incomplete_Conf -d undefined -f /etc/config/qpkg.conf) != 1 ]];}
IsNtQpkgComplete(){
! IsQpkgComplete "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
IsQpkgEnabled(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}
[[ $(/sbin/getcfg "$a" Enable -u -d undefined -f /etc/config/qpkg.conf) = TRUE ]];}
IsNtQpkgEnabled(){
! IsQpkgEnabled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
#IsQpkgSigned()
IsQpkgTimeoutsIncreased(){
[[ -e /usr/local/sbin/qpkg_service.orig ]];}
IsNumber(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
[[ ${#a} -gt 0 ]];}
IsAnsiStrippingSupported(){
if IsOsSedExtRegexSupported;then
true
elif [[ -e /opt/bin/sed&&-L /opt/etc/passwd ]];then
true
else
false
fi;}
CreatePidFile(){
pidfile=$(/bin/mktemp "$r_async_procs_path"/proc_XXXXXX);}
WritePidFile(){
[[ -n ${1:-}&&-n ${pidfile:-} ]]||return
echo "$1">"$pidfile";}
RemovePidFile(){
[[ -n ${pidfile:-}&&-e $pidfile ]]||return
rm -f "$pidfile";}
LocateSQLiteBinary(){
local a=''
sqlite_cmd=''
sqlite_pathfile=''
if [[ -z ${sqlite_cmd:-} ]]&&IsQpkgInstalled Entware;then
sqlite_pathfile=/opt/bin/sqlite3
[[ -e $sqlite_pathfile ]]&&sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]]&&IsQpkgInstalled HybridBackup;then
sqlite_pathfile=$(GetQpkgInstalledPath HybridBackup)/CloudConnector3/bin/sqlite3
[[ -e $sqlite_pathfile ]]&&sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]]&&IsQpkgInstalled ArchiwareP5;then
sqlite_pathfile=$(GetQpkgInstalledPath ArchiwareP5)/binaries/Linux/unknown/64/sqlite3
[[ -e $sqlite_pathfile ]]&&sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]];then
for a in container-station HD_Station;do
if IsQpkgInstalled "$a";then
sqlite_pathfile=$(GetQpkgInstalledPath "$a")/usr/bin/sqlite3
[[ -e $sqlite_pathfile ]]||continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in CacheMount qmiixagent qusbcam2 QPython312 QPython311 QPython39;do
if IsQpkgInstalled "$a";then
sqlite_pathfile=$(GetQpkgInstalledPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]]||continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in img2pdf Qsirch OCR_Converter;do
if IsQpkgInstalled "$a";then
sqlite_pathfile=$(GetQpkgInstalledPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]]||continue
sqlite_cmd="LD_LIBRARY_PATH=$(GetQpkgInstalledPath "$a")/lib $sqlite_pathfile"
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
sqlite_pathfile=/opt/bin/sqlite3
sqlite_cmd=$sqlite_pathfile
fi;}
LoadQpkgSigningCertDetails(){
r_qpkg_certificate=''
r_qpkg_signature=''
read -r -d '' r_qpkg_certificate<<EOB
-----BEGIN CERTIFICATE-----
MIIDxDCCAqygAwIBAgIEFQDq5zANBgkqhkiG9w0BAQsFADCBgDELMAkGA1UEBhMC
VFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYDVQQKDARR
TkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMMB1FOQVBfQ0ExIDAeBgkqhkiG9w0B
CQEWEXNlY3VyaXR5QHFuYXAuY29tMB4XDTI0MTAxMTA0MTgzOFoXDTI3MTAxMTA0
MTgzOFowgYgxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcM
BlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwDTkFTMRgwFgYDVQQDDA9E
b3dubG9hZFN0YXRpb24xIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29t
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA/Qkj1D64xGrzhK5bAI18
CBCCd8fC4xYKbjn6wtUEFprZqhazDAlL+FOH/VdwolqnXnhleJY6/GujMTqc0cjr
cZNNZi+vYH4HKQEZP9jCRrIe1xEqDPSnyn7/cT6VpWoFxFy6Bi44Rp8Y92SUDXac
rpGFzwhxxKJ8y+7XxcCfkNdbP6cgZBDcToxKPL41ffhja58oNmWiy9+d7N7dGQiE
tm5vWlRDLwz91vjYRqTgdUZh+41esh+KQP+NwXXufc4wcgYBpqJ9/qisuSrjG2hm
h1GlX3rFDw6UIwAKwJIzFB5fqZ1ry4D21BenNzdyX/a76a9oePqZsaCVPlct7emg
lwIDAQABozwwOjA4BgNVHR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5h
cC5jb20vY3JsL3F0c192MS5jcmwwDQYJKoZIhvcNAQELBQADggEBADplp152NaL+
Ov1rBztUSPt6EecPvTC4EMg1+uziqPz54LUuufvVjDHp+rEhKR9mBLPoPHYK2Pc5
85iJ5fRcCSr+PNwH2ksfHUqbY0K2p2gFMTpsGYrXPVxmcS/t1l9IA0jFlCHkMHR6
oKdbLHzxGrKFNXxhagbobdw65OUvwP5lJDnk4aInfkWqXPV5Mh/+ZchPaCaD5IE4
GZFqR1gAlktHAhvwBJhurozMbd92mQt6AVHDWt1ump/qiUgkdz2VJrdCWRd51nJJ
Ij1A6hFRu9wdulkzQlp43rmD30Eloq7mJFlgXX3mSfAa6DyWuYych75cnSbNn5VP
/txPu6xSOp4=
-----END CERTIFICATE-----
EOB
read -r -d '' r_qpkg_signature<<EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename=\"smime.p7m\"
Content-Type: application/pkcs7-mime;smime-type=signed-data;name=\"smime.p7m\"
Content-Transfer-Encoding: base64

MIIGtAYJKoZIhvcNAQcCoIIGpTCCBqECAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFAQ/j77EF9kxli2d24Kj8bRyX+1GoIIDyDCCA8QwggKsoAMCAQIC
BBUA6ucwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZU
YWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwD
TkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBx
bmFwLmNvbTAeFw0yNDEwMTEwNDE4MzhaFw0yNzEwMTEwNDE4MzhaMIGIMQswCQYD
VQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNV
BAoMBFFOQVAxDDAKBgNVBAsMA05BUzEYMBYGA1UEAwwPRG93bmxvYWRTdGF0aW9u
MSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBxbmFwLmNvbTCCASIwDQYJKoZIhvcN
AQEBBQADggEPADCCAQoCggEBAP0JI9Q+uMRq84SuWwCNfAgQgnfHwuMWCm45+sLV
BBaa2aoWswwJS/hTh/1XcKJap154ZXiWOvxrozE6nNHI63GTTWYvr2B+BykBGT/Y
wkayHtcRKgz0p8p+/3E+laVqBcRcugYuOEafGPdklA12nK6Rhc8IccSifMvu18XA
n5DXWz+nIGQQ3E6MSjy+NX34Y2ufKDZlosvfneze3RkIhLZub1pUQy8M/db42Eak
4HVGYfuNXrIfikD/jcF17n3OMHIGAaaiff6orLkq4xtoZodRpV96xQ8OlCMACsCS
MxQeX6mda8uA9tQXpzc3cl/2u+mvaHj6mbGglT5XLe3poJcCAwEAAaM8MDowOAYD
VR0fBDEwLzAtoCugKYYnaHR0cDovL2Rvd25sb2FkLnFuYXAuY29tL2NybC9xdHNf
djEuY3JsMA0GCSqGSIb3DQEBCwUAA4IBAQA6ZadedjWi/jr9awc7VEj7ehHnD70w
uBDINfrs4qj8+eC1Lrn71Ywx6fqxISkfZgSz6Dx2Ctj3OfOYieX0XAkq/jzcB9pL
Hx1Km2NCtqdoBTE6bBmK1z1cZnEv7dZfSANIxZQh5DB0eqCnWyx88RqyhTV8YWoG
6G3cOuTlL8D+ZSQ55OGiJ35Fqlz1eTIf/mXIT2gmg+SBOBmRakdYAJZLRwIb8ASY
bq6MzG3fdpkLegFRw1rdbpqf6olIJHc9lSa3QlkXedZySSI9QOoRUbvcHbpZM0Ja
eN65g99BJaKu5iRZYF195knwGug8lrmMnIe+XJ0mzZ+VT/7cT7usUjqeMYICmjCC
ApYCAQEwgYkwgYAxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNV
BAcMBlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwDTkFTMRAwDgYDVQQD
DAdRTkFQX0NBMSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBxbmFwLmNvbQIEFQDq
5zALBglghkgBZQMEAgGggeQwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
hkiG9w0BCQUxDxcNMjQxMDE2MDgxNzQ0WjAvBgkqhkiG9w0BCQQxIgQggJireFTx
DlvBWly/Q5HA1BSoAikTAPk0XVMmIIZ93yQweQYJKoZIhvcNAQkPMWwwajALBglg
hkgBZQMEASowCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBAjAKBggqhkiG9w0DBzAO
BggqhkiG9w0DAgICAIAwDQYIKoZIhvcNAwICAUAwBwYFKw4DAgcwDQYIKoZIhvcN
AwICASgwDQYJKoZIhvcNAQEBBQAEggEA+rY8b+0bWHR5IENsfxZHEr1ya5ue4fGM
imlmR0BjABr3KP9gTGYbLR+dDQNkCtw9Fy1TLOCSuxxm1gdlBLOC8+uDE86jTh5D
RNyMsL/cNAdtGxmTVS2JsCE4zaI2IvlNsnJ4zZOnO1Hl4jBbJAlt7y0dQvbDbc/+
Cy54p/JW3IS9NqJ2QYTQdeLptRSXDHglLNjyQV5xK+qq/4DrJ+ALoesmfS/2aHar
1hBRm/B3nWXlh61rd4mMcSEU+rfOHaisa9OW97steR9TOb/xoyWI06qvSrBxoAxo
x+auuROm7C3dgpY7klCWav/j95cGdSacac30zlEhndA/UeOj9JImQw==
EOB
readonly r_qpkg_certificate
readonly r_qpkg_signature;}
MakePath(){
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path}&&-n ${2:?${FUNCNAME[0]}'()': undefined reason} ]]||return
if [[ $1 != undefined ]]&&! mkdir -p "$1";then
ShowAsError "unable to create $2 path $(FormatFileName "$1") $(FormatExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0;}
ClearPath(){
[[ -n ${1:?${FUNCNAME[0]}'()': undefined parent path}&&-n ${2:?${FUNCNAME[0]}'()': undefined target path} ]]||return
local parent=${1:-undefined}
local target=$(/usr/bin/basename "${2:-undefined}")
[[ -n $parent&&$parent != undefined&&-n $target&&$target != undefined&&-d $parent/$target ]]&&rm -rf "${parent:?}/${target:?}"/*;}
FileCountAll(){
[[ -n ${1:-} ]]||return
compgen -G "$1/*" | /usr/bin/wc -l | /bin/sed 's/^ *//';}
FileCountSpec(){
[[ -n ${1:-} ]]||return
compgen -G "$1" | /usr/bin/wc -l | /bin/sed 's/^ *//';}
RunAndLog(){
[[ -n ${1:?${FUNCNAME[0]}'()': undefined commandstring}&&-n ${2:?${FUNCNAME[0]}'()': $r_nopfile} ]]||return
FuncInit
MakePath "$r_run_logs_path" 'runtime logs'
local -r r_log_pathfile=$(/bin/mktemp "$r_run_logs_path"/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
local exec_msg='exec:'
if [[ ${1: -1} = "'" ]];then
exec_msg+=" \"$1\""
else
exec_msg+=" '$1'"
fi
DebugAsProc "$exec_msg"
FormatCommand "$1">"$2"
if [[ $useropt_verbose = true ]];then
eval "$1 > >(/usr/bin/tee $r_log_pathfile) 2>&1"
z=$?
else
(eval "$1">"$r_log_pathfile" 2>&1)
z=$?
fi
if [[ -e $r_log_pathfile ]];then
ShowAsResultAndStdout "$z" "$(<"$r_log_pathfile")">>"$2"
rm -f "$r_log_pathfile" 2>/dev/null
else
ShowAsResultAndStdout "$z" '<null>'>>"$2"
fi
exec_msg='exec: completed'
case $z in
0|"${4:-}")
[[ ${3:-} != log:failure-only||$useropt_debug = true ]]&&AddExtLogToSessLog "$2"
DebugAsDone "$exec_msg OK"
[[ $useropt_debug = false ]]&&rm -f "$2" 2>/dev/null;;
*)AddExtLogToSessLog "$2"
DebugAsError "$exec_msg, but with errors"
esac
FuncExit $z;}
DeDupeWords(){
[[ -n ${1:-} ]]||return
tr ' ' '\n'<<<"$1" | /usr/bin/sort | /bin/uniq | tr '\n' ' ' | /bin/sed 's/^[[:blank:]]*//;s/[[:blank:]]*$//';}
FileMatchesMD5(){
[[ $(GenerateMD5 "${1:?${FUNCNAME[0]}'()': $r_nopfile}") = "${2:?${FUNCNAME[0]}'()': undefined checksum}" ]];}
GenerateMD5(){
[[ -e ${1:?${FUNCNAME[0]}'()': $r_nopfile} ]]&&/bin/md5sum "${1:?${FUNCNAME[0]}'()': $r_nopfile}" | cut -f1 -d' ';}
Pluralise(){
[[ ${1:-0} -ne 1 ]]&&printf s;}
Capitalise(){
[[ -n ${1:-} ]]||return
if [[ $1 == sherpa* ]];then
printf '%s' "$1"
else
printf '%s' "$(Uppercase ${1:0:1})${1:1}"
fi;}
Parenthesise(){
printf '(%s)' "${1:-}";}
Bracketise(){
[[ -n ${1:-} ]]||return
printf '[%s]' "$1";}
AddPeriod(){
[[ -n ${1:-} ]]||return
[[ ${1: -1} != ':'&&${1: -1} != '?'&&${1: -1} != '.' ]]&&printf '%s.' "$1"||printf '%s' "$1";}
Uppercase(){
[[ -n ${1:-} ]]||return
tr 'a-z' 'A-Z'<<<"$1";}
Lowercase(){
[[ -n ${1:-} ]]||return
tr 'A-Z' 'a-z'<<<"$1";}
LTrim(){
[[ -n ${1:-} ]]||return
printf '%s' "${1##+(' ')}";}
RTrim(){
[[ -n ${1:-} ]]||return
printf '%s' "${1%%+(' ')}";}
Trim(){
[[ -n ${1:-} ]]||return
RTrim "$(LTrim "$1")";}
FormatAsThous(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
local b=''
local c=''
while [[ ${#a} -gt 0 ]];do
b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then
c=$b
else
c=$b,$c
fi
if [[ ${#b} -eq 3 ]];then
a=${a%???}
else
break
fi
done
printf '%s' "$c"
return 0;}
FormatAsIsoBytes(){
/bin/awk 'BEGIN{ u[0]="B";u[1]="kB";u[2]="MB";u[3]="GB"} { n = $1;i = 0;while(n>1000) { i+=1;n= int((n/1000)+0.5) } print n u[i] } '<<<"$1";}
ShowTitle(){
[[ $show_title = true&&$title_shown = false&&$useropt_verbose = false ]]||return
EraseThisLine
if [[ -z ${r_args_raw[*]:-} ]];then
Display "$(ShowTitleArt)"
else
Display "$(ShowAsTitleName) $(ShowAsVersion)"
fi
title_shown=true;}
ShowAsTitleName(){
TextBrightWhite sherpa;}
ShowTitleArt(){
Display "$(TextBrightOrange '     _')"
Display "$(TextBrightOrange ' ___| |__   ___ _ __ _ __   __ _')"
Display "$(TextBrightOrange "/ __| '_ \ / _ \ '__| '_ \ / _\` |")  $(ShowAsDescription)"
Display "$(TextBrightOrange '\__ \ | | |  __/ |  | |_) | (_| |')  $(ShowAsCopyrightBasic)"
Display "$(TextBrightOrange '|___/_| |_|\___|_|  | .__/ \__,_|')  $(ShowAsVersion)"
Display "$(TextBrightOrange '                    |_|')";}
ShowAsDescription(){
printf '%s' 'a mini-package-manager for QNAP NAS';}
ShowAsCopyrightBasic(){
printf '%s' 'Copyright (C) 2017-2025 OneCD';}
ShowAsVersion(){
printf '%s' "v$r_this_script_ver";}
#ShowAsEmail()
ShowAsAction(){
TextBrightYellow "$(Bracketise action)";}
ShowAsSetting(){
TextBrightYellow "$(Bracketise setting)";}
ShowAsPackages(){
TextBrightOrange "$(Bracketise packages)";}
ShowAsPackageGroup(){
TextBrightOrange "$(Bracketise 'package group')";}
ShowAsOptions(){
TextBrightRed "$(Bracketise options)";}
FormatPackageName(){
printf '%s' "${1:-${qpkg_name:?${FUNCNAME[0]}'()': $r_nopackname}}";}
FormatFileName(){
printf '%s' "'${1:?${FUNCNAME[0]}'()': $r_nofile}'";}
ShowAsURL(){
TextUnderlinedCyan "${1:?${FUNCNAME[0]}'()': undefined URL}";}
FormatExitcode(){
printf '%s' "[${1:?${FUNCNAME[0]}'()': undefined exitcode}]";}
FormatLogFilename(){
printf '%s' "${r_chars_results}log file: '${1:?${FUNCNAME[0]}'()': $r_nofile}'";}
FormatCommand(){
echo "${r_chars_results}command: '${1:?${FUNCNAME[0]}'()': undefined commandstring}'";}
ShowAsResultAndStdout(){
[[ -n ${1:-}&&-n ${2:-} ]]||return
local a=$r_chars_results
[[ ${1:-0} -ne 0 ]]&&a=$r_chars_alert
echo "${a}result_code: $(FormatExitcode "$1") ***** stdout/stderr begins below *****"
echo "$2"
echo "${a}***** stdout/stderr is complete *****";}
DisplayProcReport(){
[[ ${report_title_shown:=false} = false ]]||return
local a=''
[[ -n ${1:-} ]]&&a=$1' '
ShowAsProc "${a}report"
report_title_shown=true;}
DebugInfoMajSepr(){
DebugInfo "$(eval printf '%0.s=' "{1..$r_debug_log_full_width}")";}
DebugInfoMinSepr(){
DebugInfo "$(eval printf '%0.s-' "{1..$r_debug_log_full_width}")";}
DebugExtLogMinSepr(){
DebugAsLog "$(eval printf '%0.s-' "{1..$r_debug_log_full_width}")";}
DebugHardware(){
DebugItem "$1" hardware "$2" "$3";}
DebugKernel(){
DebugItem "$1" kernel "$2" "$3";}
DebugFirmware(){
DebugItem "$1" firmware "$2" "$3";}
DebugOS(){
DebugItem "$1" os "$2" "$3";}
DebugShell(){
DebugItem "$1" shell "$2" "$3";}
DebugUserspace(){
DebugItem "$1" userspace "$2" "$3";}
DebugStorage(){
DebugItem "$1" storage "$2" "$3";}
DebugScript(){
DebugItem ok script "$1" "$2";}
DebugIpk(){
DebugItem "$1" ipk "$2" "$3";}
DebugQpkg(){
DebugItem "$1" qpkg "$2" "$3";}
DebugItem(){
[[ -n ${1:-}&&-n ${2:-}&&-n ${3:-}&&-n ${4:-} ]]||return
local a=$(Uppercase "$2")
case $1 in
error)
DebugErrorTabld "$a" "$3" "$4";;
warning)
DebugWarningTabld "$a" "$3" "$4";;
info)
DebugInfoTabld "$a" "$3" "$4";;
*)DebugDetectTabld "$a" "$3" "$4"
esac;}
DebugDetectTabld(){
if [[ -z ${3:-} ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugInfoTabld(){
if [[ -z ${3:-} ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugWarningTabld(){
if [[ -z ${3:-} ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugErrorTabld(){
if [[ -z ${3:-} ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugVar(){
if [[ -n ${!1:-} ]];then
DebugAsVar "\$$1: '${!1}'"
else
DebugAsVar "\$$1: null"
fi;}
DebugArray(){
[[ -n ${1:-} ]]||return
if [[ -n ${2:-} ]];then
DebugAsArray "\$$1: ['$2']"
else
DebugAsArray "\$$1: null"
fi;}
DebugInfo(){
[[ -n ${1:-} ]]||return
if [[ ${2:-} = ' '||${2:-} = "'' " ]];then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi;}
FuncInit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn;}
FuncExit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
return ${1:-0};}
FuncForkInit(){
[[ -n ${pidfile:?${FUNCNAME[0]}'()': undefined \$pidfile} ]]||return
trap '[[ -n ${pidfile:-}&&-e $pidfile ]]&&rm -f "$pidfile" 2>/dev/null;exit' SIGINT
original_sess_active_pathfile=$sess_active_pathfile
sess_active_pathfile=$(/bin/mktemp "$r_action_logs_path"/"${FUNCNAME[1]}"_XXXXXX)
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn;}
FuncForkExit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
SendActionStatus ex
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
if [[ -n ${sess_active_pathfile:-}&&-e $sess_active_pathfile ]];then
if [[ -s $sess_active_pathfile ]];then
/bin/cat "$sess_active_pathfile">>"$original_sess_active_pathfile"
fi
rm -f "$sess_active_pathfile"
fi
RemovePidFile
exit ${1:-0}
} 2>/dev/null
CalcAmountDiff(){
if [[ $2 -gt $1 ]];then
printf '%s' "$(($2-$1))"
else
printf '%s' "$(($1-$2))"
fi
} 2>/dev/null
CalcMillisecondsDiffFromNanoseconds(){
printf '%s' "$((($2-$1)/(10**6)))"
} 2>/dev/null
ConvertSecondsToFullDate(){
/bin/date -d @"$1" "$r_full_datetime_format"
} 2>/dev/null
ConvertSecondsToDatecode(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
if [[ ${#a} -ne 10 ]];then
printf 000000
return 1
fi
/bin/date -d @"$a" '+%y%m%d'
} 2>/dev/null
ConvertSecondsToTime(){
/bin/date -d @"$1" '+%-l:%M:%S %p' | tr -s ' '
} 2>/dev/null
ConvertSecondsToDuration(){
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
if [[ $h -gt 0 ]];then
printf '%01dh:%02dm:%02ds' "$h" "$m" "$s"
elif [[ $m -gt 0 ]];then
printf '%01dm:%02ds' "$m" "$s"
else
[[ $s -eq 0 ]]&&s=1
if [[ $s -eq 1 ]];then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
fi
} 2>/dev/null
ConvertMillisecondsToSeconds(){
printf '%s' "$(($1/(10**3)))"
} 2>/dev/null
ConvertMillisecondsToDuration(){
ConvertSecondsToDuration "$(ConvertMillisecondsToSeconds "$1")"
} 2>/dev/null
ConvertMillisecondsToFuncDuration(){
if [[ ${1:-0} -lt 30000 ]];then
printf '%s' "$(FormatAsThous "${1:-0}")ms" | /usr/bin/tail -n1
else
ConvertMillisecondsToDuration "$1"
fi
} 2>/dev/null
ConvertNanosecondsToMilliseconds(){
printf '%s' "$(($1/(10**6)))"
} 2>/dev/null
ConvertLongDateAsHuman(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
if [[ ${#a} -ne 8 ]];then
printf 'invalid longdate code length'
return 1
fi
local b=${a:6:2}
local c=''
if((b>= 1&&b<= 10));then
c=early
elif((b>= 11&&b<= 20));then
c=mid
elif((b>= 21&&b<= 31));then
c=late
else
printf 'invalid day code'
return 1
fi
b=${a:4:2}
if((b<1||b>12));then
printf 'invalid month code'
return 1
fi
printf '%s-%s %s' "$c" "$(/bin/date -d 2025-$b-01 '+%B')" "${a::4}";}
ConvertAsSmartDate(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
local b=''
case ${#a} in
6)
b=$(/bin/date -d "${a::2}-${a:2:2}-${a:4:2}" "$r_extended_datetime_format");;
8)
b=$(/bin/date -d ${a::4}-${a:4:2}-${a:6:2} "$r_extended_datetime_format");;
10)
b=$(/bin/date -d @"$a" "$r_full_datetime_format")
esac
if [[ -n $b ]];then
printf '%s (%s)' "$1" "$b"
else
printf '%s' "$1"
fi
return
} 2>/dev/null
ConvertNowToFullDate(){
/bin/date "$r_full_datetime_format"
} 2>/dev/null
ConvertNowToSeconds(){
/bin/date +%s
} 2>/dev/null
ConvertNowToMilliseconds(){
ConvertNanosecondsToMilliseconds "$(ConvertNowToNanoseconds)"
} 2>/dev/null
ConvertNowToNanoseconds(){
/bin/date +%s%N
} 2>/dev/null
FormatAsLongMinutesSecs(){
local m=${1%%:*}
local s=${1#*:}
m=${m##* }
s=${s##* }
printf '%01dm:%02ds\n' "$((10#$m))" "$((10#$s))"
} 2>/dev/null
DebugAsFuncEn(){
DebugThis "$(Parenthesise '>>') ${FUNCNAME[2]}()";}
DebugAsFuncEx(){
DebugThis "$(Parenthesise '<<') ${FUNCNAME[2]}()|${1:-0}|${2:-}";}
DebugAsProc(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '--') $1";}
DebugAsDone(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '==') $1";}
DebugAsDetect(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '**') $1";}
DebugAsInfo(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise II) $1";}
DebugAsWarn(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise WW) $1";}
DebugAsError(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise EE) $1";}
DebugAsLog(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise LL) $1";}
DebugAsVar(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise vv) $1";}
DebugAsArray(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise aa) $1";}
DebugThis(){
[[ -n ${1:-} ]]||return
[[ ${useropt_verbose:-false} = true ]]&&ShowAsDebug "$1"
if [[ ${useropt_show_about:=false} = false&&${useropt_show_aboutall:=false} = false ]];then
WriteToLog dbug "$1"
fi;}
AddExtLogToSessLog(){
local a=''
local b=false
if [[ $useropt_verbose = true ]];then
b=true
useropt_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(FormatLogFilename "${1:?${FUNCNAME[0]}'()': $r_nopfile}")"
while read -r a;do
DebugAsLog "$a"
done<"$1"
DebugExtLogMinSepr
useropt_verbose=$b;}
ShowAsProcLong(){
[[ -n ${1:-} ]]&&ShowAsProc "${1:-} (might take a while)" "${2:-}"
}>&2
ShowAsProc(){
[[ -n ${1:-} ]]||return
local a=$1
local b=''
[[ -n ${2:-} ]]&&b=$2
local c="$a ... $b"
if [[ -z ${r_inhibit_display_pathfile:-} ]]||[[ -n ${r_inhibit_display_pathfile:-}&&! -e $r_inhibit_display_pathfile ]];then
if [[ ${useropt_verbose:=false} = false&&${useropt_terse:=true} = true ]]||[[ ${useropt_verbose:=false} = false&&-n $b ]];then
OpStepClearWait "$(TextBrightYellow proc)" "$c"
else
OpStepClear "$(TextBrightYellow proc)" "$c"
fi
fi
WriteToLog proc "$c"
}>&2
ShowAsDebug(){
[[ -n ${1:-} ]]&&OpStepClear "$(TextBlackOnCyan dbug)" "$1";}
ShowAsNote(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightYellow note)" "$a"
WriteToLog note "$a"
}>&2
ShowAsDone(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightGreen 'done')" "$a"
WriteToLog 'done' "$a"
}>&2
ShowAsWarn(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightOrange warn)" "$a"
WriteToLog warn "$a"
}>&2
ShowAsAbort(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightRed bort)" "$a"
WriteToLog bort "$a"
SetError
}>&2
ShowAsFail(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightRed fail)" "$a"
WriteToLog fail "$a"
}>&2
ShowAsError(){
local a=''
[[ -n ${1:-} ]]&&a=$(AddPeriod "$1")||return
OpStepClear "$(TextBrightRed derp)" "$a"
WriteToLog derp "$a"
SetError
}>&2
ShowAsQuiz(){
[[ -n ${1:-} ]]||return
OpStepClearWait "$(TextBrightOrangeBlink quiz)" "$1:"
WriteToLog quiz "$1:";}
ShowAsQuizDone(){
[[ -n ${1:-} ]]||return
OpStepClear "$(TextBrightOrange quiz)" "$1";}
ShowAsPercentProgress(){
local -r r_a=${1:-}
local -i b=${3:-0}
local -i c=${4:-0}
local -i d=${5:-0}
local -i e=${6:-0}
local -r r_f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then
ShowAsProc "$r_a" "$r_f"
else
ShowAsProcLong "$r_a" "$r_f"
fi
[[ $((b+c+d)) -ge $e ]]&&sleep 0.5
return 0
}>&2
PercFrac(){
local -i a=$((${1:-0}+${2:-0}+${3:-0}))
local -i b=${4:-0}
local c=''
[[ $b -gt 0 ]]||return
if [[ $a -gt $b ]];then
a=$b
c='100%'
else
c=$((200*(a+1)/(b+1)%2+100*(a+1)/(b+1)))%
fi
printf '%s' "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0
} 2>/dev/null
ShowAsIterativeProgress(){
local -r r_a=${1:?${FUNCNAME[0]}'()': undefined action}
local -i b=${2:-0}
local -r r_c=${3:?${FUNCNAME[0]}'()': undefined suffix1}
local -i d=${4:-0}
local -r r_e=${5:?${FUNCNAME[0]}'()': undefined suffix2}
local f=''
f="$(TextBrightWhite "$b") ${r_c}$(Pluralise "$b") ($(TextBrightWhite "$d") ${r_e}$(Pluralise "$d"))"
if [[ ${6:-short} != long ]];then
ShowAsProc "$r_a" "$f"
else
ShowAsProcLong "$r_a" "$f"
fi
return 0;}
ShowAsActionLogDetail(){
if [[ ${2:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
if [[ ${7:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$7"
return 1
fi
local package_type=''
local quantity_msg=''
package_type=$7$(Pluralise "$8")
case $8 in
0)
quantity_msg='no ';;
1)
:;;
*)quantity_msg=$8' '
esac
if [[ ${8:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$8"
return 1
fi
case ${4:-} in
failed)
if [[ -n "${6:-}" ]];then
case $3 in
download|?(reas)sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6";;
*)if IsQpkgDbWillLog "$2";then
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "for more information: /etc/init.d/$(/usr/bin/basename "$(GetQpkgServicePathFile "$2")") log"
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
fi
esac
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" 'no reason was provided by the service-script'
fi;;
skipped*)if [[ -n "${6:-}" ]];then
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "$6"
else
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "no reason provided"
fi;;
*)DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" "$5" "$6"
esac
return 0;}
OpStepClearWait(){
local -i n=4
[[ ${colourful:=$r_colourful_default} = true ]]&&n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
OpStepClear(){
local -i n=4
[[ $colourful = true ]]&&n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
WriteToLog(){
[[ -n ${1:-}&&-n ${2:-} ]]||return
[[ ${useropt_debug:=false} = true&&-n ${sess_active_pathfile:-} ]]&&printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")">>"$sess_active_pathfile";}
TextBrightGreen(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightYellow(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrange(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrangeBlink(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRed(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRedBlink(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
#TextCyan()
TextDarkGrey(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
#TextUnderlined()
TextUnderlinedCyan(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBlackOnCyan(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightWhite(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
Tableise(){
[[ -e $r_gnu_awk_cmd ]]||return
$r_gnu_awk_cmd '{
nf[NR]=NF
for (i = 1;i<= NF;i++) {
cell[NR,i] = $i
gsub(/\033\[[0-9;]*[mK]/, "", $i)
len[NR,i] = l = length($i)
if (l>max[i]) max[i] = l;}
}
END {
for (row = 1;row<= NR;row++) {
for (col = 1;col<nf[row];col++)
printf "%s%*s%s", cell[row,col], max[col]-len[row,col], "", OFS
print cell[row,nf[row]];}
}' FS='|' OFS="$(printf "%$((r_report_column_spacing))s")";}
StripANSICodes(){
if IsOsSedExtRegexSupported;then
echo -en "${1:-}" | /bin/sed -r 's/\x1b\[[0-9;]*m//g'
elif [[ -e /opt/bin/sed&&-L /opt/etc/passwd ]];then
echo -en "${1:-}" | /opt/bin/sed -r 's/\x1b\[[0-9;]*m//g'
else
echo -en "${1:-}"
fi
} 2>/dev/null
SetQpkgIndex(){
[[ -n ${qpkg_name:-} ]]||return
SetQpkgDefaultIndex
SetQpkgArch
for qpkg_index in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$qpkg_index]} = "$qpkg_name" ]]||continue
[[ ${r_qpkg_arch[$qpkg_index]} = all||${r_qpkg_arch[$qpkg_index]} = "$r_nas_qpkg_arch" ]]||continue
return 0
done
qpkg_index=0
return 1;}
SetQpkgDefaultIndex(){
[[ -n ${qpkg_name:-} ]]||return
for qpkg_default_index in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$qpkg_default_index]} = "$qpkg_name" ]]||continue
return 0
done
qpkg_default_index=0
return 1;}
SetError(){
run_package_actions=false
IsError&&return
_script_error_flag_=true
DebugVar _script_error_flag_;}
SetHardwareCPUCores(){
[[ ${r_cpu_cores-unset} = unset ]]&&readonly r_cpu_cores=$(GetHardwareCPUCores);}
SetHardwareInstalledRAM(){
[[ ${r_nas_ram_kb-unset} = unset ]]&&readonly r_nas_ram_kb=$(GetHardwareInstalledRAM);}
SetHardwarePlatform(){
[[ ${r_nas_platform-unset} = unset ]]&&readonly r_nas_platform=$(GetHardwarePlatform);}
SetCapabilities(){
SetColourisation
UpdateOsSedRegexSupport
UpdateOsDecimalSleepSupport;}
SetColourisation(){
if [[ $r_colourful_default = true ]];then
colourful=true
SendParentChangeEnv 'colourful=true'
else
colourful=false
SendParentChangeEnv 'colourful=false'
fi;}
SetOsSedRegexSupport(){
IsOsCanSedExtRegex
sed_ext_regex_supported=$?;}
SetOsDecimalSleepSecondsSupport(){
IsOsCanDecimalSleepSeconds
sleep_decimal_seconds_supported=$?;}
SetOsKernelPageSize(){
[[ ${r_kernel_page_size-unset} = unset ]]&&readonly r_kernel_page_size=$(GetOsKernelPageSize);}
SetOsFirmwareVersion(){
[[ ${r_nas_firmware_version-unset} = unset ]]&&readonly r_nas_firmware_version=$(GetOsFirmwareVersion);}
SetOsFirmwareVer(){
[[ ${r_nas_firmware_ver-unset} = unset ]]&&readonly r_nas_firmware_ver=$(GetOsFirmwareVer);}
SetOsFirmwareDate(){
[[ ${r_nas_firmware_date-unset} = unset ]]&&readonly r_nas_firmware_date=$(GetOsFirmwareDate);}
SetOsFirmwareBuild(){
[[ ${r_nas_firmware_build-unset} = unset ]]&&readonly r_nas_firmware_build=$(GetOsFirmwareBuild);}
SetNasArch(){
[[ ${r_nas_arch-unset} = unset ]]&&readonly r_nas_arch=$(GetNasArch);}
SetQpkgArch(){
[[ ${r_nas_qpkg_arch-unset} = unset ]]&&readonly r_nas_qpkg_arch=$(GetQpkgArch);}
UpdateOsSedRegexSupport(){
unset sed_ext_regex_supported
SetOsSedRegexSupport;}
UpdateOsDecimalSleepSupport(){
unset sleep_decimal_seconds_supported
SetOsDecimalSleepSecondsSupport;}
HideCursor(){
[[ ${useropt_verbose:=false} = false ]]&&printf '\033[?25l';}
ShowCursor(){
printf '\033[?25h';}
HideKeystrokes(){
[[ ${useropt_verbose:=false} = false&&-n ${r_gnu_stty_cmd:-}&&-e $r_gnu_stty_cmd ]]&&IsInTerminal&&$r_gnu_stty_cmd '-echo';}
ShowKeystrokes(){
[[ -n ${r_gnu_stty_cmd:-}&&-e $r_gnu_stty_cmd ]]&&IsInTerminal&&$r_gnu_stty_cmd 'echo';}
sleep(){
local n=${1:-}
[[ ${n//.} -eq 0 ]]&&n=1
if IsOsDecimalSleepSecondsSupported;then
/bin/sleep "$n"
elif [[ -e $r_gnu_sleep_cmd&&-L /opt/etc/passwd ]];then
$r_gnu_sleep_cmd "$n"
else
/bin/sleep "$((${n%.*}+1))"
fi
return 0
} 2>/dev/null
LoadObjects(){
[[ ${objects_loaded:=false} = false ]]||return 0
FuncInit
local curl_options=''
local new_archive_checksum=''
local original_archive_checksum=''
LoadLists
ShowAsProc objects
if [[ ! -e $PWD/dont-refresh-objects ]];then
IsFile "$r_objects_archive_pathfile"&&original_archive_checksum=$(GenerateMD5 "$r_objects_archive_pathfile")
if IsNtFile "$r_objects_archive_pathfile"||! IsFileRecent "$r_objects_archive_pathfile" "$r_file_change_threshold_minutes";then
DebugAsProc 'download objects archive'
IsOsCanSecureDownload||curl_options=' --insecure'
/sbin/curl${curl_options} --silent --fail "$r_objects_archive_url">"$r_objects_archive_pathfile"
if IsFile "$r_objects_archive_pathfile";then
DebugAsDone 'objects archive downloaded'
else
DebugAsWarn 'objects archive download failed'
fi
fi
fi
if IsFile "$r_objects_archive_pathfile";then
new_archive_checksum=$(GenerateMD5 "$r_objects_archive_pathfile")
else
DebugAsWarn 'object archive missing'
fi
if IsNtFile "$r_objects_pathfile"||[[ $original_archive_checksum != "$new_archive_checksum" ]];then
if IsFile "$r_objects_archive_pathfile";then
DebugAsProc 'extracting objects from archive'
/bin/tar --extract --gzip --no-same-owner --file="$r_objects_archive_pathfile" --directory="$r_cache_path"
if IsFile "$r_objects_pathfile";then
DebugAsDone 'extracted objects from archive'
else
DebugAsWarn 'extraction from archive failed'
fi
else
ShowAsAbort 'no object archive exists to extract from'
FuncExit 1;exit
fi
fi
if IsNtFile "$r_objects_pathfile";then
ShowAsAbort 'objects missing'
FuncExit 1;exit
fi
unset r_objects_epoch
r_objects_epoch=undefined
. "$r_objects_pathfile"
objects_loaded=true
readonly r_objects_epoch
DebugVar r_objects_epoch
FuncExit;}
LoadDatabase(){
[[ ${packages_loaded:=false} = false ]]||return 0
FuncInit
local new_archive_checksum=''
local original_archive_checksum=''
local curl_options=''
local previous=''
local qpkg_name=''
LoadObjects
ShowAsProc database
if [[ ! -e $PWD/dont-refresh-packages ]];then
IsFile "$r_packages_archive_pathfile"&&original_archive_checksum=$(GenerateMD5 "$r_packages_archive_pathfile")
if IsNtFile "$r_packages_archive_pathfile"||! IsFileRecent "$r_packages_archive_pathfile" "$r_file_change_threshold_minutes";then
DebugAsProc 'download database archive'
IsOsCanSecureDownload||curl_options=' --insecure'
/sbin/curl${curl_options} --silent --fail "$r_packages_archive_url">"$r_packages_archive_pathfile"
if IsFile "$r_packages_archive_pathfile";then
DebugAsDone 'database archive downloaded'
else
DebugAsWarn 'database archive download failed'
fi
fi
fi
if IsFile "$r_packages_archive_pathfile";then
new_archive_checksum=$(GenerateMD5 "$r_packages_archive_pathfile")
else
DebugAsWarn 'database archive missing'
fi
if IsNtFile "$r_packages_pathfile"||[[ $original_archive_checksum != "$new_archive_checksum" ]];then
if IsFile "$r_packages_archive_pathfile";then
DebugAsProc 'extracting database from archive'
/bin/tar --extract --gzip --no-same-owner --file="$r_packages_archive_pathfile" --directory="$r_cache_path"
if IsFile "$r_packages_pathfile";then
DebugAsDone 'extracted database from archive'
else
DebugAsWarn 'extraction from archive failed'
fi
InitQPKGsTiers
else
ShowAsAbort 'no database archive exists to extract from'
FuncExit 1;exit
fi
fi
if IsNtFile "$r_packages_pathfile";then
ShowAsAbort 'database missing'
FuncExit 1;exit
fi
unset r_qpkg_abbrvs
unset r_qpkg_appl_author
unset r_qpkg_appl_author_email
unset r_qpkg_appl_version
unset r_qpkg_arch
unset r_qpkg_author
unset r_qpkg_author_email
unset r_qpkg_can_backup
unset r_qpkg_can_clean
unset r_qpkg_can_restart_to_update
unset r_qpkg_conflicts_with
unset r_qpkg_depends_on
unset r_qpkg_description
unset r_qpkg_hash
unset r_qpkg_is_sherpa_compatible
unset r_qpkg_is_unique_unpack
unset r_qpkg_max_os_version
unset r_qpkg_min_os_version
unset r_qpkg_min_ram_kb
unset r_qpkg_name
unset r_qpkg_note
unset r_qpkg_opt_depends_on
unset r_qpkg_requires_ipks
unset r_qpkg_test_for_active
unset r_qpkg_url
unset r_qpkg_version
unset r_qpkg_will_log
unset r_base_qpkg_conflicts_with
unset readonly r_base_qpkg_warnings
unset r_essential_ipks
unset r_essential_pips
unset r_exclusion_pips
unset r_packages_epoch
r_packages_epoch=undefined
r_qpkg_abbrvs+=('')
r_qpkg_appl_author+=('')
r_qpkg_appl_author_email+=('')
r_qpkg_appl_version+=('')
r_qpkg_arch+=('')
r_qpkg_author+=('')
r_qpkg_author_email+=('')
r_qpkg_can_backup+=('')
r_qpkg_can_clean+=('')
r_qpkg_can_restart_to_update+=('')
r_qpkg_conflicts_with+=('')
r_qpkg_depends_on+=('')
r_qpkg_description+=('')
r_qpkg_hash+=('')
r_qpkg_is_sherpa_compatible+=('')
r_qpkg_is_unique_unpack+=('')
r_qpkg_max_os_version+=('')
r_qpkg_min_os_version+=('')
r_qpkg_min_ram_kb+=('')
r_qpkg_name+=('')
r_qpkg_note+=('')
r_qpkg_opt_depends_on+=('')
r_qpkg_requires_ipks+=('')
r_qpkg_test_for_active+=('')
r_qpkg_url+=('')
r_qpkg_version+=('')
r_qpkg_will_log+=('')
. "$r_packages_pathfile"
packages_loaded=true
readonly r_qpkg_abbrvs
readonly r_qpkg_appl_author
readonly r_qpkg_appl_author_email
readonly r_qpkg_appl_version
readonly r_qpkg_arch
readonly r_qpkg_author
readonly r_qpkg_author_email
readonly r_qpkg_can_backup
readonly r_qpkg_can_clean
readonly r_qpkg_can_restart_to_update
readonly r_qpkg_conflicts_with
readonly r_qpkg_depends_on
readonly r_qpkg_description
readonly r_qpkg_hash
readonly r_qpkg_is_sherpa_compatible
readonly r_qpkg_is_unique_unpack
readonly r_qpkg_max_os_version
readonly r_qpkg_min_os_version
readonly r_qpkg_min_ram_kb
readonly r_qpkg_name
readonly r_qpkg_note
readonly r_qpkg_opt_depends_on
readonly r_qpkg_requires_ipks
readonly r_qpkg_test_for_active
readonly r_qpkg_url
readonly r_qpkg_version
readonly r_qpkg_will_log
readonly r_base_qpkg_conflicts_with
readonly r_base_qpkg_warnings
readonly r_essential_ipks
readonly r_essential_pips
readonly r_exclusion_pips
readonly r_packages_epoch
readonly r_qpkgs_name_migration
DebugVar r_packages_epoch
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]]&&continue
QPKGs-GRall:Add "$qpkg_name"
previous=$qpkg_name
done
BuildQPKGsTiers
FuncExit;}
CaughtSIGINT(){
trap - SIGINT
[[ -n ${r_inhibit_display_pathfile:-} ]]&&/bin/touch "$r_inhibit_display_pathfile"
[[ -n ${r_abort_actions_pathfile:-} ]]&&/bin/touch "$r_abort_actions_pathfile"
EraseThisLine
ShowAsAbort 'caught SIGINT'
CloseActionMsgPipe
exit;}
CaughtEXIT(){
trap - EXIT
ShowKeystrokes
ShowCursor
ReleaseLockfile;}
readonly r_script_startseconds=$(ConvertNowToSeconds)
trap CaughtSIGINT SIGINT
trap CaughtEXIT EXIT
Init||exit
ProcActions
ShowResults
IsNtError
