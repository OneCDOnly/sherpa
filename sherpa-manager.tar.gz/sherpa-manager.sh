#!/usr/bin/env bash
#* Please don't edit this file directly, it was built/modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#* sherpa-manager.sh
#* copyright (C) 2017-2024 OneCD.
#* Contact:
#*   one.cd.only@gmail.com
#* Description:
#*   This is the management script for the sherpa mini-package-manager.
#*   It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#* Project:
#*	 https://git.io/sherpa
#* Forum:
#*	 https://forum.qnap.com/viewtopic.php?t=132373
#* Tested on:
#*	 GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	 GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	   Copyright (C) 2007 Free Software Foundation, Inc.
#*   ... and periodically on:
#*	 GNU bash, version 5.0.17(1)-release (aarch64-openwrt-linux-gnu)
#*	   Copyright (C) 2019 Free Software Foundation, Inc.
#* License:
#*   This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
set -o nounset -o pipefail
shopt -s extglob
[[ $- != *m* ]] || set +m
ln -fns /proc/self/fd /dev/fd
readonly ARGS_RAW=$*
Init()
{
OsIsOk || return
UserIsOk || return
LoadConsts
LoadVars
UpdateCapabilities
LoadCMDs
CMDsIsOk || return
HideKeystrokes
HideCursor
LoadEnv || return
ClaimLockfile || return
CreatePaths || return
PrepareArgs
ParseManagementArgs || return
ParseHelpArgs || return
ArchivePriorSessLogs
DebugLogInit
ParseShowArgs || return
ParseListArgs || return
ParseActionArgs || return
ShowTitle
ShowArgSuggestions
CheckQPKGsConflicts || return
CheckQPKGsWarnings
DebugLogEnv
CheckTasks
CheckEnv
QPKGsAssignToActions
return 0
}
ShowResults()
{
FuncInit
local a=''
if [[ $generate_show_report = true ]];then
if [[ $useropt_show_log_last = true ]];then
ReleaseLockfile
ViewLogLast
elif [[ $useropt_show_log_tail = true ]];then
ReleaseLockfile
ViewLogTail
elif [[ $useropt_show_backups = true ]];then
ReleaseLockfile
ShowReportBackups
elif [[ $useropt_show_versions = true ]];then
ReleaseLockfile
ShowReportVersions
elif [[ $useropt_show_dependencies = true ]];then
ShowReportDependencies
elif [[ $useropt_show_features = true ]];then
ShowReportFeatures
elif [[ $useropt_show_packages = true ]];then
ShowReportPackages
elif [[ $useropt_show_repos = true ]];then
ShowReportRepos
elif [[ $useropt_show_status = true ]];then
ShowReportStatuses
fi
fi
if [[ $generate_list_report = true ]];then
if [[ ${packages_loaded:=false} = true ]];then
for a in "${QPKG_IS_STATES[@]}";do
case $a in
downloaded|signed)
:
;;
*)
if QPKGs.AClist.IS${a}.IsSet;then
QPKGs.IS${a}:Show
break
elif QPKGs.AClist.ISNT${a}.IsSet;then
QPKGs.ISNT${a}:Show
break
fi
esac
done
fi
fi
if [[ $useropt_paste_log_last = true ]];then
Log.Last:Paste
elif [[ $useropt_paste_log_tail = true ]];then
Log.Tail:Paste
fi
if [[ $useropt_help_basic = true ]];then
Help.Basic:Show
Help.Basic.Examples:Show
fi
if [[ $generate_help_report = true ]];then
ReleaseLockfile
if [[ $useropt_help_tips = true ]];then
Help.Tips:Show
elif [[ $useropt_help_abbreviations = true ]];then
Help.Abbreviations:Show
elif [[ $useropt_help_actions = true ]];then
Help.Actions:Show
elif [[ $useropt_help_actions_all = true ]];then
Help.ActionsAll:Show
elif [[ $useropt_help_lists = true ]];then
Help.Lists:Show
elif [[ $useropt_help_options = true ]];then
Help.Options:Show
elif [[ $useropt_help_packages = true ]];then
Help.Packages:Show
elif [[ $useropt_help_show = true ]];then
Help.Show:Show
elif [[ $useropt_help_problems = true ]];then
Help.Problems:Show
elif [[ $useropt_help_upgrades = true ]];then
Help.Upgrades:Show
elif [[ $useropt_help_groups = true ]];then
Help.Groups:Show
fi
fi
if [[ $generate_action_results_report = true || $generate_show_report = true ]];then
ShowReportAllActionResults
fi
[[ $show_backuploc = true ]] && Help.BackupLocation:Show
[[ $show_suggest_raise_issue = true ]] && Help.Issue:Show
DebugInfoMinSepr
DebugScript finished "$(ConvertNowToFullDate)"
DebugScript 'elapsed time' "$(ConvertSecondsToDuration "$(($(ConvertNowToSeconds)-SCRIPT_STARTSECONDS))")"
DebugInfoMajSepr
[[ $title_shown = true ]] && Display
FuncExit
[[ $archive_debug_afterward = true ]] && ArchiveActiveSessLog
ResetActiveSessLog
}
DebugLogInit()
{
DebugInfoMajSepr
DebugScript started "$(ConvertSecondsToFullDate "$SCRIPT_STARTSECONDS")"
DebugScript PID "$$"
DebugInfoMinSepr
DebugInfo 'Markers: (**) detected, (II) information, (WW) warning, (EE) error, (LL) log file, (--) processing,'
DebugInfo '(==) done, (>>) f entry, (<<) f exit, (aa) array name & values, (vv) variable name & value,'
DebugInfo '($1) positional argument value'
DebugInfoMinSepr
DebugVar THIS_PACKAGE_VER
DebugVar THIS_SCRIPT_VER
DebugVar LOADER_SCRIPT_VER
}
LoadConsts()
{
readonly QPKG_DISABLE_TIMEOUT_SECONDS=10
readonly QPKG_ENABLE_TIMEOUT_SECONDS=10
readonly QPKG_RESTART_TIMEOUT_SECONDS=1800
readonly QPKG_START_TIMEOUT_SECONDS=1500
readonly QPKG_STATUS_CHECK_TIMEOUT_SECONDS=15
readonly QPKG_STOP_TIMEOUT_SECONDS=300
readonly ACTION_RESULT_INDENT=6
readonly COLUMN_SPACING=2
readonly FILE_BYTES_COL_WIDTH=16
readonly FILE_CHANGE_DATE_COL_WIDTH=60
readonly FOOTER_NAME_COL_WIDTH=14
readonly HELP_DESC_INDENT=3
readonly HELP_SYNTAX_INDENT=6
readonly STD_COL_WIDTH=28
readonly PACKAGE_ABBS_COL_WIDTH=84
readonly PACKAGE_ACTION_COL_WIDTH=27
readonly PACKAGE_ACTIVE_TEST_BUILTIN_COL_WIDTH=11
readonly PACKAGE_APP_VER_COL_WIDTH=22
readonly PACKAGE_ARCH_COL_WIDTH=15
readonly PACKAGE_AUTHOR_COL_WIDTH=40
readonly PACKAGE_AUTO_UPDATE_COL_WIDTH=10
readonly PACKAGE_COMPATIBLE_COL_WIDTH=9
readonly PACKAGE_DEPENDENCIES_COL_WIDTH=29
readonly PACKAGE_DESCRIPTION_COL_WIDTH=10
readonly PACKAGE_ENABLED_COL_WIDTH=10
readonly PACKAGE_INSTALL_DATE_COL_WIDTH=20
readonly PACKAGE_INSTALLED_COL_WIDTH=12
readonly PACKAGE_MANAGED_COL_WIDTH=10
readonly PACKAGE_MAX_OS_COL_WIDTH=10
readonly PACKAGE_MIN_OS_COL_WIDTH=10
readonly PACKAGE_MIN_RAM_COL_WIDTH=14
readonly PACKAGE_NAME_COL_WIDTH=21
readonly FILE_NAME_COL_WIDTH=$((PACKAGE_NAME_COL_WIDTH+14))
readonly PACKAGE_PATH_COL_WIDTH=48
readonly PACKAGE_REPO_COL_WIDTH=40
readonly PACKAGE_STATUS_COL_WIDTH=23
readonly PACKAGE_SUPPORTS_BACKUP_COL_WIDTH=10
readonly PACKAGE_SUPPORTS_CLEAN_COL_WIDTH=11
readonly PACKAGE_SUPPORTS_START_TO_UPDATE_COL_WIDTH=11
readonly PACKAGE_TIER_COL_WIDTH=8
readonly PACKAGE_VER_COL_WIDTH=15
readonly CHARS_ALERT='! '
readonly CHARS_ATTENTION='* '
readonly CHARS_BLANK='  '
readonly CHARS_BULLET='• '
readonly CHARS_DROPEND='└─ '
readonly CHARS_ELLIPSIS='...'
readonly CHARS_NORMAL='- '
readonly CHARS_NOTE='* '
readonly CHARS_REGULAR_PROMPT='$ '
readonly CHARS_SUDO_PROMPT="${CHARS_REGULAR_PROMPT}sudo "
readonly CHARS_RESULTS='= '
readonly CHAR_SPACER=' '
readonly CHARS_SUPER_PROMPT='# '
readonly DEBUG_LOG_DATAWIDTH=101
readonly DEBUG_LOG_FIRST_COL_WIDTH=9
readonly DEBUG_LOG_SECOND_COL_WIDTH=22
readonly DEBUG_LOG_THIRD_COL_WIDTH=$((DEBUG_LOG_DATAWIDTH-DEBUG_LOG_FIRST_COL_WIDTH-DEBUG_LOG_SECOND_COL_WIDTH-4))
if OsIsSupportSudo;then
if [[ $(UserGetSudoUID) = undefined ]];then
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
else
readonly HELP_SYNTAX_PREFIX=$CHARS_REGULAR_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUDO_PROMPT
fi
else
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
fi
readonly FILE_CHANGE_THRESHOLD_MINUTES=60
readonly LOG_TAIL_LINES=5000
}
LoadVars()
{
action_msg_pipe_fd=none
archive_debug_afterward=false
backup_stdin_fd=none
branch_default=stable
fork_pid=''
generate_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
highlight_backups_older_than='2 weeks ago'
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
proc_counts_path=''
qpkg_timeouts_increased=false
run_package_actions=false
show_backuploc=false
show_action_results_failed=false
show_action_results_ok=false
show_action_results_skipped=false
show_suggest_raise_issue=false
show_title=true
show_action_results_zero=false
switch_colour=false
switch_branch=false
switch_terse=false
terse_default=true
title_shown=false
user_branch_value=''
user_colourful_value=''
user_terse_value=''
if [[ -t 0 ]];then
colourful_default=true
useropt_colourful=$(LoadSetting Colourful "$colourful_default")
else
colourful_default=false
useropt_colourful=false
fi
useropt_branch=$(LoadSetting Git_Branch "$branch_default")
useropt_check=false
useropt_debug=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_show=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_paste_log_last=false
useropt_paste_log_tail=false
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_features=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_repos=false
useropt_show_all_results=false
useropt_show_status=false
useropt_show_versions=false
useropt_terse=$(LoadSetting Terse "$terse_default")
useropt_verbose=false
}
LoadCMDs()
{
readonly GNU_AWK_CMD=/opt/bin/awk
readonly GNU_FIND_CMD=/opt/bin/find
readonly GNU_GREP_CMD=/opt/bin/grep
readonly GNU_LESS_CMD=/opt/bin/less
readonly GNU_SED_CMD=/opt/bin/sed
readonly GNU_SLEEP_CMD=/opt/bin/sleep
readonly GNU_SORT_CMD=/opt/bin/sort
readonly GNU_STTY_CMD=/opt/bin/stty
readonly GNU_TIMEOUT_CMD=/opt/bin/timeout
readonly OPKG_CMD=/opt/bin/opkg
readonly PERL_CMD=/opt/bin/perl
readonly PYTHON_CMD=/opt/bin/python
readonly PYTHON3_CMD=/opt/bin/python3
readonly PIP_CMD="$PYTHON3_CMD -m pip"
readonly AWK_CMD=/bin/awk
readonly BASENAME_CMD=/usr/bin/basename
readonly CAT_CMD=/bin/cat
CURL_CMD=/sbin/curl
readonly DF_CMD=/bin/df
readonly DIRNAME_CMD=/usr/bin/dirname
readonly DU_CMD=/usr/bin/du
readonly GREP_CMD=/bin/grep
readonly LESS_CMD=/bin/less
readonly MD5SUM_CMD=/bin/md5sum
readonly MKNOD_CMD=/bin/mknod
readonly MKTEMP_CMD=/bin/mktemp
readonly MORE_CMD=/bin/more
readonly PS_CMD=/bin/ps
readonly READLINK_CMD=/usr/bin/readlink
readonly SCREEN_CMD=/usr/sbin/screen
readonly SED_CMD=/bin/sed
readonly SH_CMD=/bin/sh
readonly SLEEP_CMD=/bin/sleep
readonly SORT_CMD=/usr/bin/sort
readonly TAIL_CMD=/usr/bin/tail
readonly TAR_CMD=/bin/tar
readonly TEE_CMD=/usr/bin/tee
readonly UNAME_CMD=/bin/uname
readonly UNIQ_CMD=/bin/uniq
readonly UNZIP_CMD=/usr/bin/unzip
readonly UPTIME_CMD=/usr/bin/uptime
readonly WC_CMD=/usr/bin/wc
}
CMDsIsOk()
{
IsSysFileExist $AWK_CMD || return
IsSysFileExist $BASENAME_CMD || return
IsSysFileExist $CAT_CMD || return
IsSysFileExist $CURL_CMD || return
IsSysFileExist $DF_CMD || return
IsSysFileExist $DIRNAME_CMD || return
IsSysFileExist $DU_CMD || return
IsSysFileExist $GREP_CMD || return
IsSysFileExist $MD5SUM_CMD || return
IsSysFileExist $MKNOD_CMD || return
IsSysFileExist $MKTEMP_CMD || return
IsSysFileExist $PS_CMD || return
IsSysFileExist $READLINK_CMD || return
IsSysFileExist $SCREEN_CMD || return
IsSysFileExist $SH_CMD || return
IsSysFileExist $TAIL_CMD || return
IsSysFileExist $TAR_CMD || return
IsSysFileExist $TEE_CMD || return
IsSysFileExist $UNAME_CMD || return
IsSysFileExist $UNIQ_CMD || return
IsSysFileExist $UNZIP_CMD || return
IsSysFileExist $UPTIME_CMD || return
[[ ! -e $SORT_CMD ]] && ln -s /bin/busybox "$SORT_CMD"
LocateSQLiteBinary
return 0
}
LocateSQLiteBinary()
{
local a=''
sqlite_pathfile=''
sqlite_cmd=''
if [[ -z ${sqlite_cmd:-} ]] && QpkgIsInstalled Entware;then
sqlite_pathfile=/opt/bin/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]] && QpkgIsInstalled HybridBackup;then
sqlite_pathfile=$(QpkgGetInstallationPath HybridBackup)/CloudConnector3/bin/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]] && QpkgIsInstalled ArchiwareP5;then
sqlite_pathfile=$(QpkgGetInstallationPath ArchiwareP5)/binaries/Linux/unknown/64/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]];then
for a in container-station HD_Station;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstallationPath "$a")/usr/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in CacheMount qmiixagent QPython312 QPython311 QPython39;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstallationPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in img2pdf Qsirch OCR_Converter;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstallationPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd="LD_LIBRARY_PATH=$(QpkgGetInstallationPath "$a")/lib $sqlite_pathfile"
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
sqlite_pathfile=/opt/bin/sqlite3
sqlite_cmd=$sqlite_pathfile
fi
}
LoadEnv()
{
ShowAsProc env
qpkg_name=sherpa
readonly CERT_DB_PATHFILE=/etc/config/nas_sign_qpkg.db
readonly CPU_CORES=$(HardwareGetCPUCores)
readonly CONCURRENCY=$CPU_CORES
readonly ENTWARE_VER=$(QpkgGetEntwareType)
readonly KERNEL_PAGE_SIZE=$(OsGetKernelPageSize)
readonly NAS_ARCH=$(OsGetArch)
readonly NAS_FIRMWARE_BUILD=$(OsGetFirmwareBuild)
readonly NAS_FIRMWARE_DATE=$(OsGetFirmwareDate)
readonly NAS_FIRMWARE_VER=$(OsGetFirmwareVer)
readonly NAS_PLATFORM=$(HardwareGetPlatform)
readonly NAS_QPKG_ARCH=$(QpkgGetArch)
readonly NAS_RAM_KB=$(HardwareGetInstalledRAM)
readonly NAS_UPSTATE=$(OsGetUpState)
OsIsSupportSecureDownload || CURL_CMD+=' --insecure'
readonly CURL_CMD
args=()
args_incomplete=()
qpkg_index=0
qpkg_default_index=0
useropt_branch=$(UserGetGitBranch)
readonly OBJECTS_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
readonly PACKAGES_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa.packages'/$useropt_branch/packages.tar.gz
readonly QPKG_BU_PATH=$(UserGetDefVol)/.qpkg_config_backup
readonly THIS_PACKAGE_PATH=$(QpkgGetInstallationPath)
if [[ -z $THIS_PACKAGE_PATH || $THIS_PACKAGE_PATH = undefined || ! -d $THIS_PACKAGE_PATH ]];then
ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1
fi
readonly CACHE_PATH=$THIS_PACKAGE_PATH/cache
readonly ACTION_TIMES_PATH=$CACHE_PATH/action.times
readonly ASYNC_PROCS_PATH=$CACHE_PATH/proc
readonly DEPENDENT_QPKGS_LIST_PATHFILE=$CACHE_PATH/dependents
readonly DISPLAY_INHIBIT_PATHFILE=$CACHE_PATH/display.inhibit
readonly INDEPENDENT_QPKGS_LIST_PATHFILE=$CACHE_PATH/independents
readonly IPK_CACHE_PATH=$CACHE_PATH/IPKs
readonly IPK_DL_PATH=$IPK_CACHE_PATH/downloads
readonly IPK_DOWNGRADE_PATH=$IPK_CACHE_PATH/downgrade
readonly PREV_IPK_LIST=$IPK_CACHE_PATH/ipk.list.save
readonly PIP_CACHE_PATH=$CACHE_PATH/PIPs
readonly PREV_PIP_LIST=$PIP_CACHE_PATH/pip.list.save
readonly OBJECTS_ARCHIVE_PATHFILE=$CACHE_PATH/objects.tar.gz
readonly OBJECTS_PATHFILE=$CACHE_PATH/objects
readonly PACKAGES_ARCHIVE_PATHFILE=$CACHE_PATH/packages.tar.gz
readonly PACKAGES_PATHFILE=$CACHE_PATH/packages
readonly QPKG_CACHE_PATH=$CACHE_PATH/QPKGs
readonly QPKG_DL_PATH=$QPKG_CACHE_PATH/downloads
readonly LOGS_PATH=$THIS_PACKAGE_PATH/logs
readonly OOM_LOG_PATHFILE=$LOGS_PATH/oom.log
readonly RAM_FREEUSED_PATHFILE=$LOGS_PATH/ram.freeused
readonly RAMFS_FREESPACE_PATHFILE=$LOGS_PATH/ramfs.freespace
readonly SCREEN_SESSIONS_PATHFILE=$LOGS_PATH/screen.sessions
readonly SESS_ACTION_RESULTS_PATHFILE=$LOGS_PATH/session.action.results.log
readonly SESS_ARCHIVE_PATHFILE=$LOGS_PATH/session.archive.log
readonly SESS_LAST_PATHFILE=$LOGS_PATH/session.last.log
readonly SESS_TAIL_PATHFILE=$LOGS_PATH/session.tail.log
sess_active_pathfile=$THIS_PACKAGE_PATH/session.$$.active.log
readonly ACTION_FORKS_COUNT=/var/run/sherpa/actions/forks
readonly ACTION_LOGS_PATH=/var/log/sherpa/actions/logs
readonly QPKG_STATES_PATH=/var/run/sherpa/packages/states
readonly ACTION_ABORT_PATHFILE=$QPKG_STATES_PATH/abort.action
readonly ACTION_MSG_PIPE=$QPKG_STATES_PATH/action.messages.pipe
readonly REPORT_COLS_PATH=/var/run/sherpa/report/columns
readonly REPORT_FLAGS_PATH=/var/run/sherpa/report/flags
readonly REPORTS_PATH=/var/log/sherpa/reports
readonly REPORT_OUTPUT_PATHFILE=$REPORTS_PATH/report.ansi
readonly RUN_LOGS_PATH=/var/run/sherpa/run.logs
readonly THIS_PACKAGE_VER=$(QpkgGetInstalledVer)
readonly THIS_SCRIPT_VER='240814'-$useropt_branch
readonly EXTERNAL_PACKAGES_ARCHIVE_PATHFILE=/opt/var/opkg-lists/entware
readonly EXTERNAL_PACKAGES_PATHFILE=$CACHE_PATH/Packages
[[ -e $PYTHON3_CMD && ! -L $PYTHON_CMD ]] && ln -s "$PYTHON3_CMD" "$PYTHON_CMD"
rm -f "$REPORT_OUTPUT_PATHFILE" "$RAMFS_FREESPACE_PATHFILE" "$DISPLAY_INHIBIT_PATHFILE" 2> /dev/null
if [[ -e $GNU_STTY_CMD && -t 0 ]];then
local terminal_dimensions=$($GNU_STTY_CMD size)
readonly SESS_ROWS=${terminal_dimensions% *}
readonly SESS_COLS=${terminal_dimensions#* }
else
readonly SESS_ROWS=40
readonly SESS_COLS=156
fi
}
LoadLists()
{
[[ ${lists_loaded:=false} = false ]] || return 0
PACKAGE_TIERS=(independent auxiliary dependent)
QPKG_IS_STATES=(active backedup downloaded enabled installable installed missing signed upgradable)
QPKG_ISNT_STATES=(active backedup downloaded enabled installable installed missing signed upgradable)
QPKG_IS_GROUPS=(all canbackup canclean canrestarttoupdate dependent hasdependents independent)
QPKG_ISNT_GROUPS=(canclean)
QPKG_STATES_TRANSIENT=(restarting slow starting stopping unknown)
QPKG_SERVICE_RESULTS=(failed ok)
QPKG_ACTIONS=(status list rebuild reassign download backup deactivate disable uninstall upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
IPK_ACTIONS=(downgrade download uninstall upgrade install)
PIP_ACTIONS=(uninstall upgrade install)
USER_QPKG_ACTIONS=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall restore sign status uninstall upgrade)
readonly PACKAGE_TIERS
readonly QPKG_IS_STATES
readonly QPKG_ISNT_STATES
readonly QPKG_IS_GROUPS
readonly QPKG_ISNT_GROUPS
readonly QPKG_STATES_TRANSIENT
readonly QPKG_SERVICE_RESULTS
readonly IPK_STATES
readonly QPKG_ACTIONS
readonly IPK_ACTIONS
readonly PIP_ACTIONS
readonly USER_QPKG_ACTIONS
local action=''
for action in "${QPKG_ACTIONS[@]}" check debug downgrade update;do
readonly "$(Uppercase "$action")"_LOG_FILE=$action.log
done
lists_loaded=true
}
CreatePaths()
{
ClearPath "$CACHE_PATH" "$ASYNC_PROCS_PATH"
ClearPath "$CACHE_PATH" "$IPK_CACHE_PATH"
ClearPath "$CACHE_PATH" "$IPK_DL_PATH"
ClearPath "$CACHE_PATH" "$PIP_CACHE_PATH"
ClearPath /var/run/sherpa/report "$REPORT_COLS_PATH"
ClearPath /var/run/sherpa/report "$REPORT_FLAGS_PATH"
MakePath "$ACTION_TIMES_PATH" 'action times' || return
MakePath "$ASYNC_PROCS_PATH" 'asynchronous process tracking' || return
MakePath "$CACHE_PATH" cache || return
MakePath "$IPK_CACHE_PATH" 'IPK cache' || return
MakePath "$IPK_DL_PATH" 'IPK download' || return
MakePath "$IPK_DOWNGRADE_PATH" 'IPK downgrade' || return
MakePath "$LOGS_PATH" logs || return
MakePath "$PIP_CACHE_PATH" 'PIP cache' || return
MakePath "$REPORT_COLS_PATH" 'report columns' || return
MakePath "$REPORT_FLAGS_PATH" 'report flags' || return
MakePath "$REPORTS_PATH" reports || return
MakePath "$QPKG_BU_PATH" 'QPKG backup' || return
MakePath "$QPKG_DL_PATH" 'QPKG download' || return
}
DebugLogEnv()
{
[[ $run_package_actions = true ]] || return 0
[[ $useropt_debug = true ]] || return 0
FuncInit
ShowAsProc 'log env'
DebugInfoMinSepr
DebugHardware ok model "$(get_display_name)"
DebugHardware ok CPU "$(HardwareGetCPUInfo)"
DebugHardware ok 'CPU cores' "$CPU_CORES"
DebugHardware ok 'CPU architecture' "$NAS_ARCH"
DebugHardware ok RAM "$(FormatAsThous "$NAS_RAM_KB")kiB"
DebugFirmware ok OS "$(OsGetQnapOS)"
if OsIsSupported;then
DebugFirmware ok version "$NAS_FIRMWARE_VER.$NAS_FIRMWARE_BUILD"
else
DebugFirmware warning version "$NAS_FIRMWARE_VER"
fi
if OsIsCompatibleWithSigned;then
DebugFirmware ok 'build date' "$NAS_FIRMWARE_DATE"
else
DebugFirmware warning 'build date' "$NAS_FIRMWARE_DATE"
fi
DebugFirmware ok 'kernel version' "$(OsGetKernelVersion)"
if OsIsStdKernelPageSize;then
DebugFirmware ok 'kernel page size' "$KERNEL_PAGE_SIZE"
else
DebugFirmware warning 'kernel page size' "$KERNEL_PAGE_SIZE"
fi
DebugFirmware ok platform "$NAS_PLATFORM"
case $NAS_UPSTATE in
starting-up|shutting-down)
DebugFirmware warning 'OS state' "$NAS_UPSTATE"
;;
*)
DebugFirmware ok 'OS state' "$NAS_UPSTATE"
esac
DebugFirmware ok 'OS uptime' "$(OsGetUptime)"
if OsIsLoadAverageElevated;then
DebugFirmware warning 'system load' "$(OsGetSysLoadAverages)"
else
DebugFirmware ok 'system load' "$(OsGetSysLoadAverages)"
fi
DebugUserspace ok 'GLIBC' "$(/sbin/ldd --version | head -n1 | cut -d' ' -f4) $(/sbin/ldd --version | /bin/grep Copyright | /bin/sed 's|\$||')"
DebugUserspace ok 'bash' "$(bash --version | head -n1)"
DebugUserspace ok 'shell options' "$-"
DebugUserspace ok 'time in shell' "$(UserGetTimeInShell)"
if OsIsSupportSudo;then
DebugUserspace ok '$SUDO_UID' "$(UserGetSudoUID)"
else
DebugUserspace ok '$SUDO_UID' 'N/A'
fi
DebugUserspace ok '$EUID' "$EUID"
DebugUserspace ok 'default volume' "$(UserGetDefVol)"
DebugUserspace ok '/opt' "$($READLINK_CMD /opt 2> /dev/null || printf 'not present')"
local public_share=$(/sbin/getcfg SHARE_DEF defPublic -d Qpublic -f /etc/config/def_share.info)
if [[ -L /share/$public_share ]];then
DebugUserspace ok "'$public_share' share" "/share/$public_share"
else
DebugUserspace warning "'$public_share' share" 'not present'
fi
if [[ ${#PATH} -le $DEBUG_LOG_THIRD_COL_WIDTH ]];then
DebugUserspace ok '$PATH' "$PATH"
else
DebugUserspace ok '$PATH (LHS-only)' "${PATH:0:$((DEBUG_LOG_THIRD_COL_WIDTH-${#CHARS_ELLIPSIS}))}${CHARS_ELLIPSIS}"
fi
DebugScript 'git branch' "$useropt_branch"
DebugScript 'logs path' "$LOGS_PATH"
DebugScript 'action concurrency' "$CONCURRENCY"
if OsIsSupportUnofficialPackages;then
if OsIsAllowUnofficialPackages;then
DebugQpkg detect 'allow unofficial' yes
else
DebugQpkg warning 'allow unofficial' no
fi
else
DebugQpkg detect 'allow unofficial' 'N/A'
fi
if OsIsSupportSignedPackages;then
if OsIsAllowUnsignedPackages;then
DebugQpkg detect 'allow unsigned' yes
else
DebugQpkg detect 'allow unsigned' no
fi
else
DebugQpkg detect 'allow unsigned' 'N/A'
fi
DebugQpkg detect architecture "$NAS_QPKG_ARCH"
DebugQpkg detect "$(ShowAsPackageName Entware) type" "$ENTWARE_VER"
DebugQpkg detect "$(ShowAsPackageName Entware) install date" "$(QpkgGetInstallDate Entware)"
if QpkgIsInstalled SortMyQPKGs;then
DebugQpkg detect "$(ShowAsPackageName SortMyQPKGs)" installed
else
DebugQpkg warning "$(ShowAsPackageName SortMyQPKGs)" 'not installed'
fi
if OsIsSupportQpkgTimeout;then
if QpkgIsInstalled IncreaseTimeouts;then
if QPKGs.IsTimeoutsIncreased;then
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" 'N/A'
fi
DebugInfoMinSepr
RunAndLog "$DF_CMD -h | $GREP_CMD '^Filesystem\|^none\|^tmpfs\|ram'" "$RAMFS_FREESPACE_PATHFILE"
DebugInfoMinSepr
RunAndLog "$SCREEN_CMD -ls" "$SCREEN_SESSIONS_PATHFILE" '' 1
DebugInfoMinSepr
RunAndLog '/usr/bin/free' "$RAM_FREEUSED_PATHFILE" '' 1
DebugInfoMinSepr
RunAndLog "$GREP_CMD -i 'out of memory\|oom-killer' /mnt/HDA_ROOT/.logs/kmsg" "$OOM_LOG_PATHFILE" '' 1
DebugInfoMinSepr
FuncExit
}
CheckTasks()
{
if [[ $arg_problem = true || $useropt_help_basic = true ]];then
generate_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
run_package_actions=false
fi
[[ $get_qpkg_states = true ]] || return 0
FuncInit
local action=''
local build_states=false
local group=''
local state=''
if [[ $useropt_check = true || $useropt_show_status = true ]];then
build_states=true
elif [[ $useropt_show_dependencies = true || $useropt_show_features = true || $useropt_show_packages = true || $useropt_show_repos = true ]];then
build_states=true
elif [[ $useropt_help_actions = true || $useropt_help_actions_all = true || $useropt_help_groups = true || $useropt_help_lists = true || $useropt_help_options = true || $useropt_help_packages = true || $useropt_help_problems = true || $useropt_help_tips = true || $useropt_help_upgrades = true || $useropt_show_all_results = true ]];then
:
else
LoadPackages
for action in "${USER_QPKG_ACTIONS[@]}";do
if QPKGs-AC${action}-to.IsAny;then
build_states=true
break
fi
for group in "${QPKG_IS_GROUPS[@]}";do
if QPKGs.AC${action}.GR${group}.IsSet;then
build_states=true
break 2
fi
done
for group in "${QPKG_ISNT_GROUPS[@]}";do
if QPKGs.AC${action}.GRNT${group}.IsSet;then
build_states=true
break 2
fi
done
for state in "${QPKG_IS_STATES[@]}";do
if QPKGs.AC${action}.IS${state}.IsSet;then
build_states=true
break 2
fi
done
for state in "${QPKG_ISNT_STATES[@]}";do
if QPKGs.AC${action}.ISNT${state}.IsSet;then
build_states=true
break 2
fi
done
done
fi
if [[ $build_states = true ]];then
QPKGs.States:Build
else
get_qpkg_states=false
run_package_actions=false
fi
FuncExit
}
CheckEnv()
{
[[ $run_package_actions = true ]] || return 0
FuncInit
ShowAsProc 'check env'
local installed_ver=''
local target_packages=''
if [[ $($GREP_CMD -i 'out of memory\|oom-killer' /mnt/HDA_ROOT/.logs/kmsg | $WC_CMD -l) -gt 0 ]];then
ShowAsWarn "the $(TextBrightRed 'Out-Of-Memory killer') has been triggered ... check for $(TextBrightRed inactive) QPKGs"
fi
if QpkgIsInstalled Entware;then
if [[ $ENTWARE_VER != none ]];then
_UpdateEntwarePackageList_ &
else
DebugAsWarn "$(ShowAsPackageName Entware) appears to be installed but is inactive. Please consider starting the $(ShowAsPackageName Entware) QPKG."
fi
if [[ $useropt_check = true ]] || QPKGs-ACupgrade-to.Exist Entware;then
ipks_install=true
ipks_upgrade=true
pips_install=true
if Python3IsOutdated;then
ShowAsNote "the $(TextBrightOrange Python) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'python*'
fi
if PerlIsOutdated;then
ShowAsNote "the $(TextBrightOrange Perl) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'perl*'
fi
fi
case $NAS_QPKG_ARCH in
a41)
if OsIsNonStdKernelPageSize;then
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($OPKG_CMD list-installed | $GREP_CMD "^${target_packages%% *} *" | head -n1 | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]];then
ipks_downgrade=true
ShowAsNote "various IPKs will be downgraded to suit $KERNEL_PAGE_SIZE kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
fi
target_packages='git git-http'
installed_version=$($OPKG_CMD list-installed | $GREP_CMD "^${target_packages%% *} *" | head -n1 | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 2392 ]];then
ipks_downgrade=true
ShowAsNote "git IPKs will be downgraded back to a working version"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
esac
fi
QPKGs.IsCanBackup:Build
QPKGs.IsCanRestartToUpdate:Build
QPKGs.IsCanClean:Build
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-ISupgradable.Exist sherpa;then
ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded"
QPKGs-ACupgrade-to:Add sherpa
fi
wait 2> /dev/null
FuncExit
}
QPKGsAssignToActions()
{
[[ $run_package_actions = true ]] || return 0
FuncInit
ShowAsProc 'QPKG assignment'
local action=''
local prospect=''
if QpkgIsInstalled Entware;then
local entware_install_date=$(QpkgGetInstallDate Entware)
if [[ $entware_install_date = undefined || ${entware_install_date//[!0-9]/} -le 20240809 ]] && [[ $NAS_ARCH != armv5tel ]];then
ShowAsNote "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were updated early in August 2024)"
QPKGs-ACreinstall-to:Add Entware
fi
fi
if QPKGs-ACrebuild-to.IsAny;then
for qpkg_name in $(QPKGs-ACrebuild-to:Array);do
QpkgSetIndex
if QPKGs-ISNTinstalled.Exist "$qpkg_name" && QpkgIsBackupExist;then
QPKGs-ACinstall-to:Add "$qpkg_name"
QPKGs-ACrestore-to:Add "$qpkg_name"
fi
done
fi
for qpkg_name in $(QPKGs-ACinstall-to:Array) $(QPKGs-ACreinstall-to:Array);do
QpkgSetIndex
for prospect in $(QpkgGetDependencies);do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
done
for qpkg_name in $(QPKGs-ISinstalled:Array);do
if [[ $useropt_check = true ]] || QPKGs-ACactivate-to.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDependencies);do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for action in reinstall reactivate upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDependents);do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
done
for action in deactivate uninstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDependents);do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
done
if QPKGs-ACreinstall-to.Exist Entware;then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACinstall-to.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDependents);do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in backup restore upgrade reinstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-ISenabled.Exist "$qpkg_name";then
QPKGs-ACdeactivate-to:Add "$qpkg_name"
! QPKGs-ACuninstall-to.Exist "$qpkg_name" && ! QPKGs-ACinstall-to.Exist "$qpkg_name" && QPKGs-ACactivate-to:Add "$qpkg_name"
fi
done
done
for action in reinstall install activate reactivate;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
QpkgSetIndex
for prospect in $(QpkgGetDependencies);do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
done
done
done
if QPKGs.ACuninstall.GRall.IsSet;then
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
QPKGs-ACactivate-to:Remove "$(QPKGs-ACreactivate-to:Array)"
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACinstall-to.Exist "$qpkg_name";then
QPKGs_were_installed_name+=("$qpkg_name")
QpkgSetIndex
QPKGs_were_installed_path+=("$($DIRNAME_CMD "$(QpkgGetInstallationPath)")")
fi
QPKGs-ACdeactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdownload-to:Add "$(QPKGs-ACinstall-to:Array)"
for qpkg_name in $(QPKGs-ACreinstall-to:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACdownload-to:Add "$qpkg_name"
done
for qpkg_name in $(QPKGs-ACupgrade-to:Array);do
QPKGs-ISupgradable.Exist "$qpkg_name" && QPKGs-ACdownload-to:Add "$qpkg_name"
done
if [[ $useropt_check = true ]];then
OsIsSupportSignedPackages && QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
for qpkg_name in $(QPKGs-GRdependent:Array);do
QPKGs-ISenabled.Exist "$qpkg_name" && QPKGs-ACreactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdeactivate-to:Remove sherpa
QPKGs-ACuninstall-to:Remove sherpa
if QPKGs-ACsign-to.IsAny || QPKGs-ACinstall-to.IsAny;then
LoadQpkgSigning
fi
FuncExit
}
ProcActions()
{
[[ $run_package_actions = true ]] || return
FuncInit
ShowAsProc 'package actions'
local tier=''
local action=''
local state=''
local -i tier_index=0
rm -f "$SESS_ACTION_RESULTS_PATHFILE" 2> /dev/null
ProcAction status all QPKG '"live" status' '"live" statused'
if [[ $useropt_show_status = false ]];then
ShowAsProc 'assign QPKGs by state'
for action in "${USER_QPKG_ACTIONS[@]}";do
for state in "${QPKG_IS_STATES[@]}";do
QPKGs.AC${action}.IS${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
done
for state in "${QPKG_ISNT_STATES[@]}";do
QPKGs.AC${action}.ISNT${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
done
done
fi
ProcAction rebuild all QPKG meta-rebuild meta-rebuilt
ProcAction reassign all QPKG reassign reassigned
ProcAction download all QPKG download downloaded
if QPKGs-ACdownload-er.IsNone && QPKGs-ACdownload-se.IsNone && QPKGs-ACdownload-sa.IsNone;then
for ((tier_index=${#PACKAGE_TIERS[@]}-1;tier_index>=0; tier_index--)); do
tier=${PACKAGE_TIERS[$tier_index]}
case $tier in
?(in)dependent)
ProcAction deactivate $tier QPKG deactivate deactivated
ProcAction disableau $tier QPKG 'disable auto-update' 'disabled auto-update'
ProcAction backup $tier QPKG backup backed-up
ProcAction disable $tier QPKG disable disabled
ProcAction uninstall $tier QPKG uninstall uninstalled
;;
auxiliary)
if QPKGs-ISenabled.Exist Entware;then
ModPathToEntware
PIPs:uninstall
IPKs:uninstall
fi
esac
done
for tier in "${PACKAGE_TIERS[@]}";do
case $tier in
?(in)dependent)
ProcAction upgrade $tier QPKG upgrade upgraded
ProcAction reinstall $tier QPKG reinstall reinstalled
ProcAction install $tier QPKG install installed
ProcAction restore $tier QPKG restore restored
ProcAction enableau $tier QPKG 'enable auto-update' 'enabled auto-update'
ProcAction clean $tier QPKG clean cleaned
[[ $tier = dependent ]] && ProcAction sign dependent QPKG '"sign"' '"signed"'
ProcAction enable $tier QPKG enable enabled
ProcAction reactivate $tier QPKG reactivate reactivated
ProcAction activate $tier QPKG activate activated
;;
auxiliary)
for action in status install reinstall upgrade activate;do
if (QPKGs-ACinstall-ok.Exist Entware) || QPKGs-AC${action}-to.IsAny && QPKGs-ISenabled.Exist Entware;then
ipks_downgrade=true
ipks_install=true
ipks_upgrade=true
pips_install=true
break
fi
done
if QPKGs-ISenabled.Exist Entware;then
ModPathToEntware
IPKs:upgrade
IPKs:install
IPKs:downgrade
PIPs:upgrade
PIPs:install
fi
QPKGs-ACinstall-ok.Exist Entware && [[ $sqlite_pathfile = /opt/bin/sqlite3 && -e $sqlite_pathfile ]] && OsIsSupportSignedPackages && QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
ProcAction sign independent QPKG '"sign"' '"signed"'
esac
done
fi
if [[ $useropt_debug = true ]];then
QPKGs.Actions:List
IPKs.Actions:List
PIPs.Actions:List
fi
if [[ $title_shown = true ]];then
if ErrorIsNt;then
ShowAsDone 'actions complete'
else
ShowAsFail 'actions complete with errors'
fi
fi
FuncExit
}
ProcAction()
{
FuncInit
local -r ACTION_PAST=${5:?${FUNCNAME[0]}'()': undefined action past}
local -r ACTION_PRESENT_MSG=${4:?${FUNCNAME[0]}'()': undefined action present}
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local original_colourful=$useropt_colourful
local package=''
local -i package_index=0
local -r PACKAGE_TYPE=${3:?${FUNCNAME[0]}'()': undefined package type}
local state=''
local -r TARGET_ACTION=${1:?${FUNCNAME[0]}'()': undefined action}
local -a target_packages=()
local -r TIER=${2:?${FUNCNAME[0]}'()': undefined tier}
total_count=0
DebugVar TARGET_ACTION
DebugVar TIER
DebugVar PACKAGE_TYPE
case $PACKAGE_TYPE in
QPKG)
TARGET_OBJECT_NAME=AC${TARGET_ACTION}-to
if [[ $TIER = all ]];then
target_packages=($(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array))
else
for package in $(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array);do
${PACKAGE_TYPE}s-GR${TIER}.Exist "$package" && target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]];then
DebugInfo 'nothing to process'
FuncExit;return
fi
if [[ $total_count -eq 1 ]];then
fork_progress_prefix="$ACTION_PRESENT_MSG $(TextBrightOrange "${target_packages[0]}") $PACKAGE_TYPE"
else
fork_progress_prefix="$ACTION_PRESENT_MSG $([[ $TIER != all ]] && echo "$TIER ")$(Uppercase "$PACKAGE_TYPE")$(Pluralise "$total_count")"
fi
SetMaxForks "$TARGET_ACTION"
InitForkCounts
OpenActionMsgPipe
re=\\bEntware\\b
if [[ $TARGET_ACTION = uninstall && ${target_packages[*]} =~ $re ]];then
ShowKeystrokes
fi
pidfile=$($MKTEMP_CMD "$ASYNC_PROCS_PATH"/bgproc_XXXXXX)
_LaunchOneActionWithManyForks_ "_${PACKAGE_TYPE}:${TARGET_ACTION}_" "${target_packages[@]}" &
echo "$!" > "$pidfile"
while [[ ${#target_packages[@]} -gt 0 && ! -e $ACTION_ABORT_PATHFILE ]];do
ReadFromActionMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
env)
eval "$msg1_value"
;;
change)
while true;do
for state in "${QPKG_IS_STATES[@]}" "${QPKG_STATES_TRANSIENT[@]}";do
case $msg1_value in
"IS${state}")
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${QPKG_ISNT_STATES[@]}" "${QPKG_STATES_TRANSIENT[@]}";do
case $msg1_value in
"ISNT${state}")
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
for group in "${QPKG_IS_GROUPS[@]}";do
case $msg1_value in
"GR${group}")
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Add "$msg2_value"
break 2
esac
done
for group in "${QPKG_ISNT_GROUPS[@]}";do
case $msg1_value in
"GRNT${group}")
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break
done
;;
status)
case $msg1_value in
ok)
[[ $TARGET_ACTION != status ]] && ((ok_count++))
;;
so)
((skip_ok_count++))
;;
sk)
((skip_count++))
;;
se)
((skip_error_count++))
;;
sa)
((skip_abort_count++))
/bin/touch "$ACTION_ABORT_PATHFILE"
;;
er)
((fail_count++))
esac
case $msg1_value in
ok|so|sk|se|sa|er)
[[ $(type -t QPKGs-AC${TARGET_ACTION}-to:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-to:Remove "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-${msg1_value}:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-${msg1_value}:Add "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-dn:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-dn:Add "$msg2_value"
;;
ex)
for package_index in "${!target_packages[@]}";do
if [[ ${target_packages[package_index]} = "$msg2_value" ]];then
unset 'target_packages[package_index]'
break
fi
done
;;
*)
DebugAsWarn "unidentified status in message queue: '$msg1_value'"
esac
;;
*)
DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
[[ -e $ACTION_ABORT_PATHFILE ]] && break
done
[[ $fail_count -gt 0 ]] && show_action_results_failed=true
[[ $ok_count -gt 0 ]] && show_action_results_ok=true
[[ $skip_count -gt 0 || $skip_ok_count -gt 0 || $skip_error_count -gt 0 || $skip_abort_count -gt 0 ]] && show_action_results_skipped=true
[[ ${#target_packages[@]} -gt 0 ]] && KillPID "$(<$pidfile)"
wait 2> /dev/null
CloseActionMsgPipe
[[ ${useropt_terse:=true} = false && $useropt_verbose = false ]] && echo
;;
IPK|PIP)
if [[ $ipks_downgrade = true || $ipks_install = true || $ipks_upgrade = true || $pips_install = true ]];then
InitForkCounts
${PACKAGE_TYPE}s:${TARGET_ACTION}
fi
esac
EraseForkCountPaths
FuncExit
ErrorIsNt
}
OpenActionMsgPipe()
{
[[ -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE" 2> /dev/null
[[ ! -p $ACTION_MSG_PIPE ]] && mknod "$ACTION_MSG_PIPE" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd<>$ACTION_MSG_PIPE"
}
CloseActionMsgPipe()
{
if [[ -n ${backup_stdin_fd:-} ]];then
[[ $backup_stdin_fd != none ]] && eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]] && eval "exec $backup_stdin_fd>&-"
fi
[[ -n ${action_msg_pipe_fd:-} && $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd>&-"
[[ -n ${ACTION_MSG_PIPE:-} && -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE" 2> /dev/null
}
SetMaxForks()
{
max_forks=$CONCURRENCY
local reason=''
if [[ $useropt_verbose = true ]];then
max_forks=1
reason='verbose mode is active'
elif [[ $useropt_debug = true ]];then
max_forks=1
reason='debug mode is active'
else
case ${1:-} in
?(re)install|upgrade)
max_forks=1
reason="'$1'"
;;
clean)
max_forks=$(((max_forks+1)/2))
reason="'$1'"
;;
backup|deactivate|download|uninstall)
max_forks=4
reason="'$1'"
;;
@(dis|en)able?(au)|rebuild|sign|status)
max_forks=8
reason="'$1'"
esac
[[ -n $reason ]] && reason+=' action was requested'
fi
[[ -n $reason ]] && DebugInfo "limiting \$max_forks to $max_forks because $reason"
DebugVar max_forks
}
PrepareArgs()
{
ShowAsProc args
local a=$(Lowercase "${ARGS_RAW//,/ }")
args=(${a/--/})
arg_problem=false
[[ -z $ARGS_RAW ]] && useropt_help_basic=true
}
ParseManagementArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
check)
generate_show_report=true
get_qpkg_states=true
requires_group=false
run_package_actions=true
user_action=$arg
useropt_check=true
;;
colo?(u)r?(ful)|follow|paste|terse)
requires_group=true
user_action=$arg
;;
debug|verbose)
requires_group=false
user_action=$arg
EnableVerbose
EnableDebugToArchiveAndFile
;;
reset)
DeleteSetting Colourful
DeleteSetting Git_Branch
DeleteSetting Terse
Reset
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
if [[ -n $action && -n $group ]];then
case $action in
colo?(u)r?(ful))
case $group in
true|false)
action=''
awaiting_group=false
switch_colour=true
user_colourful_value=$group
UpdateColourful
;;
*)
args_remaining+=("$action")
esac
;;
follow)
case $group in
?(un)stable)
action=''
awaiting_group=false
run_package_actions=false
switch_branch=true
user_branch_value=$group
UpdateBranch
;;
*)
args_remaining+=("$action")
esac
;;
paste)
case $group in
last)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_last=true
;;
tail)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_tail=true
;;
*)
args_remaining+=("$action")
esac
;;
terse)
case $group in
true|false)
action=''
awaiting_group=false
switch_terse=true
user_terse_value=$group
UpdateTerse
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseHelpArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
help)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs|actions|all|all-actions|groups|lists|options|packages|problems|show|tips|upgrades)
[[ -z $action ]] && action=help
esac
if [[ -n $action && -n $group ]];then
case $action in
help)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true
;;
actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true
;;
all|all-actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true
;;
groups)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true
;;
lists)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true
;;
options)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true
;;
packages)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true
;;
problems)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true
;;
show)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_show=true
;;
tips)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true
;;
upgrades)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
case $arg in
help)
run_package_actions=false
useropt_help_basic=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit
}
ParseShowArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
show)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs|backups|dependent|features|last|packages|repositories|results|status|tail)
[[ -z $action ]] && action=show
esac
if [[ -n $action && -n $group ]];then
case $action in
show)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_states=false
run_package_actions=false
useropt_help_abbreviations=true
;;
backups)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_backups=true
;;
dependent)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true
;;
features)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_features=true
;;
last)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_last=true
;;
packages)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_packages=true
;;
repositories)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true
;;
results)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_all_results=true
;;
status)
LoadObjects
QPKGs.ACstatus.GRall:Set
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=true
run_package_actions=true
useropt_show_status=true
;;
tail)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_tail=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseListArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
list)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs)
[[ -z $action ]] && action=list
esac
if [[ -n $action && -n $group ]];then
case $action in
list)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_states=true
run_package_actions=false
useropt_help_abbreviations=true
;;
?(NT)active)
LoadObjects
QPKGs.AClist.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
show_title=false
;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AClist.IS${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
?(in)dependent)
LoadObjects
QPKGs.AClist.GR${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
versions)
action=''
awaiting_group=false
generate_list_report=true
show_title=false
useropt_show_versions=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseActionArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
[[ -n ${args[*]:-} ]] && LoadPackages
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|rebuild|?(re|un)install|restore|sign|upgrade)
requires_group=true
user_action=$arg
;;
status)
generate_show_report=true
get_qpkg_states=true
requires_group=true
user_action=$arg
useropt_show_status=true
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg");DebugVar group
if [[ -n $action && -n $group ]];then
case $action in
?(de|re)activate|backup|clean|@(dis|en)able|reassign|@(re|un)install|restore|sign|upgrade)
case $group in
?(NT)active)
LoadObjects
QPKGs.AC${action}.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
esac
esac
case $group in
all|canbackup|?(NT)canclean|canrestarttoupdate|?(in)dependent|hasdependents)
LoadObjects
QPKGs.AC${action}.GR${group}:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_active_status=false
get_qpkg_states=true
run_package_actions=true
;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AC${action}.IS${group}:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_states=true
run_package_actions=true
;;
*)
LoadObjects
QPKGs-AC${action}-to:Add "$group"
awaiting_group=false
generate_action_results_report=true
get_qpkg_states=true
run_package_actions=true
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
action=$(MatchVerb "$arg")
case $action in
status)
LoadObjects
QPKGs.ACstatus.ISinstalled:Set
generate_show_report=true
get_qpkg_states=true
run_package_actions=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit
}
MatchVerb()
{
local a=${1:-}
case $a in
activate|start)
printf activate
;;
add|install)
printf install
;;
backup|clean|colo?(u)r?(ful)|@(dis|en)able|follow|help|list|paste|reassign|rebuild|reinstall|reset|restore|sign|terse)
printf '%s' "$a"
;;
c|check)
printf check
;;
deactivate|stop)
printf deactivate
;;
d?(e)bug)
printf debug
;;
disable-auto-update)
printf disableau
;;
enable-auto-update)
printf enableau
;;
reactivate|restart)
printf reactivate
;;
remove|rm|uninstall)
printf uninstall
;;
s|status?(es))
printf status
;;
show|view)
printf show
;;
update|upgrade)
printf upgrade
;;
v|verbose)
printf verbose
esac
}
MatchNoun()
{
local a=${1:-}
case $a in
a|abs|abbreviations)
printf abs
;;
action?(s))
printf actions
;;
action?(s)-all|all-action?(s))
printf all-actions
;;
active|no@(n|t)-inactive|no@(n|t)-stopped|started)
printf active
;;
all|entire|everything)
printf all
;;
b|backups)
printf backups
;;
backedup|canbackup|enabled|installable|installed|missing|results|show|?(un)stable)
printf '%s' "$a"
;;
d|deps|dependencies|dependent?(s))
printf dependent
;;
disable|false|no|off|unset)
printf false
;;
disabled|no@(n|t)-enabled)
printf NTenabled
;;
enable|on|set|true|yes)
printf true
;;
f|features)
printf features
;;
group?(s))
printf groups
;;
inactive|no@(n|t)-active|no@(n|t)-started|stopped)
printf NTactive
;;
indep?(endent)?(s))
printf independent
;;
l|last)
printf last
;;
list?(s))
printf lists
;;
log|tail)
printf tail
;;
me|problem?(s))
printf problems
;;
new|updat?(e)able|upgrad@(a|e)ble)
printf upgradable
;;
no@(n|t)-back?(ed)up)
printf NTbackedup
;;
no@(n|t)-installable)
printf NTinstallable
;;
no@(n|t)-installed)
printf NTinstalled
;;
no@(n|t)-missing)
printf NTmissing
;;
no@(n|t)-upgradable)
printf NTupgradable
;;
o|option?(s))
printf options
;;
p|package?(s)|qpkg?(s))
printf packages
;;
r|repos|repositories)
printf repositories
;;
s|status?(es))
printf status
;;
tip?(s))
printf tips
;;
upgrade?(s)|upgrading)
printf upgrades
;;
version?(s))
printf versions
;;
*)
QpkgMatchAbbrv "$a"
esac
}
ShowArgSuggestions()
{
FuncInit
local arg=''
local -a args_remaining=()
if [[ ${#args_incomplete[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args_incomplete[@]}";do
case $arg in
?(de|re)activate|backup|clean|@(dis|en)able|@(dis|en)able-auto-update|reassign|@(re|un)install|?(re)start|restore|rm|sign|stop|upgrade)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false
;;
colo?(u)r?(ful)|terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
DisplayAsProjSynIndentExam '' "$arg enable"
DisplayAsProjSynIndentExam '' "$arg disable"
arg_problem=true
useropt_help_basic=false
;;
follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to '$arg' like" "$arg stable"
DisplayAsProjSynIndentExam '' "$arg unstable"
arg_problem=true
useropt_help_basic=false
;;
install|rebuild)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg all"
arg_problem=true
useropt_help_basic=false
;;
list)
DisplayAsProjSynExam "please provide a valid source to '$arg' like" "$arg installable"
DisplayAsProjSynIndentExam '' "$arg new"
arg_problem=true
useropt_help_basic=false
;;
paste)
DisplayAsProjSynExam "please provide a valid source to '$arg' online like" "$arg log"
DisplayAsProjSynIndentExam '' "$arg last"
arg_problem=true
useropt_help_basic=false
;;
show)
DisplayAsProjSynExam "please provide a valid source after '$arg' like" "$arg abs"
DisplayAsProjSynIndentExam '' "$arg log"
DisplayAsProjSynIndentExam '' "$arg packages"
DisplayAsProjSynIndentExam '' "$arg results"
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && echo
ShowAsError "incomplete argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
args_remaining=()
fi
fi
if [[ ${#args[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args[@]}";do
case $arg in
active|@(dis|en)abled|started)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "deactivate $arg"
arg_problem=true
useropt_help_basic=false
;;
all)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before 'all' like" 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all QPKGs, use' 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed QPKG configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false
;;
all-deactivate|deactivate-all)
DisplayAsProjSynExam 'to deactivate all QPKGs, use' 'deactivate all'
arg_problem=true
useropt_help_basic=false
;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all QPKGs, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false
;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed QPKG configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false
;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all QPKGs, use' 'stop all'
arg_problem=true
useropt_help_basic=false
;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all QPKGs, use' 'uninstall all'
arg_problem=true
useropt_help_basic=false
;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all QPKGs, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false
;;
@(dis|en)able|false|off|no|on|true|yes)
DisplayAsProjSynExam "please provide a valid setting before '$arg' like" "colour $arg"
DisplayAsProjSynIndentExam '' "terse $arg"
arg_problem=true
useropt_help_basic=false
;;
download)
ShowAsError "'$arg' is not a manual action"
arg_problem=true
useropt_help_basic=false
;;
@(in|not-)active|?(in)dependent?(s)|stopped)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "activate $arg"
arg_problem=true
useropt_help_basic=false
;;
?(un)stable)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "follow $arg"
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && Display
ShowAsError "unknown argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
useropt_help_basic=false
fi
fi
DebugArray args_incomplete "${args_incomplete[*]:-}"
DebugArray args_remaining "${args_remaining[*]:-}"
FuncExit
}
AllocPackGroupsToAcs()
{
FuncInit
ShowAsProc 'match QPKG groups to actions'
local action=''
local group=''
for action in "${USER_QPKG_ACTIONS[@]}";do
for group in "${QPKG_IS_GROUPS[@]}";do
if QPKGs.AC${action}.GR${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GR${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GR$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for group in "${QPKG_ISNT_GROUPS[@]}";do
if QPKGs.AC${action}.GRNT${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GRNT$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit
}
AllocPackStatesToAcs()
{
FuncInit
ShowAsProc 'match QPKG states to actions'
local action=''
local check_later=false
local state=''
for action in "${USER_QPKG_ACTIONS[@]}";do
for state in "${QPKG_IS_STATES[@]}";do
check_later=false
if QPKGs.AC${action}.IS${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
else
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any '$state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for state in "${QPKG_ISNT_STATES[@]}";do
check_later=false
if QPKGs.AC${action}.ISNT${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
else
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any 'not $state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit
}
ResetArchivedLogs()
{
if [[ -n $LOGS_PATH && -d $LOGS_PATH ]];then
ClearPath "$THIS_PACKAGE_PATH" "$LOGS_PATH"
echo 'log reset' > "$sess_active_pathfile"
ShowAsDone 'logs cleared'
fi
return 0
}
ResetCachePath()
{
if [[ -n $CACHE_PATH && -d $CACHE_PATH ]];then
ClearPath "$THIS_PACKAGE_PATH" "$CACHE_PATH"
ShowAsDone 'package cache cleared'
fi
return 0
}
ResetReportsPath()
{
if [[ -n $REPORTS_PATH && -d $REPORTS_PATH ]];then
ClearPath /var/log/sherpa "$REPORTS_PATH"
ShowAsDone 'reports cleared'
fi
return 0
}
Quiz()
{
local prompt=${1:?${FUNCNAME[0]}'()': undefined prompt}
local response=''
ShowAsQuiz "$prompt"
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD igncr
read -rn1 response
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD -igncr
DebugVar response
ShowAsQuizDone "$prompt: $response"
case ${response:0:1} in
y|Y)
return 0
;;
*)
return 1
esac
}
PatchEntwareService()
{
local -r TAB=$'\t'
local -r PREFIX='# the following line was inserted by sherpa: https://git.io/sherpa'
local -r PACKAGE_INIT_PATHFILE=$(QpkgGetServicePathFile Entware)
local find=''
local insert=''
if $GREP_CMD -q 'opt.orig' "$PACKAGE_INIT_PATHFILE";then
DebugInfo 'patch: do the "/opt shuffle" - already done'
else
find='# sym-link $QPKG_DIR to /opt'
insert='opt_path="/opt";opt_backup_path="/opt.orig"; [[ -d "$opt_path" \&\& ! -L "$opt_path" \&\& ! -e "$opt_backup_path" ]] \&\& mv "$opt_path" "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
find='/bin/ln -sf $QPKG_DIR /opt'
insert='[[ -L "$opt_path" \&\& -d "$opt_backup_path" ]] \&\& cp "$opt_backup_path"/* --target-directory "$opt_path" \&\& rm -r "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
DebugAsDone 'patch: do the "opt shuffle"'
fi
return 0
}
_UpdateEntwarePackageList_()
{
if IsNtSysFileExist $OPKG_CMD;then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${ENTWARE_PACKAGE_LIST_UPTODATE:-false} = false ]] || return
local -i z=0
if ! IsThisFileRecent "$EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES" || [[ ! -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE || $useropt_check = true ]];then
DebugAsProc "updating $(ShowAsPackageName Entware) package list"
RunAndLog "$OPKG_CMD update" "$LOGS_PATH/Entware.$UPDATE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
DebugAsDone "updated $(ShowAsPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(ShowAsPackageName Entware) package list $(ShowAsExitcode "$z")"
fi
else
DebugInfo "$(ShowAsPackageName Entware) package list was updated less-than $FILE_CHANGE_THRESHOLD_MINUTES minutes ago: skipping update"
fi
[[ -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE && ! -f $EXTERNAL_PACKAGES_PATHFILE ]] && OpenIpkArchive
readonly ENTWARE_PACKAGE_LIST_UPTODATE=true
return 0
}
IsThisFileRecent()
{
[[ -e ${1:-} && $((($(ConvertNowToSeconds)-$(/usr/bin/stat "$1" -c %Z))/60)) -le ${2:-1440} ]]
}
SaveIpkAndPipList()
{
$PIP_CMD freeze | cut -d'=' -f1 > "$PREV_PIP_LIST"
[[ -e $PREV_PIP_LIST ]] && DebugAsDone "saved current PIP list to $(ShowAsFileName "$PREV_PIP_LIST")"
$OPKG_CMD list-installed > "$PREV_IPK_LIST"
[[ -e $PREV_IPK_LIST ]] && DebugAsDone "saved current $(ShowAsPackageName Entware) IPK list to $(ShowAsFileName "$PREV_IPK_LIST")"
} 2> /dev/null
LoadIpkList()
{
local name=''
local separator=''
local version=''
if [[ -e $PREV_IPK_LIST ]];then
DebugInfo "IPKs are being loaded from $(ShowAsFileName "$PREV_IPK_LIST")"
while read -r name separator version;do
name=$(Lowercase "$name")
IPKs-ACinstall-to:Add "$name"
done < "$PREV_IPK_LIST"
fi
}
LoadPipList()
{
local name=''
local re=''
if [[ -e $PREV_PIP_LIST ]];then
DebugInfo "PIPs are being loaded from $(ShowAsFileName "$PREV_PIP_LIST")"
while read -r name;do
name=$(Lowercase "$name")
re=\\b$name\\b
[[ ${EXCLUSION_PIPS[*]} =~ $re ]] || PIPs-ACinstall-to:Add "$name"
done < "$PREV_PIP_LIST"
fi
}
CalcIpkDepsToInstall()
{
IsSysFileExist $GNU_GREP_CMD || return
FuncInit
local complete=false
local -a dep_acc=()
local element=''
local ipk_titles=''
local -i iterations=0
local -r ITERATION_LIMIT=20
local -i pre_exclude_count=0
local pre_exclude_list=''
local req_list=''
local -i requested_count=0
local -a this_list=()
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$($WC_CMD -w <<< "$req_list")
if [[ $requested_count -eq 0 ]];then
DebugAsWarn 'no IPKs requested'
FuncExit 1;return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while [[ $iterations -le $ITERATION_LIMIT ]];do
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
((iterations++))
printf -v ipk_titles '^Package: %s$\|' "${this_list[@]}"
ipk_titles=${ipk_titles%??}
this_list=($($GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD -vG '^Section:\|^Version:' | $GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator "$ipk_titles" | $GNU_GREP_CMD -vG "$ipk_titles" | $GNU_GREP_CMD -vG '^Package: ' | $SED_CMD 's|^Depends: ||;s|, |\n|g' | $SORT_CMD | $UNIQ_CMD))
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
if [[ ${#this_list[@]} -eq 0 ]];then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
if [[ $complete = true ]];then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$ITERATION_LIMIT [$ITERATION_LIMIT]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$($WC_CMD -w <<< "$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]];then
ShowAsProc 'exclude IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do
if [[ $element != 'ca-certs' && $element != 'python3-gdbm' ]];then
if [[ $element != 'libjpeg' ]];then
if ! $OPKG_CMD status "$element" | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $OPKG_CMD status 'libjpeg-turbo' | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
FuncExit
}
CalcIpkDownloadSize()
{
FuncInit
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]];then
ShowAsProc "calculate size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($GNU_GREP_CMD -w '^Package:\|^Size:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD --after-context 1 --no-group-separator ": $($SED_CMD 's/ /$ /g;s/\$ /\$\\\|: /g' <<< "$(IPKs-ACdownload-to:List)")" | $GREP_CMD '^Size:' | $SED_CMD 's|^Size: ||'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$((${size_array[*]:-}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
FuncExit
}
IPKs:upgrade()
{
[[ $ipks_upgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local log_pathfile=$LOGS_PATH/ipks.$UPGRADE_LOG_FILE
local -i total_count=0
local -i z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($OPKG_CMD list-upgradable | cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
ShowAsProc "upgrade $desc"
_DirSizeMonitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillPID "$fork_pid"
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultToLog IPK auxiliary upgrade "$total_count" ok
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultToLog IPK auxiliary upgrade "$total_count" failed "$z"
fi
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:install()
{
[[ $ipks_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local -i i=0
local log_pathfile=$LOGS_PATH/ipks.$INSTALL_LOG_FILE
local previous=''
local -i total_count=0
local -i z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware || ([[ $useropt_check = true ]] && QpkgIsInstalled Entware);then
IPKs-ACinstall-to:Add "$ESSENTIAL_IPKS"
if [[ -e $PREV_IPK_LIST && $useropt_check = false ]];then
LoadIpkList
mv -f "$PREV_IPK_LIST" "$PREV_IPK_LIST.installing"
fi
fi
if QPKGs.ACinstall.GRall.IsSet;then
for qpkg_name in "${QPKG_NAME[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QpkgSetIndex
IPKs-ACinstall-to:Add "$(QpkgGetIPKs)"
done
else
for qpkg_name in "${QPKG_NAME[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
if QPKGs-ACinstall-to.Exist "$qpkg_name" || QPKGs-ISinstalled.Exist "$qpkg_name" || (QPKGs-ACreinstall-to.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name");then
QpkgSetIndex
IPKs-ACinstall-to:Add "$(QpkgGetIPKs)"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
ShowAsProc "install $desc"
_DirSizeMonitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD install --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillPID "$fork_pid"
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultToLog IPK auxiliary install "$total_count" ok
HideKeystrokes
UpdateCapabilities
rm -f "$PREV_IPK_LIST.installing" 2> /dev/null
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultToLog IPK auxiliary install "$total_count" failed "$z"
if [[ -e $PREV_IPK_LIST.installing ]];then
mv -f "$PREV_IPK_LIST.installing" "$PREV_IPK_LIST"
fi
fi
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:downgrade()
{
[[ $ipks_downgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local -i fail_count=0
local log_pathfile=''
local name=''
local -i ok_count=0
local package_type=''
local remote_url=''
local -i total_count=0
local url_prefix=''
local url_suffix=''
local -i z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
if [[ $total_count -gt 0 ]];then
package_type=IPK
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNLOAD_LOG_FILE
ShowAsProc "download $desc"
case $NAS_QPKG_ARCH in
a41)
if OsIsNonStdKernelPageSize;then
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.38-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$IPK_DOWNGRADE_PATH/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.39.2-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$IPK_DOWNGRADE_PATH/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
esac
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
total_count=1
ok_count=0
fail_count=0
desc="$total_count auxiliary ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNGRADE_LOG_FILE
ShowAsProc "downgrade $desc"
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
RunAndLog "$OPKG_CMD install --force-downgrade --cache $IPK_CACHE_PATH --tmp-dir $IPK_DOWNGRADE_PATH $IPK_DOWNGRADE_PATH/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultToLog IPK auxiliary downgrade "$ok_count" ok
else
((fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultToLog IPK auxiliary downgrade "$fail_count" failed "$z"
fi
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:uninstall()
{
:
}
PIPs:upgrade()
{
:
}
PIPs:install()
{
[[ $pips_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
$OPKG_CMD status python3-pip | $GREP_CMD -q "Status:.*installed" || return
ErrorIsNt || return
FuncInit
local desc=''
local exec_cmd=''
local -i fail_count=0
local log_pathfile=$LOGS_PATH/pips.$INSTALL_LOG_FILE
local -i ok_count=0
local package_type=PIP
local -i total_count=0
local -i z=0
if [[ $useropt_check = true ]] || IPKs-ACinstall-ok.Exist python3-pip;then
PIPs-ACinstall-to:Add "$ESSENTIAL_PIPS"
if [[ -e $PREV_PIP_LIST && $useropt_check = false ]];then
LoadPipList
mv -f "$PREV_PIP_LIST" "$PREV_PIP_LIST.installing"
fi
((total_count++))
exec_cmd="$PIP_CMD install --upgrade --no-input $(PIPs-ACinstall-to:List) --cache-dir $PIP_CACHE_PATH 2> >($GREP_CMD -v \"Running pip as the 'root' user\") >&2"
desc="$total_count auxiliary PIP$(Pluralise "$total_count")"
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 0 "$total_count"
RunAndLog "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
DebugAsDone "installed $desc"
SaveActionResultToLog PIP auxiliary install "$ok_count" ok
rm -f "$PREV_PIP_LIST.installing" 2> /dev/null
else
((fail_count++))
SaveActionResultToLog PIP auxiliary install "$fail_count" failed "$z"
if [[ -e $PREV_PIP_LIST.installing ]];then
mv -f "$PREV_PIP_LIST.installing" "$PREV_PIP_LIST"
fi
fi
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
PIPs:uninstall()
{
:
}
OpenIpkArchive()
{
if [[ ! -e $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE ]];then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
RunAndLog "/usr/local/sbin/7z e -o$($DIRNAME_CMD "$EXTERNAL_PACKAGES_PATHFILE") $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$CACHE_PATH/ipk.archive.extract" log:failure-only
if [[ ! -e $EXTERNAL_PACKAGES_PATHFILE ]];then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0
}
CloseIpkArchive()
{
rm -f "$EXTERNAL_PACKAGES_PATHFILE" 2> /dev/null
}
_LaunchOneActionWithManyForks_()
{
FuncForkInit
local a=${1:-function null}
shift
local -a c=("$@")
fork_id=0
for qpkg_name in "${c[@]}";do
[[ ! -e $ACTION_ABORT_PATHFILE ]] || break
while [[ $fork_count -ge $max_forks ]];do
[[ ! -e $ACTION_ABORT_PATHFILE ]] || break 2
sleep .2
UpdateForkProgress
done
IncForkProgressIndex
MarkThisAcForkAsStarted
QpkgSetIndex
action_pidfile=$($MKTEMP_CMD "$ASYNC_PROCS_PATH"/bgproc_XXXXXX)
$a &
echo "$!" > "$action_pidfile"
DebugAsDone "forked $a() instance for '$qpkg_name'"
UpdateForkProgress
done
while [[ $fork_count -gt 0 ]];do
[[ ! -e $ACTION_ABORT_PATHFILE ]] || break
sleep .2
UpdateForkProgress
done
FuncForkExit
}
_DirSizeMonitor_()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} ]] || exit
[[ -d $1 && ${2:-0} -gt 0 ]] || exit
IsSysFileExist $GNU_FIND_CMD || exit
local -i current_bytes=-1
local -i last_bytes=0
local perc_msg=''
local progress_msg=''
local stall_msg=''
local -i stall_seconds=0
local -i stall_seconds_threshold=4
local -i total_bytes=${2:-0}
InitProgress
while [[ $current_bytes -lt $total_bytes ]];do
current_bytes=$($GNU_FIND_CMD "$1" -type f -name '*.ipk' -exec $DU_CMD --bytes --total --apparent-size {} + 2> /dev/null | $GREP_CMD total$ | cut -f1)
[[ -z $current_bytes ]] && current_bytes=0
if [[ $current_bytes -ne $last_bytes ]];then
stall_seconds=0
last_bytes=$current_bytes
else
((stall_seconds++))
fi
perc_msg="$((200*(current_bytes)/(total_bytes)%2+100*(current_bytes)/(total_bytes)))%"
[[ $current_bytes -lt $total_bytes && $perc_msg = '100%' ]] && perc_msg='99%'
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$total_bytes")"))"
if [[ $stall_seconds -ge $stall_seconds_threshold ]];then
stall_msg=' stalled for '
if [[ $stall_seconds -lt 60 ]];then
stall_msg+="$stall_seconds seconds"
else
stall_msg+=$(ConvertSecondsToDuration "$stall_seconds")
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg=$(TextBrightRed "$stall_msg")
elif [[ $stall_seconds -ge 45 ]];then
stall_msg=$(TextBrightOrange "$stall_msg")
elif [[ $stall_seconds -ge 20 ]];then
stall_msg=$(TextBrightYellow "$stall_msg")
fi
progress_msg+=$stall_msg
fi
[[ ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
WriteMsgInPlace "$progress_msg"
sleep 1
done
[[ -n $progress_msg ]] && WriteMsgInPlace 'done!'
}
WriteMsgInPlace()
{
local -i a=0
local b=$(tr -s ' ' <<< "${1:-}")
local c=$(StripANSICodes "$b")
if [[ $c != "$prev_clean_msg" ]];then
if [[ ${#c} -lt ${#prev_clean_msg} ]];then
a=$((${#c}-${#prev_clean_msg}))
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"; printf "%${a}s"; printf "%${a}s" | tr ' ' '\b'
else
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"
fi
prev_clean_msg=$c
fi
}
KillPID()
{
[[ -n ${1:-} && $1 -gt 0 && -d /proc/$1 ]] || return
kill -9 "$1"
wait
} &> /dev/null
Reset()
{
ResetCachePath
ResetReportsPath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
exit 0
}
UpdateColourful()
{
local a=''
if [[ $switch_colour = true && -n $user_colourful_value ]];then
for a in true false;do
[[ $a != "$user_colourful_value" ]] && continue
useropt_colourful=$user_colourful_value
if [[ ${1:-} = silent ]];then
SaveSetting Colourful "$useropt_colourful"
else
SaveSetting Colourful "$useropt_colourful" announce
fi
switch_colour=false
return
done
ShowAsAbort "user setting '$user_colourful_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
UpdateBranch()
{
local a=''
if [[ $switch_branch = true && -n $user_branch_value ]];then
for a in unstable stable;do
[[ $a != "$user_branch_value" ]] && continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then
SaveSetting Git_Branch "$useropt_branch"
else
SaveSetting Git_Branch "$useropt_branch" announce
Reset
fi
switch_branch=false
return
done
ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1
fi
}
UpdateTerse()
{
local a=''
if [[ $switch_terse = true && -n $user_terse_value ]];then
for a in true false;do
[[ $a != "$user_terse_value" ]] && continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then
SaveSetting Terse "$useropt_terse"
else
SaveSetting Terse "$useropt_terse" announce
fi
switch_terse=false
return
done
ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
SaveSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined value}")
case $b in
true|false)
b=$(Uppercase "$b")
esac
/sbin/setcfg sherpa "$a" "$b" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]] && ShowAsDone "user setting '$a = $b' has been saved"
}
LoadSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined default value}")
Lowercase "$(/sbin/getcfg sherpa "$a" -d "$b" -f /etc/config/qpkg.conf)"
}
DeleteSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
/sbin/setcfg -e sherpa "$a" -f /etc/config/qpkg.conf
}
UserIsOk()
{
if ! UserIsSU;then
if OsIsSupportSudo;then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${CHARS_SUDO_PROMPT}sherpa $ARGS_RAW" >&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again"
fi
return 1
fi
return 0
}
UserIsSU()
{
[[ $EUID -eq 0 ]]
}
#DebugBinPathVerAndMinVer()
IsSysFileExist()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined pathfile} ]] || exit
local a=${1%% *}
if ! [[ -f $a || -L $a ]];then
ShowAsAbort "a required NAS system file $(ShowAsFileName "$a") is missing"
return 1
fi
return 0
}
IsNtSysFileExist()
{
! IsSysFileExist "${1:?${FUNCNAME[0]}'()': undefined pathfile}"
}
LenANSIDiff()
{
local original=${1:-}
local stripped=$(StripANSICodes "$original")
printf '%s' "$((${#original}-${#stripped}))"
return 0
}
AddSeparators()
{
local a=''
[[ -z ${1:-} ]] && return
a=$(Trim "$1")
a=${a// /, }
a=${a//!/ }
printf '%s' "$a"
}
DisplayAsProjSynExam()
{
printf "\n${CHARS_BULLET}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf "\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}sherpa %s\n" '' "${2:-}"
}
DisplayAsProjSynIndentExam()
{
if [[ -n $1	]];then
printf "\n%${HELP_DESC_INDENT}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf '\n'
fi
printf "%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}sherpa %s\n" '' "${2:-}"
}
DisplayAsSynExam()
{
printf "\n${CHARS_BULLET}%s:\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_PREFIX}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}"
}
DisplayAsIndentItem()
{
printf "%${HELP_DESC_INDENT}s${CHARS_BULLET}%s\n" '' "$(Capitalise "${1:-}")"
}
DisplayAsIndentQuotedInfoItem()
{
if [[ -e $GNU_AWK_CMD ]];then
printf "%${HELP_DESC_INDENT}s%s|%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
else
printf "%${HELP_DESC_INDENT}s%-$((FOOTER_NAME_COL_WIDTH+2+$(LenANSIDiff "${1:-}")))s%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
fi
}
GeneratePacksReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Appl. version:'
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Description:'
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GeneratePacksReportDataLine()
{
local app_ver=''
local app_ver_msg=$CHARS_BLANK
local description_msg=$CHARS_BLANK
local mode=''
local name=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local description=$(QpkgGetDesc "$name")
local notes=$(QpkgGetNote "$name")
[[ $notes = none ]] && notes=''
local name_msg=$CHARS_NORMAL
local notes_msg="${notes}."
if QpkgIsMissing;then
mode=highlighted
/bin/touch "$REPORT_FLAGS_PATH"/status-missing
elif QpkgIsNtInstalled;then
mode=muted
/bin/touch "$REPORT_FLAGS_PATH"/state-notinstalled
else
mode=normal
/bin/touch "$REPORT_FLAGS_PATH"/state-installed
fi
app_ver=$(QpkgGetApplVer)
case $app_ver in
dynamic|final|static)
/bin/touch "$REPORT_FLAGS_PATH"/app-$app_ver
esac
app_ver_msg+=$app_ver
description_msg+="$(Capitalise "$description")."
name_msg+=$qpkg_name
case $mode in
muted)
app_ver_msg=$(TextDarkGrey "$app_ver_msg")
description_msg=$(TextDarkGrey "$description_msg")
name_msg=$(TextDarkGrey "$name_msg")
;;
highlighted)
name_msg=$(TextBrightRed "$name_msg")
esac
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s\n' "$name_msg" "$app_ver_msg" "$description_msg"
if [[ -n $notes ]];then
printf "%s|%s|%$((${#CHARS_BLANK}))s%s\n" '' '' '' "$(TextBrightOrange "${CHARS_DROPEND}${CHARS_NOTE}") $notes_msg"
fi
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+$(LenANSIDiff "$description_msg")))s" "$description_msg"
if [[ -n $notes ]];then
printf "\n%$((${#CHARS_BLANK}+PACKAGE_NAME_COL_WIDTH+PACKAGE_APP_VER_COL_WIDTH+(COLUMN_SPACING*2)))s$(TextBrightOrange "${CHARS_DROPEND}${CHARS_NOTE}")%s" '' "$notes_msg"
fi
printf '\n'
fi
}
GenerateStatusReportTitleLine()
{
local a=''
a='QPKG name'
printf "%-${PACKAGE_NAME_COL_WIDTH}s" "$a:"
printf "%$((COLUMN_SPACING))s"
a='QPKG statuses'
printf "%-${STD_COL_WIDTH}s" "$a:"
printf "%$((COLUMN_SPACING))s"
a='QPKG action (result)'
printf "%-${STD_COL_WIDTH}s" "$a:"
printf "%$((COLUMN_SPACING))s"
a='QPKG version'
QPKGs-ISupgradable.IsAny && a+=" ($(TextBrightOrange new))"
printf "%-${STD_COL_WIDTH}s" "$a:"
printf "%$((COLUMN_SPACING))s"
a='Appl. version'
printf "%-${STD_COL_WIDTH}s" "$a:"
printf "%$((COLUMN_SPACING))s"
a='QPKG installation path'
printf "%-${STD_COL_WIDTH}s" "$a:"
printf '\n'
}
GenerateStatusReportDataLine()
{
local action=''
local action_msg=$CHARS_BLANK
local app_ver=''
local app_ver_msg=$CHARS_BLANK
local mode=''
local -i n=0
local name_msg=$CHARS_BLANK
local path_msg=$CHARS_BLANK
local result=''
local status=''
local status_msg=$CHARS_NORMAL
local ver_msg=$CHARS_BLANK
if QpkgIsMissing;then
mode=highlighted
/bin/touch "$REPORT_FLAGS_PATH"/status-missing
elif QpkgIsNtInstalled;then
mode=muted
/bin/touch "$REPORT_FLAGS_PATH"/state-notinstalled
else
mode=normal
/bin/touch "$REPORT_FLAGS_PATH"/state-installed
fi
app_ver=$(QpkgGetApplVer)
case $app_ver in
dynamic|final|static)
/bin/touch "$REPORT_FLAGS_PATH"/app-$app_ver
esac
case $mode in
normal)
app_ver_msg+=$app_ver
name_msg+=$qpkg_name
path_msg+=$(QpkgGetInstallationPath)
if QPKGs-ISenabled.Exist "$qpkg_name";then
status+=" $(TextBrightGreen enabled)"
/bin/touch "$REPORT_FLAGS_PATH"/state-enabled
else
status+=" $(TextBrightRed disabled)"
/bin/touch "$REPORT_FLAGS_PATH"/state-disabled
fi
if QPKGs-ISactive.Exist "$qpkg_name";then
status+=" $(TextBrightGreen active)"
/bin/touch "$REPORT_FLAGS_PATH"/status-active
elif QPKGs-ISslow.Exist "$qpkg_name";then
status+=" $(TextBrightOrange slow)"
/bin/touch "$REPORT_FLAGS_PATH"/status-slow
elif QPKGs-ISNTactive.Exist "$qpkg_name";then
status+=" $(TextBrightRed inactive)"
/bin/touch "$REPORT_FLAGS_PATH"/status-inactive
else
status+=" $(TextBrightOrange unknown)"
/bin/touch "$REPORT_FLAGS_PATH"/status-unknown
fi
if QpkgIsSherpaCompatible;then
action=$(QpkgGetServiceAction)
/bin/touch "$REPORT_FLAGS_PATH"/action-$action
if [[ $action = not-found ]];then
if OsIsStarting && [[ -e $REPORT_FLAGS_PATH/state-enabled && -e $REPORT_FLAGS_PATH/status-inactive ]];then
action_msg+=$(TextBrightOrange pending)
/bin/touch "$REPORT_FLAGS_PATH"/action-pending
else
action_msg+=$(TextDarkGrey not-found)
fi
else
action_msg+="$action"
fi
result=$(QpkgGetServiceResult)
/bin/touch "$REPORT_FLAGS_PATH"/result-$result
case $result in
ok)
action_msg+=" ($(TextBrightGreen OK))"
;;
in-progress)
action_msg+=" ($(TextBrightOrange $result))"
;;
aborted|failed)
action_msg+=" ($(TextBrightRed $result))"
esac
else
action_msg+=$(TextDarkGrey unsupported)
/bin/touch "$REPORT_FLAGS_PATH"/action-unsupported
fi
status_msg+=$(AddSeparators "$status")
ver_msg+=$(QpkgGetInstalledVer)
;;
muted)
if QpkgIsSherpaCompatible;then
action=$(QpkgGetServiceAction)
if [[ $action != not-found ]];then
/bin/touch "$REPORT_FLAGS_PATH"/action-$action
action_msg+="$action"
result=$(QpkgGetServiceResult)
/bin/touch "$REPORT_FLAGS_PATH"/result-$result
case $result in
ok)
action_msg+=" ($(TextBrightGreen OK))"
;;
in-progress)
action_msg+=" ($(TextBrightOrange $result))"
;;
aborted|failed)
action_msg+=" ($(TextBrightRed $result))"
esac
else
action_msg+=$(TextDarkGrey 'N/A')
/bin/touch "$REPORT_FLAGS_PATH"/na
fi
else
action_msg+=$(TextDarkGrey 'N/A')
/bin/touch "$REPORT_FLAGS_PATH"/na
fi
app_ver_msg+=$(TextDarkGrey "$app_ver")
name_msg+=$(TextDarkGrey "$qpkg_name")
path_msg+=$(TextDarkGrey 'N/A')
/bin/touch "$REPORT_FLAGS_PATH"/na
if ! QpkgIsArchOK;then
status='incompatible arch'
elif ! QpkgIsMinOSVerOk;then
status="incompatible $(OsGetQnapOS)"
elif ! QpkgIsMinRAMOk;then
status='insufficient RAM'
else
status='not installed'
fi
status_msg=$(TextDarkGrey "${CHARS_NORMAL}${status}")
ver_msg+=$(TextDarkGrey "$(QpkgGetAvailVer "$qpkg_name")")
;;
highlighted)
app_ver_msg+=$(TextBrightRed "$app_ver")
name_msg+=$(TextBrightRed "$qpkg_name")
path_msg=$(TextBrightRedBlink "${CHARS_ALERT}$(QpkgGetInstallationPath)")
status_msg=$(TextBrightRedBlink "${CHARS_ALERT}missing")
ver_msg+=$(TextBrightRed "$(QpkgGetInstalledVer)")
esac
if QPKGs-ISupgradable.Exist "$qpkg_name";then
ver_msg+=" ($(TextBrightOrange "$(QpkgGetAvailVer)"))"
/bin/touch "$REPORT_FLAGS_PATH"/status-upgradable
fi
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s|%s|%s|%s\n' "$name_msg" "$status_msg" "$action_msg" "$ver_msg" "$app_ver_msg" "$path_msg"
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((STD_COL_WIDTH+$(LenANSIDiff "$status_msg")))s" "$status_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((STD_COL_WIDTH+$(LenANSIDiff "$action_msg")))s" "$action_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((STD_COL_WIDTH+$(LenANSIDiff "$ver_msg")))s" "$ver_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((STD_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_PATH_COL_WIDTH+$(LenANSIDiff "$path_msg")))s" "$path_msg"
printf '\n'
fi
}
GenerateReposReportTitleLine()
{
local a=''
a="QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a="Repository:"
printf "%-$((PACKAGE_REPO_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a="Install date:"
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateReposReportDataLine()
{
local assigned_repo=''
local assigned_repo_msg=$CHARS_NORMAL
local install_date=$(QpkgGetInstallDate)
local install_date_msg=$CHARS_BLANK
local mode=''
local name_msg=$CHARS_BLANK
local store_id=$(QpkgGetStoreID)
if [[ $store_id = undefined || $store_id = sherpa ]];then
store_id=sherpa
assigned_repo=sherpa
/bin/touch "$REPORT_FLAGS_PATH"/repo-sherpa
else
assigned_repo=$(GetRepoURLFromStoreID "$store_id")
fi
if QpkgIsMissing;then
mode=highlighted
/bin/touch "$REPORT_FLAGS_PATH"/status-missing
elif QpkgIsNtInstalled;then
mode=muted
/bin/touch "$REPORT_FLAGS_PATH"/state-notinstalled
else
mode=normal
/bin/touch "$REPORT_FLAGS_PATH"/state-installed
fi
case $mode in
normal)
case $assigned_repo in
sherpa)
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
name_msg+=$qpkg_name
;;
undefined)
assigned_repo_msg+='N/A'
name_msg+=$qpkg_name
/bin/touch "$REPORT_FLAGS_PATH"/na
;;
*)
assigned_repo_msg=$(TextBrightOrange "${CHARS_ATTENTION}$assigned_repo")
name_msg+=$(TextBrightOrange "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/repo-other
esac
install_date_msg+=$install_date
;;
muted)
assigned_repo_msg=$(TextDarkGrey "${CHARS_NORMAL}N/A")
/bin/touch "$REPORT_FLAGS_PATH"/na
if ! QpkgIsArchOK;then
install_date='incompatible arch'
elif ! QpkgIsMinOSVerOk;then
install_date="incompatible $(OsGetQnapOS)"
elif ! QpkgIsMinRAMOk;then
install_date='insufficient RAM'
else
install_date='not installed'
fi
install_date_msg+=$(TextDarkGrey "$install_date")
name_msg+=$(TextDarkGrey "$qpkg_name")
;;
highlighted)
case $assigned_repo in
sherpa)
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
;;
unassigned)
assigned_repo_msg+=$(TextBrightOrange "$assigned_repo")
;;
*)
assigned_repo_msg+=$assigned_repo
/bin/touch "$REPORT_FLAGS_PATH"/repo-other
esac
install_date_msg=$(TextBrightRedBlink "${CHARS_ALERT}missing")
name_msg+=$(TextBrightRed "$qpkg_name")
esac
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s\n' "$name_msg" "$assigned_repo_msg" "$install_date_msg"
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_REPO_COL_WIDTH+$(LenANSIDiff "$assigned_repo_msg")))s" "$assigned_repo_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+$(LenANSIDiff "$install_date_msg")))s" "$install_date_msg"
printf '\n'
fi
}
GenerateAbsReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Installed?'
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Acceptable QPKG name abbreviations and aliases:'
printf "%-$((PACKAGE_ABBS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateAbsReportDataLine()
{
local abs_msg=''
local installed_msg=$CHARS_BLANK
local mode=''
local name_msg=$CHARS_BLANK
if QpkgIsMissing;then
mode=highlighted
/bin/touch "$REPORT_FLAGS_PATH"/status-missing
elif QpkgIsNtInstalled;then
mode=muted
/bin/touch "$REPORT_FLAGS_PATH"/state-notinstalled
else
mode=normal
/bin/touch "$REPORT_FLAGS_PATH"/state-installed
fi
case $mode in
normal)
abs_msg=${CHARS_NORMAL}$(AddSeparators "$(QpkgGetAbbrvs)")
installed_msg+=true
name_msg+=$qpkg_name
;;
muted)
if ! QpkgIsArchOK "$qpkg_name";then
abs_msg="${CHARS_ALERT}incompatible architecture"
elif ! QpkgIsMinOSVerOk "$qpkg_name";then
abs_msg="${CHARS_ALERT}incompatible $(OsGetQnapOS) version"
elif ! QpkgIsMinRAMOk "$qpkg_name";then
abs_msg="${CHARS_ALERT}insufficient RAM installed"
else
abs_msg=${CHARS_NORMAL}$(AddSeparators "$(QpkgGetAbbrvs "$qpkg_name")")
fi
abs_msg=$(TextDarkGrey "$abs_msg")
installed_msg+=$(TextDarkGrey false)
name_msg+=$(TextDarkGrey "$qpkg_name")
;;
highlighted)
abs_msg=$(TextBrightRed "${CHARS_ALERT}$(AddSeparators "$(QpkgGetAbbrvs)")")
installed_msg=$(TextBrightRedBlink "${CHARS_ALERT}missing")
name_msg+=$(TextBrightRed "$qpkg_name")
esac
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s\n' "$name_msg" "$installed_msg" "$abs_msg"
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+$(LenANSIDiff "$installed_msg")))s" "$installed_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ABBS_COL_WIDTH+$(LenANSIDiff "$abs_msg")))s" "$abs_msg"
printf '\n'
fi
}
GenerateDepsReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Dependencies:'
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Installed?'
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Enabled?'
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Managed?'
printf "%-$((PACKAGE_MANAGED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Min. RAM:'
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Min. OS:'
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Max. OS:'
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Supported arch?'
printf "%-$((PACKAGE_ARCH_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateDepsReportDataLine()
{
local arch_msg=$CHARS_BLANK
local dep_name=''
local deps=''
local deps_msg=$CHARS_NORMAL
local deps_raw=$(QpkgGetDependencies "$qpkg_name")
local enabled_msg=$CHARS_BLANK
local installed_msg=$CHARS_BLANK
local managed='N/A'
local managed_msg=$CHARS_BLANK
local max_os=$(QpkgGetMaxOSVer "$qpkg_name")
local max_os_msg=$CHARS_BLANK
local min_os=$(QpkgGetMinOSVer "$qpkg_name")
local min_os_msg=$CHARS_BLANK
local min_ram=$(QpkgGetMinRAM "$qpkg_name")
local min_ram_msg=$CHARS_BLANK
local mode=''
local name_msg=$CHARS_BLANK
[[ -z $deps_raw ]] && deps_raw=none
[[ -n $max_os && $max_os != none && ${#max_os} -eq 3 ]] && max_os=${max_os:0:1}.${max_os:1:1}.${max_os:2:1}
[[ -n $min_os && $min_os != none && ${#min_os} -eq 3 ]] && min_os=${min_os:0:1}.${min_os:1:1}.${min_os:2:1}
[[ $min_ram != none ]] && min_ram=$(FormatAsThous "$min_ram")kB
/bin/touch "$REPORT_FLAGS_PATH"/deps
if QpkgIsMissing;then
mode=highlighted
elif QpkgIsNtInstalled;then
mode=muted
/bin/touch "$REPORT_FLAGS_PATH"/state-notinstalled
else
mode=normal
if QpkgIsRepoSelfManaged;then
managed_msg+=$(TextBrightGreen true)
else
managed_msg+=$(TextBrightOrange false)
fi
fi
case $mode in
normal)
name_msg+=$qpkg_name
if QpkgIsArchOK;then
arch_msg+=$(TextBrightGreen true)
else
arch_msg=$(TextBrightRed "$CHARS_ALERT")
arch_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
if QpkgIsInstalled "$dep_name" && QpkgIsEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
deps_msg=$(TextBrightRed "$CHARS_ALERT")
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
done
else
deps+=$deps_raw
fi
deps_msg+=${deps// /, }
if QpkgIsEnabled;then
enabled_msg+=$(TextBrightGreen true)
else
enabled_msg=$(TextBrightRed "$CHARS_ALERT")
enabled_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
installed_msg+=$(TextBrightGreen true)
if QpkgIsMaxOSVerOk;then
if [[ $max_os != none ]];then
max_os_msg+=$(TextBrightGreen "$max_os")
else
max_os_msg+=$max_os
fi
else
max_os_msg=$(TextBrightRed "$CHARS_ALERT")
max_os_msg+=$(TextBrightRed "$max_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if QpkgIsMinOSVerOk;then
min_os_msg+=$(TextBrightGreen "$min_os")
else
min_os_msg=$(TextBrightRed "$CHARS_ALERT")
min_os_msg+=$(TextBrightRed "$min_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if QpkgIsMinRAMOk;then
if [[ $min_ram != none ]];then
min_ram_msg+=$(TextBrightGreen "$min_ram")
else
min_ram_msg+=$min_ram
fi
else
min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
min_ram_msg+=$(TextBrightRed "$min_ram")
name_msg=${CHARS_BLANK}$(TextBrightRed "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
;;
muted)
managed_msg+=$(TextDarkGrey 'N/A')
name_msg+=$(TextDarkGrey "$qpkg_name")
/bin/touch "$REPORT_FLAGS_PATH"/na
if QpkgIsArchOK "$qpkg_name";then
arch_msg+=$(TextDarkGrey true)
else
arch_msg=$(TextBrightOrange "$CHARS_ATTENTION")
arch_msg+=$(TextBrightOrange false)
/bin/touch "$REPORT_FLAGS_PATH"/req-attention
fi
deps_msg=$(TextDarkGrey "$CHARS_NORMAL")
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
deps+=$(TextDarkGrey "$dep_name")
done
else
deps+=$(TextDarkGrey "$deps_raw")
fi
deps_msg+=${deps// /$(TextDarkGrey ', ')}
enabled_msg+=$(TextDarkGrey 'N/A')
installed_msg+=$(TextDarkGrey false)
/bin/touch "$REPORT_FLAGS_PATH"/na
if QpkgIsMaxOSVerOk "$qpkg_name";then
max_os_msg+=$(TextDarkGrey "$max_os")
else
max_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
max_os_msg+=$(TextBrightOrange "$max_os")
/bin/touch "$REPORT_FLAGS_PATH"/req-attention
fi
if QpkgIsMinOSVerOk "$qpkg_name";then
min_os_msg+=$(TextDarkGrey "$min_os")
else
min_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
min_os_msg+=$(TextBrightOrange "$min_os")
/bin/touch "$REPORT_FLAGS_PATH"/req-attention
fi
if QpkgIsMinRAMOk "$qpkg_name";then
min_ram_msg+=$(TextDarkGrey "$min_ram")
else
min_ram_msg=$(TextBrightOrange "$CHARS_ATTENTION")
min_ram_msg+=$(TextBrightOrange "$min_ram")
/bin/touch "$REPORT_FLAGS_PATH"/req-attention
fi
;;
highlighted)
if QpkgIsArchOK;then
arch_msg+=$(TextBrightGreen true)
else
arch_msg=$(TextBrightRed "$CHARS_ALERT")
arch_msg+=$(TextBrightRed false)
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
if QpkgIsInstalled "$dep_name" && QpkgIsEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
fi
done
else
deps+=$(TextBrightGreen "$deps_raw")
fi
deps_msg+=${deps// /, }
if QpkgIsEnabled;then
enabled_msg+=$(TextBrightGreen true)
else
enabled_msg=$(TextBrightRedBlink "$CHARS_ALERT")
enabled_msg+=$(TextBrightRed 'false')
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
installed_msg=$(TextBrightRedBlink "$CHARS_ALERT")
installed_msg+=$(TextBrightRedBlink 'missing')
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
if QpkgIsMaxOSVerOk;then
max_os_msg+=$(TextBrightGreen "$max_os")
else
max_os_msg=$(TextBrightRed "$CHARS_ALERT")
max_os_msg+=$(TextBrightRed "$max_os")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if QpkgIsMinOSVerOk;then
min_os_msg+=$(TextBrightGreen "$min_os")
else
min_os_msg=$(TextBrightRed "$CHARS_ALERT")
min_os_msg+=$(TextBrightRed "$min_os")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
if QpkgIsMinRAMOk;then
min_ram_msg+=$(TextBrightGreen "$min_ram")
else
min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
min_ram_msg+=$(TextBrightRed "$min_ram")
/bin/touch "$REPORT_FLAGS_PATH"/req-alert
fi
name_msg+=$(TextBrightRed "$qpkg_name")
esac
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' "$name_msg" "$deps_msg" "$installed_msg" "$enabled_msg" "$managed_msg" "$min_ram_msg" "$min_os_msg" "$max_os_msg" "$arch_msg"
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+$(LenANSIDiff "$deps_msg")))s" "$deps_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+$(LenANSIDiff "$installed_msg")))s" "$installed_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+$(LenANSIDiff "$enabled_msg")))s" "$enabled_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MANAGED_COL_WIDTH+$(LenANSIDiff "$managed_msg")))s" "$managed_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+$(LenANSIDiff "$min_ram_msg")))s" "$min_ram_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+$(LenANSIDiff "$min_os_msg")))s" "$min_os_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+$(LenANSIDiff "$max_os_msg")))s" "$max_os_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ARCH_COL_WIDTH+$(LenANSIDiff "$arch_msg")))s" "$arch_msg"
printf '\n'
fi
}
GenerateFeaturesReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='CanBack?'
printf "%-$((PACKAGE_SUPPORTS_BACKUP_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='CanClean?'
printf "%-$((PACKAGE_SUPPORTS_CLEAN_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='StartUpd?'
printf "%-$((PACKAGE_SUPPORTS_START_TO_UPDATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='AutoUpd?'
printf "%-$((PACKAGE_AUTO_UPDATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='LiveTest?'
printf "%-$((PACKAGE_ACTIVE_TEST_BUILTIN_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Indep?'
printf "%-$((PACKAGE_TIER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Compat?'
printf "%-$((PACKAGE_COMPATIBLE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
a='Enhanced?'
printf "%-$((STD_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateFeaturesReportDataLine()
{
local active_test_msg=$CHARS_BLANK
local autoupdate_msg=$CHARS_BLANK
local backup_msg=$CHARS_BLANK
local clean_msg=$CHARS_BLANK
local compatible_msg=$CHARS_BLANK
local mode=''
local name_msg=$CHARS_BLANK
local restart_to_update_msg=$CHARS_BLANK
local sherpa_compatible_msg=$CHARS_BLANK
local tier_msg=$CHARS_BLANK
if QpkgIsMissing;then
mode=highlighted
elif QpkgIsNtInstalled;then
mode=muted
else
mode=normal
fi
if [[ $(QpkgGetActiveTest) = builtin ]];then
active_test_msg+=true
else
active_test_msg+=false
fi
if QpkgIsCanBackup;then
backup_msg+=true
else
backup_msg+=false
fi
if QpkgIsCanClean;then
clean_msg+=true
else
clean_msg+=false
fi
if QpkgIsCanRestartToUpdate;then
restart_to_update_msg+=true
elif [[ $qpkg_name = sherpa ]];then
restart_to_update_msg+=true
else
restart_to_update_msg+=false
fi
if QpkgIsInstalled && QpkgIsCanRestartToUpdate;then
if QpkgIsAutoUpdate;then
autoupdate_msg+=true
else
autoupdate_msg+=false
fi
elif [[ $qpkg_name = sherpa ]];then
autoupdate_msg+=true
else
autoupdate_msg+='N/A'
/bin/touch "$REPORT_FLAGS_PATH"/na
fi
if QpkgIsIndependent;then
tier_msg+=true
else
tier_msg+=false
fi
if QpkgIsArchOK;then
compatible_msg+=true
else
compatible_msg+=false
fi
if QpkgIsSherpaCompatible;then
sherpa_compatible_msg+=true
else
sherpa_compatible_msg+=false
fi
case $mode in
normal)
if [[ $active_test_msg =~ true ]];then
active_test_msg=$(TextBrightGreen "$active_test_msg")
else
active_test_msg=$(TextBrightOrange "$active_test_msg")
fi
if [[ $compatible_msg =~ true ]];then
compatible_msg=$(TextBrightGreen "$compatible_msg")
else
compatible_msg=$(TextBrightRed "$compatible_msg")
fi
if [[ $autoupdate_msg =~ true ]];then
autoupdate_msg=$(TextBrightGreen "$autoupdate_msg")
elif [[ $autoupdate_msg =~ false ]];then
autoupdate_msg=$(TextBrightOrange "$autoupdate_msg")
fi
if [[ $backup_msg =~ true ]];then
backup_msg=$(TextBrightGreen "$backup_msg")
fi
if [[ $clean_msg =~ true ]];then
clean_msg=$(TextBrightGreen "$clean_msg")
fi
name_msg+=$qpkg_name
if [[ $restart_to_update_msg =~ true ]];then
restart_to_update_msg=$(TextBrightGreen "$restart_to_update_msg")
fi
if [[ $sherpa_compatible_msg =~ true ]];then
sherpa_compatible_msg=$(TextBrightGreen "$sherpa_compatible_msg")
else
sherpa_compatible_msg=$(TextBrightOrange "$sherpa_compatible_msg")
fi
;;
muted)
active_test_msg=$(TextDarkGrey "$active_test_msg")
compatible_msg=$(TextDarkGrey "$compatible_msg")
autoupdate_msg=$(TextDarkGrey "$autoupdate_msg")
backup_msg=$(TextDarkGrey "$backup_msg")
clean_msg=$(TextDarkGrey "$clean_msg")
name_msg+=$(TextDarkGrey "$qpkg_name")
restart_to_update_msg=$(TextDarkGrey "$restart_to_update_msg")
sherpa_compatible_msg=$(TextDarkGrey "$sherpa_compatible_msg")
tier_msg=$(TextDarkGrey "$tier_msg")
;;
highlighted)
if [[ $active_test_msg =~ true ]];then
active_test_msg=$(TextBrightGreen "$active_test_msg")
else
active_test_msg=$(TextBrightOrange "$active_test_msg")
fi
if [[ $compatible_msg =~ true ]];then
compatible_msg=$(TextBrightGreen "$compatible_msg")
else
compatible_msg=$(TextBrightOrange "$compatible_msg")
fi
if [[ $autoupdate_msg =~ true ]];then
autoupdate_msg=$(TextBrightGreen "$autoupdate_msg")
else
autoupdate_msg=$(TextBrightOrange "$autoupdate_msg")
fi
if [[ $backup_msg =~ true ]];then
backup_msg=$(TextBrightGreen "$backup_msg")
else
backup_msg=$(TextBrightOrange "$backup_msg")
fi
if [[ $clean_msg =~ true ]];then
clean_msg=$(TextBrightGreen "$clean_msg")
else
clean_msg=$(TextBrightOrange "$clean_msg")
fi
name_msg+=$(TextBrightRed "$qpkg_name")
if [[ $restart_to_update_msg =~ true ]];then
restart_to_update_msg=$(TextBrightGreen "$restart_to_update_msg")
else
restart_to_update_msg=$(TextBrightOrange "$restart_to_update_msg")
fi
if [[ $sherpa_compatible_msg =~ true ]];then
sherpa_compatible_msg=$(TextBrightGreen "$sherpa_compatible_msg")
else
sherpa_compatible_msg=$(TextBrightOrange "$sherpa_compatible_msg")
fi
esac
if [[ -e $GNU_AWK_CMD ]];then
printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' "$name_msg" "$backup_msg" "$clean_msg" "$restart_to_update_msg" "$autoupdate_msg" "$active_test_msg" "$tier_msg" "$compatible_msg" "$sherpa_compatible_msg"
else
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_SUPPORTS_BACKUP_COL_WIDTH+$(LenANSIDiff "$backup_msg")))s" "$backup_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_SUPPORTS_CLEAN_COL_WIDTH+$(LenANSIDiff "$clean_msg")))s" "$clean_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_SUPPORTS_START_TO_UPDATE_COL_WIDTH+$(LenANSIDiff "$restart_to_update_msg")))s" "$restart_to_update_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_AUTO_UPDATE_COL_WIDTH+$(LenANSIDiff "$autoupdate_msg")))s" "$autoupdate_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ACTIVE_TEST_BUILTIN_COL_WIDTH+$(LenANSIDiff "$active_test_msg")))s" "$active_test_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_TIER_COL_WIDTH+$(LenANSIDiff "$tier_msg")))s" "$tier_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_COMPATIBLE_COL_WIDTH+$(LenANSIDiff "$compatible_msg")))s" "$compatible_msg"
printf "%$((COLUMN_SPACING))s"
printf "%-$((STD_COL_WIDTH+$(LenANSIDiff "$sherpa_compatible_msg")))s" "$sherpa_compatible_msg"
printf '\n'
fi
}
DisplayAsBacksReportTitleLine()
{
local a=''
printf '\n'
a="${CHARS_BULLET}Backup file:"
printf "%-$((FILE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}Size in bytes:"
printf "%-$((FILE_BYTES_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}Backup date:"
printf "%-$((FILE_CHANGE_DATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
DisplayAsBacksReportItemLine()
{
local epoch_time=${1:-0}
local epoch_time_msg=$CHARS_NORMAL
local file_bytes=${3:-0}
local file_bytes_msg=$CHARS_BLANK
local file_name=${2:-}
local file_name_msg=$CHARS_BLANK
local local_highlight_backups_older_than=${4:-'1 week ago'}
local mode=''
if [[ ${epoch_time%.*} -lt $(/bin/date --date="$local_highlight_backups_older_than" +%s) ]];then
mode=highlighted
else
mode=normal
fi
file_bytes=$(FormatAsThous "$file_bytes")
case $mode in
normal)
epoch_time_msg+=$(ConvertSecondsToFullDate "$epoch_time")
file_bytes_msg+=$file_bytes
file_name_msg+=$file_name
/bin/touch "$REPORT_FLAGS_PATH"/backup-file-ok
;;
highlighted)
epoch_time_msg=$(TextBrightRed "${CHARS_ALERT}$(ConvertSecondsToFullDate "$epoch_time")")
file_bytes_msg+=$(TextBrightRed "$file_bytes")
file_name_msg+=$(TextBrightRed "$file_name")
/bin/touch "$REPORT_FLAGS_PATH"/backup-file-old
esac
printf "%-$((FILE_NAME_COL_WIDTH+$(LenANSIDiff "$file_name_msg")))s" "$file_name_msg"
printf "%$((COLUMN_SPACING))s"
printf "%$((FILE_BYTES_COL_WIDTH+$(LenANSIDiff "$file_bytes_msg")))s" "$file_bytes_msg "
printf "%$((COLUMN_SPACING))s"
printf "%-$((FILE_CHANGE_DATE_COL_WIDTH+$(LenANSIDiff "$epoch_time_msg")))s" "$epoch_time_msg"
printf '\n'
}
DisplayAsHelpTitle()
{
printf "\n${CHARS_BULLET}%s\n" "$(Capitalise "${1:-}" | tr -s ' ')"
}
DisplayAsHelpTitleHighlighted()
{
printf "\n$(TextBrightOrange "${CHARS_BULLET}%s\n")" "$(Capitalise "${1:-}")"
}
DisplayAsIndentActionResultDurationReason()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
local action=''
local duration=''
case $1 in
disableau)
action='disable auto-update'
;;
enableau)
action='enable auto-update'
;;
*)
action=$1
esac
[[ -n ${3:-} ]] && duration=$(ConvertMillisecondsToDuration "$3")
printf "%${ACTION_RESULT_INDENT}s" ''
if [[ -z ${4:-} ]];then
printf "%s %s%s" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")"
else
printf "%s %s%s (%s)" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")" "$4"
fi
printf '\n'
}
EraseThisLine()
{
[[ ${useropt_verbose:=false} = false ]] && printf '\033[2K\r'
} >&2
Display()
{
if [[ -z ${1:-} ]];then
printf '\n'
else
printf '%s\n' "$1"
fi
}
DisplayWait()
{
printf '%s' "${1:-}"
}
Help.Actions:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport actions
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these packages (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'check all application dependencies are installed' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clean local repository files from these packages (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these packages' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these packages. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these packages. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'install these packages' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'reactivate these packages (this will upgrade internal applications where-supported)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign packages to $(ShowAsTitleName). Detach packages previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these packages ('install' packages, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these packages' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'digitally "sign" these QPKGs' "sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these packages' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these packages (this will upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all packages can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.ActionsAll:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport 'all actions'
{
Help.Basic:Show
DisplayAsHelpTitle "the 'all' group applies to all QPKGs. If $(ShowAsAction) is 'install all' then all available QPKGs will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all QPKGs (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all QPKGs (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all QPKGs' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all QPKGs. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on QPKG activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all QPKGs. QPKGs must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on QPKG activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (this will upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all QPKGs where backup files exist ('install' QPKGs and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all QPKGs' 'reinstall all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'digitally "sign" all QPKGs' 'sign all'
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'status all'
DisplayAsProjSynIndentExam 'uninstall all QPKGs' 'uninstall all'
DisplayAsProjSynIndentExam 'upgrade all QPKGs (and internal applications where-supported)' 'upgrade all'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.BackupLocation:Show()
{
DisplayAsSynExam 'the backup location can be accessed by running' "cd $QPKG_BU_PATH"
return 0
}
Help.Basic:Show()
{
DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0
}
Help.Basic.Examples:Show()
{
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show packages'
DisplayAsProjSynIndentExam '' p
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')"
return 0
}
Help.Groups:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport groups
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only independent QPKGs (these do not depend on other QPKGs)' "$(ShowAsAction) independent"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) independents"
DisplayAsProjSynIndentExam 'select only dependent QPKGs (these require another QPKG to be installed and active)' "$(ShowAsAction) dependent"
DisplayAsProjSynIndentExam 'select only active QPKGs' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only inactive QPKGs' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installed QPKGs' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing QPKGs (these are partly installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Issue:Show()
{
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://forum.qnap.com/viewtopic.php?f=320&t=132373')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange 'log for analysis!')"
Display
return 0
}
Help.Lists:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport lists
{
Help.Basic:Show
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available QPKGs' 'list all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed QPKGs' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only QPKGs that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowReportAllActionResults()
{
local -i a=0
local -i b=0
local -i c=0
local -i d=0
local -i e=0
local action=''
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ $useropt_show_all_results = true ]];then
show_action_results_failed=true
show_action_results_ok=true
show_action_results_skipped=true
fi
if [[ -e $SESS_ACTION_RESULTS_PATHFILE ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $datetime -gt 0 && $duration -gt 0 ]];then
[[ $a -eq 0 ]] && a=$datetime
b=$datetime
c=$duration
((d++))
fi
done < "$SESS_ACTION_RESULTS_PATHFILE"
a=$(ConvertMillisecondsToSeconds "$a")
b=$(ConvertMillisecondsToSeconds "$b")
c=$(ConvertMillisecondsToSeconds "$c")
[[ $b -gt 0 ]] && e=$((b+c+1))
if [[ $show_action_results_ok = true || $show_action_results_skipped = true || $show_action_results_failed = true || $show_action_results_zero = true ]];then
{
DisplayAsHelpTitle "package action$(Pluralise "$d") started @ $(ConvertSecondsToTime "$a"), ended @ $(ConvertSecondsToTime "$e"), elapsed = $(ConvertSecondsToDuration "$(CalcAmountDiff "$a" "$e")")"
[[ $show_action_results_ok = true ]] && ShowReportActionResults ok
[[ $show_action_results_skipped = true ]] && ShowReportActionResults skipped
[[ $show_action_results_failed = true ]] && ShowReportActionResults failed
[[ $show_action_results_zero = true ]] && ShowZeroQpkgs
} > "$REPORT_OUTPUT_PATHFILE"
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
fi
fi
}
ShowReportActionResults()
{
local action=''
local -i count=0
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ -e $SESS_ACTION_RESULTS_PATHFILE ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]] || [[ $1 = skipped && ($result = 'skipped-ok' || $result = 'skipped-error' || $result = 'skipped-abort') ]];then
[[ $action = status && $useropt_show_all_results = false ]] && continue
((count++))
[[ $count -gt 1 ]] && break
fi
done < "$SESS_ACTION_RESULTS_PATHFILE"
if [[ $count -eq 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "this package action completed $(TextBrightGreen OK):"
;;
skipped)
DisplayAsHelpTitle "this package action was $(TextBrightOrange skipped) (and why):"
;;
failed)
DisplayAsHelpTitle "this package action $(TextBrightRed failed) (and why):"
esac
elif [[ $count -gt 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "these package actions completed $(TextBrightGreen OK):"
;;
skipped)
DisplayAsHelpTitle "these package actions were $(TextBrightOrange skipped) (and why):"
;;
failed)
DisplayAsHelpTitle "these package actions $(TextBrightRed failed) (and why):"
esac
fi
if [[ $count -ge 1 ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]] || [[ $1 = skipped && ($result = 'skipped-ok' || $result = 'skipped-error' || $result = 'skipped-abort') ]];then
[[ $action = status && $useropt_show_all_results = false ]] && continue
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason" "$package_type" "$quantity"
fi
done < "$SESS_ACTION_RESULTS_PATHFILE"
fi
fi
if [[ $count -eq 0 ]];then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK)."
;;
skipped)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped)."
;;
failed)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
return 0
}
Help.Show:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport show
{
Help.Basic:Show
DisplayAsHelpTitle "'show' usage examples:"
DisplayAsProjSynIndentExam 'show QPKG abbreviations' 'show abbreviations'
DisplayAsProjSynIndentExam '' 'show abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'show QPKG dependency report' 'show dependencies'
DisplayAsProjSynIndentExam '' 'show deps'
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'show QPKG repository assignments report' 'show repositories'
DisplayAsProjSynIndentExam '' 'show repos'
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show last session action results' 'show results'
DisplayAsProjSynIndentExam '' results
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'show status'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Options:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport options
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Packages:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport packages
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for QPKGs will go here:'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Problems:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport problems
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'activate these QPKGs' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all dependencies exist for installed QPKGs' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clear local repository files from these QPKGs' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'find the live status of each application in these QPKGs' "status $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "s $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Upgrades:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport upgrades
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for upgrading your QPKGs:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable QPKGs' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'find the live application status of upgradable QPKGs' 'status upgradable'
DisplayAsProjSynIndentExam '' 's upgradable'
DisplayAsProjSynIndentExam '' 's new'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Tips:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport tips
{
Help.Basic:Show
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) QPKGs" 'install all'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive QPKGs' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
Help.BackupLocation:Show
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
ViewLogLast()
{
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
EraseThisLine
if [[ -e $SESS_LAST_PATHFILE ]];then
DisplayFileInViewport "$SESS_LAST_PATHFILE" linenumbers
Display
else
ShowAsError 'no last session log to display'
fi
return 0
}
ViewLogTail()
{
DisableDebugToArchiveAndFile
ExtractTailFromLog
EraseThisLine
if [[ -e $SESS_TAIL_PATHFILE ]];then
DisplayFileInViewport "$SESS_TAIL_PATHFILE" linenumbers
Display
else
ShowAsError 'no session log tail to display'
fi
return 0
}
DisplayFileInViewport()
{
local filename=${1:-}
local jumptoend=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local showlinenumbers=false
local wraplines=false
if [[ ! -e $filename ]];then
echo "filename $(ShowAsFileName "$filename") not found"
return 1
fi
case 'linenumbers' in
${2:-}|${3:-}|${4:-})
showlinenumbers=true
esac
case 'jumptoend' in
${2:-}|${3:-}|${4:-})
jumptoend=true
esac
case 'wrap' in
${2:-}|${3:-}|${4:-})
wraplines=true
esac
if [[ $useropt_verbose = true ]];then
if [[ -e $CAT_CMD ]];then
$CAT_CMD "$filename"
return
else
echo "$(<$1)"
return
fi
fi
if [[ $($WC_CMD -l < "$filename") -ge $SESS_ROWS || $($WC_CMD -L < "$filename") -ge $SESS_COLS ]];then
if [[ -e $GNU_LESS_CMD ]];then
options=' --quit-on-intr --tilde --mouse --RAW-CONTROL-CHARS --shift 4 --redraw-on-quit --quit-if-one-screen'
[[ $wraplines = false ]] && options+=' --chop-long-lines'
[[ $showlinenumbers = true ]] && options+=' --LINE-NUMBERS'
[[ $jumptoend = true ]] && options+=' +G'
LESSSECURE=1 ${GNU_LESS_CMD}${options} --prompt "$prompt" "$filename"
return
fi
if [[ -e $LESS_CMD ]];then
options=' -~'
[[ $wraplines = false ]] && options+='S'
[[ $showlinenumbers = true ]] && options+='N'
${LESS_CMD}${options} "$filename"
return
fi
fi
if [[ -e $CAT_CMD ]];then
[[ $showlinenumbers = true ]] && options+=' --number'
${CAT_CMD}${options} "$filename"
return
elif [[ -e $MORE_CMD ]];then
$MORE_CMD "$filename"
return
fi
echo "$(<$1)"
}
Log.Last:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $SESS_LAST_PATHFILE ]];then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$SESS_LAST_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no last session log found'
fi
return 0
}
Log.Tail:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]];then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$SESS_TAIL_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no session log tail found'
fi
return 0
}
GetLogSessStartLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*started:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | head -n1 | cut -d':' -f1)-1))
[[ $linenum -lt 1 ]] && linenum=1
printf '%s' "$linenum"
}
GetLogSessFinishLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*finished:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | cut -d':' -f1)+2))
[[ $linenum -eq 2 ]] && linenum=3
printf '%s' "$linenum"
}
ArchiveActiveSessLog()
{
[[ -n ${sess_active_pathfile:-} && -e $sess_active_pathfile ]] && $CAT_CMD "$sess_active_pathfile" >> "$SESS_ARCHIVE_PATHFILE"
}
ArchivePriorSessLogs()
{
local f=''
for f in "$THIS_PACKAGE_PATH"/session.*.active.log;do
if [[ -f $f && $f != "$sess_active_pathfile" ]];then
$CAT_CMD "$f" >> "$SESS_ARCHIVE_PATHFILE"
rm -f "$f" 2> /dev/null
fi
done
}
ResetActiveSessLog()
{
rm -f "$sess_active_pathfile" 2> /dev/null
}
ExtractPrevSessFromTail()
{
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
local -i start_line=0
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]];then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]];do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]] && break
done
$SED_CMD "$start_line,$end_line!d" "$SESS_TAIL_PATHFILE" > "$SESS_LAST_PATHFILE"
else
rm -f "$SESS_LAST_PATHFILE" 2> /dev/null
fi
return 0
}
ExtractTailFromLog()
{
if [[ -e $SESS_ARCHIVE_PATHFILE ]];then
$TAIL_CMD -n${LOG_TAIL_LINES} "$SESS_ARCHIVE_PATHFILE" > "$SESS_TAIL_PATHFILE"
else
rm -f "$SESS_TAIL_PATHFILE" 2> /dev/null
fi
return 0
}
ShowReportVersions()
{
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: ${THIS_PACKAGE_VER:-undefined}"
Display "manager: ${THIS_SCRIPT_VER:-undefined}"
Display "loader: ${LOADER_SCRIPT_VER:-undefined}"
Display "objects: ${OBJECTS_VER:-undefined}"
Display "packages: ${PACKAGES_EPOCH}$([[ $PACKAGES_EPOCH != undefined ]] && printf '%s' " ($(ConvertSecondsToFullDate "$PACKAGES_EPOCH"))")"
return 0
}
InitForkCounts()
{
MakePath "$ACTION_FORKS_COUNT" 'action forks'
proc_counts_path=$($MKTEMP_CMD -d "$ACTION_FORKS_COUNT"/"${FUNCNAME[1]}"_XXXXXX)
[[ -n ${proc_counts_path:?undefined proc counts path} ]] || return
EraseForkCountPaths
proc_fork_count_path=$proc_counts_path/fork.count
proc_ok_count_path=$proc_counts_path/ok.count
proc_skip_count_path=$proc_counts_path/skip.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_fail_count_path=$proc_counts_path/fail.count
mkdir -p "$proc_fork_count_path"
mkdir -p "$proc_ok_count_path"
mkdir -p "$proc_skip_count_path"
mkdir -p "$proc_skip_ok_count_path"
mkdir -p "$proc_skip_error_count_path"
mkdir -p "$proc_skip_abort_count_path"
mkdir -p "$proc_fail_count_path"
InitProgress
}
IncForkProgressIndex()
{
local a
((progress_index++))
printf -v a '%02d' "$progress_index"
proc_fork_pathfile=$proc_fork_count_path/$a
proc_ok_pathfile=$proc_ok_count_path/$a
proc_skip_pathfile=$proc_skip_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_fail_pathfile=$proc_fail_count_path/$a
}
RefreshForkCounts()
{
fork_count=$(ls -A -1 "$proc_fork_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
ok_count=$(ls -A -1 "$proc_ok_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_count=$(ls -A -1 "$proc_skip_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_ok_count=$(ls -A -1 "$proc_skip_ok_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_error_count=$(ls -A -1 "$proc_skip_error_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_abort_count=$(ls -A -1 "$proc_skip_abort_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
fail_count=$(ls -A -1 "$proc_fail_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
} &> /dev/null
EraseForkCountPaths()
{
ClearPath /var/run/sherpa/actions/forks "$proc_counts_path"
[[ -e $ACTION_ABORT_PATHFILE ]] && rm -f "$ACTION_ABORT_PATHFILE"
} &> /dev/null
InitProgress()
{
progress_index=0
prev_clean_msg=''
RefreshForkCounts
}
UpdateForkProgress()
{
local a=''
local b=''
RefreshForkCounts
[[ $useropt_verbose = false && ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
a=$((skip_count+skip_ok_count+skip_error_count+skip_abort_count))
b=$(PercFrac "$ok_count" "$a" "$fail_count" "$total_count")
if [[ $ok_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightGreen "$ok_count") OK"
fi
if [[ $a -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightOrange "$a") skipped"
fi
if [[ $fail_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightRed "$fail_count") failed"
fi
if [[ $fork_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightYellow "$fork_count") in-progress"
fi
[[ -n $b && ! -e $DISPLAY_INHIBIT_PATHFILE ]] && ShowAsProc "${fork_progress_prefix:-}" "$b"
return 0
} >&2
QPKGs.Missing:Show()
{
! QPKGs.AClist.ISmissing.IsSet || return 0
! QPKGs.ACreinstall.ISmissing.IsSet || return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b=' is'
c='it'
else
b='s are'
c='them'
fi
ShowAsNote "the $a QPKG${b} missing or broken. Please reinstall $c"
return 1
}
QPKGs.NewVers:Show()
{
! QPKGs.AClist.ISupgradable.IsSet || return 0
! QPKGs.ACupgrade.ISupgradable.IsSet || return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISupgradable:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISupgradable:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b='a '
c='version is'
else
c="version$(Pluralise "${#packages[@]}") are"
fi
ShowAsNote "${b}new QPKG $c available for $a"
return 1
}
CheckQPKGsConflicts()
{
[[ $run_package_actions = false ]] || return 0
local a=''
if [[ -n ${BASE_QPKG_CONFLICTS_WITH:-} ]];then
for a in "${BASE_QPKG_CONFLICTS_WITH[@]}";do
if QpkgIsEnabled "$a";then
ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
return 1
fi
done
fi
return 0
}
CheckQPKGsWarnings()
{
local a=''
if [[ -n ${BASE_QPKG_WARNINGS:-} ]];then
for a in "${BASE_QPKG_WARNINGS[@]}";do
if QpkgIsEnabled "$a";then
ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
return 1
fi
done
fi
return 0
}
QPKGs.Actions:List()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
local b=''
local border_shown=false
for a in "${QPKG_ACTIONS[@]}";do
for b in ok er sk so se sa;do
if QPKGs-AC${a}-${b}.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
case $b in
ok|sk|so)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]] && DebugInfoMinSepr
FuncExit
}
IPKs.Actions:List()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
local border_shown=false
for a in "${IPK_ACTIONS[@]}";do
if IPKs-AC${a}-ok.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) "
fi
if IPKs-AC${a}-er.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) "
fi
done
[[ $border_shown = true ]] && DebugInfoMinSepr
FuncExit
}
PIPs.Actions:List()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
DebugInfoMinSepr
for a in "${PIP_ACTIONS[@]}";do
PIPs-AC${a}-ok.IsAny && DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny && DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) "
done
DebugInfoMinSepr
FuncExit
}
QPKGs.States:List()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
QPKGs.States:Build
DebugInfoMinSepr
for a in "${QPKG_IS_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}";do
[[ $a = installed ]] && continue
if [[ $a = unknown ]];then
QPKGs-IS${a}.IsAny && DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
else
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
fi
done
for a in "${QPKG_ISNT_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}";do
[[ $a = installed ]] && continue
if [[ $a = ok ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
else
QPKGs-ISNT${a}.IsAny && DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
fi
done
for a in "${QPKG_STATES_TRANSIENT[@]}";do
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
done
DebugInfoMinSepr
FuncExit
}
QPKGs.Tiers:Build()
{
FuncInit
if [[ ${qpkgs_tiers_built:=false} = true ]];then
DebugAsDone "don't build tiers: they're already built"
FuncExit;return
fi
local previous=''
if [[ ! -e $DEPENDENT_QPKGS_LIST_PATHFILE || ! -e $INDEPENDENT_QPKGS_LIST_PATHFILE ]];then
ShowAsProc tiers
rm -f "$DEPENDENT_QPKGS_LIST_PATHFILE" "$INDEPENDENT_QPKGS_LIST_PATHFILE" 2> /dev/null
for qpkg_name in "${QPKG_NAME[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QpkgSetIndex
if QpkgIsDependent;then
echo "$qpkg_name" >> "$DEPENDENT_QPKGS_LIST_PATHFILE"
else
echo "$qpkg_name" >> "$INDEPENDENT_QPKGS_LIST_PATHFILE"
fi
done
qpkgs_tiers_built=true
fi
[[ -e $DEPENDENT_QPKGS_LIST_PATHFILE ]] && QPKGs-GRdependent:Add "$(<$DEPENDENT_QPKGS_LIST_PATHFILE)"
[[ -e $INDEPENDENT_QPKGS_LIST_PATHFILE ]] && QPKGs-GRindependent:Add "$(<$INDEPENDENT_QPKGS_LIST_PATHFILE)"
FuncExit
}
QPKGs.Tiers:Init()
{
rm -f "$DEPENDENT_QPKGS_LIST_PATHFILE" "$INDEPENDENT_QPKGS_LIST_PATHFILE" 2> /dev/null
qpkgs_tiers_built=false
}
QPKGs.States:Build()
{
FuncInit
local a=''
local b=''
if [[ ${qpkgs_states_built:=false} = true ]];then
DebugAsDone "don't build states: they're already built"
FuncExit;return
fi
LoadPackages
QPKGs.States:Init
OsIsStarting && ShowAsWarn "$(OsGetQnapOS) is starting all enabled QPKGs $CHARS_ELLIPSIS check again in a few minutes"
OsIsStopping && ShowAsWarn "$(OsGetQnapOS) is shutting-down and all QPKGs are stopping"
if OsIsLoadAverageInsane;then
ShowAsWarn 'the NAS has an exceptionally-high system-load, recommend aborting and trying again later'
elif OsIsLoadAverageHigh;then
ShowAsWarn 'the NAS has an unusually-high system-load, so this may take a while'
elif OsIsLoadAverageElevated;then
ShowAsNote 'the NAS has an elevated system-load, so this may take a little longer than usual'
fi
ShowAsProc 'QPKG states'
MakePath "$QPKG_STATES_PATH" states || return
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstallable;then
echo installable
else
echo notinstallable
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsMissing;then
echo missing
else
echo notmissing
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsUpgradable;then
echo upgradable
else
echo notupgradable
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstalled;then
if QpkgIsEnabled;then
echo enabled
else
echo notenabled
fi
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstalled;then
echo installed
else
echo notinstalled
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsBackupExist;then
echo backedup
else
echo notbackedup
fi >> "$QPKG_STATES_PATH/$qpkg_name"
done &
wait 2> /dev/null
for qpkg_name in $(QPKGs-GRall:Array);do
a=/var/log/$qpkg_name.action
b=/var/log/$qpkg_name.result
if [[ -e $a && -e $b ]];then
case $(<$b) in
in-progress)
case $(<$a) in
start)
QPKGs-ISstarting:Add "$qpkg_name"
;;
restart)
QPKGs-ISrestarting:Add "$qpkg_name"
;;
stop)
QPKGs-ISstopping:Add "$qpkg_name"
esac
;;
ok)
QPKGs-ISok:Add "$qpkg_name"
;;
failed)
QPKGs-ISNTok:Add "$qpkg_name"
esac
fi
a=$QPKG_STATES_PATH/$qpkg_name
[[ -e $a ]] || continue
for b in $(<$a);do
case $b in
backedup)
QPKGs-ISbackedup:Add "$qpkg_name"
;;
notbackedup)
QPKGs-ISNTbackedup:Add "$qpkg_name"
;;
backupable)
:
;;
notbackupable)
:
;;
enabled)
QPKGs-ISenabled:Add "$qpkg_name"
;;
notenabled)
QPKGs-ISNTenabled:Add "$qpkg_name"
;;
installable)
QPKGs-ISinstallable:Add "$qpkg_name"
;;
notinstallable)
QPKGs-ISNTinstallable:Add "$qpkg_name"
;;
installed)
QPKGs-ISinstalled:Add "$qpkg_name"
;;
notinstalled)
QPKGs-ISNTinstalled:Add "$qpkg_name"
;;
missing)
QPKGs-ISmissing:Add "$qpkg_name"
QPKGs-ISok:Remove "$qpkg_name"
QPKGs-ISNTok:Add "$qpkg_name"
;;
notmissing)
QPKGs-ISNTmissing:Add "$qpkg_name"
;;
upgradable)
QPKGs-ISupgradable:Add "$qpkg_name"
;;
notupgradable)
QPKGs-ISNTupgradable:Add "$qpkg_name"
esac
done
done
qpkgs_states_built=true
QPKGs.Missing:Show
QPKGs.NewVers:Show
FuncExit
}
QPKGs.States:Init()
{
LoadObjects || return
FuncInit
local a=''
DebugAsProc 'initialising state lists'
for a in "${QPKG_IS_STATES[@]:-}" "${QPKG_STATES_TRANSIENT[@]:-}";do
[[ $a = active ]] && continue
QPKGs-IS${a}:Init
done
for a in "${QPKG_ISNT_STATES[@]:-}";do
[[ $a = active ]] && continue
QPKGs-ISNT${a}:Init
done
ClearPath /var/run/sherpa/packages "$QPKG_STATES_PATH"
DebugAsDone 'initialised state lists'
qpkgs_states_built=false
FuncExit
}
QPKGs.IsCanBackup:Build()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsCanBackup "$qpkg_name" && QPKGs-GRcanbackup:Add "$qpkg_name"
done
FuncExit
}
QPKGs.IsCanRestartToUpdate:Build()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsCanRestartToUpdate "$qpkg_name" && QPKGs-GRcanrestarttoupdate:Add "$qpkg_name"
done
FuncExit
}
QPKGs.IsCanClean:Build()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsCanClean "$qpkg_name" && QPKGs-GRcanclean:Add "$qpkg_name"
done
FuncExit
}
QPKGs.IsTimeoutsIncreased()
{
[[ -e /usr/local/sbin/qpkg_service.orig ]]
}
Help.Abbreviations:Show()
{
FuncInit
local a=''
local f=''
local -i m=0
local -i n=0
LoadPackages
DisableDebugToArchiveAndFile
DisplayProcReport abbreviations
ResetReportsPath &> /dev/null
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages)."
printf '\n'
} > "$REPORT_OUTPUT_PATHFILE"
if [[ -e $GNU_AWK_CMD ]];then
printf -v a '%s\n' 'QPKG name:|Installed?|Acceptable QPKG name abbreviations and aliases:'
else
printf -v a '%s\n' "$(GenerateAbsReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateAbsReportDataLine > "$REPORTS_PATH/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi >> "$REPORT_OUTPUT_PATHFILE"
fi
DisplayAsProjSynExam "example: to install $(ShowAsPackageName SABnzbd), $(ShowAsPackageName Mylar3) and $(ShowAsPackageName nzbToMedia) all-at-once" 'install sab my nzb2' >> "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
FuncExit
}
ShowReportBackups()
{
FuncInit
local epoch_time=0
local -i file_bytes=0
local file_date=''
local file_name=''
local file_time=''
DisableDebugToArchiveAndFile
DisplayProcReport backups
ResetReportsPath &> /dev/null
{
DisplayAsBacksReportTitleLine
if [[ -e $GNU_FIND_CMD ]];then
while read -r epoch_time file_name file_bytes;do
[[ -z $epoch_time || -z $file_name ]] && break
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_backups_older_than"
done <<< "$($GNU_FIND_CMD "$QPKG_BU_PATH"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2> /dev/null | $SORT_CMD)"
else
while read -r file_date file_time file_name file_bytes;do
[[ -z $file_date || -z $file_name ]] && break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$($BASENAME_CMD "$file_name")
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_backups_older_than"
done <<< "$(cd "$QPKG_BU_PATH" && ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2> /dev/null | $AWK_CMD '{print $6" "$7" "$8" "$5}')"
fi
GenerateReportFooter
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
FuncExit
}
ShowReportDependencies()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport dependency
ResetReportsPath &> /dev/null
if [[ -e $GNU_AWK_CMD ]];then
printf -v a '%s\n' 'QPKG name:|Dependencies:|Installed?|Enabled?|Managed?|Min. RAM:|Min. OS:|Max. OS:|Supported arch?'
else
printf -v a '%s\n' "$(GenerateDepsReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateDepsReportDataLine > "$REPORTS_PATH/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$REPORT_OUTPUT_PATHFILE"
GenerateReportFooter >> "$REPORT_OUTPUT_PATHFILE"
fi
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
echo
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
FuncExit
}
ShowReportFeatures()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport features
ResetReportsPath &> /dev/null
if [[ -e $GNU_AWK_CMD ]];then
printf -v a '%s\n' 'QPKG name:|CanBack?|CanClean?|StartUpd?|AutoUpd?|LiveTest?|Indep?|Compat?|Enhanced?'
else
printf -v a '%s\n' "$(GenerateFeaturesReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateFeaturesReportDataLine > "$REPORTS_PATH/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$REPORT_OUTPUT_PATHFILE"
GenerateReportHeadingsFooter >> "$REPORT_OUTPUT_PATHFILE"
fi
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
echo
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
FuncExit
}
ShowReportPackages()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport package
{
Help.Basic:Show
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once."
printf '\n'
} > "$REPORT_OUTPUT_PATHFILE"
if [[ -e $GNU_AWK_CMD ]];then
printf -v a '%s\n' 'QPKG name:|Appl. version:|Description:'
else
printf -v a '%s\n' "$(GeneratePacksReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GeneratePacksReportDataLine "$qpkg_name" > "$REPORTS_PATH/$n" &
done
m=$n
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi >> "$REPORT_OUTPUT_PATHFILE"
GenerateReportFooter >> "$REPORT_OUTPUT_PATHFILE"
fi
{
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
} >> "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
echo
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
FuncExit
}
ShowReportRepos()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport repository
ResetReportsPath &> /dev/null
if [[ -e $GNU_AWK_CMD ]];then
printf -v a '%s\n' 'QPKG name:|Repository:|Install date:'
else
printf -v a '%s\n' "$(GenerateReposReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateReposReportDataLine > "$REPORTS_PATH/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$REPORT_OUTPUT_PATHFILE"
GenerateReportFooter >> "$REPORT_OUTPUT_PATHFILE"
fi
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
echo
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
FuncExit
}
ShowReportStatuses()
{
FuncInit
local a=false
local b=''
local c=''
local f=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport status
ResetReportsPath &> /dev/null
for qpkg_name in $(QPKGs-GRall:Array);do
QPKGs-ACstatus-dn.Exist "$qpkg_name" || continue
((n++))
QpkgSetIndex
QPKGs-ISupgradable.Exist "$qpkg_name" && a=true
GenerateStatusReportDataLine > "$REPORTS_PATH/$n" &
done
if [[ -e $GNU_AWK_CMD ]];then
[[ $a = true ]] && b=" ($(TextBrightOrange new))"
printf -v c '%s\n' "QPKG name:|QPKG statuses:|QPKG action (result):|QPKG version${b}:|Appl. version:|QPKG installation path:"
else
printf -v c '%s\n' "$(GenerateStatusReportTitleLine)"
fi
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && printf -v c '%s\n' "$c$(<$f)"
done
if [[ -n $c ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$c" | Tableise
else
printf '%s' "$c"
fi > "$REPORT_OUTPUT_PATHFILE"
GenerateReportFooter >> "$REPORT_OUTPUT_PATHFILE"
fi
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
echo
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_failed=false
FuncExit
}
GenerateReportFooter()
{
DisplayAsHelpTitle 'report information:'
local a=''
a=$({
if [[ -e "$REPORT_FLAGS_PATH"/status-missing ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '! missing')" 'QPKG is missing from its installation path. Please reinstall it'
fi
if [[ -e "$REPORT_FLAGS_PATH"/req-alert ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" 'prevents QPKG working correctly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/state-disabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed disabled)" "QPKG won't start at bootup. Enable it first, then start it"
fi
if [[ -e "$REPORT_FLAGS_PATH"/result-aborted ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed aborted))" 'last action was aborted'
fi
if [[ -e "$REPORT_FLAGS_PATH"/result-failed ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed failed))" 'last action failed'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-inactive ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed inactive)" 'application is dead or not-started. Try starting/activating it'
fi
if [[ -e "$REPORT_FLAGS_PATH"/backup-file-old ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" "QPKG backup file was updated more-than $highlight_backups_older_than."
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-upgradable ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange new))" 'an upgraded QPKG version is available'
fi
if [[ -e "$REPORT_FLAGS_PATH"/req-attention ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" 'QPKG cannot be installed'
fi
if [[ -e "$REPORT_FLAGS_PATH"/action-pending ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange pending)" 'QPKG is waiting for first action to be run. Check again shortly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-stopping ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange stopping)" 'QPKG is stopping. Check again shortly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-slow ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange slow)" 'application is alive, but was slow to respond to the status request. Try checking again shortly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-starting ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange starting)" 'QPKG is starting. Check again shortly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/result-in-progress ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange in-progress))" 'an action is in-progress. Check again shortly'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-unknown ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange unknown)" 'application status could not be determined'
fi
if [[ -e "$REPORT_FLAGS_PATH"/repo-other ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '* URL')" 'another repository is managing this QPKG'
fi
if [[ -e "$REPORT_FLAGS_PATH"/state-enabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen enabled)" 'QPKG will be started at bootup'
fi
if [[ -e "$REPORT_FLAGS_PATH"/result-ok ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightGreen OK))" 'last action was successful'
fi
if [[ -e "$REPORT_FLAGS_PATH"/status-active ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen active)" 'application is alive (and responsive if a daemon)'
fi
if [[ -e "$REPORT_FLAGS_PATH"/repo-sherpa ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen sherpa)" "$(ShowAsTitleName) is managing this QPKG"
fi
if [[ -e "$REPORT_FLAGS_PATH"/app-dynamic ]];then
DisplayAsIndentQuotedInfoItem dynamic 'application version is the latest available'
fi
if [[ -e "$REPORT_FLAGS_PATH"/app-static ]];then
DisplayAsIndentQuotedInfoItem static 'application version auto-update is disabled or unsupported'
fi
if [[ -e "$REPORT_FLAGS_PATH"/app-final ]];then
DisplayAsIndentQuotedInfoItem final 'application version is the last available'
fi
if [[ -e "$REPORT_FLAGS_PATH"/action-not-found ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey not-found)" 'action tracking files were not found'
fi
if [[ -e "$REPORT_FLAGS_PATH"/action-unsupported ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey unsupported)" 'action tracking is unsupported by this QPKG'
fi
if [[ -e "$REPORT_FLAGS_PATH"/na ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey 'N/A')" 'not applicable'
fi
})
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi
if [[ -e "$REPORT_FLAGS_PATH"/deps ]];then
DisplayAsHelpTitle "QPKG dependencies are automatically installed/started/stopped/restarted as-required by $(ShowAsTitleName)."
fi
if compgen -G "${REPORT_FLAGS_PATH}/backup-file-*" > /dev/null;then
DisplayAsIndentItem "backups are listed oldest-first."
fi
if compgen -G "${REPORT_FLAGS_PATH}/backup-file-*" > /dev/null;then
DisplayAsIndentItem "all $(ShowAsTitleName) backup files are stored here: $QPKG_BU_PATH"
fi
}
GenerateReportHeadingsFooter()
{
DisplayAsHelpTitle 'column headings:'
local a=''
a=$({
DisplayAsIndentQuotedInfoItem 'CanBack?' "application config 'backup' and 'restore' are supported"
DisplayAsIndentQuotedInfoItem 'CanClean?' "application 'clean' is supported"
DisplayAsIndentQuotedInfoItem 'StartUpd?' 'application restart-to-update is supported'
DisplayAsIndentQuotedInfoItem 'AutoUpd?' 'application restart-to-update is enabled'
DisplayAsIndentQuotedInfoItem 'LiveTest?' "has a built-in 'status' check, and can test for daemon \"live\" status"
DisplayAsIndentQuotedInfoItem 'Indep?' 'is independent of other QPKGs'
DisplayAsIndentQuotedInfoItem 'Compat?' 'has a release compatible with this NAS arch'
DisplayAsIndentQuotedInfoItem 'Enhanced?' "$(ShowAsTitleName) enhanced service actions are supported"
})
if [[ -n $a ]];then
if [[ -e $GNU_AWK_CMD ]];then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi
}
QPKGs.ISbackedup:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISbackedup.IsAny;then
for qpkg_name in $(QPKGs-ISbackedup:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'backed-up' QPKGs"
fi
return 0
}
QPKGs.ISNTbackedup:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTbackedup.IsAny;then
for qpkg_name in $(QPKGs-ISNTbackedup:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not backed-up' QPKGs"
fi
return 0
}
QPKGs.ISenabled:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISenabled.IsAny;then
for qpkg_name in $(QPKGs-ISenabled:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'enabled' QPKGs"
fi
return 0
}
QPKGs.ISNTenabled:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTenabled.IsAny;then
for qpkg_name in $(QPKGs-ISNTenabled:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not enabled' QPKGs"
fi
return 0
}
QPKGs.ISinstalled:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISinstalled.IsAny;then
for qpkg_name in $(QPKGs-ISinstalled:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'installed' QPKGs"
fi
return 0
}
QPKGs.ISNTinstalled:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTinstalled.IsAny;then
for qpkg_name in $(QPKGs-ISNTinstalled:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not installed' QPKGs"
fi
return 0
}
#QPKGs.GRall:Show()
QPKGs.ISinstallable:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISinstallable.IsAny;then
for qpkg_name in $(QPKGs-ISinstallable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'installable' QPKGs"
fi
return 0
}
QPKGs.ISNTinstallable:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTinstallable.IsAny;then
for qpkg_name in $(QPKGs-ISNTinstallable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not installable' QPKGs"
fi
return 0
}
QPKGs.ISmissing:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISmissing.IsAny;then
for qpkg_name in $(QPKGs-ISmissing:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'missing' QPKGs"
fi
return 0
}
QPKGs.ISNTmissing:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTmissing.IsAny;then
for qpkg_name in $(QPKGs-ISNTmissing:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not missing' QPKGs"
fi
return 0
}
QPKGs.ISactive:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISactive.IsAny;then
for qpkg_name in $(QPKGs-ISactive:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'active' QPKGs"
fi
return 0
}
QPKGs.ISNTactive:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTactive.IsAny;then
for qpkg_name in $(QPKGs-ISNTactive:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'inactive' QPKGs"
fi
return 0
}
QPKGs.ISupgradable:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISupgradable.IsAny;then
for qpkg_name in $(QPKGs-ISupgradable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'upgradable' QPKGs"
fi
return 0
}
QPKGs.ISNTupgradable:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTupgradable.IsAny;then
for qpkg_name in $(QPKGs-ISNTupgradable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'non-upgradable' QPKGs"
fi
return 0
}
QPKGs.GRindependent:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-GRindependent.IsAny;then
for qpkg_name in $(QPKGs-GRindependent:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'independent' QPKGs"
fi
return 0
}
QPKGs.GRdependent:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-GRdependent.IsAny;then
for qpkg_name in $(QPKGs-GRdependent:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'dependent' QPKGs"
fi
return 0
}
SendParentChangeEnv()
{
WriteToActionMsgPipe env "$1" '' ''
}
SendPackageStateChange()
{
WriteToActionMsgPipe change "$1" package "$qpkg_name"
}
SendActionStatus()
{
WriteToActionMsgPipe status "$1" package "$qpkg_name"
}
WriteToActionMsgPipe()
{
[[ $action_msg_pipe_fd != none && -e /proc/$$/fd/$action_msg_pipe_fd ]] && echo "$1|$2|$3|$4" >&$action_msg_pipe_fd
return 0
}
ReadFromActionMsgPipe()
{
local _msg1_key
local _msg1_value
local _msg2_key
local _msg2_value
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value <&$action_msg_pipe_fd
eval "$1='$_msg1_key' $2='$_msg1_value' $3='$_msg2_key' $4='$_msg2_value'"
return 0
}
FindNextFD()
{
local -i fd=-1
for fd in {10..100};do
if [[ ! -e /proc/$$/fd/$fd ]];then
printf '%s' "$fd"
return 0
fi
done
return 1
}
MarkThisAcForkAsStarted()
{
[[ -n $proc_fork_pathfile ]] && /bin/touch "$proc_fork_pathfile"
}
MarkThisAcForkAsOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_ok_pathfile"
SendActionStatus ok
}
MarkThisAcForkAsSkippedOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_ok_pathfile"
SendActionStatus so
}
MarkThisAcForkAsSkipped()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_pathfile"
SendActionStatus sk
}
MarkThisAcForkAsSkippedError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_error_pathfile"
SendActionStatus se
}
MarkThisAcForkAsSkippedAbort()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_abort_pathfile"
SendActionStatus sa
}
MarkThisAcForkAsError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_fail_pathfile"
SendActionStatus er
}
NoteIpkAcAsOk()
{
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-ok:Add "$1"
return 0
}
NoteIpkAcAsEr()
{
local a="failing request to $2 $(ShowAsPackageName "$1")"
[[ -n ${3:-} ]] && a+=" as $3"
DebugAsError "$a" >&2
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-er:Add "$1"
return 0
}
ModPathToEntware()
{
local a=''
local b=/opt/bin:/opt/sbin
if QPKGs-ISenabled.Exist Entware;then
! [[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=$b:${a%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=${a%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0
}
HardwareGetCPUInfo()
{
if $GREP_CMD -q '^model name' /proc/cpuinfo;then
$GREP_CMD '^model name' /proc/cpuinfo | head -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
elif $GREP_CMD -q '^Processor name' /proc/cpuinfo;then
$GREP_CMD '^Processor name' /proc/cpuinfo | head -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
else
printf unknown
return 1
fi
return 0
}
OsGetArch()
{
$UNAME_CMD -m
}
OsGetKernelVersion()
{
$UNAME_CMD -r
}
OsGetKernelPageSize()
{
$GREP_CMD KernelPageSize /proc/1/smaps | head -n1 | cut -f2 -d':' | tr -d ' '
}
HardwareGetPlatform()
{
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf
}
UserGetDefVol()
{
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info
}
Python3IsOutdated()
{
[[ -e $PYTHON3_CMD ]] || return
installed_ver=$(Python3GetVer "$PYTHON3_CMD")
[[ $NAS_ARCH = armv5tel && ${installed_ver//./} -lt 3114 ]] || [[ $NAS_ARCH != armv5tel && ${installed_ver//./} -lt $MIN_PYTHON_VER ]]
}
Python3GetVer()
{
PythonGetVer "${1:-python3}"
}
PythonGetVer()
{
GetThisBinPath ${1:-python} &> /dev/null && ${1:-python} -V 2>&1 | $SED_CMD 's|^Python ||'
}
PerlIsOutdated()
{
[[ -e $PERL_CMD ]] || return
installed_ver=$(PerlGetVer "$PERL_CMD")
[[ $NAS_ARCH = armv5tel && ${installed_ver//./} -lt 5281 ]] || [[ $NAS_ARCH != armv5tel && ${installed_ver//./} -lt $MIN_PERL_VER ]]
}
PerlGetVer()
{
GetThisBinPath ${1:-perl} &> /dev/null && ${1:-perl} -e 'print "$^V\n"' 2> /dev/null | $SED_CMD 's|v||'
}
GetThisBinPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined binary} ]] && command -v "$1" 2>&1
}
GetRepoURLFromStoreID()
{
[[ -n ${1:-} ]] || return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf
}
OsGetUptime()
{
local n=$(< /proc/uptime)
ConvertSecondsToDuration "${n%%.*}"
}
UserGetTimeInShell()
{
local n=''
[[ -n ${LOADER_SCRIPT_PPID:-} ]] && n=$($PS_CMD -o pid,etime | $GREP_CMD $LOADER_SCRIPT_PPID | head -n1)
FormatAsLongMinutesSecs "${n:6}"
}
OsGetSysLoadAverages()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print "1m:"$1", 5m:"$2", 15m:"$3}'
}
OsGetSysLoad1MinAverage()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print $1}'
}
HardwareGetCPUCores()
{
local n=$($GREP_CMD -c '^processor' /proc/cpuinfo)
[[ $n -eq 0 ]] && n=$($GREP_CMD -c '^Processor' /proc/cpuinfo)
printf '%s' "$n"
}
HardwareGetInstalledRAM()
{
$GREP_CMD MemTotal /proc/meminfo | $SED_CMD 's|.*: ||;s|kB||;s| ||g'
}
OsGetFirmwareVer()
{
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf
}
OsGetFirmwareBuild()
{
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf
}
OsGetFirmwareDate()
{
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf
}
OsGetQnapOS()
{
if $GREP_CMD -q zfs /proc/filesystems;then
printf 'QuTS hero'
else
printf QTS
fi
}
QpkgGetArch()
{
case $NAS_ARCH in
x86_64)
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]] && printf i64 || printf i86
;;
i686|x86)
printf i86
;;
armv5tel)
printf a19
;;
armv7l)
case $NAS_PLATFORM in
ARM_MS)
printf a31
;;
ARM_AL)
printf a41
;;
*)
printf none
esac
;;
aarch64)
printf a64
;;
*)
printf none
esac
}
QpkgGetEntwareType()
{
if QpkgIsInstalled Entware;then
if [[ -e /opt/etc/passwd ]];then
if [[ -L /opt/etc/passwd ]];then
printf std
else
printf alt
fi
else
printf none
fi
else
printf 'not-installed'
fi
} 2> /dev/null
UserGetSudoUID()
{
printf '%s' "${SUDO_UID:-undefined}"
}
OsGetUpState()
{
if OsIsStarting;then
printf 'starting-up'
elif OsIsStopping;then
printf 'shutting-down'
else
printf stable
fi
}
UserGetGitBranch()
{
/sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf
}
OsIsOk()
{
if ! OsIsQNAP;then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0
}
OsIsQNAP()
{
[[ -e /etc/init.d/functions ]]
}
OsIsSupported()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 400 ]]
}
OsIsSupportSecureDownload()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 500 ]]
}
OsIsSupportQpkgTimeout()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]]
}
OsIsSupportSignedPackages()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 440 ]]
}
OsIsCompatibleWithSigned()
{
[[ $NAS_FIRMWARE_DATE -lt 20201015 || $NAS_FIRMWARE_DATE -gt 20201020 ]]
}
OsIsSupportUnofficialPackages()
{
[[ ${NAS_FIRMWARE_VER//.} -gt 426 && ${NAS_FIRMWARE_VER//.} -lt 440 ]]
}
OsIsSupportSudo()
{
[[ -e /usr/bin/sudo ]]
}
OsIsSupportSedExtRegex()
{
[[ $(echo -en "\033[1;97ma" | /bin/sed -r 's/\x1b\[[0-9;]*m//g' | /usr/bin/wc -c) -eq 1 ]]
}
OsIsSupportDecimalSleepSeconds()
{
/bin/sleep .01 &> /dev/null
}
OsIsAllowUnsignedPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert -d FALSE) = TRUE ]]
}
OsIsAllowUnofficialPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Check_Official -d TRUE) = FALSE ]]
}
OsIsStarting()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcS' | $GREP_CMD -v grep
} &> /dev/null
OsIsStopping()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcK' | $GREP_CMD -v grep
} &> /dev/null
OsIsStdKernelPageSize()
{
[[ ${KERNEL_PAGE_SIZE:=$(OsGetKernelPageSize)} = 4kB ]]
}
OsIsNonStdKernelPageSize()
{
! OsIsStdKernelPageSize
}
OsIsLoadAverageElevated()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*2*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OsIsLoadAverageHigh()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*4*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OsIsLoadAverageInsane()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*8*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
SetError()
{
run_package_actions=false
ErrorIsSet && return
_script_error_flag_=true
DebugVar _script_error_flag_
}
ErrorIsSet()
{
[[ ${_script_error_flag_:=false} = true ]]
}
ErrorIsNt()
{
[[ ${_script_error_flag_:=false} != true ]]
}
ShowZeroQpkgs()
{
[[ ${packages_loaded:=false} = true ]] || return
local a=''
local b=''
for a in "${QPKG_IS_STATES[@]:-}";do
for b in "${USER_QPKG_ACTIONS[@]:-}";do
[[ $b = list ]] && continue
QPKGs.AC${b}.IS${a}.IsSet && QPKGs-AC${b}-ok.IsNone && ShowAsWarn "no QPKGs were able to $(Lowercase "$b")"
done
done
return 0
}
ClaimLockfile()
{
local a=''
readonly LOCK_PATHFILE=/var/run/sherpa.lock
for a in sherpa-manager.sh sherpa-manager.source;do
if [[ -e $LOCK_PATHFILE && -d /proc/$(<"$LOCK_PATHFILE") && $(< /proc/"$(<"$LOCK_PATHFILE")"/cmdline) =~ $a ]];then
ShowAsAbort "another sherpa instance was found (PID:$(<"$LOCK_PATHFILE")), can't continue"
return 1
fi
done
echo "$$" > "$LOCK_PATHFILE"
return 0
}
ReleaseLockfile()
{
[[ -n ${LOCK_PATHFILE:-} ]] && rm -f "$LOCK_PATHFILE" 2> /dev/null
}
EnableVerbose()
{
useropt_verbose=true
DebugVar useropt_verbose
useropt_terse=false
ShowKeystrokes
ShowCursor
}
EnableDebugToArchiveAndFile()
{
useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward
}
DisableDebugToArchiveAndFile()
{
archive_debug_afterward=false
useropt_debug=false
}
SaveActionResultToLog()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
local -r PACKAGE_TYPE=${1:?${FUNCNAME[0]}'()': undefined package type}
local -r qpkg_name=${2:?${FUNCNAME[0]}'()': undefined package name}
local -r ACTION=${3:?${FUNCNAME[0]}'()': undefined action}
local -r QTY=${4:-1}
local -r CLEAN_ACTION=${ACTION//\"/}
local -r RESULT=${5:?${FUNCNAME[0]}'()': undefined result}
local -r REASON=${6:-}
local -r STARTTIME=$(ConvertNanosecondsToMilliseconds "${!var_safe_name}")
local -r DURATION=$(CalcAmountDiff "$STARTTIME" "$(ConvertNowToMilliseconds)")
local -r ACTION_TIMES_PATHFILE=$ACTION_TIMES_PATH/$CLEAN_ACTION.milliseconds
if [[ $2 = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
echo "$STARTTIME|$ACTION|$QTY|$qpkg_name|$PACKAGE_TYPE|$RESULT|$DURATION|$REASON" >> "$SESS_ACTION_RESULTS_PATHFILE"
if [[ -e $ACTION_TIMES_PATHFILE ]] && $GREP_CMD -q "^$qpkg_name|" < "$ACTION_TIMES_PATHFILE";then
$SED_CMD -i "/^$qpkg_name|/d" "$ACTION_TIMES_PATHFILE"
fi
echo "$qpkg_name|$DURATION" >> "$ACTION_TIMES_PATHFILE"
case $4 in
ok|skipped-ok)
DebugAsInfo "$REASON"
;;
skipped)
DebugAsWarn "$REASON"
;;
failed|skipped-@(error|abort))
DebugAsError "$REASON"
esac
return 0
}
_QPKG:reassign_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if ! QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif [[ $(QpkgGetStoreID) = sherpa || $(QpkgGetStoreID) = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'already assigned to sherpa'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "reassigning $(ShowAsPackageName)"
RunAndLog "/sbin/setcfg -e $qpkg_name store -f /etc/config/qpkg.conf" "$LOGS_PATH/$qpkg_name.$REASSIGN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reassign '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:download_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -r REMOTE_HASH=$(QpkgGetHash)
local -r REMOTE_URL=$(QpkgGetURL)
local -r REMOTE_FILENAME=$($BASENAME_CMD "$REMOTE_URL")
local -r LOCAL_PATHFILE=$QPKG_DL_PATH/$REMOTE_FILENAME
local -r LOCAL_FILENAME=$($BASENAME_CMD "$LOCAL_PATHFILE")
local -r LOG_PATHFILE=$LOGS_PATH/$LOCAL_FILENAME.$DOWNLOAD_LOG_FILE
local -i z=0
if [[ -z $REMOTE_URL || -z $REMOTE_HASH ]];then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped 'NAS arch is incompatible'
MarkThisAcForkAsSkipped
z=1
elif [[ -f $LOCAL_PATHFILE ]];then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH";then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped-ok "existing file $(ShowAsFileName "$LOCAL_FILENAME") checksum is correct"
MarkThisAcForkAsSkippedOk
z=2
else
DebugInfo "deleting $(ShowAsFileName "$LOCAL_FILENAME") as checksum is incorrect"
rm -f "$LOCAL_PATHFILE" 2> /dev/null
fi
fi
[[ $z -eq 0 ]] || FuncForkExit $z
if [[ ! -f $LOCAL_PATHFILE ]];then
DebugAsProc "downloading $(ShowAsFileName "$REMOTE_FILENAME")"
rm -f "$LOG_PATHFILE" 2> /dev/null
RunAndLog "$CURL_CMD --location --output $LOCAL_PATHFILE $REMOTE_URL" "$LOG_PATHFILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH";then
[[ $(Lowercase "${LOCAL_PATHFILE##*.}") = zip ]] && $UNZIP_CMD -nq "$LOCAL_PATHFILE" -d "$QPKG_DL_PATH"
SaveActionResultToLog QPKG "$qpkg_name" download '' ok
SendPackageStateChange ISdownloaded
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "cache file $(ShowAsFileName "$LOCAL_FILENAME") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkThisAcForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "$z"
MarkThisAcForkAsError
z=1
fi
fi
FuncForkExit $z
}
_QPKG:install_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'already installed'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsArchOK "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS arch is incompatible'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsMinOSVerOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped "$(OsGetQnapOS) version is incompatible"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsMinRAMOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS has insufficient RAM'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetPathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped-error 'no local file found for processing: please report this issue'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
if [[ $qpkg_name = Entware ]] && ! QPKGs-ISinstalled.Exist Entware && QPKGs-ACinstall-to.Exist Entware;then
local -r OPT_PATH=/opt
local -r OPT_BU_PATH=/opt.orig
if [[ -d $OPT_PATH && ! -L $OPT_PATH && ! -e $OPT_BU_PATH ]];then
DebugAsProc 'backup original /opt'
mv "$OPT_PATH" "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
DebugAsProc "installing $(ShowAsPackageName)"
[[ ${QPKGs_were_installed_name[*]:-} = *"$qpkg_name"* ]] && a+="QINSTALL_PATH=$(QpkgGetOriginalPath "$qpkg_name") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$INSTALL_LOG_FILE" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsCanLog && ! QpkgServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
SendPackageStateChange ISinstalled
if QpkgIsEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$qpkg_name" install '' ok "version $(QpkgGetInstalledVer)"
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv _UpdateEntwarePackageList_
PatchEntwareService
if [[ -L ${OPT_PATH:-} && -d ${OPT_BU_PATH:-} ]];then
DebugAsProc 'restoring original /opt'
mv "$OPT_BU_PATH"/* "$OPT_PATH" && ClearPath / "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
SendParentChangeEnv "QPKGs-ACsign-to:Add $qpkg_name"
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" install '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:reinstall_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a='QPKG_REINSTALL=true '
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if ! QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "not installed, please use 'install' instead."
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetPathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped-error 'no local file found for processing, please report this issue.'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "reinstalling $(ShowAsPackageName)"
QpkgIsInstalled && a+="QINSTALL_PATH=$($DIRNAME_CMD "$(QpkgGetInstallationPath)") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$REINSTALL_LOG_FILE" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsCanLog && ! QpkgServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
if QpkgIsEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' ok "version $(QpkgGetInstalledVer)"
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:rebuild_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if ! QpkgIsCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'does not support rebuild'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "already installed, please use 'restore' instead"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'backup file does not exist'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "meta-rebuilding $(ShowAsPackageName)"
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' ok
MarkThisAcForkAsOk
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:upgrade_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a='QPKG_UPGRADE=true '
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if ! QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif ! QPKGs-ISupgradable.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'no new QPKG is available'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetPathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped-error 'no local file found for processing, please report this issue'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local prev_ver=$(QpkgGetInstalledVer)
DebugAsProc "upgrading $(ShowAsPackageName)"
QpkgIsInstalled && a+="QINSTALL_PATH=$($DIRNAME_CMD "$(QpkgGetInstallationPath "$qpkg_name")") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$UPGRADE_LOG_FILE" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsCanLog && ! QpkgServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
SendPackageStateChange ISNTupgradable
if QpkgIsEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QpkgGetInstalledVer)
if [[ $current_ver = "$prev_ver" ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "version $current_ver"
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "version $prev_ver -> version $current_ver"
fi
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:uninstall_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "it's needed here! 😉"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r QPKG_UNINSTALLER_PATHFILE=$(QpkgGetInstallationPath)/.uninstall.sh
[[ $qpkg_name = Entware ]] && SaveIpkAndPipList
if [[ -e $QPKG_UNINSTALLER_PATHFILE ]];then
DebugAsProc "uninstalling $(ShowAsPackageName)"
RunAndLog "${a}${SH_CMD} $QPKG_UNINSTALLER_PATHFILE" "$LOGS_PATH/$qpkg_name.$UNINSTALL_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
[[ -e /sbin/qpkg_cli ]] && ! QPKGs-ACinstall-to.Exist "$qpkg_name" && /sbin/qpkg_cli --remove "$qpkg_name" &> /dev/null
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' ok
/sbin/rmcfg "$qpkg_name" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISNTinstalled
SendPackageStateChange ISNTactive
SendPackageStateChange ISNTenabled
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$z"
MarkThisAcForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$(ShowAsFileName '.uninstall.sh') not found"
MarkThisAcForkAsError
fi
FuncForkExit $z
}
_QPKG:activate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "not enabled, please 'enable' it first"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r LOG_PATHFILE=$LOGS_PATH/$qpkg_name.$ACTIVATE_LOG_FILE
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $QPKG_START_TIMEOUT_SECONDS"
local service_pathfile=$(QpkgGetServicePathFile)
DebugAsProc "activating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} start" "$LOG_PATHFILE" log:failure-only
z=$?
elif QpkgIsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} start $qpkg_name" "$LOG_PATHFILE" log:failure-only
QpkgServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile start" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" activate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISactive
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" activate '' failed "$z"
SendPackageStateChange ISNTactive
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:reactivate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "not enabled, please 'enable' it first"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r LOG_PATHFILE=$LOGS_PATH/$qpkg_name.$REACTIVATE_LOG_FILE
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $QPKG_RESTART_TIMEOUT_SECONDS"
local service_pathfile=$(QpkgGetServicePathFile)
DebugAsProc "reactivating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} restart" "$LOG_PATHFILE" log:failure-only
z=$?
elif QpkgIsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} restart $qpkg_name" "$LOG_PATHFILE" log:failure-only
QpkgServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile restart" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:deactivate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]	&& a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r LOG_PATHFILE=$LOGS_PATH/$qpkg_name.$DEACTIVATE_LOG_FILE
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $QPKG_STOP_TIMEOUT_SECONDS"
local service_pathfile=$(QpkgGetServicePathFile)
DebugAsProc "deactivating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} stop" "$LOG_PATHFILE" log:failure-only
z=$?
elif QpkgIsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} stop $qpkg_name" "$LOG_PATHFILE" log:failure-only
QpkgServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile stop" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISNTactive
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgAppCenterNotifier
FuncForkExit $z
}
_QPKG:enable_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'already enabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r LOG_PATHFILE=$LOGS_PATH/$qpkg_name.$ENABLE_LOG_FILE
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $QPKG_ENABLE_TIMEOUT_SECONDS"
DebugAsProc "enabling $(ShowAsPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} enable $qpkg_name" "$LOG_PATHFILE" log:failure-only
QpkgIsEnabled "$qpkg_name" && SendPackageStateChange ISenabled
ClearQpkgAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" enable '' ok
MarkThisAcForkAsOk
FuncForkExit $z
}
_QPKG:disable_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'already disabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r LOG_PATHFILE=$LOGS_PATH/$qpkg_name.$DISABLE_LOG_FILE
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $QPKG_DISABLE_TIMEOUT_SECONDS"
DebugAsProc "disabling $(ShowAsPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} disable $qpkg_name" "$LOG_PATHFILE" log:failure-only
! QpkgIsEnabled "$qpkg_name" && SendPackageStateChange ISNTenabled
ClearQpkgAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" disable '' ok
MarkThisAcForkAsOk
FuncForkExit $z
}
_QPKG:enableau_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is always enabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "enabling auto-update $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetServicePathFile) enable-auto-update" "$LOGS_PATH/$qpkg_name.$ENABLEAU_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" enableau '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" enableau '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:disableau_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update cannot be disabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "disabling auto-update $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetServicePathFile) disable-auto-update" "$LOGS_PATH/$qpkg_name.$DISABLEAU_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" disableau '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" disableau '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:backup_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'backup is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "backing-up $(ShowAsPackageName) configuration"
RunAndLog "${a}$(QpkgGetServicePathFile) backup" "$LOGS_PATH/$qpkg_name.$BACKUP_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" backup '' ok
SendPackageStateChange ISbackedup
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" backup '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:restore_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "not installed, try 'rebuild' instead"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'restore is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'backup file does not exist'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "restoring $(ShowAsPackageName) configuration"
RunAndLog "${a}$(QpkgGetServicePathFile) restore" "$LOGS_PATH/$qpkg_name.$RESTORE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" restore '' ok
SendPackageStateChange ISrestored
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" restore '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:clean_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsCanClean;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'clean is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "cleaning $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetServicePathFile) clean" "$LOGS_PATH/$qpkg_name.$CLEAN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" clean '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" clean '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:sign_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
local b=''
local -i z=0
if [[ -e $ACTION_ABORT_PATHFILE ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort 'abort requested, unable to continue'
MarkThisAcForkAsSkippedAbort
z=3
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugVar sqlite_cmd
if ! QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif ! OsIsSupportSignedPackages;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not required: firmware < 4.3.5'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
elif [[ ! -e $sqlite_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(ShowAsFileName sqlite3) binary not found"
MarkThisAcForkAsSkippedAbort
z=3
elif [[ ! -e $CERT_DB_PATHFILE ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(OsGetQnapOS) QPKG certificate database not found"
MarkThisAcForkAsSkippedAbort
z=3
else
a="SELECT 1 FROM Certificate WHERE QpkgName = '$qpkg_name' LIMIT 1;"
b=$(eval "$sqlite_cmd" "$CERT_DB_PATHFILE" \"$a\")
if [[ $b = 1 ]];then
a="DELETE FROM Certificate WHERE QpkgName = '$qpkg_name';"
b=$(eval "$sqlite_cmd" "$CERT_DB_PATHFILE" \"$a\")
z=0
fi
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "\"signing\" $(ShowAsPackageName)"
a="INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$qpkg_name','$QPKG_CERTIFICATE','$QPKG_SIGNATURE');"
for ((retries=0;retries<10; retries++)); do
eval "$sqlite_cmd" "$CERT_DB_PATHFILE" "\"$a\""
z=$?
case $z in
5)
sleep 0.5
;;
*)
break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' ok
SendPackageStateChange ISsigned
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' failed "($z) but don't know why. Please report this as a bug"
SendParentChangeEnv 'show_suggest_raise_issue=true'
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:status_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
local b=''
[[ $useropt_debug = true ]] && b+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" status '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit
DebugAsProc "status $(ShowAsPackageName)"
a=$(QpkgGetActiveTest)
if [[ $a = builtin ]];then
if [[ -e $GNU_TIMEOUT_CMD ]];then
$GNU_TIMEOUT_CMD "$QPKG_STATUS_CHECK_TIMEOUT_SECONDS" /bin/bash -c "${b}$(QpkgGetServicePathFile) status"
z=$?
else
RunAndLog "${b}$(QpkgGetServicePathFile) status" "$LOGS_PATH/$qpkg_name.$STATUS_LOG_FILE" log:failure-only
z=$?
fi
elif [[ $a != none ]];then
eval "$a" &> /dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive
;;
1)
SendPackageStateChange ISNTactive
;;
124)
SendPackageStateChange ISslow
;;
*)
SendPackageStateChange ISunknown
esac
SaveActionResultToLog QPKG "$qpkg_name" status '' ok
MarkThisAcForkAsOk
FuncForkExit
}
ClearQpkgAppCenterNotifier()
{
[[ -e /sbin/qpkg_cli ]] && /sbin/qpkg_cli --cancel "$qpkg_name"
QpkgIsNtInstalled && return
/sbin/setcfg "$qpkg_name" Status complete -f /etc/config/qpkg.conf
return 0
} &> /dev/null
QpkgServiceResultWasOk()
{
[[ -n $qpkg_name ]] || return
[[ $(QpkgGetServiceResult) = ok ]]
}
LogQpkgServiceResult()
{
if ! local a=$(QpkgGetServiceResult);then
DebugAsWarn "unable to get status of $(ShowAsPackageName) service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $a in
in-progress)
DebugInfo "$(ShowAsPackageName) service action is in-progress"
;;
ok)
DebugInfo "$(ShowAsPackageName) service action completed OK"
;;
failed)
if [[ -e /var/log/$qpkg_name.log ]];then
DebugAsError "$(ShowAsPackageName) service action failed. Check $(ShowAsFileName "/var/log/$qpkg_name.log") for more information"
AddExtLogToSessLog /var/log/$qpkg_name.log
else
DebugAsError "$(ShowAsPackageName) service action failed"
fi
;;
*)
DebugAsWarn "$(ShowAsPackageName) service status is unrecognised or unsupported"
esac
return 0
}
QpkgGetInstallationPath()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Install_Path -d undefined -f /etc/config/qpkg.conf
}
QpkgGetServicePathFile()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Shell -d undefined -f /etc/config/qpkg.conf
}
QpkgGetApplVer()
{
local a=''
local -i i=0
if [[ $qpkg_index -gt 0 ]];then
a=${QPKG_APPL_VERSION[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_APPL_VERSION[$qpkg_default_index]}
[[ $a = version ]] && a=${QPKG_VERSION[$qpkg_default_index]}
[[ $a != none ]] || return
else
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "$qpkg_name" ]];then
a=${QPKG_APPL_VERSION[$i]}
[[ $a = version ]] && a=${QPKG_VERSION[$qpkg_default_index]}
[[ $a != none ]] || return
break
fi
done
fi
[[ -n $a ]] || return
[[ $a = dynamic ]] && QpkgIsInstalled && ! QpkgIsAutoUpdate && a=static
printf '%s' "$a"
return 0
}
QpkgGetAvailVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "$1" ]];then
printf '%s' "${QPKG_VERSION[$i]}"
return 0
fi
done
elif [[ $qpkg_index -gt 0 ]];then
a=${QPKG_VERSION[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_VERSION[$qpkg_default_index]}
[[ $a != none ]] || return
printf '%s' "$a"
return 0
fi
return 1
}
QpkgGetInstalledVer()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Version -d undefined -f /etc/config/qpkg.conf
}
QpkgGetStoreID()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" store -d undefined -f /etc/config/qpkg.conf
}
QpkgGetInstallDate()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" date -d undefined -f /etc/config/qpkg.conf
}
QpkgGetOriginalPath()
{
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]];then
for i in "${!QPKGs_were_installed_name[@]}";do
[[ ${QPKGs_were_installed_name[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]] || continue
printf '%s' "${QPKGs_were_installed_path[$i]}"
return 0
done
fi
return 1
}
QpkgGetPathFilename()
{
local a=''
a=$(QpkgGetURL)
[[ -n $a ]] || return
[[ $(Lowercase "${a##*.}") != qpkg ]] && a=${a%.*}.qpkg
printf '%s' "$QPKG_DL_PATH/$($BASENAME_CMD "$a")"
return 0
}
QpkgGetHash()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${QPKG_HASH[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_HASH[$qpkg_default_index]}
[[ $a != none ]] || return
printf '%s' "$a"
return 0
}
QpkgGetURL()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "$1" ]] && [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]];then
printf '%s' "${QPKG_URL[$i]}"
return 0
fi
done
return 1
else
a=${QPKG_URL[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_URL[$qpkg_default_index]}
[[ -n $a ]] || a=none
printf '%s' "$a"
fi
return 0
}
QpkgGetMinRAM()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_MIN_RAM_KB[$i]}
break
done
else
a=${QPKG_MIN_RAM_KB[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_MIN_RAM_KB[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetMinOSVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_MIN_OS_VERSION[$i]}
break
done
else
a=${QPKG_MIN_OS_VERSION[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_MIN_OS_VERSION[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetMaxOSVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_MAX_OS_VERSION[$i]}
break
done
else
a=${QPKG_MAX_OS_VERSION[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_MAX_OS_VERSION[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
#QpkgGetAuthorEmail()
#QpkgGetAppAuthor()
#QpkgGetAppAuthorEmail()
QpkgGetDesc()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_DESC[$i]}
break
done
else
a=${QPKG_DESC[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_DESC[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetNote()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_NOTE[$i]}
break
done
else
a=${QPKG_NOTE[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_NOTE[$qpkg_default_index]}
[[ $a = none ]] && return 1
fi
printf '%s' "$a"
return 0
}
QpkgGetAbbrvs()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_ABBRVS[$i]}
break
done
else
a=${QPKG_ABBRVS[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_ABBRVS[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDependencies()
{
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${QPKG_DEPENDS_ON[$qpkg_index]}
[[ $g = none ]] && return 1
[[ $g = default ]] && g=${QPKG_DEPENDS_ON[$qpkg_default_index]}
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=" $x"
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first && -n $alt ]] && first=$alt
if QpkgIsArchOK "$alt";then
out+=" $alt"
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]] && IFS=$oldIFS
if [[ $found = false ]];then
out+=" $first"
first=''
fi
done
printf '%s' "$out"
return 0
}
QpkgGetDependents()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRindependent.Exist "$qpkg_name";then
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_DEPENDS_ON[$i]} =~ $re ]];then
[[ ${ar[*]:-} != "${QPKG_NAME[$i]}" ]] && ar+=(${QPKG_NAME[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1
}
QpkgGetIPKs()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${QPKG_REQUIRES_IPKS[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_REQUIRES_IPKS[$qpkg_default_index]}
[[ $a = none ]] && return 1
printf '%s' "$a"
return 0
}
QpkgGetActiveTest()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
a=${QPKG_TEST_FOR_ACTIVE[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_TEST_FOR_ACTIVE[$qpkg_default_index]}
[[ $a = none ]] && return 1
printf '%s' "$a"
return 0
}
QpkgGetServiceAction()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local b=''
[[ -e /var/log/$a.action ]] && b=$(</var/log/${a}.action)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi
}
QpkgGetServiceResult()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local b=''
[[ -e /var/log/$a.result ]] && b=$(</var/log/${a}.result)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi
}
QpkgMatchAbbrv()
{
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!QPKG_NAME[@]}";do
ar=(${QPKG_ABBRVS[$i]})
for j in "${!ar[@]}";do
[[ ${ar[$j]} = "$1" ]] || continue
printf '%s' "${QPKG_NAME[$i]}"
z=0
break 2
done
done
return $z
}
QpkgSetIndex()
{
[[ -n ${qpkg_name:-} ]] || return
QpkgSetDefaultIndex
for qpkg_index in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$qpkg_index]} = "$qpkg_name" ]] || continue
[[ ${QPKG_ARCH[$qpkg_index]} = all || ${QPKG_ARCH[$qpkg_index]} = "$NAS_QPKG_ARCH" ]] || continue
return 0
done
qpkg_index=0
return 1
}
QpkgSetDefaultIndex()
{
[[ -n ${qpkg_name:-} ]] || return
for qpkg_default_index in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$qpkg_default_index]} = "$qpkg_name" ]] || continue
return 0
done
qpkg_default_index=0
return 1
}
QpkgIsRepoSelfManaged()
{
local a=$(QpkgGetStoreID "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -z $a || $a = undefined || $a = sherpa ]]
}
QpkgIsBackupExist()
{
[[ -e $QPKG_BU_PATH/${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}.config.tar.gz ]]
}
QpkgIsDependent()
{
[[ $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${QPKG_DEPENDS_ON[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_DEPENDS_ON[$qpkg_default_index]}
[[ $a != none ]]
}
QpkgIsIndependent()
{
! QpkgIsDependent
}
QpkgIsUpgradable()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
QpkgIsInstalled "$a" && QpkgIsRepoSelfManaged "$a" && [[ $(QpkgGetInstalledVer "$a") != "$(QpkgGetAvailVer "$a")" ]] && QpkgIsArchOK "$a" && QpkgIsMinOSVerOk "$a" && QpkgIsMaxOSVerOk "$a" && QpkgIsMinRAMOk "$a"
}
QpkgIsInstallable()
{
[[ $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
! QpkgIsInstalled && QpkgIsRepoSelfManaged && QpkgIsArchOK && QpkgIsMinOSVerOk && QpkgIsMaxOSVerOk && QpkgIsMinRAMOk
}
QpkgIsCanBackup()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_CAN_BACKUP[$i]}
break
done
else
a=${QPKG_CAN_BACKUP[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_CAN_BACKUP[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
[[ $a = true ]]
}
QpkgIsCanRestartToUpdate()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" ]] || continue
${QPKG_CAN_RESTART_TO_UPDATE[$i]} && return 0 || break
done
return 1
}
QpkgIsCanClean()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" ]] || continue
${QPKG_CAN_CLEAN[$i]} && return 0 || break
done
return 1
}
QpkgIsSherpaCompatible()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "$1" ]] || continue
a=${QPKG_IS_SHERPA_COMPATIBLE[$i]}
break
done
else
a=${QPKG_IS_SHERPA_COMPATIBLE[$qpkg_index]}
[[ $a = default ]] && a=${QPKG_IS_SHERPA_COMPATIBLE[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
[[ $a = true ]]
}
QpkgIsCanLog()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
[[ ${QPKG_NAME[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" ]] || continue
${QPKG_CAN_LOG[$i]} && return 0 || break
done
return 1
}
QpkgIsInstalled()
{
$GREP_CMD -q "^\[${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}\]" /etc/config/qpkg.conf
}
QpkgIsNtInstalled()
{
! QpkgIsInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
QpkgIsMissing()
{
local a=$(QpkgGetInstallationPath "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ $a != undefined && ! -d $a ]]
}
QpkgIsEnabled()
{
[[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Enable -u -f /etc/config/qpkg.conf) = TRUE ]]
}
QpkgIsArchOK()
{
local a=$(QpkgGetURL "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a && $a != none ]]
}
QpkgIsMinRAMOk()
{
local a=$(QpkgGetMinRAM "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || $NAS_RAM_KB -ge $a ]]
}
QpkgIsMinOSVerOk()
{
local a=$(QpkgGetMinOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -ge $a ]]
}
QpkgIsMaxOSVerOk()
{
local a=$(QpkgGetMaxOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -le $a ]]
}
QpkgIsAutoUpdate()
{
[[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Auto_Update -u -f /etc/config/qpkg.conf) = TRUE ]]
}
LoadQpkgSigning()
{
QPKG_CERTIFICATE=''
QPKG_SIGNATURE=''
read -r -d '' QPKG_CERTIFICATE << EOB
-----BEGIN CERTIFICATE-----
MIIDwzCCAqugAwIBAgIFALhDVuwwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYT
AlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwE
UU5BUDEMMAoGA1UECwwDTkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcN
AQkBFhFzZWN1cml0eUBxbmFwLmNvbTAeFw0yMjAzMTgwNzM5MTRaFw0yNTAzMTcw
NzM5MTRaMIGGMQswCQYDVQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQH
DAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsMA05BUzEWMBQGA1UEAwwN
TGljZW5zZUNlbnRlcjEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20w
ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC/bAgbZryVvBXfpBHNUKQV
sAkAfvDXjKnxa7lKHrRIcFcOnf+voUZcP1Ly9qWb782gB2eUHsUS1Xqj4CF/dUJf
FEnOBrQUo9+Q9B3x4oTRpMdky7acP4dxAbt4T92swgaReQXAewy9s9//a52HIBca
1dAA4JPwplqiZ/oh18GDCKxh84Iu9Gcu2J5e+VXEI/KUxCwKUd22aDTpv128MSoq
dYexCerCJtQbgM3cwkkMiDnFpjrsta5iFpyrNKdLoBJ7YbY3d5Onkqy4DjE8hwR7
0j7Qd+3xbMqv3FOCKeLLLn6N03IXHKP/big/MdXKY1dJQVA3/ks/knPH8mhcOM0d
AgMBAAGjPDA6MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFw
LmNvbS9jcmwvcXRzX3YxLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAWlT1GDH6v8G3
laIAs2/RdxhPgtKX4aL+fnTEFNF5V2yH0G4luyq5tHQw+VCHtDM6Z3GXWhciKPAR
upbRcHq744JCFaUb6i8z1w1KVJDaQ38EVE5+JtpoPMrrnb+hKB/gGmi4PoMSpnvX
VCxLbCbBnwi19o6t/MnPbz0shvUB2NDngnal6lYQFw/F8Sr6cSjV6GAY4TOZotdu
+gunwqQtYUycEVfNyiWVk/flgED8R8oxTPl9ZoDGen+OgjkZrvgynKnqPLHyxZSd
hYSoWyWcZWkMCQ+69kOgJVvrRa7z9F9y30uAHXIUrsLV2d/dImVjApMHbZ60iALG
AVIlas0e4g==
-----END CERTIFICATE-----
EOB
read -r -d '' QPKG_SIGNATURE << EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename=\"smime.p7m\"
Content-Type: application/pkcs7-mime;smime-type=signed-data; name=\"smime.p7m\"
Content-Transfer-Encoding: base64

MIIGtAYJKoZIhvcNAQcCoIIGpTCCBqECAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFAkoseBaFir08zCz63r2YA82DXzxoIIDxzCCA8MwggKroAMCAQIC
BQC4Q1bsMA0GCSqGSIb3DQEBCwUAMIGAMQswCQYDVQQGEwJUVzEPMA0GA1UECAwG
VGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsM
A05BUzEQMA4GA1UEAwwHUU5BUF9DQTEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlA
cW5hcC5jb20wHhcNMjIwMzE4MDczOTE0WhcNMjUwMzE3MDczOTE0WjCBhjELMAkG
A1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYD
VQQKDARRTkFQMQwwCgYDVQQLDANOQVMxFjAUBgNVBAMMDUxpY2Vuc2VDZW50ZXIx
IDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tMIIBIjANBgkqhkiG9w0B
AQEFAAOCAQ8AMIIBCgKCAQEAv2wIG2a8lbwV36QRzVCkFbAJAH7w14yp8Wu5Sh60
SHBXDp3/r6FGXD9S8valm+/NoAdnlB7FEtV6o+Ahf3VCXxRJzga0FKPfkPQd8eKE
0aTHZMu2nD+HcQG7eE/drMIGkXkFwHsMvbPf/2udhyAXGtXQAOCT8KZaomf6IdfB
gwisYfOCLvRnLtieXvlVxCPylMQsClHdtmg06b9dvDEqKnWHsQnqwibUG4DN3MJJ
DIg5xaY67LWuYhacqzSnS6ASe2G2N3eTp5KsuA4xPIcEe9I+0Hft8WzKr9xTgini
yy5+jdNyFxyj/24oPzHVymNXSUFQN/5LP5Jzx/JoXDjNHQIDAQABozwwOjA4BgNV
HR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5hcC5jb20vY3JsL3F0c192
MS5jcmwwDQYJKoZIhvcNAQELBQADggEBAFpU9Rgx+r/Bt5WiALNv0XcYT4LSl+Gi
/n50xBTReVdsh9BuJbsqubR0MPlQh7QzOmdxl1oXIijwEbqW0XB6u+OCQhWlG+ov
M9cNSlSQ2kN/BFROfibaaDzK652/oSgf4BpouD6DEqZ711QsS2wmwZ8ItfaOrfzJ
z289LIb1AdjQ54J2pepWEBcPxfEq+nEo1ehgGOEzmaLXbvoLp8KkLWFMnBFXzcol
lZP35YBA/EfKMUz5fWaAxnp/joI5Ga74Mpyp6jyx8sWUnYWEqFslnGVpDAkPuvZD
oCVb60Wu8/Rfct9LgB1yFK7C1dnf3SJlYwKTB22etIgCxgFSJWrNHuIxggKbMIIC
lwIBATCBijCBgDELMAkGA1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UE
BwwGVGFpcGVpMQ0wCwYDVQQKDARRTkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMM
B1FOQVBfQ0ExIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tAgUAuENW
7DALBglghkgBZQMEAgGggeQwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
hkiG9w0BCQUxDxcNMjIxMjAyMDMwOTE3WjAvBgkqhkiG9w0BCQQxIgQgvtdZSm+m
c7QevdJma9Em5ycFr3I7Wo4aG40Vcx/mT5IweQYJKoZIhvcNAQkPMWwwajALBglg
hkgBZQMEASowCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBAjAKBggqhkiG9w0DBzAO
BggqhkiG9w0DAgICAIAwDQYIKoZIhvcNAwICAUAwBwYFKw4DAgcwDQYIKoZIhvcN
AwICASgwDQYJKoZIhvcNAQEBBQAEggEAuInAOUj+ebOkTqlqg3cf7v2FdKeCvZZn
cunx1xRnHJRVAAvcH/UZ3t7RF6MV5NmEQdVN79NBZl0KU1x7K3zyvcXnkacNuHnI
t+6neKKKkxJmB4hh4ljeYtx9a1RBgwH+PiYyH8+58S7+MF3MVhSH8jEiomgSbvsK
BroOCFQDoYWk14K/VIXW1scmvpNvFNBWwm19pYwi977rF+lPWzMHx/0jVXspFSEd
U48h9xKvPg6CsIlyfuKetHBjZZI6iSCvh2FZOWsD1/W2oGYkkY9Hdff24B34/res
cKXk/K9/JFAONWBbXUpxtzpBCeVJlZS1wQgu4Q+Fr6imaBXJkiyiNg==
EOB
readonly QPKG_CERTIFICATE
readonly QPKG_SIGNATURE
}
MakePath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} && -n ${2:?${FUNCNAME[0]}'()': undefined reason} ]] || return
if [[ $1 != undefined ]] && ! mkdir -p "$1";then
ShowAsError "unable to create $2 path $(ShowAsFileName "$1") $(ShowAsExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0
}
ClearPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined parent path} && -n ${2:?${FUNCNAME[0]}'()': undefined target path} ]] || return
local parent=${1:-undefined}
local target=$($BASENAME_CMD "${2:-undefined}")
[[ -n $parent && $parent != undefined && -n $target && $target != undefined && -d $parent/$target ]] && rm -rf "${parent:?}/${target:?}"/*
}
RunAndLog()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined commandstring} && -n ${2:?${FUNCNAME[0]}'()': undefined pathfile} ]] || return
FuncInit
MakePath "$RUN_LOGS_PATH" 'runtime logs'
local -r LOG_PATHFILE=$($MKTEMP_CMD "$RUN_LOGS_PATH"/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
ShowAsCommand "$1" > "$2"
DebugAsProc "exec: '$1'"
if [[ $useropt_verbose = true ]];then
eval "$1 > >($TEE_CMD $LOG_PATHFILE) 2>&1"
z=$?
else
(eval "$1" > "$LOG_PATHFILE" 2>&1)
z=$?
fi
if [[ -e $LOG_PATHFILE ]];then
ShowAsResultAndStdout "$z" "$(<"$LOG_PATHFILE")" >> "$2"
rm -f "$LOG_PATHFILE" 2> /dev/null
else
ShowAsResultAndStdout "$z" '<null>' >> "$2"
fi
case $z in
0|"${4:-}")
[[ ${3:-} != log:failure-only || $useropt_debug = true ]] && AddExtLogToSessLog "$2"
DebugAsDone 'exec: complete'
[[ $useropt_debug = false ]] && rm -f "$2" 2> /dev/null
;;
*)
AddExtLogToSessLog "$2"
DebugAsError 'exec: complete, but with errors'
esac
FuncExit $z
}
DeDupeWords()
{
[[ -n ${1:-} ]] || return
tr ' ' '\n' <<< "$1" | $SORT_CMD | $UNIQ_CMD | tr '\n' ' ' | $SED_CMD 's|^[[:blank:]]*||;s|[[:blank:]]*$||'
}
FileMatchesMD5()
{
[[ $($MD5SUM_CMD "${1:?${FUNCNAME[0]}'()': undefined pathfile}" | cut -f1 -d' ') = "${2:?${FUNCNAME[0]}'()': undefined checksum}" ]]
}
Pluralise()
{
[[ ${1:-0} -ne 1 ]] && printf s
}
Capitalise()
{
[[ -n ${1:-} ]] || return
if [[ $1 == sherpa* ]];then
printf '%s' "$1"
else
printf '%s' "$(Uppercase ${1:0:1})${1:1}"
fi
}
Uppercase()
{
tr 'a-z' 'A-Z' <<< "${1:-}"
}
Lowercase()
{
tr 'A-Z' 'a-z' <<< "${1:-}"
}
LTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob;printf '%s' "${1##+(' ')}")
}
RTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob;printf '%s' "${1%%+(' ')}")
}
Trim()
{
[[ -n ${1:-} ]] || return
RTrim "$(LTrim "$1")"
}
FormatAsThous()
{
local a=$($SED_CMD 's/[^0-9]*//g' <<< "${1:-}")
local b=''
local c=''
while [[ ${#a} -gt 0 ]];do
b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then
c=$b
else
c=$b,$c
fi
if [[ ${#b} -eq 3 ]];then
a=${a%???}
else
break
fi
done
printf '%s' "$c"
return 0
}
FormatAsIsoBytes()
{
$AWK_CMD 'BEGIN{ u[0]="B";u[1]="kB"; u[2]="MB"; u[3]="GB"} { n = $1; i = 0; while(n > 1000) { i+=1; n= int((n/1000)+0.5) } print n u[i] } ' <<< "$1"
}
ShowTitle()
{
[[ $show_title = true && $title_shown = false && $useropt_verbose = false ]] || return
EraseThisLine
if [[ -z ${ARGS_RAW[*]:-} ]];then
Display "$(ShowTitleArt)"
else
Display "$(ShowAsTitleName) $(ShowAsVersion)"
fi
title_shown=true
}
ShowAsTitleName()
{
TextBrightWhite sherpa
}
ShowTitleArt()
{
Display "$(TextBrightOrange '     _')"
Display "$(TextBrightOrange ' ___| |__   ___ _ __ _ __   __ _')"
Display "$(TextBrightOrange "/ __| '_ \ / _ \ '__| '_ \ / _\` |")  $(ShowAsDescription)"
Display "$(TextBrightOrange '\__ \ | | |  __/ |  | |_) | (_| |')  $(ShowAsCopyrightBasic)"
Display "$(TextBrightOrange '|___/_| |_|\___|_|  | .__/ \__,_|')  $(ShowAsVersion)"
Display "$(TextBrightOrange '                    |_|')"
}
ShowAsDescription()
{
printf '%s' 'a mini-package-manager for QNAP NAS'
}
ShowAsCopyrightBasic()
{
printf '%s' 'copyright (C) 2017-2024 OneCD'
}
ShowAsVersion()
{
printf '%s' "v$THIS_SCRIPT_VER"
}
#ShowAsEmail()
ShowAsAction()
{
TextBrightYellow '[action]'
}
ShowAsPackages()
{
TextBrightOrange '[packages]'
}
ShowAsPackageGroup()
{
TextBrightOrange '[package group]'
}
ShowAsOptions()
{
TextBrightRed '[options]'
}
ShowAsPackageName()
{
printf '%s' "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
ShowAsFileName()
{
printf '%s' "'${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsURL()
{
TextUnderlinedCyan "${1:?${FUNCNAME[0]}'()': undefined URL}"
}
ShowAsExitcode()
{
printf '%s' "[${1:?${FUNCNAME[0]}'()': undefined exitcode}]"
}
ShowAsLogFilename()
{
printf '%s' "${CHARS_RESULTS}log file: '${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsCommand()
{
echo "${CHARS_RESULTS}command: '${1:?${FUNCNAME[0]}'()': undefined commandstring}'"
}
ShowAsResultAndStdout()
{
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] || return
local a=$CHARS_RESULTS
[[ ${1:-0} -ne 0 ]] && a=$CHARS_ALERT
echo "${a}result_code: $(ShowAsExitcode "$1") ***** stdout/stderr begins below *****"
echo "$2"
echo "${a}***** stdout/stderr is complete *****"
}
DisplayProcReport()
{
[[ ${report_title_shown:=false} = false ]] || return
local a=''
[[ -n ${1:-} ]] && a="$1 "
ShowAsProc "${a}report"
report_title_shown=true
}
DebugInfoMajSepr()
{
DebugInfo "$(eval printf '%0.s=' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugInfoMinSepr()
{
DebugInfo "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugExtLogMinSepr()
{
DebugAsLog "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugScript()
{
DebugDetectTabld SCRIPT "${1:-}" "${2:-}"
}
DebugHardware()
{
case ${1:-} in
warning)
DebugWarningTabld HARDWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld HARDWARE "${2:-}" "${3:-}"
esac
}
DebugFirmware()
{
case ${1:-} in
warning)
DebugWarningTabld FIRMWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld FIRMWARE "${2:-}" "${3:-}"
esac
}
DebugUserspace()
{
case ${1:-} in
warning)
DebugWarningTabld USERSPACE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld USERSPACE "${2:-}" "${3:-}"
esac
}
DebugIpk()
{
case ${1:-} in
error)
DebugErrorTabld IPK "${2:-}" "${3:-}"
;;
*)
DebugInfoTabld IPK "${2:-}" "${3:-}"
esac
}
DebugQpkg()
{
case ${1:-} in
error)
DebugErrorTabld QPKG "${2:-}" "${3:-}"
;;
warning)
DebugWarningTabld QPKG "${2:-}" "${3:-}"
;;
info)
DebugInfoTabld QPKG "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld QPKG "${2:-}" "${3:-}"
esac
}
DebugDetectTabld()
{
if [[ -z ${3:-} ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugInfoTabld()
{
if [[ -z ${3:-} ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugWarningTabld()
{
if [[ -z ${3:-} ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugErrorTabld()
{
if [[ -z ${3:-} ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugVar()
{
if [[ -n ${!1:-} ]];then
DebugAsVar "\$$1 : '${!1}'"
else
DebugAsVar "\$$1 : null"
fi
}
DebugArray()
{
[[ -n ${1:-} ]] || return
if [[ -n ${2:-} ]];then
DebugAsArray "\$$1 : ['$2']"
else
DebugAsArray "\$$1 : [null]"
fi
}
DebugInfo()
{
[[ -n ${1:-} ]] || return
if [[ ${2:-} = ' ' || ${2:-} = "'' " ]];then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi
}
FuncInit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn
}
FuncExit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
return ${1:-0}
}
FuncForkInit()
{
trap '[[ -n ${action_pidfile:-} && -e $action_pidfile ]] && rm -f "$action_pidfile" 2> /dev/null;[[ -n ${pidfile:-} && -e ${pidfile:-} ]] && rm -f "$pidfile" 2> /dev/null; exit' SIGINT
original_sess_active_pathfile=$sess_active_pathfile
MakePath "$ACTION_LOGS_PATH" 'action logs'
sess_active_pathfile=$($MKTEMP_CMD "$ACTION_LOGS_PATH"/"${FUNCNAME[1]}"_XXXXXX)
local -r VAR_NAME=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn
}
FuncForkExit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
SendActionStatus ex
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
if [[ -n $sess_active_pathfile && -e $sess_active_pathfile ]];then
if [[ -s $sess_active_pathfile ]];then
$CAT_CMD "$sess_active_pathfile" >> "$original_sess_active_pathfile"
fi
rm -f "$sess_active_pathfile" 2> /dev/null
fi
[[ -n ${action_pidfile:-} && -e $action_pidfile ]] && rm -f "$action_pidfile" 2> /dev/null;[[ -n ${pidfile:-} && -e ${pidfile:-} ]] && rm -f "$pidfile" 2> /dev/null
exit ${1:-0}
}
CalcAmountDiff()
{
if [[ $2 -gt $1 ]];then
printf '%s' "$(($2-$1))"
else
printf '%s' "$(($1-$2))"
fi
} 2> /dev/null
CalcMillisecondsDiffFromNanoseconds()
{
printf '%s' "$((($2-$1)/(10**6)))"
} 2> /dev/null
ConvertSecondsToFullDate()
{
/bin/date -d @"$1" +%c | tr -s ' '
} 2> /dev/null
ConvertSecondsToTime()
{
/bin/date -d @"$1" '+%-l:%M:%S %p' | tr -s ' '
} 2> /dev/null
ConvertSecondsToDuration()
{
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
if [[ $h -gt 0 ]];then
printf '%01dh:%02dm:%02ds' "$h" "$m" "$s"
elif [[ $m -gt 0 ]];then
printf '%01dm:%02ds' "$m" "$s"
else
[[ $s -eq 0 ]] && s=1
if [[ $s -eq 1 ]];then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
fi
} 2> /dev/null
ConvertMillisecondsToSeconds()
{
printf '%s' "$(($1/(10**3)))"
} 2> /dev/null
ConvertMillisecondsToDuration()
{
ConvertSecondsToDuration "$(ConvertMillisecondsToSeconds "$1")"
} 2> /dev/null
ConvertMillisecondsToFuncDuration()
{
if [[ ${1:-0} -lt 30000 ]];then
printf '%s' "$(FormatAsThous "${1:-0}")ms" | $TAIL_CMD -n1
else
ConvertMillisecondsToDuration "$1"
fi
} 2> /dev/null
ConvertNanosecondsToMilliseconds()
{
printf '%s' "$(($1/(10**6)))"
} 2> /dev/null
ConvertNowToFullDate()
{
/bin/date +%c | tr -s ' '
} 2> /dev/null
ConvertNowToSeconds()
{
/bin/date +%s
} 2> /dev/null
ConvertNowToMilliseconds()
{
ConvertNanosecondsToMilliseconds "$(ConvertNowToNanoseconds)"
} 2> /dev/null
ConvertNowToNanoseconds()
{
/bin/date +%s%N
} 2> /dev/null
FormatAsLongMinutesSecs()
{
local m=${1%%:*}
local s=${1#*:}
m=${m##* }
s=${s##* }
printf '%01dm:%02ds\n' "$((10#$m))" "$((10#$s))"
} 2> /dev/null
DebugAsFuncEn()
{
DebugThis "(>>) ${FUNCNAME[2]}()"
}
DebugAsFuncEx()
{
DebugThis "(<<) ${FUNCNAME[2]}|${1:-0}|${2:-}"
}
DebugAsProc()
{
[[ -n $1 ]] && DebugThis "(--) $1"
}
DebugAsDone()
{
[[ -n $1 ]] && DebugThis "(==) $1"
}
DebugAsDetect()
{
[[ -n $1 ]] && DebugThis "(**) $1"
}
DebugAsInfo()
{
[[ -n $1 ]] && DebugThis "(II) $1"
}
DebugAsWarn()
{
[[ -n $1 ]] && DebugThis "(WW) $1"
}
DebugAsError()
{
[[ -n $1 ]] && DebugThis "(EE) $1"
}
DebugAsLog()
{
[[ -n $1 ]] && DebugThis "(LL) $1"
}
DebugAsVar()
{
[[ -n $1 ]] && DebugThis "(vv) $1"
}
DebugAsArray()
{
[[ -n $1 ]] && DebugThis "(aa) $1"
}
DebugThis()
{
[[ -n ${1:-} ]] || return
[[ ${useropt_verbose:-false} = true ]] && ShowAsDebug "$1"
WriteToLog dbug "$1"
}
AddExtLogToSessLog()
{
local a=''
local b=false
if [[ $useropt_verbose = true ]];then
b=true
useropt_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(ShowAsLogFilename "${1:?${FUNCNAME[0]}'()': undefined pathfile}")"
while read -r a;do
DebugAsLog "$a"
done < "$1"
DebugExtLogMinSepr
useropt_verbose=$b
}
ShowAsProcLong()
{
ShowAsProc "${1:-} (might take a while)" "${2:-}"
} >&2
ShowAsProc()
{
local a=''
local b=''
[[ -n ${1:-} ]] && a=$1 || return
[[ -n ${2:-} ]] && b=${2:-}
if [[ ${useropt_verbose:=false} = false && ${useropt_terse:=true} = true ]] || [[ ${useropt_verbose:=false} = false && -n ${2:-} ]];then
OpStepClearWait "$(TextBrightYellow proc)" "$a $CHARS_ELLIPSIS $b"
else
OpStepClear "$(TextBrightYellow proc)" "$a $CHARS_ELLIPSIS $b"
fi
WriteToLog proc "${a}${b}"
} >&2
ShowAsDebug()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBlackOnCyan dbug)" "$1"
}
ShowAsNote()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightYellow note)" "$a"
WriteToLog note "$a"
} >&2
ShowAsDone()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightGreen 'done')" "$a"
WriteToLog 'done' "$a"
} >&2
ShowAsWarn()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightOrange warn)" "$a"
WriteToLog warn "$a"
} >&2
ShowAsAbort()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed bort)" "$a"
WriteToLog bort "$a"
SetError
} >&2
ShowAsFail()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed fail)" "$a"
WriteToLog fail "$a"
} >&2
ShowAsError()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed derp)" "$a"
WriteToLog derp "$a"
SetError
} >&2
ShowAsQuiz()
{
[[ -n ${1:-} ]] || return
OpStepClearWait "$(TextBrightOrangeBlink quiz)" "$1:"
WriteToLog quiz "$1:"
}
ShowAsQuizDone()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBrightOrange quiz)" "$1"
}
AddPeriod()
{
[[ -n ${1:-} ]] || return
[[ ${1: -1} != ':' && ${1: -1} != '?' && ${1: -1} != '.' ]] && printf '%s.' "$1" || printf '%s' "$1"
}
ShowAsPercentProgress()
{
local -r a=${1:-}
local -i b=${3:-0}
local -i c=${4:-0}
local -i d=${5:-0}
local -i e=${6:-0}
local -r f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then
ShowAsProc "$a" "$f"
else
ShowAsProcLong "$a" "$f"
fi
[[ $((b+c+d)) -ge $e ]] && sleep 0.5
return 0
} >&2
PercFrac()
{
local -i a=$((${1:-0}+${2:-0}+${3:-0}))
local -i b=${4:-0}
local c=''
[[ $b -gt 0 ]] || return
if [[ $a -gt $b ]];then
a=$b
c='100%'
else
c="$((200*(a+1)/(b+1)%2+100*(a+1)/(b+1)))%"
fi
printf '%s' "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0
} 2> /dev/null
ShowAsIterativeProgress()
{
local -r a=${1:?${FUNCNAME[0]}'()': undefined action}
local -i b=${2:-0}
local -r c=${3:?${FUNCNAME[0]}'()': undefined suffix1}
local -i d=${4:-0}
local -r e=${5:?${FUNCNAME[0]}'()': undefined suffix2}
local f=''
f="$(TextBrightWhite "$b") ${c}$(Pluralise "$b") ($(TextBrightWhite "$d") ${e}$(Pluralise "$d"))"
if [[ ${6:-short} != long ]];then
ShowAsProc "$a" "$f"
else
ShowAsProcLong "$a" "$f"
fi
return 0
}
ShowAsActionLogDetail()
{
if [[ ${2:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
if [[ ${7:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$7"
return 1
fi
local package_type=''
local quantity_msg=''
package_type=$7$(Pluralise "$8")
case $8 in
0)
quantity_msg='no '
;;
1)
:
;;
*)
quantity_msg="$8 "
esac
if [[ ${8:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$8"
return 1
fi
case ${4:-} in
failed)
if [[ -n "${6:-}" ]];then
case $3 in
download|?(reas)sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
;;
*)
if QpkgIsCanLog "$2";then
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "For more information: /etc/init.d/$($BASENAME_CMD "$(QpkgGetServicePathFile "$2")") log"
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
fi
esac
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" 'no reason was provided by the service-script'
fi
;;
skipped*)
if [[ -n "${6:-}" ]];then
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "$6"
else
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "no reason provided"
fi
;;
*)
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" "$5" "$6"
esac
return 0
}
OpStepClearWait()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
OpStepClear()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
WriteToLog()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
[[ ${useropt_debug:=false} = true && -n ${sess_active_pathfile:-} ]] && printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")" >> "$sess_active_pathfile"
}
TextBrightGreen()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightYellow()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightOrange()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightOrangeBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightRed()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightRedBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
#TextCyan()
TextDarkGrey()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
#TextUnderlined()
TextUnderlinedCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBlackOnCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightWhite()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
Tableise()
{
awk '{
nf[NR]=NF
for (i = 1;i <= NF; i++) {
cell[NR,i] = $i
gsub(/\033\[[0-9;]*[mK]/, "", $i)
len[NR,i] = l = length($i)
if (l > max[i]) max[i] = l
}
}
END {
for (row = 1;row <= NR; row++) {
for (col = 1;col < nf[row]; col++)
printf "%s%*s%s", cell[row,col], max[col]-len[row,col], "", OFS
print cell[row,nf[row]]
}
}' FS='|' OFS="$(printf "%$((COLUMN_SPACING))s")"
}
StripANSICodes()
{
if [[ ${sed_ext_regex_supported:=false} = true ]];then
echo -en "${1:-}" | /bin/sed -r 's/\x1b\[[0-9;]*m//g'
elif [[ -e /opt/bin/sed && -L /opt/etc/passwd ]];then
echo -en "${1:-}" | /opt/bin/sed -r 's/\x1b\[[0-9;]*m//g'
else
echo -en "${1:-}"
fi
} 2> /dev/null
UpdateParentCapabilities()
{
SendParentChangeEnv UpdateColourisation
SendParentChangeEnv UpdateSedRexegSupport
SendParentChangeEnv UpdateSleepDecimalSecondsSupport
}
UpdateCapabilities()
{
UpdateColourisation
UpdateSedRexegSupport
UpdateSleepDecimalSecondsSupport
}
UpdateColourisation()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd && $(LoadSetting Colourful "$colourful_default") = true ]];then
useropt_colourful=true
SendParentChangeEnv 'useropt_colourful=true'
else
useropt_colourful=false
SendParentChangeEnv 'useropt_colourful=false'
fi
}
UpdateSedRexegSupport()
{
OsIsSupportSedExtRegex && sed_ext_regex_supported=true || sed_ext_regex_supported=false
}
UpdateSleepDecimalSecondsSupport()
{
OsIsSupportDecimalSleepSeconds && sleep_decimal_seconds_supported=true || sleep_decimal_seconds_supported=false
}
HideCursor()
{
[[ $useropt_verbose = false ]] && printf '\033[?25l'
}
ShowCursor()
{
printf '\033[?25h'
}
HideKeystrokes()
{
[[ $useropt_verbose = false && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD '-echo'
}
ShowKeystrokes()
{
[[ -n ${GNU_STTY_CMD:-} && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD 'echo'
}
sleep()
{
local n=${1:-}
[[ ${n//.} -eq 0 ]] && n=1
if [[ ${sleep_decimal_seconds_supported:=false} = true ]];then
$SLEEP_CMD "$n"
elif [[ -e $GNU_SLEEP_CMD && -L /opt/etc/passwd ]];then
$GNU_SLEEP_CMD "$n"
else
$SLEEP_CMD "$((${n%.*}+1))"
fi
return 0
} 2> /dev/null
LoadObjects()
{
[[ ${objects_loaded:=false} = false ]] || return 0
FuncInit
LoadLists
if [[ ! -e $PWD/dont-refresh-objects ]];then
if [[ ! -e $OBJECTS_PATHFILE ]] || ! IsThisFileRecent "$OBJECTS_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES";then
ShowAsProc 'download objects'
if $CURL_CMD --silent --fail "$OBJECTS_ARCHIVE_URL" > "$OBJECTS_ARCHIVE_PATHFILE";then
$TAR_CMD --extract --gzip --no-same-owner --file="$OBJECTS_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
fi
fi
if [[ ! -e $OBJECTS_PATHFILE ]];then
ShowAsAbort 'objects missing'
FuncExit 1;exit
fi
ShowAsProc objects
. "$OBJECTS_PATHFILE"
objects_loaded=true
readonly OBJECTS_VER
DebugVar OBJECTS_VER
FuncExit
}
LoadPackages()
{
[[ ${packages_loaded:=false} = false ]] || return 0
FuncInit
local previous=''
LoadObjects
if [[ ! -e $PWD/dont-refresh-packages ]];then
if [[ ! -e $PACKAGES_PATHFILE ]] || ! IsThisFileRecent "$PACKAGES_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES";then
ShowAsProc 'download QPKG list'
if $CURL_CMD --silent --fail "$PACKAGES_ARCHIVE_URL" > "$PACKAGES_ARCHIVE_PATHFILE";then
$TAR_CMD --extract --gzip --no-same-owner --file="$PACKAGES_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
QPKGs.Tiers:Init
fi
fi
if [[ ! -e $PACKAGES_PATHFILE ]];then
ShowAsAbort 'QPKG list missing'
FuncExit 1;exit
fi
ShowAsProc QPKGs
unset QPKG_ABBRVS
unset QPKG_APPL_AUTHOR
unset QPKG_APPL_AUTHOR_EMAIL
unset QPKG_APPL_VERSION
unset QPKG_ARCH
unset QPKG_AUTHOR
unset QPKG_AUTHOR_EMAIL
unset QPKG_CAN_BACKUP
unset QPKG_CAN_CLEAN
unset QPKG_CAN_LOG
unset QPKG_CAN_RESTART_TO_UPDATE
unset QPKG_CONFLICTS_WITH
unset QPKG_DEPENDS_ON
unset QPKG_DESC
unset QPKG_HASH
unset QPKG_MAX_OS_VERSION
unset QPKG_MIN_OS_VERSION
unset QPKG_MIN_RAM_KB
unset QPKG_NAME
unset QPKG_NOTE
unset QPKG_REQUIRES_IPKS
unset QPKG_TEST_FOR_ACTIVE
unset QPKG_URL
unset QPKG_VERSION
PACKAGES_EPOCH=undefined
QPKG_ABBRVS+=('')
QPKG_APPL_AUTHOR+=('')
QPKG_APPL_AUTHOR_EMAIL+=('')
QPKG_APPL_VERSION+=('')
QPKG_ARCH+=('')
QPKG_AUTHOR+=('')
QPKG_AUTHOR_EMAIL+=('')
QPKG_CAN_BACKUP+=('')
QPKG_CAN_CLEAN+=('')
QPKG_CAN_LOG+=('')
QPKG_CAN_RESTART_TO_UPDATE+=('')
QPKG_CONFLICTS_WITH+=('')
QPKG_DEPENDS_ON+=('')
QPKG_DESC+=('')
QPKG_HASH+=('')
QPKG_IS_SHERPA_COMPATIBLE+=('')
QPKG_MAX_OS_VERSION+=('')
QPKG_MIN_OS_VERSION+=('')
QPKG_MIN_RAM_KB+=('')
QPKG_NAME+=('')
QPKG_NOTE+=('')
QPKG_REQUIRES_IPKS+=('')
QPKG_TEST_FOR_ACTIVE+=('')
QPKG_URL+=('')
QPKG_VERSION+=('')
. "$PACKAGES_PATHFILE"
readonly QPKG_ABBRVS
readonly QPKG_APPL_AUTHOR
readonly QPKG_APPL_AUTHOR_EMAIL
readonly QPKG_APPL_VERSION
readonly QPKG_ARCH
readonly QPKG_AUTHOR
readonly QPKG_AUTHOR_EMAIL
readonly QPKG_CAN_BACKUP
readonly QPKG_CAN_CLEAN
readonly QPKG_CAN_LOG
readonly QPKG_CAN_RESTART_TO_UPDATE
readonly QPKG_CONFLICTS_WITH
readonly QPKG_DEPENDS_ON
readonly QPKG_DESC
readonly QPKG_HASH
readonly QPKG_IS_SHERPA_COMPATIBLE
readonly QPKG_MAX_OS_VERSION
readonly QPKG_MIN_OS_VERSION
readonly QPKG_MIN_RAM_KB
readonly QPKG_NAME
readonly QPKG_NOTE
readonly QPKG_REQUIRES_IPKS
readonly QPKG_TEST_FOR_ACTIVE
readonly QPKG_URL
readonly QPKG_VERSION
packages_loaded=true
readonly BASE_QPKG_CONFLICTS_WITH
readonly BASE_QPKG_WARNINGS
readonly ESSENTIAL_IPKS
readonly ESSENTIAL_PIPS
readonly EXCLUSION_PIPS
readonly MIN_PERL_VER
readonly MIN_PYTHON_VER
readonly PACKAGES_EPOCH
DebugVar PACKAGES_EPOCH
for qpkg_name in "${QPKG_NAME[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QPKGs-GRall:Add "$qpkg_name"
done
QPKGs.Tiers:Build
FuncExit
}
CaughtSIGINT()
{
trap - SIGINT
[[ -n ${DISPLAY_INHIBIT_PATHFILE:-} ]] && [[ -d $($DIRNAME_CMD "$DISPLAY_INHIBIT_PATHFILE") ]] && /bin/touch "$DISPLAY_INHIBIT_PATHFILE"
[[ -n ${ACTION_ABORT_PATHFILE:-} ]] && [[ -d $($DIRNAME_CMD "$ACTION_ABORT_PATHFILE") ]] && /bin/touch "$ACTION_ABORT_PATHFILE"
EraseThisLine
ShowAsAbort 'caught SIGINT'
CloseActionMsgPipe
exit
}
CaughtEXIT()
{
trap - EXIT
ShowKeystrokes
ShowCursor
ReleaseLockfile
}
readonly SCRIPT_STARTSECONDS=$(ConvertNowToSeconds)
trap CaughtSIGINT SIGINT
trap CaughtEXIT EXIT
Init || exit
ProcActions
ShowResults
ErrorIsNt
