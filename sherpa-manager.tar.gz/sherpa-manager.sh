#!/bin/bash
#*
#* Please don't edit this file directly, it was built or modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#*
#* sherpa-manager.sh
#*	  Copyright (C) 2017-2026 OneCD.
#*
#* Contact:
#*	  one.cd.only@gmail.com
#*
#* Description:
#*	  This is the management script for the sherpa mini-package-manager. It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#*
#* Project:
#*	  https://git.io/sherpa
#*
#* Support forums:
#*	  https://community.qnap.com/t/qpkg-sherpa-a-mini-package-manager-cli/1081
#*	  https://forum.qnap.com/viewtopic.php?t=132373
#*
#* Tested on:
#*	  GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	  GNU bash, version 3.2.57(1)-release (x86_64-QNAP-linux-gnu)
#*	  GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*		 Copyright (C) 2007 Free Software Foundation, Inc.
#*
#* Notes:
#*	  All sherpa scripts are optimised for compatibility with bash 3.2 (via QTS BusyBox) as this is the native QNAP NAS shell. Be-careful reusing code in other shells, as these scripts contain syntax quirks often compatible only with bash.
#*
#* License:
#*	  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	  You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
#*
set -o nounset
shopt -s extglob
[[ $- != *m* ]]||set +m
[[ -L /dev/fd ]]||ln -fns /proc/self/fd /dev/fd
readonly r_args_raw=$*
Init(){
HideCursor
HideKeystrokes
LoadConsts
LoadDefaults
ShowAsProc init
IsOsOk||return
IsUserOk||return
SetCapabilities
LoadCMDs
IsCMDsOk||return
LoadEnv||return
ClaimLockfile||return
CreatePaths||return
PrepareArgs
ParseManagementArgs||return
ParseHelpArgs||return
ArchivePriorSessLog
DebugLogInit
ParseShowArgs||return
ParseListArgs||return
ParseActionArgs||return
ShowTitle
CheckIfSelfSigned
ShowArgSuggestions
CheckQPKGsConflicts||return
CheckQPKGsWarnings
DebugLogEnv
CheckTasks
CheckEnv
AssignQpkgsToActions
return 0;}
ShowResults(){
FuncInit
if [[ $generate_show_report = true ]];then
if [[ $useropt_show_log_last = true ]];then
ReleaseLockfile
ViewLogLast
elif [[ $useropt_show_log_tail = true ]];then
ReleaseLockfile
ViewLogTail
elif [[ $useropt_show_backups = true ]];then
ReleaseLockfile
ReportBackups
elif [[ $useropt_show_dependencies = true ]];then
ReportDependencies
elif [[ $useropt_show_features = true ]];then
ReportFeatures
elif [[ $useropt_show_packages = true ]];then
ReportPackages
elif [[ $useropt_show_repos = true ]];then
ReportRepos
elif [[ $useropt_show_status = true ]];then
ReportStatuses
show_action_results_report=false
fi
fi
if [[ $generate_list_report = true ]];then
if [[ $useropt_list_versions = true ]];then
ReleaseLockfile
ShowVersionsList
else
ShowQPKGLists
fi
fi
if [[ $useropt_paste_log_last = true ]];then
PasteLogLast
elif [[ $useropt_paste_log_tail = true ]];then
PasteLogTail
fi
if [[ $useropt_help_basic = true ]];then
ShowHelpBasic
ShowHelpBasicExamples
fi
if [[ $generate_help_report = true ]];then
ReleaseLockfile
! IsAnsiStrippingSupported &&colourful=false
if [[ $useropt_help_tips = true ]];then
ShowHelpTips
elif [[ $useropt_help_abbreviations = true ]];then
HelpAbbreviations
elif [[ $useropt_help_actions = true ]];then
ShowHelpActions
elif [[ $useropt_help_actions_all = true ]];then
ShowHelpActionsAll
elif [[ $useropt_help_lists = true ]];then
ShowHelpLists
elif [[ $useropt_help_options = true ]];then
ShowHelpOptions
elif [[ $useropt_help_packages = true ]];then
ShowHelpPackages
elif [[ $useropt_help_show = true ]];then
ShowHelpShow
elif [[ $useropt_help_problems = true ]];then
ShowHelpProblems
elif [[ $useropt_help_upgrades = true ]];then
ShowHelpUpgrades
elif [[ $useropt_help_groups = true ]];then
ShowHelpGroups
fi
fi
if [[ $show_action_results_report = true ]];then
ReportAllActionResults
fi
[[ $show_backuploc = true ]]&&ShowHelpBackupLocation
[[ $show_suggest_raise_issue = true ]]&&ShowHelpIssue
DebugInfoMinSepr
DebugScript info finished "$(ConvertNowToFullDate)"
DebugScript info 'elapsed time' "$(ConvertSecondsToDuration "$(($(ConvertNowToSeconds)-r_script_startseconds))")"
DebugInfoMajSepr
FuncExit
[[ $archive_debug_afterward = true ]]&&ArchiveActiveSessLog
ResetActiveSessLog;}
DebugLogInit(){
DebugInfoMajSepr
DebugScript info started "$(ConvertSecondsToFullDate "$r_script_startseconds")"
DebugScript info PID "$$"
DebugInfoMinSepr
DebugInfo "Markers: $(Parenthesise '**') detected, $(Parenthesise II) information, $(Parenthesise WW) warning, $(Parenthesise EE) error, $(Parenthesise LL) log file, $(Parenthesise '--') processing,"
DebugInfo "$(Parenthesise '==') done, $(Parenthesise '>>') f entry, $(Parenthesise '<<') f exit, $(Parenthesise aa) array name & values, $(Parenthesise vv) variable name & value,"
DebugInfo "$(Parenthesise 'NA') not-applicable, $(Parenthesise '$1') positional argument value"
DebugInfoMinSepr
DebugVar r_this_package_ver
DebugVar r_this_script_ver;}
LoadConsts(){
readonly e_noact='undefined action'
readonly e_nochk='undefined checksum'
readonly e_nocmd='undefined command'
readonly e_noext='undefined exitcode'
readonly e_nofil='undefined filename'
readonly e_nofun='undefined function'
readonly e_nonam='undefined name'
readonly e_noopr='undefined operation'
readonly e_nopfi='undefined pathfile'
readonly e_nopnm='undefined package name'
readonly e_noprm='undefined prompt'
readonly e_nopth='undefined path'
readonly e_nopty='undefined package type'
readonly e_norea='undefined reason'
readonly e_nores='undefined result'
readonly e_nostr='undefined string'
readonly e_notir='undefined tier'
readonly e_nourl='undefined URL'
readonly e_noval='undefined value'
readonly e_novar='undefined variable'
readonly r_qpkg_disable_timeout_seconds=10
readonly r_qpkg_enable_timeout_seconds=10
readonly r_qpkg_restart_timeout_seconds=1800
readonly r_qpkg_start_timeout_seconds=1500
readonly r_qpkg_status_check_timeout_seconds=15
readonly r_qpkg_stop_timeout_seconds=300
readonly r_report_qpkg_abbreviations_column_width=84
readonly r_report_qpkg_action_column_width=27
readonly r_report_qpkg_active_test_builtin_column_width=9
readonly r_report_qpkg_appl_version_column_width=22
readonly r_report_qpkg_auto_update_column_width=11
readonly r_report_qpkg_can_backup_column_width=8
readonly r_report_qpkg_can_clean_column_width=9
readonly r_report_qpkg_can_start_to_update_column_width=9
readonly r_report_qpkg_dependencies_column_width=29
readonly r_report_qpkg_description_column_width=10
readonly r_report_qpkg_install_date_column_width=20
readonly r_report_qpkg_is_complete_column_width=9
readonly r_report_qpkg_is_enabled_column_width=8
readonly r_report_qpkg_is_enhanced_column_width=9
readonly r_report_qpkg_is_installed_column_width=10
readonly r_report_qpkg_is_managed_column_width=8
readonly r_report_qpkg_is_prohibited_column_width=11
readonly r_report_qpkg_is_signed_column_width=8
readonly r_report_qpkg_min_ram_column_width=13
readonly r_report_qpkg_name_column_width=21
readonly r_report_qpkg_opt_dependencies_column_width=29
readonly r_report_qpkg_os_version_column_width=8
readonly r_report_qpkg_path_column_width=48
readonly r_report_qpkg_repo_column_width=42
readonly r_report_qpkg_status_column_width=23
readonly r_report_qpkg_tier_column_width=9
readonly r_report_qpkg_version_column_width=19
readonly r_report_lazy_column_width=28
readonly r_debug_log_string_length=104
IsNumber $r_debug_log_string_length &&r_debug_log_width=$r_debug_log_string_length
readonly r_debug_log_width
readonly r_debug_log_first_column_width=9
readonly r_debug_log_second_column_width=24
readonly r_help_desc_indent=3
readonly r_help_syntax_indent=6
readonly r_report_action_result_indent=4
readonly r_report_column_spacing=2
readonly r_report_file_bytes_column_width=14
readonly r_report_file_change_date_column_width=60
readonly r_report_file_name_column_width=35
readonly r_report_highlight_backups_older_than='2 weeks ago'
readonly r_report_info_name_column_width=14
readonly r_chars_alert='! '
readonly r_chars_attention='* '
readonly r_chars_blank='  '
readonly r_chars_bullet='• '
readonly r_chars_dropend='└─ '
readonly r_chars_normal='- '
readonly r_chars_note='* '
readonly r_chars_regular_prompt='$ '
readonly r_chars_sudo_prompt=$r_chars_regular_prompt'sudo '
readonly r_chars_results='= '
readonly r_chars_super_prompt='# '
readonly r_extended_datetime_format='+%a %-d %b %Y'
readonly r_full_datetime_format=$r_extended_datetime_format' %-I:%M:%S %p %Z'
if IsOsCanSudo;then
if [[ $(GetUserSudoUID) = undefined ]];then
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
else
readonly r_help_syntax_prefix=$r_chars_regular_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_sudo_prompt
fi
else
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
fi
readonly r_char_tab=$'\t'
package_release_version=v260421
readonly r_entware_packages_last_updated=20260407
readonly r_file_change_threshold_minutes=60
readonly r_log_tail_lines=5000;}
LoadDefaults(){
if IsInTerminal;then
readonly r_colourful_default=true
else
readonly r_colourful_default=false
fi
archive_debug_afterward=false
colourful=$r_colourful_default
generate_help_report=false
generate_list_report=false
generate_report_headers=false
generate_show_report=false
get_qpkg_extended_states=false
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
release_lock=true
run_package_actions=false
show_action_results_failed=false
show_action_results_ok=false
show_action_results_report=false
show_action_results_skipped=false
show_action_results_zero=false
show_backuploc=false
show_suggest_raise_issue=false
show_title=true
switch_branch=false
switch_colour=false
switch_report_info=false
switch_terse=false
title_art_shown=false
title_shown=false
action_msg_pipe_fd=none
backup_stdin_fd=none
proc_counts_path=''
user_branch_value=''
user_report_info_value=''
user_terse_value=''
useropt_debug=false
useropt_fix=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_show=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_list_versions=false
useropt_paste_log_last=false
useropt_paste_log_tail=false
useropt_show_about=false
useropt_show_aboutall=false
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_features=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_previous_action_results_report=false
useropt_show_report_info=$(LoadSetting ReportInfo true)
useropt_show_repos=false
useropt_show_status=false
useropt_terse=$(LoadSetting Terse true)
useropt_verbose=false
useropt_branch=$(LoadSetting Git_Branch stable);}
LoadCMDs(){
readonly r_gnu_awk_cmd=/opt/bin/awk
readonly r_gnu_dd_cmd=/opt/bin/dd
readonly r_gnu_find_cmd=/opt/bin/find
readonly r_gnu_grep_cmd=/opt/bin/grep
readonly r_gnu_less_cmd=/opt/bin/less
readonly r_gnu_nice_cmd=/opt/bin/nice
readonly r_gnu_sleep_cmd=/opt/bin/sleep
readonly r_gnu_stty_cmd=/opt/bin/stty
readonly r_gnu_timeout_cmd=/opt/bin/timeout
readonly r_opkg_cmd=/opt/bin/opkg
readonly r_python3_cmd=/opt/bin/python3
readonly r_pip_cmd=$r_python3_cmd' -m pip'
readonly r_python_cmd=/opt/bin/python;}
IsCMDsOk(){
IsCriticalFile /bin/awk||return
IsCriticalFile /usr/bin/basename||return
IsCriticalFile /bin/cat||return
IsCriticalFile /sbin/curl||return
IsCriticalFile /bin/df||return
IsCriticalFile /usr/bin/dirname||return
IsCriticalFile /usr/bin/du||return
IsCriticalFile /bin/grep||return
[[ ! -x /bin/less ]]&&ln -sf /bin/busybox /bin/less
IsCriticalFile /bin/md5sum||return
IsCriticalFile /bin/mknod||return
IsCriticalFile /bin/mktemp||return
IsCriticalFile /bin/ps||return
IsCriticalFile /usr/local/bin/python2||return
IsCriticalFile /usr/bin/readlink||return
IsCriticalFile /usr/sbin/screen||return
IsCriticalFile /bin/sh||return
IsCriticalFile /bin/sha1sum||return
[[ ! -x /usr/bin/sort ]]&&ln -sf /bin/busybox /usr/bin/sort
IsCriticalFile /usr/bin/stat||return
IsCriticalFile /usr/bin/tail||return
IsCriticalFile /bin/tar||return
IsCriticalFile /usr/bin/tee||return
IsCriticalFile /bin/uname||return
IsCriticalFile /bin/uniq||return
IsCriticalFile /usr/bin/unzip||return
IsCriticalFile /usr/bin/uptime||return
return 0;}
LoadEnv(){
qpkg_name=sherpa
SetHardwareCPUCores
SetHardwareInstalledRAM
SetQpkgArch
args=()
args_incomplete=()
qpkg_index=0
readonly r_cert_db_pathfile=/etc/config/nas_sign_qpkg.db
readonly r_concurrency=$r_cpu_cores
readonly r_entware_type=$(GetQpkgEntwareType)
readonly r_script_built_epoch=1776732926
local -r r_sherpa_packages_base_url=https://github.com/OneCDOnly/sherpa.packages
readonly r_this_package_ver=$(GetQpkgInstalledVer)
local script_epoch=0
IsNumber $r_script_built_epoch &&script_epoch=$r_script_built_epoch
useropt_branch=$(GetUserGitBranch)
readonly r_objects_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
readonly r_this_script_ver=$(ConvertSecondsToDatecode $script_epoch)-$useropt_branch
[[ $useropt_branch = unstable ]]&&package_release_version=testing
readonly r_packages_archive_url=$r_sherpa_packages_base_url/releases/download/$package_release_version/$r_nas_qpkg_arch.packages.tar.gz
readonly r_sys_log_path=/var/log
readonly r_qpkg_service_result_path=$r_sys_log_path
readonly r_sys_run_path=/var/run
readonly r_qpkg_bu_path=$(GetUserDefVol)/.qpkg_config_backup
readonly r_this_package_path=$(GetQpkgInstalledPath)
if [[ -z $r_this_package_path ||$r_this_package_path = undefined ||! -d $r_this_package_path ]];then
ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1
fi
readonly r_cache_path=$r_this_package_path/cache
readonly r_ipk_cache_path=$r_cache_path/IPKs
readonly r_ipk_downgrade_path=$r_ipk_cache_path/downgrade
readonly r_ipk_download_path=$r_ipk_cache_path/downloads
readonly r_pip_cache_path=$r_cache_path/PIPs
readonly r_qpkg_cache_path=$r_cache_path/QPKGs
readonly r_qpkg_download_path=$r_qpkg_cache_path/downloads
readonly r_log_path=$r_this_package_path/log
readonly r_dependent_qpkgs_list_pathfile=$r_cache_path/dependents
readonly r_independent_qpkgs_list_pathfile=$r_cache_path/independents
readonly r_inhibit_display_pathfile=$r_cache_path/display.inhibit
readonly r_objects_archive_pathfile=$r_cache_path/objects.tar.gz
readonly r_objects_pathfile=$r_cache_path/objects
readonly r_optional_qpkgs_list_pathfile=$r_cache_path/optionals
readonly r_packages_archive_pathfile=$r_cache_path/$r_nas_qpkg_arch.packages.tar.gz
readonly r_packages_pathfile=$r_cache_path/$r_nas_qpkg_arch.packages
readonly r_prev_ipk_list_pathfile=$r_ipk_cache_path/ipk-list.save
readonly r_prev_pip_list_pathfile=$r_pip_cache_path/pip-list.save
readonly r_session_archive_log_pathfile=$r_log_path/session.archive.log
readonly r_temp_run_path=$r_sys_run_path/sherpa.d
readonly r_action_counts_path=$r_temp_run_path/action/count
readonly r_async_procs_path=$r_temp_run_path/proc
readonly r_qpkg_states_path=$r_temp_run_path/qpkg/state
readonly r_run_logs_path=$r_temp_run_path/log
readonly r_temp_report_path=$r_temp_run_path/report
readonly r_report_flags_path=$r_temp_report_path/flag
readonly r_report_rows_path=$r_temp_report_path/row
readonly r_temp_log_path=$r_sys_log_path/sherpa.d
readonly r_action_log_path=$r_temp_log_path/action/log
readonly r_action_times_path=$r_action_log_path/times
readonly r_report_path=$r_temp_log_path/report
readonly r_abort_actions_pathfile=$r_temp_run_path/abort.action
readonly r_action_msg_pipe=$r_temp_run_path/action-messages.pipe
readonly r_action_results_pathfile=$r_action_log_path/action-results.log
readonly r_oom_log_pathfile=$r_temp_log_path/oom.log
readonly r_ram_freeused_pathfile=$r_temp_log_path/ram.freeused
readonly r_ramfs_freespace_pathfile=$r_temp_log_path/ramfs.freespace
readonly r_report_output_pathfile=$r_temp_log_path/report.ansi
readonly r_screen_sessions_pathfile=$r_temp_log_path/screen.sessions
readonly r_session_last_pathfile=$r_temp_log_path/session-last.log
readonly r_session_tail_pathfile=$r_temp_log_path/session-tail.log
session_active_log_pathfile=$r_temp_log_path/session.$$.active.log
readonly r_external_apps_path=/opt
readonly r_external_apps_temp_path=$r_external_apps_path.temp
readonly r_external_packages_archive_pathfile=$r_external_apps_path/var/opkg-lists/entware
readonly r_external_packages_pathfile=$r_cache_path/Packages
[[ -x $r_python3_cmd &&! -L $r_python_cmd ]]&&ln -s "$r_python3_cmd" "$r_python_cmd"
rm -f "$r_report_output_pathfile" "$r_ramfs_freespace_pathfile" "$r_inhibit_display_pathfile" 2>/dev/null
if [[ -x $r_gnu_stty_cmd ]]&&IsInTerminal;then
local terminal_dimensions=$($r_gnu_stty_cmd size)
readonly r_sess_rows=${terminal_dimensions% *}
readonly r_sess_columns=${terminal_dimensions#* }
else
readonly r_sess_rows=40
readonly r_sess_columns=156
fi;}
LoadLists(){
[[ ${lists_loaded:=false} = false ]]||return 0
unset r_package_tiers
unset r_qpkg_tiers
unset r_qpkg_basic_states
unset r_qpkg_extended_states
unset r_qpkg_is_groups
unset r_qpkg_is_states
unset r_qpkg_isnt_groups
unset r_qpkg_isnt_states
unset r_qpkg_service_results
unset r_qpkg_transient_states
unset r_qpkg_actions
unset r_ipk_actions
unset r_pip_actions
unset r_user_qpkg_actions
r_package_tiers=(independent auxiliary optional dependent)
r_qpkg_tiers=(independent optional dependent)
r_qpkg_basic_states=(complete enabled installed)
r_qpkg_extended_states=(active backedup downloaded installable missing signed upgradable)
r_qpkg_transient_states=(restarting slow starting stopping unknown)
r_qpkg_is_states=(${r_qpkg_basic_states[*]} ${r_qpkg_extended_states[*]} ${r_qpkg_transient_states[*]})
r_qpkg_isnt_states=(${r_qpkg_basic_states[*]} ${r_qpkg_extended_states[*]} ${r_qpkg_transient_states[*]})
r_qpkg_is_groups=(all canbackup canclean canrestarttoupdate dependent hasdependents independent optional)
r_qpkg_isnt_groups=(canclean)
r_qpkg_service_results=(failed ok)
r_qpkg_actions=(status list rebuild reassign download backup resign unsign deactivate disable uninstall upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
r_ipk_actions=(downgrade download uninstall upgrade install)
r_pip_actions=(uninstall upgrade install)
r_user_qpkg_actions=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall resign restore status uninstall upgrade)
readonly r_package_tiers
readonly r_qpkg_tiers
readonly r_qpkg_basic_states
readonly r_qpkg_extended_states
readonly r_qpkg_is_groups
readonly r_qpkg_is_states
readonly r_qpkg_isnt_groups
readonly r_qpkg_isnt_states
readonly r_qpkg_service_results
readonly r_qpkg_transient_states
readonly r_qpkg_actions
readonly r_ipk_actions
readonly r_pip_actions
readonly r_user_qpkg_actions
local action=''
for action in "${r_qpkg_actions[@]}" debug downgrade fix update;do
readonly r_"$(Lowercase "$action")"_log_file=$action.log
done
lists_loaded=true;}
CreatePaths(){
ClearPath "$r_temp_run_path" "$r_async_procs_path"
MakePath "$r_temp_log_path" 'temporary logs'||return
MakePath "$r_temp_run_path" 'temporary runtime files'||return
MakePath "$r_action_counts_path" 'action counts'||return
MakePath "$r_action_log_path" 'action logs'||return
MakePath "$r_action_times_path" 'action times'||return
MakePath "$r_async_procs_path" 'asynchronous process tracking'||return
MakePath "$r_log_path" 'persistent logs'||return
MakePath "$r_qpkg_bu_path" 'QPKG backup'||return
MakePath "$r_qpkg_states_path" states||return
MakePath "$r_run_logs_path" 'run logs'||return
MakePath "$r_cache_path" cache||return
CreatePackagePaths;}
CreatePackagePaths(){
ClearPath "$r_cache_path" "$r_ipk_cache_path"
ClearPath "$r_cache_path" "$r_ipk_download_path"
ClearPath "$r_cache_path" "$r_pip_cache_path"
MakePath "$r_ipk_cache_path" 'IPK cache'||return
MakePath "$r_ipk_downgrade_path" 'IPK downgrade'||return
MakePath "$r_ipk_download_path" 'IPK download'||return
MakePath "$r_pip_cache_path" 'PIP cache'||return
MakePath "$r_qpkg_cache_path" 'QPKG cache'||return
MakePath "$r_qpkg_download_path" 'QPKG download'||return;}
CreateReportPaths(){
ClearPath "$r_temp_report_path" "$r_report_flags_path"
ClearPath "$r_temp_report_path" "$r_report_rows_path"
MakePath "$r_temp_report_path" 'temporary reports'||return
MakePath "$r_report_flags_path" 'report flags'||return
MakePath "$r_report_rows_path" 'report rows'||return;}
ClearCachePath(){
if [[ -n $r_cache_path &&-d $r_cache_path ]];then
ClearPath "$r_this_package_path" "$r_cache_path"
ShowAsDone 'persistent cache cleared'
fi
return 0;}
#ClearTempReportPath()
ClearTempRunPath(){
if [[ -n $r_temp_run_path &&-d $r_temp_run_path ]];then
ClearPath "$r_sys_run_path" "$r_temp_run_path"
ShowAsDone 'temp runtime cleared'
fi
return 0;}
ClearTempLogPath(){
if [[ -n $r_temp_log_path &&-d $r_temp_log_path ]];then
ClearPath "$r_sys_log_path"/sherpa "$r_temp_log_path"
ShowAsDone 'temp logs cleared'
fi
return 0;}
DebugLogEnv(){
if [[ $useropt_show_about = false &&$useropt_show_aboutall = false ]];then
[[ $run_package_actions = true ]]||return 0
[[ $useropt_debug = true ]]||return 0
fi
FuncInit
ShowAsProc 'log env'
if [[ $useropt_show_about = true ||$useropt_show_aboutall = true ]];then
useropt_debug=true
useropt_verbose=true
fi
SetNasArch
SetHardwarePlatform
DebugInfoMinSepr
DebugHardware ok 'NAS model' "$(get_display_name)"
DebugHardware ok CPU "$(GetHardwareCPUInfo)"
DebugHardware ok 'CPU cores' "$r_cpu_cores"
DebugHardware ok 'CPU architecture' "$(GetCpuDataWidth)"
DebugHardware ok 'basic CPU SHA1 benchmark' "$(GetHardwareCPUBenchmark)"
DebugHardware ok RAM "${r_nas_ram_gb}GiB"
DebugKernel ok name "$(GetOsKernelName)"
DebugKernel ok version "$(GetOsKernelVersion)"
if IsOsStdKernelPageSize;then
DebugKernel ok 'page size' "$r_kernel_page_size"
else
DebugKernel warning 'page size' "$r_kernel_page_size"
fi
DebugFirmware ok OS "$(GetOsName)"
SetOsFirmwareVersion
SetOsFirmwareBuild
if IsOsSupported;then
DebugFirmware ok version "$r_nas_firmware_version.$r_nas_firmware_build"
else
DebugFirmware warning version "$r_nas_firmware_version"
fi
SetOsFirmwareDate
if IsOsCompatibleWithSigned;then
DebugFirmware ok 'build date' "$(ConvertAsSmartDate "$r_nas_firmware_date")"
else
DebugFirmware warning 'build date' "$(ConvertAsSmartDate "$r_nas_firmware_date")"
fi
DebugFirmware ok platform "$r_nas_platform"
if IsOsOnline;then
DebugOS ok state online
else
DebugOS warning state "$(GetOsState)"
fi
DebugOS ok uptime "$(GetOsUptime)"
if IsOsLoadAverageElevated;then
DebugOS warning 'load averages' "$(GetOsSysLoadAverages)"
else
DebugOS ok 'load averages' "$(GetOsSysLoadAverages)"
fi
DebugStorage ok 'default volume mounted' "$(GetUserDefVol)"
DebugStorage ok 'basic write benchmark' "$(GetHardwareVolumeBenchmark)"
if [[ -L /opt ]];then
DebugStorage ok /opt "$(/usr/bin/readlink /opt 2>/dev/null)"
elif [[ -d /opt ]];then
DebugStorage ok /opt 'is a directory, not a symlink'
else
DebugStorage ok /opt 'not present'
fi
DebugUserspace ok libc "$(GetUserLIBC)"
DebugUserspace ok 'libc copyright' "$(GetUserLIBCCopyright)"
DebugUserspace ok '$EUID' "$EUID"
if IsOsCanSudo;then
if [[ $EUID = 0 ]];then
DebugUserspace ok '$SUDO_UID' N/A
else
DebugUserspace ok '$SUDO_UID' "$(GetUserSudoUID)"
fi
else
DebugUserspace ok '$SUDO_UID' N/A
fi
DebugUserspace ok 'BusyBox version' "$(GetBusyBoxVersion)"
DebugUserspace ok 'BusyBox copyright' "$(GetBusyBoxCopyright)"
DebugUserspace ok 'BusyBox function count' "$(GetBusyBoxFunctionCount)"
DebugScript ok 'QPKG version' "$(ConvertAsSmartDate "$r_this_package_ver")"
DebugScript ok 'manager version' "$r_this_script_ver"
DebugScript ok 'manager epoch' "$(ConvertAsSmartDate "$r_script_built_epoch")"
DebugScript ok 'objects epoch' "$(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
DebugScript ok 'packages epoch' "$(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
if ! [[ $package_release_version = testing ]];then
DebugQpkg ok 'package release' "$(ConvertAsSmartDate "$package_release_version")"
else
DebugQpkg warning 'package release' "$package_release_version"
fi
if IsOsCanUnofficialPackages;then
if IsOsAllowUnofficialPackages;then
DebugQpkg detect 'allow unofficial' yes
else
DebugQpkg warning 'allow unofficial' no
fi
else
DebugQpkg detect 'allow unofficial' N/A
fi
if IsOsCanManageSignedPackages;then
if IsOsRequireSignedPackages;then
DebugQpkg detect 'require signed' yes
else
DebugQpkg detect 'require signed' no
fi
else
DebugQpkg detect 'require signed' N/A
fi
SetQpkgArch
DebugQpkg detect architecture "$r_nas_qpkg_arch ($(DecodeQpkgArch $r_nas_qpkg_arch))"
if IsQpkgInstalled Entware;then
if ! IsEntwareUpgradable;then
DebugQpkg detect "date $(FormatPackageName Entware) installed" "$(ConvertAsSmartDate "$(GetQpkgInstalledDate Entware)")"
else
DebugQpkg warning "date $(FormatPackageName Entware) installed" "$(ConvertAsSmartDate "$(GetQpkgInstalledDate Entware)")"
fi
if [[ $r_entware_type = std ]];then
DebugQpkg detect "$(FormatPackageName Entware) type" "$r_entware_type"
else
DebugQpkg warning "$(FormatPackageName Entware) type" "$r_entware_type"
fi
else
DebugQpkg detect "date $(FormatPackageName Entware) installed" N/A
fi
SetOsFirmwareVer
if IsQpkgInstalled SortMyQPKGs;then
DebugQpkg detect "$(FormatPackageName SortMyQPKGs)" installed
else
if [[ $r_nas_firmware_ver -lt 400 ||$r_nas_firmware_ver -ge 520 ]];then
DebugQpkg detect "$(FormatPackageName SortMyQPKGs)" N/A
else
DebugQpkg warning "$(FormatPackageName SortMyQPKGs)" 'not installed'
fi
fi
if IsOsCanQpkgTimeout;then
if IsQpkgInstalled IncreaseTimeouts;then
if IsQpkgTimeoutsIncreased;then
DebugQpkg detect "$(FormatPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(FormatPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg detect "$(FormatPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(FormatPackageName IncreaseTimeouts)" N/A
fi
DebugInfoMinSepr
if [[ $useropt_show_about = true ]];then
useropt_debug=false
useropt_verbose=false
return
fi
Executer "/bin/df -h|/bin/grep -iEv '^(devtmpfs|cgroup_root)'" "$r_ramfs_freespace_pathfile"
DebugInfoMinSepr
Executer "/usr/sbin/screen -ls|/bin/sed '/^[[:space:]]*$/d;s/^[[:space:]]*//'" "$r_screen_sessions_pathfile" '' 1
DebugInfoMinSepr
Executer '/usr/bin/free' "$r_ram_freeused_pathfile" '' 1
DebugInfoMinSepr
Executer "/bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg" "$r_oom_log_pathfile" '' 1
DebugInfoMinSepr
if [[ $useropt_show_aboutall = true ]];then
useropt_debug=false
useropt_verbose=false
return
fi
FuncExit;}
CheckIfSelfSigned(){
if IsOsCanManageSignedPackages&&IsOsRequireSignedPackages&&IsNtQpkgSigned sherpa;then
[[ $title_art_shown = true ]]&&Display
ShowAsWarn "$(ShowAsTitleName) is unsigned, and $(GetOsName) is presently configured to require all packages to be signed."
ShowAsWarn "Please either self-sign $(ShowAsTitleName) with 'sherpa resign self', or allow unsigned QPKGs in your $(GetOsName) App Center"
fi;}
CheckTasks(){
if [[ $arg_problem = true ||$useropt_help_basic = true ]];then
show_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_extended_states=false
run_package_actions=false
fi
[[ $get_qpkg_extended_states = true ]]||return 0
FuncInit
local action=''
local build_extended_states=false
local group=''
local state=''
if [[ $useropt_fix = true ||$useropt_show_status = true ]];then
build_extended_states=true
elif [[ $useropt_help_abbreviations = true ||$useropt_show_backups = true ||$useropt_show_dependencies = true ||$useropt_show_features = true ||$useropt_show_packages = true ||$useropt_show_repos = true ]];then
build_extended_states=true
elif [[ $useropt_help_actions = true ||$useropt_help_actions_all = true ||$useropt_help_basic = true ||$useropt_help_groups = true ||$useropt_help_lists = true ||$useropt_help_options = true ||$useropt_help_packages = true ||$useropt_help_problems = true ||$useropt_help_show = true ||$useropt_help_tips = true ||$useropt_help_upgrades = true ||$useropt_list_versions = true ||$useropt_paste_log_last = true ||$useropt_paste_log_tail = true ||$useropt_show_about = true ||$useropt_show_about = true ||$useropt_show_previous_action_results_report = true ||$useropt_show_log_last = true ||$useropt_show_log_tail = true ||$switch_branch = true ||$switch_colour = true ||$switch_report_info = true ||$switch_terse = true ]];then
:
else
LoadDatabase
for action in "${r_user_qpkg_actions[@]}";do
if QPKGs-AC${action}-to.IsAny;then
build_extended_states=true
break
fi
for group in "${r_qpkg_is_groups[@]}";do
if QPKGs.AC${action}GR${group}.IsSet;then
build_extended_states=true
break 2
fi
done
for group in "${r_qpkg_isnt_groups[@]}";do
if QPKGs.AC${action}GRNT${group}.IsSet;then
build_extended_states=true
break 2
fi
done
for state in "${r_qpkg_extended_states[@]}";do
case $state in
downloaded)
continue;;
*)if QPKGs.AC${action}IS${state}.IsSet;then
build_extended_states=true
break 2
fi
esac
done
for state in "${r_qpkg_extended_states[@]}";do
case $state in
downloaded)
continue;;
*)if QPKGs.AC${action}ISNT${state}.IsSet;then
build_extended_states=true
break 2
fi
esac
done
done
fi
[[ $build_extended_states = true ]]&&BuildExtendedQPKGsStates
FuncExit;}
CheckEnv(){
[[ $run_package_actions = true ]]||return 0
FuncInit
ShowAsProc 'check env'
local installed_version=''
local target_packages=''
if [[ $(/bin/grep -iE 'out of memory|oom-killer' /mnt/HDA_ROOT/.logs/kmsg|/usr/bin/wc -l) -gt 0 ]];then
ShowAsWarn "the $(TextBrightRed 'Out-Of-Memory killer') has been triggered, check for $(TextBrightRed inactive) QPKGs"
fi
SetNasArch
if IsValidQpkgInstalled Entware;then
if [[ $r_entware_type != none ]];then
_UpdateEntwarePackageList_ &
else
DebugAsWarn "$(FormatPackageName Entware) appears to be installed but is inactive. Please consider starting the $(FormatPackageName Entware) QPKG."
fi
if [[ $useropt_fix = true ]]||QPKGs-ACupgrade-to.Exist Entware;then
ipks_install=true
ipks_upgrade=true
pips_install=true
fi
SetQpkgArch
case $r_nas_qpkg_arch in
a41)
if IsOsNonStdKernelPageSize;then
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($r_opkg_cmd list-installed|/bin/grep "^${target_packages%% *} *"|head -n1|cut -d' ' -f3|cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]];then
ipks_downgrade=true
ShowAsNote "various IPKs will be downgraded to suit $r_kernel_page_size kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
fi
esac
fi
BuildQPKGsIsCanBackup
BuildQPKGsIsCanRestartToUpdate
BuildQPKGsIsCanClean
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-ISupgradable.Exist sherpa;then
ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded"
QPKGs-ACupgrade-to:Add sherpa
fi
wait 2>/dev/null
FuncExit;}
AssignQpkgsToActions(){
[[ $run_package_actions = true ]]||return 0
FuncInit
ShowAsProc 'auto-assign actions'
local action=''
local prospect=''
if IsOsOnline&&IsValidQpkgInstalled Entware&&IsEntwareUpgradable &&(IsNonStatusActionRequested ||[[ $useropt_fix = true ]]);then
ShowAsNote "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were last updated in $(ConvertLongDateAsHuman $r_entware_packages_last_updated))"
QPKGs-ACreinstall-to:Add Entware
fi
if QPKGs-ACrebuild-to.IsAny;then
for qpkg_name in $(QPKGs-ACrebuild-to:Array);do
SetQpkgIndex
if IsNtValidQpkgInstalled "$qpkg_name" &&(IsQpkgBackupExist ||(QPKGs-ACbackup-to.Exist "O$qpkg_name" &&QPKGs-ACuninstall-to.Exist "O$qpkg_name"));then
QPKGs-ACinstall-to:Add "$qpkg_name"
QPKGs-ACrestore-to:Add "$qpkg_name"
fi
done
fi
for qpkg_name in $(QPKGs-ACinstall-to:Array) $(QPKGs-ACreinstall-to:Array);do
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do
[[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect" &&QPKGs-ACinstall-to:Add "$prospect"
done
done
for qpkg_name in $(GetQpkgsIsValidInstalled);do
if [[ $useropt_fix = true ]]||QPKGs-ACactivate-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies);do
[[ $prospect != none ]]||continue
IsNtValidQpkgInstalled "$prospect" &&QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for action in activate deactivate disable enable install reinstall reactivate uninstall upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do
if IsQpkgEnabled "$prospect";then
! QPKGs-ACuninstall-to.Exist "$prospect" &&! QPKGs-ACinstall-to.Exist "$prospect" &&QPKGs-ACreactivate-to:Add "$prospect"
fi
done
fi
done
done
for action in deactivate uninstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
IsValidQpkgInstalled "$prospect" &&QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
done
if QPKGs-ACreinstall-to.Exist Entware;then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name" &&QPKGs-ACinstall-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" &&! QPKGs-ACinstall-to.Exist "$prospect" &&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in reinstall reactivate upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbDependents);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" &&! QPKGs-ACinstall-to.Exist "$prospect" &&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
done
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRoptional.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name" &&QPKGs-ACinstall-to.Exist "$qpkg_name";then
SetQpkgIndex
for prospect in $(GetQpkgDbOptionals);do
if IsQpkgEnabled "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" &&! QPKGs-ACinstall-to.Exist "$prospect" &&QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in backup restore upgrade reinstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if IsQpkgEnabled "$qpkg_name";then
QPKGs-ACdeactivate-to:Add "$qpkg_name"
! QPKGs-ACuninstall-to.Exist "$qpkg_name" &&! QPKGs-ACinstall-to.Exist "$qpkg_name" &&QPKGs-ACactivate-to:Add "$qpkg_name"
fi
done
done
for action in reinstall install activate reactivate;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
SetQpkgIndex
for prospect in $(GetQpkgDbDependencies) $(GetQpkgDbOptionals);do
IsValidQpkgInstalled "$prospect"&&IsQpkgEnabled "$prospect" &&QPKGs-ACreactivate-to:Add "$prospect"
done
done
done
if QPKGs.ACuninstallGRall.IsSet;then
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if IsValidQpkgInstalled "$qpkg_name" &&QPKGs-ACinstall-to.Exist "$qpkg_name";then
QPKGs_were_installed_name+=("$qpkg_name")
SetQpkgIndex
QPKGs_were_installed_path+=("$(/usr/bin/dirname "$(GetQpkgInstalledPath)")")
fi
QPKGs-ACdeactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdownload-to:Add "$(QPKGs-ACinstall-to:Array)"
for qpkg_name in $(QPKGs-ACreinstall-to:Array);do
IsValidQpkgInstalled "$qpkg_name" &&QPKGs-ACdownload-to:Add "$qpkg_name"
done
for qpkg_name in $(QPKGs-ACupgrade-to:Array);do
QPKGs-ISupgradable.Exist "$qpkg_name" &&QPKGs-ACdownload-to:Add "$qpkg_name"
done
if IsOsCanManageSignedPackages &&QPKGs-ACinstall-to.IsAny;then
QPKGs-ACsign-to:Add "$(QPKGs-ACinstall-to:Array)"
fi
if QPKGs-ACresign-to.IsAny;then
for qpkg_name in $(QPKGs-ACresign-to:Array);do
SetQpkgIndex
QPKGs-ACunsign-to:Add "$qpkg_name"
QPKGs-ACsign-to:Add "$qpkg_name"
done
fi
if [[ $useropt_fix = true ]];then
IsOsCanManageSignedPackages &&QPKGs-ACsign-to:Add "$(GetQpkgsIsValidInstalled)"
for qpkg_name in $(QPKGs-GRdependent:Array);do
IsQpkgEnabled "$qpkg_name" &&QPKGs-ACreactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdeactivate-to:Remove sherpa
QPKGs-ACuninstall-to:Remove sherpa
if QPKGs-ACsign-to.IsAny ||QPKGs-ACinstall-to.IsAny;then
LoadQpkgSigningCert
fi
FuncExit;}
ProcActions(){
[[ $run_package_actions = true ]]||return
FuncInit
ShowAsProc 'package actions'
local action=''
local state=''
local tier=''
local -i tier_index=0
rm -f "$r_action_results_pathfile" 2>/dev/null
ProcAction status all QPKG 'live status'
if [[ $useropt_show_status = false ]];then
ShowAsProc 'assign QPKGs by state'
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
case $state in
downloaded|installed)
continue;;
*)QPKGs.AC${action}IS${state}.IsSet &&QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
esac
done
for state in "${r_qpkg_isnt_states[@]}";do
case $state in
enabled|downloaded)
continue;;
*)QPKGs.AC${action}ISNT${state}.IsSet &&QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
esac
done
done
fi
ProcAction rebuild all QPKG meta-rebuild
ProcAction reassign all QPKG reassign
ProcAction download all QPKG download
if QPKGs-ACdownload-er.IsNone &&QPKGs-ACdownload-se.IsNone &&QPKGs-ACdownload-sa.IsNone;then
for((tier_index=${#r_package_tiers[@]}-1;tier_index>=0;tier_index--));do
tier=${r_package_tiers[$tier_index]}
if [[ $tier != auxiliary ]];then
ProcAction deactivate $tier QPKG deactivate
ProcAction disableau $tier QPKG 'disable auto-update'
ProcAction backup $tier QPKG backup
ProcAction disable $tier QPKG disable
ProcAction uninstall $tier QPKG uninstall
IsOsCanManageSignedPackages &&ProcAction unsign $tier QPKG unsign
elif IsQpkgEnabled Entware;then
ModPathToEntware
PIPs:uninstall
IPKs:uninstall
fi
done
for tier in "${r_package_tiers[@]}";do
if [[ $tier != auxiliary ]];then
IsOsCanManageSignedPackages &&ProcAction sign $tier QPKG '"sign"'
ProcAction upgrade $tier QPKG upgrade
ProcAction reinstall $tier QPKG reinstall
ProcAction install $tier QPKG install
ProcAction restore $tier QPKG restore
ProcAction enableau $tier QPKG 'enable auto-update'
ProcAction clean $tier QPKG clean
ProcAction enable $tier QPKG enable
ProcAction reactivate $tier QPKG reactivate
ProcAction activate $tier QPKG activate
else
for action in status install reinstall upgrade activate;do
if QPKGs-ACinstall-ok.Exist Entware ||QPKGs-AC${action}-to.IsAny;then
ipks_downgrade=true
ipks_install=true
ipks_upgrade=true
pips_install=true
break
fi
done
if IsQpkgEnabled Entware;then
ModPathToEntware
IPKs:upgrade
IPKs:install
IPKs:downgrade
PIPs:upgrade
PIPs:install
fi
fi
done
fi
IsOsCanManageSignedPackages &&ProcAction unsign all QPKG unsign
if [[ $useropt_debug = true ]];then
ListQPKGsActions
ListIPKsActions
ListPIPsActions
fi
if [[ $title_shown = true ]];then
if IsNtError;then
ShowAsDone 'actions complete'
else
ShowAsFail 'actions complete with errors'
fi
fi
show_action_results_report=true
FuncExit;}
ProcAction(){
FuncInit
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local package=''
local -i package_index=0
local -r r_action=${1:?${FUNCNAME[0]}(): $e_noact}
local -r r_action_intransitive_msg=${4:?${FUNCNAME[0]}(): $e_noact message}
local -r r_package_type=${3:?${FUNCNAME[0]}(): $e_nopty}
local -r r_tier=${2:?${FUNCNAME[0]}(): $e_notir}
local re=''
local state=''
local target_object_name=''
local -a target_packages=()
total_count=0
DebugVar r_action
DebugVar r_tier
DebugVar r_package_type
case $r_package_type in
QPKG)
target_object_name=AC${r_action}-to
if [[ $r_tier = all ]];then
target_packages=($(${r_package_type}s-$target_object_name:Array))
else
for package in $(${r_package_type}s-$target_object_name:Array);do
${r_package_type}s-GR${r_tier}.Exist "$package" &&target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]];then
DebugInfo 'nothing to process'
FuncExit;return
fi
if [[ $total_count -eq 1 ]];then
fork_progress_prefix="$r_action_intransitive_msg $(TextBrightOrange "${target_packages[0]}") $r_package_type"
else
fork_progress_prefix="$r_action_intransitive_msg $([[ $r_tier != all ]]&&TextBrightOrange "$r_tier ")$(Uppercase "$r_package_type")$(Pluralise "$total_count")"
fi
SetMaxForks "$r_action"
InitActionForkCounters
OpenMsgPipe
re=\\bEntware\\b
if [[ $r_action = uninstall &&${target_packages[*]} =~ $re ]];then
ShowKeystrokes
fi
CreatePidFile
_ExecOneActionWithManyForks_ "_${r_package_type}:${r_action}_" "${target_packages[@]}" &
WritePidFile "$!"
while [[ ${#target_packages[@]} -gt 0 &&! -e $r_abort_actions_pathfile ]];do
ReadFromMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
run)
eval "$msg1_value";;
change)
while true;do
for state in "${r_qpkg_is_states[@]}";do
case $msg1_value in
"IS${state}")
IsFuncExist QPKGs-ISNT${state}:Init &&QPKGs-ISNT${state}:Remove "$msg2_value"
IsFuncExist QPKGs-IS${state}:Init &&QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${r_qpkg_isnt_states[@]}";do
case $msg1_value in
"ISNT${state}")
IsFuncExist QPKGs-IS${state}:Init &&QPKGs-IS${state}:Remove "$msg2_value"
IsFuncExist QPKGs-ISNT${state}:Init &&QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_is_groups[@]}";do
case $msg1_value in
"GR${group}")
IsFuncExist QPKGs-GRNT${group}:Init &&QPKGs-GRNT${group}:Remove "$msg2_value"
IsFuncExist QPKGs-GR${group}:Init &&QPKGs-GR${group}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_isnt_groups[@]}";do
case $msg1_value in
"GRNT${group}")
IsFuncExist QPKGs-GR${group}:Init &&QPKGs-GR${group}:Remove "$msg2_value"
IsFuncExist QPKGs-GRNT${group}:Init &&QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break
done;;
update)
case $msg1_value in
ok)
[[ $r_action != status ]]&&((done_ok_count++));;
er)
((done_fail_count++));;
sk)
((skip_ok_count++));;
se)
((skip_error_count++));;
sa)
((skip_abort_count++))
/bin/touch "$r_abort_actions_pathfile"
esac
case $msg1_value in
en)
:;;
ok|er|sk|se|sa)
IsFuncExist QPKGs-AC${r_action}-to:Init &&QPKGs-AC${r_action}-to:Remove "$msg2_value"
IsFuncExist QPKGs-AC${r_action}-${msg1_value}:Init &&QPKGs-AC${r_action}-${msg1_value}:Add "$msg2_value"
IsFuncExist QPKGs-AC${r_action}-dn:Init &&QPKGs-AC${r_action}-dn:Add "$msg2_value";;
ex)
for package_index in "${!target_packages[@]}";do
if [[ ${target_packages[package_index]} = "$msg2_value" ]];then
unset 'target_packages[package_index]'
break
fi
done;;
*)DebugAsWarn "unidentified update in message queue: '$msg1_value'"
esac;;
*)DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
[[ -e $r_abort_actions_pathfile ]]&&break
done
[[ $done_fail_count -gt 0 ]]&&show_action_results_failed=true
[[ $done_ok_count -gt 0 ]]&&show_action_results_ok=true
[[ $skip_ok_count -gt 0 ||$skip_error_count -gt 0 ||$skip_abort_count -gt 0 ]]&&show_action_results_skipped=true
wait 2>/dev/null
CloseMsgPipe
[[ ${useropt_terse:=true} = false &&$useropt_verbose = false ]]&&echo;;
IPK|PIP)
if [[ $ipks_downgrade = true ||$ipks_install = true ||$ipks_upgrade = true ||$pips_install = true ]];then
InitActionForkCounters
${r_package_type}s:${r_action}
fi
esac
EraseForkCountPaths
FuncExit
IsNtError;}
OpenMsgPipe(){
[[ -p $r_action_msg_pipe ]]&&rm -f "$r_action_msg_pipe"
[[ ! -d $(/usr/bin/dirname "$r_action_msg_pipe") ]]&&mkdir -p "$(/usr/bin/dirname "$r_action_msg_pipe")"
[[ ! -p $r_action_msg_pipe ]]&&/bin/mknod "$r_action_msg_pipe" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd<>$r_action_msg_pipe"
} 2>/dev/null
CloseMsgPipe(){
if [[ -n ${backup_stdin_fd:-} ]];then
[[ $backup_stdin_fd != none ]]&&eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]]&&eval "exec $backup_stdin_fd>&-"
fi
[[ -n ${action_msg_pipe_fd:-} &&$action_msg_pipe_fd != none ]]&&eval "exec $action_msg_pipe_fd>&-"
[[ -n ${r_action_msg_pipe:-} &&-p $r_action_msg_pipe ]]&&rm -f "$r_action_msg_pipe"
} 2>/dev/null
SetMaxForks(){
local default_forks=$r_concurrency
max_forks=$default_forks
[[ -n ${1:-} ]]||return
local reason=''
if [[ $useropt_verbose = true ]];then
max_forks=1
reason='verbose mode is active'
elif [[ $useropt_debug = true ]];then
max_forks=1
reason='debug mode is active'
else
case $1 in
?(re)install|upgrade)
max_forks=1;;
sign|unsign)
max_forks=1;;
@(dis|en)able)
max_forks=1;;
clean)
max_forks=$(((r_concurrency+1)/2));;
backup|deactivate|download|uninstall)
max_forks=4;;
@(dis|en)ableau|rebuild|status)
max_forks=8
esac
[[ $max_forks -ne $default_forks ]]&&reason="'$1' was requested"
fi
[[ -n $reason ]]&&DebugInfo "setting \$max_forks to $max_forks because $reason";}
PrepareArgs(){
ShowAsProc args
local a=$(Lowercase "${r_args_raw//,/ }")
args=(${a/--/})
arg_problem=false
[[ -z $r_args_raw ]]&&useropt_help_basic=true;}
ParseManagementArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in ${args[@]+"${args[@]}"};do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
debug|verbose)
requires_group=false
user_action=$arg
EnableVerbose
EnableDebugToArchiveAndFile;;
fix)
generate_show_report=true
get_qpkg_extended_states=true
requires_group=false
run_package_actions=true
user_action=$arg
useropt_fix=true;;
follow|paste|report-info|terse)
requires_group=true
user_action=$arg;;
reset)
DeleteSetting Git_Branch announce
DeleteSetting Terse announce
DeleteSetting ReportInfo announce
Reset
esac
if [[ -n $user_action &&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun $arg)
DebugVar group
if [[ -n $action &&-n $group ]];then
case $action in
follow)
case $group in
?(un)stable)
action=''
awaiting_group=false
run_package_actions=false
switch_branch=true
user_branch_value=$group
WriteBranch;;
*)args_remaining+=("$action")
esac;;
paste)
case $group in
last)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_last=true;;
tail)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_tail=true;;
*)args_remaining+=("$action")
esac;;
report-info)
case $group in
true|false)
action=''
awaiting_group=false
switch_report_info=true
user_report_info_value=$group
WriteReportInfo;;
*)args_remaining+=("$action")
esac;;
terse)
case $group in
true|false)
action=''
awaiting_group=false
switch_terse=true
user_terse_value=$group
WriteTerse;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true &&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]+"${args_remaining[@]}"})
FuncExit;}
ParseHelpArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in ${args[@]+"${args[@]}"};do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
help)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action &&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun $arg)
DebugVar group
case $group in
abs|actions|all|all-actions|groups|lists|options|packages|problems|show|tips|upgrades)
[[ -z $action ]]&&action=help
esac
if [[ -n $action &&-n $group ]];then
case $action in
help)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true;;
actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true;;
all|all-actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true;;
groups)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true;;
lists)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true;;
options)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true;;
packages)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true;;
problems)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true;;
show)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_show=true;;
tips)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true;;
upgrades)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true &&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in ${args_incomplete[@]+"${args_incomplete[@]}"};do
case $arg in
help)
run_package_actions=false
useropt_help_basic=true
local a=''
local tmp=()
for a in ${args_incomplete[@]+"${args_incomplete[@]}"};do
[[ $a != "$arg" ]]&&tmp+=($a)
done
if [[ ${#tmp[@]} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]+"${args_remaining[@]}"})
FuncExit;}
ParseShowArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in ${args[@]+"${args[@]}"};do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
show)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action &&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun $arg)
DebugVar group
case $group in
about|about-all|abs|backups|dependent|features|last|packages|repositories|results|status|tail)
[[ -z $action ]]&&action=show
esac
if [[ -n $action &&-n $group ]];then
case $action in
show)
case $group in
about)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_about=true;;
about-all)
LoadDatabase
action=''
awaiting_group=false
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_aboutall=true;;
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_help_abbreviations=true;;
backups)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_backups=true;;
dependent)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true;;
features)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_features=true;;
last)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_last=true;;
packages)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_packages=true;;
repositories)
LoadDatabase
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true;;
results)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_previous_action_results_report=true
show_action_results_report=true;;
status)
LoadObjects
QPKGs.ACstatusGRall:Set
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
useropt_show_status=true;;
tail)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_extended_states=false
run_package_actions=false
useropt_show_log_tail=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true &&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]+"${args_remaining[@]}"})
FuncExit;}
ParseListArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in ${args[@]+"${args[@]}"};do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
list)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action &&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun $arg)
DebugVar group
case $group in
?(NT)installed|upgradable|versions)
[[ -z $action ]]&&action=list
esac
if [[ -n $action &&-n $group ]];then
case $action in
list)
case $group in
all|?(in)dependent|optional)
LoadObjects
QPKGs.AClistGR${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;
?(NT)active)
LoadObjects
QPKGs.AClistIS${group}:Set
QPKGs.ACstatusISinstalled:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=true
show_title=false;;
?(NT)backedup|?(NT)complete|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AClistIS${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_extended_states=true
run_package_actions=false
show_title=false;;
versions)
LoadDatabase
action=''
awaiting_group=false
generate_list_report=true
show_title=false
useropt_list_versions=true;;
*)args_remaining+=("$action")
esac;;
*)args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true &&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]+"${args_remaining[@]}"})
FuncExit;}
ParseActionArgs(){
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
[[ -n ${args[@]+"${args[@]}"} ]]&&LoadDatabase
for arg in ${args[@]+"${args[@]}"};do
[[ -n $arg ]]||continue
potential_action=$(MatchVerb $arg);DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|rebuild|?(re|un)install|resign|restore)
requires_group=true
user_action=$arg;;
upgrade)
get_qpkg_extended_states=true
requires_group=true
user_action=$arg;;
status)
generate_show_report=true
get_qpkg_extended_states=true
requires_group=true
user_action=$arg
useropt_show_status=true
esac
if [[ -n $user_action &&$user_action != "$current_action" ]];then
[[ $awaiting_group = true ]]&&args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun $arg);DebugVar group
if [[ -n $action &&-n $group ]];then
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|@(re|un)install|resign|restore|upgrade)
case $group in
?(NT)active)
LoadObjects
QPKGs.AC${action}IS${group}:Set
QPKGs.ACstatusISinstalled:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac
esac
case $group in
all|canbackup|?(NT)canclean|canrestarttoupdate|?(in)dependent|hasdependents)
LoadObjects
QPKGs.AC${action}GR${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AC${action}IS${group}:Set
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true;;
*)[[ $action != show ]]||continue
LoadObjects
QPKGs-AC${action}-to:Add "$group"
awaiting_group=false
show_action_results_report=true
get_qpkg_extended_states=true
run_package_actions=true
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true &&$awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in ${args_incomplete[@]+"${args_incomplete[@]}"};do
action=$(MatchVerb $arg)
case $action in
status)
LoadObjects
QPKGs.ACstatusISinstalled:Set
generate_show_report=true
get_qpkg_extended_states=true
run_package_actions=true
local a=''
local tmp=()
for a in ${args_incomplete[@]+"${args_incomplete[@]}"};do
[[ $a != "$arg" ]]&&tmp+=($a)
done
if [[ ${#tmp[@]} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]+"${args_remaining[@]}"})
FuncExit;}
MatchVerb(){
[[ -n ${1:-} ]]||return
case $1 in
activate|start)
printf activate;;
add|install)
printf install;;
backup|clean|@(dis|en)able|fix|follow|help|list|paste|reassign|rebuild|reinstall|report-info|reset|restore|terse)
printf '%s' "$1";;
deactivate|stop)
printf deactivate;;
d?(e)bug)
printf debug;;
disable-auto-update)
printf disableau;;
enable-auto-update)
printf enableau;;
reactivate|restart)
printf reactivate;;
remove|rm|uninstall)
printf uninstall;;
report|show|view)
printf show;;
resign|re-sign)
printf resign;;
s|status?(es))
printf status;;
update|upgrade)
printf upgrade;;
v|verbose)
printf verbose
esac;}
MatchNoun(){
[[ -n ${1:-} ]]||return
case $1 in
a|about)
printf about;;
abs|abbreviations)
printf abs;;
about-all|backedup|canbackup|complete|installable|installed|missing|results|show|?(un)stable)
printf '%s' "$1";;
action?(s))
printf actions;;
action?(s)-all|all-action?(s))
printf all-actions;;
active|n?(o)@(n|t)?(-)inactive|n?(o)@(n|t)?(-)stopped|started)
printf active;;
all|entire|everything)
printf all;;
b|backups)
printf backups;;
d|deps|dependencies|dependent?(s))
printf dependent;;
disable|false|no|off|unset)
printf false;;
disabled|n?(o)@(n|t)?(-)enabled)
printf NTenabled;;
enable|on|set|true|yes)
printf true;;
enabled|n?(o)@(n|t)?(-)disabled)
printf enabled;;
f|features)
printf features;;
group?(s))
printf groups;;
inactive|n?(o)@(n|t)?(-)active|n?(o)@(n|t)?(-)started|stopped)
printf NTactive;;
indep?(endent)?(s))
printf independent;;
l|last)
printf last;;
list?(s))
printf lists;;
log|tail)
printf tail;;
me|problem?(s))
printf problems;;
new|updat?(e)able|upgrad@(a|e)ble)
printf upgradable;;
no@(n|t)-back?(ed)up)
printf NTbackedup;;
n?(o)@(n|t)?(-)installable)
printf NTinstallable;;
n?(o)@(n|t)?(-)installed)
printf NTinstalled;;
n?(o)@(n|t)?(-)missing)
printf NTmissing;;
n?(o)@(n|t)?(-)upgradable)
printf NTupgradable;;
@(in|nt|not)?(-)complete)
printf NTcomplete;;
o|option?(s))
printf options;;
optional?(s))
printf optional;;
p|package?(s)|qpkg?(s))
printf packages;;
r|repos|repositories)
printf repositories;;
s|status?(es))
printf status;;
tip?(s))
printf tips;;
upgrade?(s)|upgrading)
printf upgrades;;
version?(s))
printf versions;;
*)QpkgMatchAbbrv "$1"
esac;}
ShowArgSuggestions(){
FuncInit
local arg=''
local -a args_remaining=()
CreateReportPaths
if [[ -n ${args_incomplete[@]+"${args_incomplete[@]}"} ]];then
run_package_actions=false
for arg in ${args_incomplete[@]+"${args_incomplete[@]}"};do
case $arg in
?(de|re)activate|backup|clean|@(dis|en)able|@(dis|en)able-auto-update|reassign|@(re|un)install|?(re)start|restore|rm|sign|stop)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false;;
terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
DisplayAsProjSynIndentExam '' "$arg enable"
DisplayAsProjSynIndentExam '' "$arg disable"
arg_problem=true
useropt_help_basic=false;;
follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to '$arg' like" "$arg stable"
DisplayAsProjSynIndentExam '' "$arg unstable"
arg_problem=true
useropt_help_basic=false;;
install|rebuild)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg all"
arg_problem=true
useropt_help_basic=false;;
list)
DisplayAsProjSynExam "please provide a valid source to '$arg' like" "$arg installable"
DisplayAsProjSynIndentExam '' "$arg new"
arg_problem=true
useropt_help_basic=false;;
paste)
DisplayAsProjSynExam "please provide a valid source to '$arg' online like" "$arg log"
DisplayAsProjSynIndentExam '' "$arg last"
arg_problem=true
useropt_help_basic=false;;
show)
DisplayAsProjSynExam "please provide a valid source after '$arg' like" "$arg abs"
DisplayAsProjSynIndentExam '' "$arg log"
DisplayAsProjSynIndentExam '' "$arg packages"
DisplayAsProjSynIndentExam '' "$arg results"
arg_problem=true
useropt_help_basic=false;;
upgrade)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg new"
arg_problem=true
useropt_help_basic=false;;
*)arg_problem=true
args_remaining+=("$arg")
esac
done>"$r_report_output_pathfile"
if [[ ${#args_remaining[@]} -gt 0 ]];then
ShowAsError "incomplete argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
args_remaining=()
fi
fi
if [[ ${#args[@]} -gt 0 ]];then
run_package_actions=false
for arg in ${args[@]+"${args[@]}"};do
case $arg in
active|all|@(dis|en)abled|started)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "deactivate $arg"
arg_problem=true
useropt_help_basic=false;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all QPKGs, use' 'activate all'
arg_problem=true
useropt_help_basic=false;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed QPKG configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false;;
all-deactivate|deactivate-all)
DisplayAsProjSynExam 'to deactivate all QPKGs, use' 'deactivate all'
arg_problem=true
useropt_help_basic=false;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all QPKGs, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed QPKG configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all QPKGs, use' 'stop all'
arg_problem=true
useropt_help_basic=false;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all QPKGs, use' 'uninstall all'
arg_problem=true
useropt_help_basic=false;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all QPKGs, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false;;
check)
DisplayAsProjSynExam "'check' has been replaced by 'fix'" fix
arg_problem=true
useropt_help_basic=false;;
@(dis|en)able|false|off|no|on|true|yes)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "terse $arg"
arg_problem=true
useropt_help_basic=false;;
download)
ShowAsError "'$arg' is not a manual action"
arg_problem=true
useropt_help_basic=false;;
@(in|not-)active|?(in)dependent?(s)|stopped)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "activate $arg"
arg_problem=true
useropt_help_basic=false;;
?(un)stable)
DisplayAsProjSynExam "please provide a valid $(ShowAsSetting) before '$arg' like" "follow $arg"
arg_problem=true
useropt_help_basic=false;;
*)arg_problem=true
args_remaining+=("$arg")
esac
done>>"$r_report_output_pathfile"
if [[ ${#args_remaining[@]} -gt 0 ]];then
ShowAsError "unknown argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
useropt_help_basic=false
fi
fi
[[ -s $r_report_output_pathfile ]]&&/bin/cat "$r_report_output_pathfile"
DebugArray args_incomplete ${args_incomplete[@]+"${args_incomplete[@]}"}
DebugArray args_remaining ${args_remaining[@]+"${args_remaining[@]}"}
FuncExit;}
AllocPackGroupsToAcs(){
FuncInit
ShowAsProc 'allocate QPKG groups to actions'
local action=''
local group=''
for action in "${r_user_qpkg_actions[@]}";do
for group in "${r_qpkg_is_groups[@]}";do
QPKGs.AC${action}GR${group}.IsSet||continue
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GR${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GR$group' QPKGs to '$(Lowercase "$action")'"
fi
done
for group in "${r_qpkg_isnt_groups[@]}";do
if QPKGs.AC${action}GRNT${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GRNT$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit;}
AllocPackStatesToAcs(){
FuncInit
ShowAsProc 'allocate QPKG states to actions'
local action=''
local check_later=false
local state=''
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
check_later=false
[[ $state = downloaded ]]&&continue
QPKGs.AC${action}IS${state}.IsSet||continue
if [[ $state = active ]];then
check_later=true
elif [[ $state = installed ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsIsInstalled)"
elif [[ $state = enabled ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsIsEnabled)"
else
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any '$state' QPKGs to '$(Lowercase "$action")'"
fi
done
for state in "${r_qpkg_isnt_states[@]}";do
check_later=false
[[ $state = downloaded ]]&&continue
QPKGs.AC${action}ISNT${state}.IsSet||continue
if [[ $state = active ]];then
check_later=true
elif [[ $state = installed ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsNtInstalled)"
elif [[ $state = enabled ]];then
QPKGs-AC${action}-to:Add "$(GetQpkgsNtEnabled)"
else
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any 'not $state' QPKGs to '$(Lowercase "$action")'"
fi
done
done
FuncExit;}
ResetArchivedLogs(){
if [[ -n $r_log_path &&-d $r_log_path ]];then
ClearPath "$r_this_package_path" "$r_log_path"
echo "$(date): log cleared">"$session_active_log_pathfile"
ShowAsDone 'persistent logs cleared'
fi
return 0;}
Quiz(){
local a=${1:?${FUNCNAME[0]}(): $e_noprm}
local b=''
ShowAsQuiz "$a"
[[ -x $r_gnu_stty_cmd ]]&&IsInTerminal &&$r_gnu_stty_cmd igncr
read -rn1 b
[[ -x $r_gnu_stty_cmd ]]&&IsInTerminal &&$r_gnu_stty_cmd -igncr
DebugVar b
ShowAsQuizDone "$a: $b"
case ${b:0:1} in
y|Y)
return 0;;
*)return 1
esac;}
PatchEntwareService(){
local append_text=''
local match_text=''
local -r r_package_init_pathfile=$(GetQpkgServicePathFile Entware)
local -r r_prefix='# The following line was inserted by sherpa: https://git.io/sherpa'
if /bin/grep "$r_external_apps_temp_path" "$r_package_init_pathfile" &>/dev/null;then
DebugInfo 'patch: "'$r_external_apps_path' shuffle" - already done'
else
append_text='external_apps_path='$r_external_apps_path' external_apps_temp_path='$r_external_apps_temp_path';rmdir "$external_apps_path" "$external_apps_temp_path" 2>/dev/null;[[ -d $external_apps_path \&\& ! -L $external_apps_path \&\& ! -d $external_apps_temp_path ]] \&\& mv "$external_apps_path" "$external_apps_temp_path"'
match_text='# sym-link $QPKG_DIR to /opt'
/bin/sed -i "s|$match_text|${match_text}\n\n${r_char_tab}${r_prefix}\n${r_char_tab}${append_text}\n|" "$r_package_init_pathfile"
append_text='(shopt -s dotglob;[[ -L $external_apps_path \&\& -d $external_apps_temp_path ]] \&\& { mv "$external_apps_temp_path"/* "$external_apps_path"/;rm -rf "${external_apps_temp_path:?no path specified}";})'
match_text='/bin/ln -sf $QPKG_DIR /opt'
/bin/sed -i "s|$match_text|${match_text}\n\n${r_char_tab}${r_prefix}\n${r_char_tab}${append_text}\n|" "$r_package_init_pathfile"
DebugAsDone 'patch: "'$r_external_apps_path' shuffle"'
fi
return 0;}
_UpdateEntwarePackageList_(){
if IsNtCriticalFile $r_opkg_cmd;then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${r_entware_package_list_uptodate:-false} = false ]]||return
local -i z=0
if ! IsFileRecent "$r_external_packages_archive_pathfile" "$r_file_change_threshold_minutes" ||[[ ! -f $r_external_packages_archive_pathfile ||$useropt_fix = true ]];then
DebugAsProc "updating $(FormatPackageName Entware) package list"
Executer "$r_opkg_cmd update" "$r_action_log_path/Entware.$r_update_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
DebugAsDone "updated $(FormatPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(FormatPackageName Entware) package list $(FormatExitcode "$z")"
fi
else
DebugInfo "$(FormatPackageName Entware) package list was updated less-than $r_file_change_threshold_minutes minutes ago: skipping update"
fi
IsFile "$r_external_packages_archive_pathfile"&&IsNtFile "$r_external_packages_pathfile" &&OpenIpkArchive
readonly r_entware_package_list_uptodate=true
return 0;}
SaveIpkAndPipList(){
$r_pip_cmd freeze|cut -d'=' -f1>"$r_prev_pip_list_pathfile"
[[ -s $r_prev_pip_list_pathfile ]]&&DebugAsDone "saved current PIP list to $(FormatFileName "$r_prev_pip_list_pathfile")"
$r_opkg_cmd list-installed>"$r_prev_ipk_list_pathfile"
[[ -s $r_prev_ipk_list_pathfile ]]&&DebugAsDone "saved current $(FormatPackageName Entware) IPK list to $(FormatFileName "$r_prev_ipk_list_pathfile")"
} 2>/dev/null
LoadIpkList(){
local name=''
local separator=''
local version=''
if [[ -s $r_prev_ipk_list_pathfile ]];then
DebugInfo "IPKs are being loaded from $(FormatFileName "$r_prev_ipk_list_pathfile")"
while read -r name separator version;do
name=$(Lowercase "$name")
IPKs-ACinstall-to:Add "$name"
done<"$r_prev_ipk_list_pathfile"
fi;}
LoadPipList(){
local name=''
local re=''
if [[ -s $r_prev_pip_list_pathfile ]];then
DebugInfo "PIPs are being loaded from $(FormatFileName "$r_prev_pip_list_pathfile")"
while read -r name;do
name=$(Lowercase "$name")
re=\\b${name}\\b
[[ ${r_exclusion_pips[*]} =~ $re ]]||PIPs-ACinstall-to:Add "$name"
done<"$r_prev_pip_list_pathfile"
fi;}
CalcIpkDepsToInstall(){
IsCriticalFile $r_gnu_grep_cmd||return
FuncInit
local complete=false
local -a dep_acc=()
local element=''
local ipk_titles=''
local -i iterations=0
local -r r_iteration_limit=20
local -i pre_exclude_count=0
local pre_exclude_list=''
local req_list=''
local -i requested_count=0
local -a this_list=()
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$(/usr/bin/wc -w<<<"$req_list")
if [[ $requested_count -eq 0 ]];then
DebugAsWarn 'no IPKs requested'
FuncExit 1;return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while [[ $iterations -le $r_iteration_limit ]];do
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
((iterations++))
printf -v ipk_titles '^Package: %s$\|' "${this_list[@]}"
ipk_titles=${ipk_titles%??}
this_list=($($r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$r_external_packages_pathfile"|$r_gnu_grep_cmd -vG '^Section:\|^Version:'|$r_gnu_grep_cmd --word-regexp --after-context 1 --no-group-separator "$ipk_titles"|$r_gnu_grep_cmd -vG "$ipk_titles"|$r_gnu_grep_cmd -vG '^Package: '|/bin/sed 's/^Depends: //;s/, /\n/g'|/usr/bin/sort|/bin/uniq))
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
if [[ ${#this_list[@]} -eq 0 ]];then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
if [[ $complete = true ]];then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$r_iteration_limit [$r_iteration_limit]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$(/usr/bin/wc -w<<<"$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]];then
ShowAsProc 'exclude IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do
if [[ $element != 'ca-certs' &&$element != 'python3-gdbm' ]];then
if [[ $element != 'libjpeg' ]];then
if ! $r_opkg_cmd status "$element"|/bin/grep "Status:.*installed" &>/dev/null;then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $r_opkg_cmd status 'libjpeg-turbo'|/bin/grep "Status:.*installed" &>/dev/null;then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
FuncExit;}
CalcIpkDownloadSize(){
FuncInit
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]];then
ShowAsProc "calculate size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($r_gnu_grep_cmd -w '^Package:\|^Size:' "$r_external_packages_pathfile"|$r_gnu_grep_cmd --after-context 1 --no-group-separator ": $(/bin/sed 's/ /$ /g;s/\$ /\$\\\|: /g'<<<"$(IPKs-ACdownload-to:List)")"|/bin/grep '^Size:'|/bin/sed 's/^Size: //'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$((${size_array[*]}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
FuncExit;}
IPKs:upgrade(){
[[ $ipks_upgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local desc=''
local fork_pid=''
local -i total_count=0
local -i z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($r_opkg_cmd list-upgradable|cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
dir_size_progress_prefix="upgrade $desc"
_DirSizeMonitor_ &
fork_pid=$!
Executer "$r_opkg_cmd upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$r_log_path/ipks.$r_upgrade_log_file" log:failure-only
z=$?
KillPID "$fork_pid"
UpdateDirSizeProgress final
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultMetrics IPK auxiliary upgrade "$total_count" ok
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultMetrics IPK auxiliary upgrade "$total_count" er "$z"
fi
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:install(){
[[ $ipks_install = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local desc=''
local fork_pid=''
local -i i=0
local previous=''
local -i total_count=0
local -i z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware ||([[ $useropt_fix = true ]]&&IsValidQpkgInstalled Entware);then
IPKs-ACinstall-to:Add "$r_essential_ipks"
if [[ -s $r_prev_ipk_list_pathfile &&$useropt_fix = false ]];then
LoadIpkList
mv -f "$r_prev_ipk_list_pathfile" "$r_prev_ipk_list_pathfile.installing"
fi
fi
if QPKGs.ACinstallGRall.IsSet;then
for qpkg_name in $(QPKGs-GRall:Array);do
SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)"
done
else
for qpkg_name in $(QPKGs-GRall:Array);do
if QPKGs-ACinstall-to.Exist "$qpkg_name" ||IsValidQpkgInstalled "$qpkg_name" ||(QPKGs-ACreinstall-to.Exist "$qpkg_name"&&IsValidQpkgInstalled "$qpkg_name");then
SetQpkgIndex
IPKs-ACinstall-to:Add "$(GetQpkgDbIPKs)"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
dir_bytes=$(IPKs-ACdownload-to:Size)
dir_location=$r_ipk_download_path
dir_size_progress_prefix="install $desc"
_DirSizeMonitor_ &
fork_pid=$!
Executer "$r_opkg_cmd install --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$r_log_path/ipks.$r_install_log_file" log:failure-only
z=$?
KillPID "$fork_pid"
UpdateDirSizeProgress final
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultMetrics IPK auxiliary install "$total_count" ok
HideKeystrokes
SetCapabilities
rm -f "$r_prev_ipk_list_pathfile.installing" 2>/dev/null
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultMetrics IPK auxiliary install "$total_count" er "$z"
if [[ -s $r_prev_ipk_list_pathfile.installing ]];then
mv -f "$r_prev_ipk_list_pathfile.installing" "$r_prev_ipk_list_pathfile"
fi
fi
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:downgrade(){
[[ $ipks_downgrade = true ]]||return
IsQpkgEnabled Entware||return
IsNtError||return
FuncInit
local curl_insecure_opt=''
local desc=''
local -i done_fail_count=0
local log_pathfile=''
local name=''
local -i done_ok_count=0
local package_type=''
local remote_url=''
local -i total_count=0
local url_prefix=''
local url_suffix=''
local -i z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
IsOsCanSecureDownload ||curl_insecure_opt='--insecure'
if [[ $total_count -gt 0 ]];then
package_type=IPK
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_log_path/ipks.$r_download_log_file
ShowAsProc "download $desc"
SetQpkgArch
case $r_nas_qpkg_arch in
a41)
if IsOsNonStdKernelPageSize;then
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.38-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$done_ok_count" 0 0 "$total_count"
((done_ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$(/usr/bin/basename "$remote_url")
Executer "/sbin/curl $curl_insecure_opt --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
url_prefix=''
url_suffix=''
fi
esac
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
total_count=1
done_ok_count=0
done_fail_count=0
desc="$total_count auxiliary ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_log_path/ipks.$r_downgrade_log_file
ShowAsProc "downgrade $desc"
ShowAsPercentProgress "downgrade $desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
Executer "$r_opkg_cmd install --force-downgrade --cache $r_ipk_cache_path --tmp-dir $r_ipk_downgrade_path $r_ipk_downgrade_path/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((done_ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultMetrics IPK auxiliary downgrade "$done_ok_count" ok
else
((done_fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultMetrics IPK auxiliary downgrade "$done_fail_count" er "$z"
fi
ShowAsPercentProgress "downgrade $desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
IPKs:uninstall(){
:;}
PIPs:upgrade(){
:;}
PIPs:install(){
[[ $pips_install = true ]]||return
IsQpkgEnabled Entware||return
$r_opkg_cmd status python3-pip|/bin/grep "Status:.*installed" &>/dev/null||return
IsNtError||return
FuncInit
local desc=''
local exec_cmd=''
local -i done_fail_count=0
local log_pathfile=$r_action_log_path/pips.$r_install_log_file
local -i done_ok_count=0
local package_type=PIP
local -i total_count=0
local -i z=0
if [[ $useropt_fix = true ]]||IPKs-ACinstall-ok.Exist python3-pip;then
PIPs-ACinstall-to:Add "$r_base_pips"
if [[ -s $r_prev_pip_list_pathfile &&$useropt_fix = false ]];then
LoadPipList
mv -f "$r_prev_pip_list_pathfile" "$r_prev_pip_list_pathfile.installing"
fi
((total_count++))
exec_cmd="$r_pip_cmd install --upgrade --no-input $(PIPs-ACinstall-to:List) --cache-dir $r_pip_cache_path --root-user-action=ignore"
desc="$total_count auxiliary PIP$(Pluralise "$total_count")"
ShowAsPercentProgress "install $desc" '' "$done_ok_count" 0 0 "$total_count"
Executer "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((done_ok_count++))
DebugAsDone "installed $desc"
SaveActionResultMetrics PIP auxiliary install "$done_ok_count" ok
rm -f "$r_prev_pip_list_pathfile.installing" 2>/dev/null
else
((done_fail_count++))
SaveActionResultMetrics PIP auxiliary install "$done_fail_count" er "$z"
if [[ -s $r_prev_pip_list_pathfile.installing ]];then
mv -f "$r_prev_pip_list_pathfile.installing" "$r_prev_pip_list_pathfile"
fi
fi
ShowAsPercentProgress "install $desc" '' "$done_ok_count" 0 "$done_fail_count" "$total_count"
[[ ${useropt_terse:=true} = false &&${useropt_verbose:=false} = false ]]&&echo
fi
FuncExit $z;}
PIPs:uninstall(){
:;}
OpenIpkArchive(){
if [[ ! -s $r_external_packages_archive_pathfile ]];then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
Executer "/usr/local/sbin/7z e -o$(/usr/bin/dirname "$r_external_packages_pathfile") $r_external_packages_archive_pathfile" "$r_cache_path/ipk.archive.extract" log:failure-only
if [[ ! -s $r_external_packages_pathfile ]];then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0;}
CloseIpkArchive(){
rm -f "$r_external_packages_pathfile"
} 2>/dev/null
_ExecOneActionWithManyForks_(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nofun"||return
FuncForkInit
local a=$1
local -i pid=0
local qpkg_name=''
shift
local -a c=("$@")
for qpkg_name in "${c[@]}";do
[[ ! -e $r_abort_actions_pathfile ]]||break
while [[ $worker_count -ge $max_forks ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break 2
sleep .2
UpdateActionForkProgress
done
MarkActionForkAsQueued
SetQpkgIndex
(
CreatePidFile
$a &
pid=$!
WritePidFile "$pid"
DebugAsDone "forked $a() instance for '$qpkg_name' with PID $pid"
)
UpdateActionForkProgress
done
while [[ $worker_count -gt 0 ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break
sleep .2
UpdateActionForkProgress
done
wait 2>/dev/null
UpdateActionForkProgress
sleep .2
FuncForkExit;}
_DirSizeMonitor_(){
[[ -d $dir_location &&$dir_bytes -gt 0 ]]||exit
local last_bytes=0
current_bytes=-1
last_active_epoch=0
while [[ $current_bytes -lt $dir_bytes ]];do
[[ ! -e $r_abort_actions_pathfile ]]||break
sleep .2
UpdateDirSizeProgress
if [[ $current_bytes -ne $last_bytes ]];then
last_active_epoch=$(ConvertNowToSeconds)
last_bytes=$current_bytes
fi
done;}
KillPID(){
[[ -n ${1:-} &&$1 -gt 0 &&-d /proc/$1 ]]||return
kill -9 "$1"
wait
} &>/dev/null
Reset(){
ClearCachePath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
ClearTempLogPath
ClearTempRunPath
exit 0;}
WriteBranch(){
local a=''
if [[ $switch_branch = true &&-n $user_branch_value ]];then
for a in unstable stable;do
[[ $a != "$user_branch_value" ]]&&continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then
SaveSetting Git_Branch "$useropt_branch"
else
SaveSetting Git_Branch "$useropt_branch" announce
Reset
fi
switch_branch=false
return
done
ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1
fi;}
WriteReportInfo(){
local a=''
if [[ $switch_report_info = true &&-n $user_report_info_value ]];then
for a in true false;do
[[ $a != "$user_report_info_value" ]]&&continue
useropt_show_report_info=$user_report_info_value
if [[ ${1:-} = silent ]];then
SaveSetting ReportInfo "$useropt_show_report_info"
else
SaveSetting ReportInfo "$useropt_show_report_info" announce
fi
switch_report_info=false
return
done
ShowAsAbort "user setting '$user_report_info_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi;}
WriteTerse(){
local a=''
if [[ $switch_terse = true &&-n $user_terse_value ]];then
for a in true false;do
[[ $a != "$user_terse_value" ]]&&continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then
SaveSetting Terse "$useropt_terse"
else
SaveSetting Terse "$useropt_terse" announce
fi
switch_terse=false
return
done
ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi;}
SaveSetting(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_noval"||return
local a=$1
local b=$(Lowercase "$2")
case $b in
true|false)
b=$(Uppercase "$b")
esac
/sbin/setcfg sherpa "$a" "$b" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]]&&ShowAsDone "user setting '$a = $b' saved";}
LoadSetting(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_noval"||return
local a=$(Lowercase "$2")
if [[ ! -x /sbin/getcfg ]];then
printf '%s' "$a"
return
fi
Lowercase "$(/sbin/getcfg sherpa "$1" -d "$a" -f /etc/config/qpkg.conf)";}
DeleteSetting(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nonam"||return
if [[ $(LoadSetting "$1" none) != none ]];then
/sbin/setcfg -e sherpa "$1" -f /etc/config/qpkg.conf
[[ ${2:-} = announce ]]&&ShowAsDone "user setting '$1' deleted"
fi;}
LenANSIDiff(){
local a=${1:-}
local b=$(StripANSICodes "$a")
printf '%s' "$((${#a}-${#b}))"
return 0;}
AddSeparators(){
[[ -z ${1:-} ]]&&return
local a=''
a=$(Trim "$1")
a=${a// /, }
a=${a//!/ }
printf '%s' "$a";}
DisplayAsProjSynExam(){
printf "\n${r_chars_bullet}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf "\n%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsProjSynIndentExam(){
if [[ -n $1	]];then
printf "\n%${r_help_desc_indent}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]]&&printf ':'
printf '\n'
fi
printf "%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}";}
DisplayAsSynExam(){
printf "\n${r_chars_bullet}%s:\n%${r_help_syntax_indent}s${r_help_syntax_prefix}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}";}
DisplayAsIndentItem(){
printf "%${r_help_desc_indent}s${r_chars_bullet}%s\n" '' "$(Capitalise "${1:-}")";}
DisplayAsIndentQuotedInfoItem(){
if IsOsCanAutowidthTableColumns;then
printf "%${r_help_desc_indent}s%s|%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
else
printf "%${r_help_desc_indent}s%-$((r_report_info_name_column_width+2+$(LenANSIDiff "${1:-}")))s%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
fi;}
GeneratePacksReportTitleRow(){
local -a headers=('QPKG name:' 'Appl. version:' 'Description:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${headers[1]}" "$r_report_qpkg_appl_version_column_width"
printf '%s' "${headers[2]}"
fi
printf '\n';}
_GeneratePacksReportDataRow_(){
local -a column_vars=(app_ver description name)
local mode=''
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
app_ver=$(GetQpkgDbApplVer)
description=$(Capitalise "$(GetQpkgDbDesc "$name")")
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
if IsQpkgMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
case $mode in
mute)
app_ver_msg=$(FormatReportField "$app_ver" mute)
description_msg=$(FormatReportField "$description" normal_mute)
name_msg=$(FormatReportField "$name" mute);;
highlight)
name_msg=$(FormatReportField "$name" alert);;
*)app_ver_msg=$(FormatReportField "$app_ver")
description_msg=$(FormatReportField "$description" normal)
name_msg=$(FormatReportField "$name")
esac
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$app_ver_msg|$description_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$app_ver_msg" "$r_report_qpkg_appl_version_column_width"
printf ' %s' "$description_msg"
fi
printf '\n';}
GenerateStatusReportTitleRow(){
local a='QPKG version'
QPKGs-ISupgradable.IsAny &&a+=" ($(TextBrightOrange new))"
local -a headers=('QPKG name:' 'Status:' "Last action (result):" "$a:" 'Appl. version:' 'Location:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
printf '%s' "Status & Last action (result):"
fi
printf '\n';}
_GenerateStatusReportDataRow_(){
local a=''
local -a column_vars=(action app_ver auxiliary name path status ver)
local auxiliary_column=status
local mode=''
local -i n=0
local result=''
local req_alert=false
local req_attention=false
local req_oops=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
app_ver=$(GetQpkgDbApplVer)
name=$qpkg_name
path=$(GetQpkgInstalledPath)
ver=$(GetQpkgInstalledVer)
if IsValidQpkgInstalled;then
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
elif IsQpkgMissing;then
mode=missing
/bin/touch "$r_report_flags_path"/status-missing
elif IsQpkgInstalled;then
if IsNtQpkgComplete "$name";then
mode=incomplete
/bin/touch "$r_report_flags_path"/status-incomplete
elif IsNtQpkgAuthorOk;then
mode=author
/bin/touch "$r_report_flags_path"/status-wrongauthor
fi
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
case $mode in
missing|mute|normal)
if IsQpkgDbSherpaCompatible;then
action=$(GetQpkgServiceAction)
/bin/touch "$r_report_flags_path"/action-$action
if [[ $action = not-found ]];then
if IsOsStartingPackages&&IsQpkgEnabled;then
action=$(TextBrightOrange pending)
/bin/touch "$r_report_flags_path"/action-pending
else
action=$(TextDarkGrey not-found)
fi
fi
result=$(GetQpkgServiceResult)
/bin/touch "$r_report_flags_path"/result-$result
case $result in
aborted|failed)
action+=' '$(Parenthesise "$(TextBrightRed "$result")");;
in-progress)
action+=' '$(Parenthesise "$(TextBrightOrange "$result")");;
ok)
action+=' '$(Parenthesise "$(TextBrightGreen "$(Uppercase "$result")")")
esac
else
action=unsupported
/bin/touch "$r_report_flags_path"/action-unsupported
action=$(TextDarkGrey "$action")
fi;;
*)/bin/touch "$r_report_flags_path"/na
esac
case $mode in
author)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${column_vars[@]}";do
case $a in
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField 'incompatible author' attention_highlight)
req_attention=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
done;;
incomplete)
app_ver=N/A
action=N/A
ver=N/A
/bin/touch "$r_report_flags_path"/na
for a in "${column_vars[@]}";do
case $a in
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField 'incomplete installation' attention_highlight)
req_attention=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
done;;
missing)
for a in "${column_vars[@]}";do
case $a in
action)
local ${a}_msg="$(FormatReportField "${!a}")";;
name)
:;;
auxiliary)
auxiliary_msg=$(FormatReportField missing alert)
req_alert=true;;
*)local ${a}_msg="$(FormatReportField "${!a}" oops)"
req_oops=true
esac
done;;
mute)
path=N/A
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbMinOSVerOk ||! IsQpkgDbMaxOSVerOk;then
auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then
auxiliary='insufficient installed RAM'
elif IsQpkgProhibited;then
auxiliary='prohibited package'
elif IsQpkgConflicts;then
auxiliary='conflict exists'
fi
if [[ $auxiliary != false ]];then
if IsOsCanAutowidthTableColumns;then
auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute)
else
auxiliary_msg="not installable, $auxiliary"
fi
else
if IsOsCanAutowidthTableColumns;then
auxiliary_msg=$(FormatReportField 'not installed' normal_mute)
else
auxiliary_msg='not installed'
fi
fi
ver=$(GetQpkgDbVer)
for a in "${column_vars[@]}";do
case $a in
name|auxiliary|status)
:;;
*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac
done;;
*)for a in "${column_vars[@]}";do
case $a in
name|auxiliary)
:;;
status)
if IsQpkgEnabled "$qpkg_name";then
status_msg+=' '$(TextBrightGreen enabled)
/bin/touch "$r_report_flags_path"/state-enabled
else
status_msg+=' '$(TextBrightRed disabled)
/bin/touch "$r_report_flags_path"/state-disabled
fi
if QPKGs-ISactive.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightGreen active)
/bin/touch "$r_report_flags_path"/status-active
elif QPKGs-ISslow.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightOrange slow)
/bin/touch "$r_report_flags_path"/status-slow
elif QPKGs-ISNTactive.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightRed inactive)
/bin/touch "$r_report_flags_path"/status-inactive
else
status_msg+=' '$(TextBrightOrange unknown)
/bin/touch "$r_report_flags_path"/status-unknown
fi
if QPKGs-ISupgradable.Exist "$qpkg_name";then
status_msg+=' '$(TextBrightOrange upgradable)
fi
status_msg=$(FormatReportField "$(AddSeparators "$status_msg")" normal);;
*)local ${a}_msg="$(FormatReportField "${!a}")"
esac
done
esac
if QPKGs-ISupgradable.Exist "$qpkg_name";then
ver_msg+=' '$(Parenthesise "$(TextBrightOrange "$(GetQpkgDbVer)")")
/bin/touch "$r_report_flags_path"/state-upgradable
fi
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $req_oops = true ]];then
name_msg=$(FormatReportField "$name" oops)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
if IsOsCanAutowidthTableColumns;then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$status_msg|$action_msg|$ver_msg|$app_ver_msg|$path_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
if [[ -z $auxiliary_msg ]];then
printf '%s' "$(LTrim "$status_msg"), $(LTrim "$action_msg")"
else
printf '%s' "$(TextDarkGrey "! $status_msg, $(LTrim "$action_msg")")"
fi
fi
printf '\n';}
GenerateReposReportTitleRow(){
local -a headers=('QPKG name:' 'Repository:' 'Install date:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
printf '%s' "${headers[1]}"
fi
printf '\n';}
_GenerateReposReportDataRow_(){
local a=''
local -a column_vars=(assigned_repo auxiliary install_date name)
local auxiliary_column=assigned_repo
local mode=''
local req_alert=false
local req_attention=false
local store_id=$(GetQpkgInstalledStoreID)
[[ $store_id = undefined ]]&&store_id=sherpa
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
if IsQpkgMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif IsValidQpkgInstalled;then
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
if [[ $store_id = sherpa ]];then
assigned_repo=sherpa
/bin/touch "$r_report_flags_path"/repo-sherpa
else
assigned_repo=$(GetRepoURLFromStoreID "$store_id")
fi
case $mode in
highlight)
auxiliary_msg=$(FormatReportField missing alert)
install_date_msg=$(FormatReportField "$(GetQpkgInstalledDate)" oops)
req_alert=true;;
mute)
/bin/touch "$r_report_flags_path"/na
if ! IsQpkgDbMinOSVerOk ||! IsQpkgDbMaxOSVerOk;then
auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then
auxiliary='insufficient installed RAM'
elif IsQpkgProhibited;then
auxiliary='prohibited package'
fi
if [[ $auxiliary != false ]];then
if IsOsCanAutowidthTableColumns;then
auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute)
else
auxiliary_msg="not installable, $auxiliary"
fi
else
if IsOsCanAutowidthTableColumns;then
auxiliary_msg=$(FormatReportField 'not installed' normal_mute)
else
auxiliary_msg='not installed'
fi
fi
install_date_msg=$(FormatReportField N/A mute);;
*)case $assigned_repo in
sherpa)
assigned_repo_msg=$(FormatReportField "$assigned_repo" normal_ok);;
undefined)
assigned_repo_msg=N/A
/bin/touch "$r_report_flags_path"/na;;
*)assigned_repo_msg=$(FormatReportField "$assigned_repo" attention_highlight)
/bin/touch "$r_report_flags_path"/repo-other
esac
install_date_msg=$(FormatReportField "$(GetQpkgInstalledDate)")
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$assigned_repo_msg|$install_date_msg"
else
if [[ -z $auxiliary_msg ]];then
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
printf ' %s' "$assigned_repo_msg"
else
printf '%s %s' "$(TextDarkGrey "$name_msg")" "$(TextDarkGrey "($(LTrim "$assigned_repo_msg"))")"
fi
fi
printf '\n';}
GenerateAbsReportTitleRow(){
local -a headers=('QPKG name:' 'Installed?' 'Acceptable QPKG name abbreviations and aliases:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${headers[1]}" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "${headers[2]}" "$r_report_qpkg_abbreviations_column_width"
fi
printf '\n';}
_GenerateAbsReportDataRow_(){
local -a column_vars=(abs auxiliary installed name)
local auxiliary_column=installed
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
local mode=''
local req_alert=false
local req_attention=false
local req_notice=false
if IsQpkgMissing;then
mode=highlight
req_alert=true
/bin/touch "$r_report_flags_path"/status-missing
elif IsNtValidQpkgInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
abs=$(AddSeparators "$(GetQpkgDbAbbrvs "$qpkg_name")")
case $mode in
mute)
if IsQpkgProhibited;then
auxiliary='prohibited package'
elif ! IsQpkgDbMinOSVerOk ||! IsQpkgDbMaxOSVerOk;then
auxiliary="incompatible $(GetOsName) version"
elif ! IsQpkgDbMinRAMOk;then
auxiliary='insufficient installed RAM'
fi
if [[ $auxiliary != false ]];then
auxiliary_msg=$(FormatReportField "not installable, $auxiliary" alert_mute)
else
abs_msg=$(FormatReportField "$abs" normal_mute)
fi
installed_msg=$(FormatReportField false mute);;
highlight)
abs_msg=$(FormatReportField "$abs" normal_notice)
auxiliary_msg=$(FormatReportField missing alert);;
*)abs_msg=$(FormatReportField "$abs" normal)
installed_msg=$(FormatReportField true)
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/state-notinstallable
elif [[ $req_notice = true ]];then
name_msg=$(FormatReportField "$name" notice)
/bin/touch "$r_report_flags_path"/req-notice
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$installed_msg|$abs_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$abs_msg" "$r_report_qpkg_abbreviations_column_width"
fi
printf '\n';}
GenerateDepsReportTitleRow(){
local -a headers=('QPKG name:' 'Dependencies:' 'Optionals:' 'Prohibited?' 'Installed?' 'Enabled?' 'Complete?' 'Managed?' 'Signed?' 'Min. RAM:' 'Min. OS:' 'Max. OS:' 'Installed QPKG author:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${headers[1]}" "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth "${headers[2]}" "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth "${headers[3]}" "$r_report_qpkg_is_prohibited_column_width"
FormatReportFieldWidth "${headers[4]}" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "${headers[5]}" "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth "${headers[6]}" "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth "${headers[7]}" "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth "${headers[8]}" "$r_report_qpkg_is_signed_column_width"
FormatReportFieldWidth "${headers[9]}" "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth "${headers[10]}" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "${headers[11]}" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "${headers[12]}" "$r_report_lazy_column_width"
fi
printf '\n';}
_GenerateDepsReportDataRow_(){
local a=''
local -a column_vars=(author auxiliary complete deps enabled installed managed max_os min_os min_ram name opt_deps prohibited signed)
local auxiliary_column=deps
local dep_name=''
local deps_raw=$(GetQpkgDbDependencies "$qpkg_name")
local opt_deps_raw=$(GetQpkgDbOptDependencies "$qpkg_name")
local mode=''
local req_alert=false
local req_attention=false
local req_notice=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
author=$(GetQpkgAuthor)
max_os=$(GetQpkgDbMaxOSVer "$name")
min_os=$(GetQpkgDbMinOSVer "$name")
min_ram=$(GetQpkgDbMinRAM "$name")
IsQpkgRepoSelfManaged &&managed=true
IsQpkgEnabled "$name" &&enabled=true
IsQpkgComplete "$name" &&complete=true
IsQpkgSigned "$name" &&signed=true
IsQpkgProhibited "$name" &&prohibited=true
[[ -z $deps_raw ]]&&deps_raw=none
[[ -z $opt_deps_raw ]]&&opt_deps_raw=none
[[ -n $max_os &&$max_os != none &&${#max_os} -eq 3 ]]&&max_os=${max_os:0:1}.${max_os:1:1}.${max_os:2:1}
[[ -n $min_os &&$min_os != none &&${#min_os} -eq 3 ]]&&min_os=${min_os:0:1}.${min_os:1:1}.${min_os:2:1}
[[ $min_ram != none ]]&&min_ram=$(FormatAsThous "$min_ram")kB
/bin/touch "$r_report_flags_path"/deps
if IsQpkgMissing;then
mode=missing
req_alert=true
elif IsValidQpkgInstalled;then
mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
mode=author
req_attention=true
/bin/touch "$r_report_flags_path"/status-wrongauthor
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
case $mode in
author)
for a in "${column_vars[@]}";do
case $a in
author)
author_msg=$(FormatReportField "$author" attention_highlight);;
auxiliary)
auxiliary_msg=$(FormatReportField 'author incompatible' attention_highlight);;
name)
:;;
*)local ${a}_msg="$(FormatReportField N/A highlight)"
esac
done;;
missing)
auxiliary_msg=$(FormatReportField missing alert);;
mute)
deps=''
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]]&&deps+=' '
deps+=$dep_name
done
else
deps=$deps_raw
fi
opt_deps=''
if [[ $opt_deps_raw != none ]];then
for dep_name in $opt_deps_raw;do
[[ -n $opt_deps ]]&&opt_deps+=' '
opt_deps+=$dep_name
done
else
opt_deps=$opt_deps_raw
fi
/bin/touch "$r_report_flags_path"/na
author_msg=$(FormatReportField N/A mute)
deps_msg=$(FormatReportField "${deps// /, }" mute)
opt_deps_msg=$(FormatReportField "${opt_deps// /, }" mute)
enabled_msg=$(FormatReportField N/A mute)
installed_msg=$(FormatReportField "$installed" mute)
complete_msg=$(FormatReportField N/A mute)
managed_msg=$(FormatReportField N/A mute)
signed_msg=$(FormatReportField N/A mute)
if ! IsQpkgProhibited "$qpkg_name";then
prohibited_msg=$(FormatReportField "$prohibited" mute)
else
prohibited_msg=$(FormatReportField "$prohibited" attention_highlight)
req_attention=true
fi
if IsQpkgDbMaxOSVerOk "$qpkg_name";then
max_os_msg=$(FormatReportField "$max_os" mute)
else
max_os_msg=$(FormatReportField "$max_os" attention_highlight)
req_attention=true
fi
if IsQpkgDbMinOSVerOk "$qpkg_name";then
if [[ $min_os != none ]];then
min_os_msg=$(FormatReportField "$min_os" mute)
else
min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true
fi
else
min_os_msg=$(FormatReportField "$min_os" attention_highlight)
req_attention=true
fi
if IsQpkgDbMinRAMOk "$qpkg_name";then
min_ram_msg=$(FormatReportField "$min_ram" mute)
else
min_ram_msg=$(FormatReportField "$min_ram" attention_highlight)
req_attention=true
fi;;
*)author_msg=$(FormatReportField "$author" ok)
deps=''
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]]&&deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
req_notice=true
fi
done
else
deps=$deps_raw
fi
deps_msg=$(FormatReportField "${deps// /, }")
opt_deps=''
if [[ $opt_deps_raw != none ]];then
for dep_name in $opt_deps_raw;do
[[ -n $opt_deps ]]&&opt_deps+=' '
if IsValidQpkgInstalled "$dep_name"&&IsQpkgEnabled "$dep_name";then
opt_deps+=$(TextBrightGreen "$dep_name")
else
opt_deps+=$dep_name
fi
done
else
opt_deps=$opt_deps_raw
fi
opt_deps_msg=$(FormatReportField "${opt_deps// /, }")
if ! IsQpkgProhibited "$qpkg_name";then
prohibited_msg=$(FormatReportField "$prohibited")
else
prohibited_msg=$(FormatReportField "$prohibited" notice)
req_alert=true
fi
if IsQpkgEnabled;then
enabled_msg=$(FormatReportField "$enabled" ok)
else
enabled_msg=$(FormatReportField "$enabled" notice)
req_alert=true
fi
installed_msg=$(FormatReportField true ok)
if IsQpkgComplete;then
complete_msg=$(FormatReportField "$complete" ok)
else
complete_msg=$(FormatReportField "$complete" notice)
req_alert=true
fi
if IsQpkgRepoSelfManaged;then
managed_msg=$(FormatReportField "$managed" ok)
else
managed_msg=$(FormatReportField "$managed" highlight)
fi
if IsQpkgDbMaxOSVerOk;then
if [[ $max_os != none ]];then
max_os_msg=$(FormatReportField "$max_os" ok)
else
max_os_msg=$(FormatReportField "$max_os")
fi
else
max_os_msg=$(FormatReportField "$max_os" alert)
req_alert=true
fi
if IsQpkgDbMinOSVerOk;then
if [[ $min_os != none ]];then
min_os_msg=$(FormatReportField "$min_os" ok)
else
min_os_msg=$(FormatReportField "$min_os")
fi
else
min_os_msg=$(FormatReportField "$min_os" alert)
req_alert=true
fi
if IsQpkgDbMinRAMOk;then
if [[ $min_ram != none ]];then
min_ram_msg=$(FormatReportField "$min_ram" ok)
else
min_ram_msg=$(FormatReportField "$min_ram")
fi
else
min_ram_msg=$(FormatReportField "$min_ram" alert)
req_alert=true
fi
if IsOsCanManageSignedPackages;then
if [[ $signed = true ]];then
signed_msg=$(FormatReportField "$signed" ok)
else
signed_msg=$(FormatReportField "$signed" alert)
req_alert=true
fi
else
signed_msg=$(FormatReportField N/A ok)
fi
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/state-notinstallable
elif [[ $req_notice = true ]];then
name_msg=$(FormatReportField "$name" notice)
/bin/touch "$r_report_flags_path"/req-notice
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$deps_msg|$opt_deps_msg|$prohibited_msg|$installed_msg|$enabled_msg|$complete_msg|$managed_msg|$signed_msg|$min_ram_msg|$min_os_msg|$max_os_msg|$author_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$deps_msg" "$r_report_qpkg_dependencies_column_width"
FormatReportFieldWidth "$opt_deps_msg" "$r_report_qpkg_opt_dependencies_column_width"
FormatReportFieldWidth "$prohibited_msg" "$r_report_qpkg_is_prohibited_column_width"
FormatReportFieldWidth "$installed_msg" "$r_report_qpkg_is_installed_column_width"
FormatReportFieldWidth "$enabled_msg" "$r_report_qpkg_is_enabled_column_width"
FormatReportFieldWidth "$complete_msg" "$r_report_qpkg_is_complete_column_width"
FormatReportFieldWidth "$managed_msg" "$r_report_qpkg_is_managed_column_width"
FormatReportFieldWidth "$signed_msg" "$r_report_qpkg_is_signed_column_width"
FormatReportFieldWidth "$min_ram_msg" "$r_report_qpkg_min_ram_column_width"
FormatReportFieldWidth "$min_os_msg" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "$max_os_msg" "$r_report_qpkg_os_version_column_width"
FormatReportFieldWidth "$author_msg" "$r_report_lazy_column_width"
fi
printf '\n';}
GenerateFeaturesReportTitleRow(){
local -a headers=('QPKG name:' 'Independ?' 'Optional?' 'Depend?' 'Enhanced?' 'CanBack?' 'CanClean?' 'StartUpd?' 'AutoUpdate?' 'LiveTest?' 'UniqUnpack?')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "${headers[1]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${headers[2]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${headers[3]}" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "${headers[4]}" "$r_report_qpkg_is_enhanced_column_width"
FormatReportFieldWidth "${headers[5]}" "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth "${headers[6]}" "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth "${headers[7]}" "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth "${headers[8]}" "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth "${headers[9]}" "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth "${headers[10]}" "$r_report_lazy_column_width"
fi
printf '\n';}
_GenerateFeaturesReportDataRow_(){
local a=''
local -a column_vars=(active_test autoupdate auxiliary backup clean dependent enhanced independent name optional restart_to_update uniqueunpack)
local auxiliary_column=independent
local mode=''
local req_alert=false
local req_attention=false
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
name=$qpkg_name
if IsQpkgMissing;then
mode=missing
req_alert=true
elif IsValidQpkgInstalled;then
mode=normal
elif IsQpkgInstalled&&IsNtQpkgAuthorOk;then
mode=author
req_attention=true
else
mode=mute
fi
case $mode in
author)
auxiliary='author incompatible'
auxiliary_msg=$(FormatReportField "$auxiliary" attention_highlight);;
missing)
auxiliary=missing
auxiliary_msg=$(FormatReportField "$auxiliary" alert);;
mute)
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
autoupdate=N/A
IsQpkgDbCanBackup &&backup=true
IsQpkgDbCanClean &&clean=true
IsQpkgDbIndependent &&independent=true
IsQpkgDbDependent &&dependent=true
IsQpkgDbOptional &&optional=true
if IsQpkgDbCanRestartToUpdate;then
restart_to_update=true
elif [[ $name = sherpa ]];then
restart_to_update=true
fi
IsQpkgDbSherpaCompatible &&enhanced=true
IsQpkgDbUniqueUnpack &&uniqueunpack=true
for a in "${column_vars[@]}";do
case $a in
auxiliary)
:;;
*)local ${a}_msg="$(FormatReportField "${!a}" mute)"
esac
done;;
*)auxiliary=''
auxiliary_msg=''
[[ $(GetQpkgDbActiveTest) = builtin ]]&&active_test=true
if IsValidQpkgInstalled&&IsQpkgDbCanRestartToUpdate;then
IsQpkgAutoUpdate &&autoupdate=true
elif [[ $name = sherpa ]];then
autoupdate=true
else
autoupdate=N/A
/bin/touch "$r_report_flags_path"/na
fi
IsQpkgDbCanBackup &&backup=true
IsQpkgDbCanClean &&clean=true
IsQpkgDbIndependent &&independent=true
IsQpkgDbDependent &&dependent=true
IsQpkgDbOptional &&optional=true
if IsQpkgDbCanRestartToUpdate;then
restart_to_update=true
elif [[ $name = sherpa ]];then
restart_to_update=true
fi
IsQpkgDbSherpaCompatible &&enhanced=true
IsQpkgDbUniqueUnpack &&uniqueunpack=true
for a in "${column_vars[@]}";do
case $a in
auxiliary)
:;;
*)case ${!a} in
true|N/A)
local ${a}_msg="$(FormatReportField "${!a}")";;
*)local ${a}_msg="$(FormatReportField "${!a}" highlight)"
esac
esac
done
esac
[[ -n $auxiliary_msg ]]&&eval "${auxiliary_column}_msg=\"$auxiliary_msg\""
if [[ $req_alert = true ]];then
name_msg=$(FormatReportField "$name" alert)
/bin/touch "$r_report_flags_path"/req-alert
elif [[ $req_attention = true ]];then
name_msg=$(FormatReportField "$name" attention_highlight)
/bin/touch "$r_report_flags_path"/req-attention
elif [[ $mode = mute ]];then
name_msg=$(FormatReportField "$name" mute)
else
name_msg=$(FormatReportField "$name")
fi
if IsOsCanAutowidthTableColumns;then
printf '%s' "$name_msg|$independent_msg|$optional_msg|$dependent_msg|$enhanced_msg|$backup_msg|$clean_msg|$restart_to_update_msg|$autoupdate_msg|$active_test_msg|$uniqueunpack_msg"
else
FormatReportFieldWidth "$name_msg" "$r_report_qpkg_name_column_width"
FormatReportFieldWidth "$independent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$optional_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$dependent_msg" "$r_report_qpkg_tier_column_width"
FormatReportFieldWidth "$enhanced_msg" "$r_report_qpkg_is_enhanced_column_width"
FormatReportFieldWidth "$backup_msg" "$r_report_qpkg_can_backup_column_width"
FormatReportFieldWidth "$clean_msg" "$r_report_qpkg_can_clean_column_width"
FormatReportFieldWidth "$restart_to_update_msg" "$r_report_qpkg_can_start_to_update_column_width"
FormatReportFieldWidth "$autoupdate_msg" "$r_report_qpkg_auto_update_column_width"
FormatReportFieldWidth "$active_test_msg" "$r_report_qpkg_active_test_builtin_column_width"
FormatReportFieldWidth "$uniqueunpack_msg" "$r_report_lazy_column_width"
fi
printf '\n';}
GenerateBacksReportTitleRow(){
local -a headers=('Backup file:' 'Size in bytes:' 'Backup date:')
if IsOsCanAutowidthTableColumns;then
(
IFS='|'
printf '%s' "${headers[*]}"
)
else
FormatReportFieldWidth "${headers[0]}" "$r_report_file_name_column_width"
FormatReportFieldWidth "${headers[1]}" "$r_report_file_bytes_column_width"
FormatReportFieldWidth "${headers[2]}" "$r_report_file_change_date_column_width"
fi
printf '\n';}
_GenerateBacksReportItemLine_(){
local -a column_vars=(epoch_time file_bytes file_name)
local mode=''
for a in "${column_vars[@]}";do
local ${a}=false
local ${a}_msg=''
done
epoch_time=${1:-0}
file_name=${2:-}
file_bytes=$(FormatAsThous "${3:-0}")
if [[ ${epoch_time%.*} -lt $(/bin/date --date="${4:-'1 week ago'}" +%s) ]];then
mode=highlight
/bin/touch "$r_report_flags_path"/backup-file-old
else
mode=normal
/bin/touch "$r_report_flags_path"/backup-file-ok
fi
case $mode in
normal)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")")
file_bytes_msg=$(FormatReportField "$file_bytes")
file_name_msg=$(FormatReportField "$file_name" normal);;
highlight)
epoch_time_msg=$(FormatReportField "$(ConvertSecondsToFullDate "$epoch_time")" notice)
file_bytes_msg=$(FormatReportField "$file_bytes" oops)
file_name_msg=$(FormatReportField "$file_name" notice)
esac
if IsOsCanAutowidthTableColumns;then
printf '%s' "$file_name_msg|$file_bytes_msg|$epoch_time_msg"
else
FormatReportFieldWidth "$file_name_msg" "$r_report_file_name_column_width"
FormatReportFieldWidth "$file_bytes_msg" "$r_report_file_bytes_column_width"
FormatReportFieldWidth "$epoch_time_msg" "$r_report_file_change_date_column_width"
fi
printf '\n';}
FormatReportField(){
local a=''
local b=''
case ${2:-blank} in
alert)
a=$(TextBrightRedBlink "$r_chars_alert")
b=$(TextBrightRedBlink "${1:-}");;
notice)
a=$(TextBrightRed "$r_chars_alert")
b=$(TextBrightRed "${1:-}");;
normal_notice)
a=$(TextBrightRed "$r_chars_normal")
b=$(TextBrightRed "${1:-}");;
oops)
a=$r_chars_blank
b=$(TextBrightRed "${1:-}");;
attention_highlight)
a=$(TextBrightOrange "$r_chars_attention")
b=$(TextBrightOrange "${1:-}");;
highlight)
a=$r_chars_blank
b=$(TextBrightOrange "${1:-}");;
normal_ok)
a=$r_chars_normal
b=$(TextBrightGreen "${1:-}");;
ok)
a=$r_chars_blank
b=$(TextBrightGreen "${1:-}");;
normal_mute)
a=$(TextDarkGrey "$r_chars_normal")
b=$(TextDarkGrey "${1:-}");;
alert_mute)
a=$(TextDarkGrey "$r_chars_alert")
b=$(TextDarkGrey "${1:-}");;
mute)
a=$r_chars_blank
b=$(TextDarkGrey "${1:-}");;
normal)
a=$r_chars_normal
b=$1;;
*)a=$r_chars_blank
b=$1
esac
printf '%s' "${a}${b}";}
FormatReportFieldWidth(){
[[ -n ${1:-} &&-n ${2:-} ]]||return
[[ $2 -ge 0 ]]||return
printf "%-$(($(LenANSIDiff "$1")+$2+r_report_column_spacing))s" "$1";}
DisplayAsHelpTitle(){
printf '\n%s\n' "${r_chars_bullet}$(Capitalise "${1:-}"|tr -s ' ')";}
DisplayAsHelpTitleHighlighted(){
printf '\n%s\n' "$(TextBrightOrange "${r_chars_bullet}$(Capitalise "${1:-}")")";}
DisplayAsIndentActionResultDurationReason(){
[[ -n ${1:-} &&-n ${2:-} ]]||return
local action=''
local duration=''
case $1 in
disableau)
action='disable auto-update';;
enableau)
action='enable auto-update';;
*)action=$1
esac
[[ -n ${3:-} ]]&&duration=$(ConvertMillisecondsToDuration "$3")
printf "%${r_report_action_result_indent}s" ''
if [[ -z ${4:-} ]];then
printf '%s %s%s' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")"
else
printf '%s %s%s (%s)' "$(Lowercase "$action")" "$2" "$([[ -n $duration ]]&&printf ' in %s' "$duration")" "$4"
fi
printf '\n';}
EraseThisLine(){
[[ ${useropt_verbose:=false} = false ]]&&printf '\033[2K\r'
}>&2
Display(){
if [[ -z ${1:-} ]];then
printf '\n'
else
printf '%s\n' "$1"
fi;}
DisplayWait(){
printf '%s' "${1:-}";}
ShowHelpActions(){
DisableDebugToArchiveAndFile
DisplayProcReport actions
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these QPKGs (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'clean local repository files from these QPKGs (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these QPKGs. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these QPKGs. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all required application dependencies are installed' fix
DisplayAsProjSynIndentExam 'install these QPKGs' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'reactivate these QPKGs (this will upgrade internal applications where-supported and enabled)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these QPKGs ('install' QPKGs, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these QPKGs' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam "re\"sign\" these QPKGs (unsign QPKGs, then sign them again)" "resign $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "re-sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these QPKGs' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these QPKGs (this will force-upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all QPKGs can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpActionsAll(){
DisableDebugToArchiveAndFile
DisplayProcReport 'all actions'
{
ShowHelpBasic
DisplayAsHelpTitle "the 'all' group applies to all QPKGs. If $(ShowAsAction) is 'install all' then all available QPKGs will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all QPKGs (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all QPKGs (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all QPKGs' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all QPKGs. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on QPKG activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all QPKGs. QPKGs must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on QPKG activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (this will upgrade internal applications where-supported and enabled)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all QPKGs where backup files exist ('install' QPKGs and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all QPKGs' 'reinstall all'
DisplayAsProjSynIndentExam "re\"sign\" all QPKGs (unsign QPKGs, then sign them again)" 'resign all'
DisplayAsProjSynIndentExam '' 're-sign all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'status all'
DisplayAsProjSynIndentExam 'uninstall all QPKGs' 'uninstall all'
DisplayAsProjSynIndentExam 'upgrade all QPKGs (and internal applications where-supported)' 'upgrade all'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpBackupLocation(){
DisplayAsSynExam 'the backup location can be accessed by running' "cd $r_qpkg_bu_path"
return 0;}
ShowHelpBasic(){
DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0;}
ShowHelpBasicExamples(){
{
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show QPKGs'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')"
}>"$r_report_output_pathfile"
ShowReport
return 0;}
ShowHelpGroups(){
DisableDebugToArchiveAndFile
DisplayProcReport groups
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only active QPKGs' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only disabled QPKGs' "$(ShowAsAction) disabled"
DisplayAsProjSynIndentExam 'select only enabled QPKGs' "$(ShowAsAction) enabled"
DisplayAsProjSynIndentExam 'select only inactive QPKGs' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installable QPKGs' "$(ShowAsAction) installable"
DisplayAsProjSynIndentExam 'select only installed QPKGs' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing QPKGs (these are partly-installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpIssue(){
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://community.qnap.com/t/qpkg-sherpa-a-mini-package-manager-cli/1081')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
Display
return 0;}
ShowHelpLists(){
DisableDebugToArchiveAndFile
DisplayProcReport lists
{
ShowHelpBasic
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available QPKGs' 'list all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed QPKGs' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only QPKGs that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam '' new
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
DisplayAsProjSynIndentExam '' versions
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpShow(){
DisableDebugToArchiveAndFile
DisplayProcReport show
{
ShowHelpBasic
DisplayAsHelpTitle "'show' usage examples:"
DisplayAsProjSynIndentExam 'show QPKG abbreviations' 'show abbreviations'
DisplayAsProjSynIndentExam '' 'show abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'show QPKG dependency report' 'show dependencies'
DisplayAsProjSynIndentExam '' 'show deps'
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'show QPKG repository assignments report' 'show repositories'
DisplayAsProjSynIndentExam '' 'show repos'
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show last session action results' 'show results'
DisplayAsProjSynIndentExam '' results
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpOptions(){
DisableDebugToArchiveAndFile
DisplayProcReport options
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpPackages(){
DisableDebugToArchiveAndFile
DisplayProcReport packages
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for QPKGs will go here:'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpProblems(){
DisableDebugToArchiveAndFile
DisplayProcReport problems
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'activate these QPKGs' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'clear local repository files from these QPKGs' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all required application dependencies are installed' fix
DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'find the live status of each application in these QPKGs' "status $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "s $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")"
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpUpgrades(){
DisableDebugToArchiveAndFile
DisplayProcReport upgrades
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for upgrading your QPKGs:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable QPKGs' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'find the live application status of upgradable QPKGs' 'status upgradable'
DisplayAsProjSynIndentExam '' 's upgradable'
DisplayAsProjSynIndentExam '' 's new'
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ShowHelpTips(){
DisableDebugToArchiveAndFile
DisplayProcReport tips
{
ShowHelpBasic
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) QPKGs" 'install all'
DisplayAsProjSynIndentExam "install all installable $(ShowAsTitleName) QPKGs" 'install installable'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive QPKGs' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
ShowHelpBackupLocation
}>"$r_report_output_pathfile"
EraseThisLine
ShowReport
return 0;}
ViewLogLast(){
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
EraseThisLine
if [[ -s $r_session_last_pathfile ]];then
DisplayFileInViewport "$r_session_last_pathfile" linenumbers:on
else
ShowAsError 'no last session log to display'
fi
return 0;}
ViewLogTail(){
DisableDebugToArchiveAndFile
ExtractTailFromLog
EraseThisLine
if [[ -s $r_session_tail_pathfile ]];then
DisplayFileInViewport "$r_session_tail_pathfile" linenumbers:on
else
ShowAsError 'no session log tail to display'
fi
return 0;}
DisplayFileInViewport(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nopfi"||return
/bin/sed -i '1{/^[[:space:]]*$/d};${/^[[:space:]]*$/d}' "$1"
[[ -s $1 ]]||return
local a=$1
shift
local arg=''
local -a b=("${@:-}")
local headers=false
local linenumbers=false
local linewrap=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local scrolltoend=false
for arg in "${b[@]}";do
[[ $arg = headers:on ]]&&headers=true
[[ $arg = scroll:toend ]]&&scrolltoend=true
[[ $arg = linenumbers:on ]]&&linenumbers=true
[[ $arg = linewrap:on ]]&&linewrap=true
done
echo
if [[ $useropt_verbose = true ]];then
if [[ -x /bin/cat ]];then
/bin/cat "$a"
return
else
echo "$(<$a)"
return
fi
fi
if [[ -x $r_gnu_less_cmd ]];then
options='--no-init --tilde --mouse --RAW-CONTROL-CHARS --shift=4 --quit-if-one-screen --quit-on-intr --redraw-on-quit '
if IsReportLargerThanViewport "$a"&&IsGnuLessSupportHeaders;then
[[ $headers = true ]]&&options+="--header=1,$(CalcReportFirstColumnWidth "$a") "
fi
[[ $scrolltoend = true ]]&&options+='+G '
[[ $linenumbers = true ]]&&options+='--LINE-NUMBERS '
[[ $linewrap = false ]]&&options+='--chop-long-lines '
LESSSECURE=1 $r_gnu_less_cmd "$options" --prompt "$prompt" "$a"
return
fi
if [[ -x /bin/cat ]];then
[[ $linenumbers = true ]]&&options='--number'
/bin/cat "$options" "$a"
return
elif [[ -x /bin/more ]];then
/bin/more "$a"
return
fi
echo "$(<$a)";}
CalcReportFirstColumnWidth(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nopfi"||return
[[ -s $1 ]]||return
local a=$(<"$1")
local b=''
local c=''
a=$(/bin/sed '/^#[[:space:]].*/d;/#$/d;s/[[:space:]]#[[:space:]].*//'<<<"$a")
a=$(/bin/sed 's/[[:space:]]*$//'<<<"$a")
a=$(/bin/sed '/^$/d'<<<"$a")
a=$(head -n1<<<"$a")
b=$(cut -f2 -d:<<<"$a"):
b=$(/bin/sed 's/^[[:space:]]*//'<<<"$b")
c=${a%%$b*}
printf '%s' "${#c}";}
PasteLogLast(){
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -s $r_session_last_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$(/bin/cat --number "$r_session_last_pathfile"|(exec 3<>/dev/tcp/termbin.com/9999;/bin/cat>&3;/bin/cat<&3;exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript warning 'user abort' ''
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no last session log found'
fi
return 0;}
PasteLogTail(){
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -s $r_session_tail_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$(/bin/cat --number "$r_session_tail_pathfile"|(exec 3<>/dev/tcp/termbin.com/9999;/bin/cat>&3;/bin/cat<&3;exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript warning 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no session log tail found'
fi
return 0;}
GetLogSessStartLine(){
local -i linenum=$(($(/bin/grep -n 'SCRIPT:.*started:' "$r_session_tail_pathfile"|/usr/bin/tail -n${1:-1}|head -n1|cut -d':' -f1)-1))
[[ $linenum -lt 1 ]]&&linenum=1
printf '%s' "$linenum";}
GetLogSessFinishLine(){
local -i linenum=$(($(/bin/grep -n 'SCRIPT:.*finished:' "$r_session_tail_pathfile"|/usr/bin/tail -n${1:-1}|cut -d':' -f1)+2))
[[ $linenum -eq 2 ]]&&linenum=3
printf '%s' "$linenum";}
ArchiveActiveSessLog(){
[[ -n ${session_active_log_pathfile:-} &&-s $session_active_log_pathfile ]]&&/bin/cat "$session_active_log_pathfile">>"$r_session_archive_log_pathfile";}
ArchivePriorSessLog(){
local f=''
for f in "$r_log_path"/session.*.active.log;do
if [[ -f $f &&$f != "$session_active_log_pathfile" ]];then
/bin/cat "$f">>"$r_session_archive_log_pathfile"
rm -f "$f"
fi
done
} 2>/dev/null
ResetActiveSessLog(){
rm -f "$session_active_log_pathfile"
} 2>/dev/null
ExtractPrevSessFromTail(){
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
local -i start_line=0
ExtractTailFromLog
if [[ -s $r_session_tail_pathfile ]];then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]];do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]]&&break
done
/bin/sed "$start_line,$end_line!d" "$r_session_tail_pathfile">"$r_session_last_pathfile"
else
rm -f "$r_session_last_pathfile"
fi
return 0
} 2>/dev/null
ExtractTailFromLog(){
if [[ -s $r_session_archive_log_pathfile ]];then
/usr/bin/tail -n${r_log_tail_lines} "$r_session_archive_log_pathfile">"$r_session_tail_pathfile"
else
rm -f "$r_session_tail_pathfile"
fi
return 0
} 2>/dev/null
InitActionForkCounters(){
MakePath "$r_action_counts_path" 'action fork counters'
proc_counts_path=$(/bin/mktemp -d "$r_action_counts_path"/"${FUNCNAME[1]}"_XXXXXX)
ConfirmVarIsDefined proc_counts_path "${proc_counts_path:-}" "$e_nopth"||return
EraseForkCountPaths
proc_done_fail_count_path=$proc_counts_path/done.fail.count
proc_done_ok_count_path=$proc_counts_path/done.ok.count
proc_queued_count_path=$proc_counts_path/queued.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_working_count_path=$proc_counts_path/working.count
MakePath "$proc_done_fail_count_path" 'forks completed failed count'
MakePath "$proc_done_ok_count_path" 'forks completed OK count'
MakePath "$proc_queued_count_path" 'forks queued count'
MakePath "$proc_skip_abort_count_path" 'forks skipped-aborted count'
MakePath "$proc_skip_error_count_path" 'forks skipped-error count'
MakePath "$proc_skip_ok_count_path" 'forks skipped-ok count'
MakePath "$proc_working_count_path" 'forks working count'
InitProgress;}
IncrementActionForkIndex(){
local a
((fork_index++))
printf -v a '%02d' "$fork_index"
proc_done_fail_pathfile=$proc_done_fail_count_path/$a
proc_done_ok_pathfile=$proc_done_ok_count_path/$a
proc_queued_pathfile=$proc_queued_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_working_pathfile=$proc_working_count_path/$a;}
RefreshActionForkCounts(){
done_fail_count=$(FileCountAll "$proc_done_fail_count_path")
done_ok_count=$(FileCountAll "$proc_done_ok_count_path")
queued_count=$(FileCountAll "$proc_queued_count_path")
skip_abort_count=$(FileCountAll "$proc_skip_abort_count_path")
skip_error_count=$(FileCountAll "$proc_skip_error_count_path")
skip_ok_count=$(FileCountAll "$proc_skip_ok_count_path")
working_count=$(FileCountAll "$proc_working_count_path")
skipper_count=$((skip_ok_count+skip_error_count+skip_abort_count))
worker_count=$((queued_count+working_count))
} &>/dev/null
RefreshDirSizeCount(){
[[ -d $dir_location ]]||exit
IsCriticalFile $r_gnu_find_cmd||exit
current_bytes=$($r_gnu_find_cmd "$dir_location" -type f -name '*.ipk' -exec /usr/bin/du --bytes --total --apparent-size {} + 2>/dev/null|/bin/grep total$|cut -f1)
[[ -z $current_bytes ]]&&current_bytes=0
} &>/dev/null
EraseForkCountPaths(){
ClearPath "$r_action_counts_path" "$proc_counts_path"
rmdir "$proc_counts_path"
[[ -e $r_abort_actions_pathfile ]]&&rm -f "$r_abort_actions_pathfile"
} &>/dev/null
InitProgress(){
fork_index=0
RefreshActionForkCounts;}
UpdateActionForkProgress(){
local a=''
RefreshActionForkCounts
[[ $useropt_verbose = false &&! -e $r_inhibit_display_pathfile ]]||return
a=$(PercFrac "$done_ok_count" "$skipper_count" "$done_fail_count" "$total_count")
if [[ $done_ok_count -gt 0 ]];then
[[ -n $a ]]&&a+=', '
a+=$(TextBrightGreen "$done_ok_count")' OK'
fi
if [[ $skipper_count -gt 0 ]];then
[[ -n $a ]]&&a+=', '
a+=$(TextBrightOrange "$skipper_count")' skipped'
fi
if [[ $done_fail_count -gt 0 ]];then
[[ -n $a ]]&&a+=', '
a+=$(TextBrightRed "$done_fail_count")' failed'
fi
if [[ $worker_count -gt 0 ]];then
[[ -n $a ]]&&a+=', '
a+=$(TextBrightYellow "$worker_count")' in-progress'
fi
[[ -n $a ]]&&ShowAsProc "${fork_progress_prefix:-}" "$a"
return 0
}>&2
UpdateDirSizeProgress(){
[[ $dir_bytes -gt 0 ]]||return
local perc_msg=''
local progress_msg=''
local -i stalled_seconds=0
local stalled_msg=''
local stalled_seconds_threshold=4
if [[ ${1:-} = final ]];then
current_bytes=$dir_bytes
else
RefreshDirSizeCount
[[ ${last_active_epoch:=0} -ne 0 ]]&&stalled_seconds=$(CalcAmountDiff "$(ConvertNowToSeconds)" "$last_active_epoch")
fi
perc_msg=$((200*(current_bytes)/(dir_bytes)%2+100*(current_bytes)/(dir_bytes)))%
[[ $current_bytes -lt $dir_bytes &&$perc_msg = '100%' ]]&&perc_msg=99%
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$dir_bytes")"))"
if [[ $stalled_seconds -ge $stalled_seconds_threshold ]];then
stalled_msg=' stalled for '
if [[ $stalled_seconds -lt 60 ]];then
stalled_msg+=$stalled_seconds' seconds'
else
stalled_msg+=$(ConvertSecondsToDuration "$stalled_seconds")
fi
if [[ $stalled_seconds -ge 90 ]];then
stalled_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stalled_seconds -ge 90 ]];then
stalled_msg=$(TextBrightRed "$stalled_msg")
elif [[ $stalled_seconds -ge 45 ]];then
stalled_msg=$(TextBrightOrange "$stalled_msg")
elif [[ $stalled_seconds -ge 20 ]];then
stalled_msg=$(TextBrightYellow "$stalled_msg")
fi
progress_msg+=$stalled_msg
fi
[[ ! -e $r_inhibit_display_pathfile ]]||return
ShowAsProc "$dir_size_progress_prefix" "$progress_msg"
return 0
}>&2
ShowQPKGsMissing(){
! QPKGs.AClistISmissing.IsSet||return 0
! QPKGs.ACreinstallISmissing.IsSet||return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for((i=0;i<=(${#packages[@]}-1);i++));do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit &&$((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b=' is'
c='it'
else
b='s are'
c='them'
fi
ShowAsNote "the $a QPKG${b} missing or broken. Please reinstall $c"
return 1;}
ShowQPKGsNewVers(){
! QPKGs.AClistISupgradable.IsSet||return 0
! QPKGs.ACupgradeISupgradable.IsSet||return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISupgradable:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISupgradable:Array))
fi
for((i=0;i<=(${#packages[@]}-1);i++));do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit &&$((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b='a '
c='version is'
else
c='versions are'
fi
ShowAsNote "${b}new QPKG $c available for $a"
return 1;}
CheckQPKGsConflicts(){
[[ $run_package_actions = false ]]||return 0
local a=''
if [[ -n ${r_base_qpkg_conflicts_with:-} ]];then
for a in "${r_base_qpkg_conflicts_with[@]}";do
if IsQpkgEnabled "$a";then
ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
return 1
fi
done
fi
return 0;}
CheckQPKGsWarnings(){
local a=''
if [[ -n ${r_base_qpkg_warnings:-} ]];then
for a in "${r_base_qpkg_warnings[@]}";do
if IsQpkgEnabled "$a";then
ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
return 1
fi
done
fi
return 0;}
ListQPKGsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
local b=''
local border_shown=false
for a in "${r_qpkg_actions[@]}";do
for b in ok er sk se sa;do
if QPKGs-AC${a}-${b}.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
case $b in
ok|sk)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;
se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) ";;
er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListIPKsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
local border_shown=false
for a in "${r_ipk_actions[@]}";do
if IPKs-AC${a}-ok.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) "
fi
if IPKs-AC${a}-er.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) "
fi
done
[[ $border_shown = true ]]&&DebugInfoMinSepr
FuncExit;}
ListPIPsActions(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
DebugInfoMinSepr
for a in "${r_pip_actions[@]}";do
PIPs-AC${a}-ok.IsAny &&DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny &&DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) "
done
DebugInfoMinSepr
FuncExit;}
ListQPKGsStates(){
[[ $useropt_debug = true ]]||return
FuncInit
local a=''
BuildExtendedQPKGsStates
DebugInfoMinSepr
for a in "${r_qpkg_is_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]]&&continue
if [[ $a = unknown ]];then
QPKGs-IS${a}.IsAny &&DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
else
QPKGs-IS${a}.IsAny &&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
fi
done
for a in "${r_qpkg_isnt_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]]&&continue
if [[ $a = ok ]];then
QPKGs-ISNT${a}.IsAny &&DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then
QPKGs-ISNT${a}.IsAny &&DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
else
QPKGs-ISNT${a}.IsAny &&DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
fi
done
for a in "${r_qpkg_transient_states[@]}";do
QPKGs-IS${a}.IsAny &&DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
done
DebugInfoMinSepr
FuncExit;}
BuildQPKGsTiers(){
FuncInit
CheckQPKGsTiers
if [[ $qpkgs_tiers_built = true ]];then
DebugAsDetect 'tiers are already built'
else
ShowAsProc tiers
GenerateQPKGsTiers
fi
LoadQPKGsTiers
FuncExit;}
InitQPKGsTiers(){
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ ! -s ${!b} ]]&&continue
rm -f "${!b}" 2>/dev/null
done
qpkgs_tiers_built=false;}
CheckQPKGsTiers(){
qpkgs_tiers_built=true
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ -s ${!b} ]]&&continue
qpkgs_tiers_built=false
break
done;}
GenerateQPKGsTiers(){
local previous=''
local qpkg_name=''
InitQPKGsTiers
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]]&&continue ||previous=$qpkg_name
SetQpkgIndex
if IsQpkgDbOptional;then
echo "$qpkg_name">>"$r_optional_qpkgs_list_pathfile"
elif IsQpkgDbDependent;then
echo "$qpkg_name">>"$r_dependent_qpkgs_list_pathfile"
else
echo "$qpkg_name">>"$r_independent_qpkgs_list_pathfile"
fi
done
qpkgs_tiers_built=true;}
LoadQPKGsTiers(){
[[ $qpkgs_tiers_built = true ]]||return
local a=''
local b=''
for a in "${r_qpkg_tiers[@]}";do
b=r_${a}_qpkgs_list_pathfile
[[ ! -s ${!b} ]]&&continue
QPKGs-GR${a}:Add "$(<${!b})"
done;}
CheckSystemLoad(){
FuncInit
if IsOsStartingPackages;then
ShowAsNote "$(GetOsName) is starting QPKGs, check again in a few minutes"
elif IsOsStarting;then
ShowAsNote "$(GetOsName) is still booting, check again in a few minutes"
elif IsOsStopping;then
ShowAsNote "$(GetOsName) is shutting-down"
elif IsOsStoppingPackages;then
ShowAsNote "$(GetOsName) is stopping QPKGs"
fi
if IsOsLoadAverageInsane;then
ShowAsWarn 'the NAS has an exceptionally-high system-load, recommend aborting and trying again later'
elif IsOsLoadAverageHigh;then
ShowAsWarn 'the NAS has an unusually-high system-load, so this may take a while'
elif IsOsLoadAverageElevated;then
ShowAsNote 'the NAS has an elevated system-load, so this may take a little longer than usual'
fi
FuncExit;}
BuildExtendedQPKGsStates(){
FuncInit
if [[ ${qpkgs_states_built:=false} = true ]];then
DebugAsDetect 'states are already built'
FuncExit;return
fi
local a=''
CheckSystemLoad
LoadDatabase
if [[ $(FileCountAll "$r_qpkg_states_path") -gt 0 ]];then
a=$r_qpkg_states_path/$(ls "$r_qpkg_states_path" -t|head -n1)
DebugAsInfo "comparison file (last modified QPKG state file): '$a'"
if IsFileNewer /etc/config/qpkg.conf "$a";then
DebugAsInfo "'/etc/config/qpkg.conf' is newer than the comparison file"
InitQPKGsStates
else
DebugAsInfo "'/etc/config/qpkg.conf' is older than the comparison file"
fi
fi
if [[ $(FileCountAll "$r_qpkg_states_path") -eq 0 ]];then
DebugAsInfo 'no QPKG state files found'
RefreshAndStoreQPKGsStates
fi
LoadQPKGsStates
ShowQPKGsMissing
ShowQPKGsNewVers
FuncExit;}
InitQPKGsStates(){
LoadObjects||return
FuncInit
local a=''
for a in "${r_qpkg_is_states[@]}";do
[[ $a = active ]]&&continue
IsFuncExist QPKGs-IS${a}:Init &&QPKGs-IS${a}:Init
done
for a in "${r_qpkg_isnt_states[@]}";do
[[ $a = active ]]&&continue
IsFuncExist QPKGs-ISNT${a}:Init &&QPKGs-ISNT${a}:Init
done
ClearPath "$r_temp_run_path"/qpkg "$r_qpkg_states_path"
qpkgs_states_built=false
FuncExit;}
RefreshAndStoreQPKGsStates(){
FuncInit
qpkg_name=''
ShowAsProc 'refresh QPKG states'
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgUpgradable;then
echo upgradable
else
echo notupgradable
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgInstallable;then
echo installable
else
echo notinstallable
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgMissing;then
echo missing
else
echo notmissing
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
if IsQpkgBackupExist;then
echo backedup
else
echo notbackedup
fi>>"$r_qpkg_states_path/$qpkg_name"
done &
wait 2>/dev/null
FuncExit;}
LoadQPKGsStates(){
FuncInit
local a=''
local b=''
qpkg_name=''
ShowAsProc 'load QPKG states'
for qpkg_name in $(QPKGs-GRall:Array);do
a=$r_qpkg_service_result_path/$qpkg_name.action
b=$r_qpkg_service_result_path/$qpkg_name.result
if [[ -s $a &&-s $b ]];then
case $(<$b) in
in-progress)
case $(<$a) in
start)
QPKGs-ISstarting:Add "$qpkg_name";;
restart)
QPKGs-ISrestarting:Add "$qpkg_name";;
stop)
QPKGs-ISstopping:Add "$qpkg_name"
esac;;
ok)
QPKGs-ISok:Add "$qpkg_name";;
failed)
QPKGs-ISNTok:Add "$qpkg_name"
esac
fi
a=$r_qpkg_states_path/$qpkg_name
[[ -s $a ]]||continue
for b in $(<$a);do
case $b in
backedup)
QPKGs-ISbackedup:Add "$qpkg_name";;
backupable)
:;;
installable)
QPKGs-ISinstallable:Add "$qpkg_name";;
missing)
QPKGs-ISmissing:Add "$qpkg_name"
QPKGs-ISok:Remove "$qpkg_name"
QPKGs-ISNTok:Add "$qpkg_name";;
notbackedup)
QPKGs-ISNTbackedup:Add "$qpkg_name";;
notbackupable)
:;;
notinstallable)
QPKGs-ISNTinstallable:Add "$qpkg_name";;
notmissing)
QPKGs-ISNTmissing:Add "$qpkg_name";;
notupgradable)
QPKGs-ISNTupgradable:Add "$qpkg_name";;
upgradable)
QPKGs-ISupgradable:Add "$qpkg_name"
esac
done
done
qpkgs_states_built=true
FuncExit;}
BuildQPKGsIsCanBackup(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanBackup "$qpkg_name" &&QPKGs-GRcanbackup:Add "$qpkg_name"
done
FuncExit;}
BuildQPKGsIsCanRestartToUpdate(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanRestartToUpdate "$qpkg_name" &&QPKGs-GRcanrestarttoupdate:Add "$qpkg_name"
done
FuncExit;}
BuildQPKGsIsCanClean(){
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgDbCanClean "$qpkg_name" &&QPKGs-GRcanclean:Add "$qpkg_name"
done
FuncExit;}
HelpAbbreviations(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
LoadDatabase
DisableDebugToArchiveAndFile
DisplayProcReport abbreviations
CreateReportPaths
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages)."
}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GenerateAbsReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateAbsReportDataRow_>"$r_report_rows_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>>"$r_report_output_pathfile"
fi
DisplayAsProjSynExam "example: to install $(FormatPackageName SABnzbd), $(FormatPackageName HeadPhones) and $(FormatPackageName nzbToMedia) all-at-once" 'install sab hp nzb2'>>"$r_report_output_pathfile"
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportBackups(){
FuncInit
local a=''
local b=''
local epoch_time=0
local -i file_bytes=0
local file_date=''
local file_name=''
local file_time=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport backups
CreateReportPaths
printf -v a '\n%s\n' "$(GenerateBacksReportTitleRow)"
if [[ -x $r_gnu_find_cmd ]];then
while read -r epoch_time file_name file_bytes;do
[[ -z $epoch_time ||-z $file_name ]]&&break
((n++))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than">"$r_report_rows_path/$n" &
done<<<"$($r_gnu_find_cmd "$r_qpkg_bu_path"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2>/dev/null|/usr/bin/sort)"
else
while read -r file_date file_time file_name file_bytes;do
[[ -z $file_date ||-z $file_name ]]&&break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$(/usr/bin/basename "$file_name")
((n++))
_GenerateBacksReportItemLine_ "$epoch_time" "$file_name" "$file_bytes" "$r_report_highlight_backups_older_than">"$r_report_rows_path/$n" &
done<<<"$(cd "$r_qpkg_bu_path" &&ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2>/dev/null|/bin/awk '{print $6" "$7" "$8" "$5}')"
fi
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
FuncExit;}
ReportDependencies(){
FuncInit
generate_report_headers=true
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport dependency
CreateReportPaths
! IsAnsiStrippingSupported &&colourful=false
printf -v a '\n%s\n' "$(GenerateDepsReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateDepsReportDataRow_>"$r_report_rows_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportFeatures(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport features
CreateReportPaths
! IsAnsiStrippingSupported &&colourful=false
printf -v a '\n%s\n' "$(GenerateFeaturesReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateFeaturesReportDataRow_>"$r_report_rows_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportHeadingsInfo>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportPackages(){
FuncInit
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport package
CreateReportPaths
{
ShowHelpBasic
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once."
}>"$r_report_output_pathfile"
printf -v a '\n%s\n' "$(GeneratePacksReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GeneratePacksReportDataRow_ "$qpkg_name">"$r_report_rows_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile"
fi
{
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
}>>"$r_report_output_pathfile"
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportRepos(){
FuncInit
generate_report_headers=true
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport repository
CreateReportPaths
printf -v a '\n%s\n' "$(GenerateReposReportTitleRow)"
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
SetQpkgIndex
_GenerateReposReportDataRow_>"$r_report_rows_path/$n" &
done
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
FuncExit;}
ReportStatuses(){
FuncInit
generate_report_headers=true
local a=''
local b=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport status
CreateReportPaths
for qpkg_name in $(QPKGs-GRall:Array);do
QPKGs-ACstatus-dn.Exist "$qpkg_name"||continue
((n++))
SetQpkgIndex
_GenerateStatusReportDataRow_>"$r_report_rows_path/$n" &
done
printf -v a '%s\n' "$(GenerateStatusReportTitleRow)"
m=$n
wait 2>/dev/null
for((n=1;n<=m;n++));do
b=$r_report_rows_path/$n
[[ -s $b ]]&&printf -v a '%s\n' "$a$(<$b)"
done
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s' "$a"
fi>"$r_report_output_pathfile"
GenerateReportInfo>>"$r_report_output_pathfile"
fi
EraseThisLine
ShowReport
ListQPKGsStates
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_failed=false
FuncExit;}
ReportAllActionResults(){
local -i a=0
local action=''
local -i b=0
local -i c=0
local -i d=0
local -i datetime=0
local -i duration=0
local -i e=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ $useropt_show_previous_action_results_report = true ]];then
show_action_results_failed=true
show_action_results_ok=true
show_action_results_skipped=true
fi
if [[ -s $r_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $datetime -gt 0 &&$duration -gt 0 ]];then
[[ $a -eq 0 ]]&&a=$datetime
b=$datetime
c=$duration
((d++))
fi
done<"$r_action_results_pathfile"
a=$(ConvertMillisecondsToSeconds "$a")
b=$(ConvertMillisecondsToSeconds "$b")
c=$(ConvertMillisecondsToSeconds "$c")
[[ $b -gt 0 ]]&&e=$((b+c+1))
if [[ $show_action_results_ok = true ||$show_action_results_skipped = true ||$show_action_results_failed = true ||$show_action_results_zero = true ]];then
{
DisplayAsHelpTitle "package action$(Pluralise "$d") started @ $(ConvertSecondsToTime "$a"), ended @ $(ConvertSecondsToTime "$e"), elapsed = $(ConvertSecondsToDuration "$(CalcAmountDiff "$a" "$e")")"
[[ $show_action_results_ok = true ]]&&ReportActionResults ok
[[ $show_action_results_skipped = true ]]&&ReportActionResults sk
[[ $show_action_results_failed = true ]]&&ReportActionResults er
[[ $show_action_results_zero = true ]]&&ShowZeroQpkgs
}>"$r_report_output_pathfile"
ShowReport
fi
else
ShowAsDone 'no action results to report'
fi;}
ReportActionResults(){
local action=''
local -i count=0
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ -s $r_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "${1:-}" ]]||[[ $1 = sk &&($result = se ||$result = sa) ]];then
[[ $action = status &&$useropt_show_previous_action_results_report = false ]]&&continue
((count++))
[[ $count -gt 1 ]]&&break
fi
done<"$r_action_results_pathfile"
if [[ $count -eq 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "this package action completed $(TextBrightGreen OK):";;
sk)
DisplayAsHelpTitle "this package action was $(TextBrightOrange skipped) $(Parenthesise 'and why'):";;
er)
DisplayAsHelpTitle "this package action $(TextBrightRed failed) $(Parenthesise 'and why'):"
esac
elif [[ $count -gt 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "these package actions completed $(TextBrightGreen OK):";;
sk)
DisplayAsHelpTitle "these package actions were $(TextBrightOrange skipped) $(Parenthesise 'and why'):";;
er)
DisplayAsHelpTitle "these package actions $(TextBrightRed failed) $(Parenthesise 'and why'):"
esac
fi
if [[ $count -ge 1 ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "${1:-}" ]]||[[ $1 = sk &&($result = se ||$result = sa) ]];then
[[ $action = status &&$useropt_show_previous_action_results_report = false ]]&&continue
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason" "$package_type" "$quantity"
fi
done<"$r_action_results_pathfile"
fi
fi
if [[ $count -eq 0 ]];then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK).";;
sk)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped).";;
er)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
return 0;}
GenerateReportInfo(){
[[ $useropt_show_report_info = true ]]||return
DisplayAsHelpTitle 'report information:'
local a=''
a=$({
if [[ -e "$r_report_flags_path"/status-missing ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed missing)" 'QPKG is missing from its installation path. Please reinstall it'
fi
if [[ -e "$r_report_flags_path"/req-alert ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" 'QPKG is prevented from working correctly'
fi
if [[ -e "$r_report_flags_path"/state-disabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed disabled)" "QPKG won't be started at bootup. Enable it first, then start it"
fi
if [[ -e "$r_report_flags_path"/result-aborted ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed aborted))" 'previous action was aborted'
fi
if [[ -e "$r_report_flags_path"/result-failed ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed failed))" 'previous action failed'
fi
if [[ -e "$r_report_flags_path"/status-inactive ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed inactive)" 'application process is dead or not-started. Try starting it'
fi
if [[ -e "$r_report_flags_path"/backup-file-old ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" "QPKG backup file was updated more-than $r_report_highlight_backups_older_than."
fi
if [[ -e "$r_report_flags_path"/state-upgradable ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange upgradable)" 'a new QPKG version is available'
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange new))" 'the new QPKG version'
fi
if [[ -e "$r_report_flags_path"/status-wrongauthor ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange 'author incompatible')" "QPKG is a non-compatible, identically-named duplicate of a $(ShowAsTitleName) QPKG"
fi
if [[ -e "$r_report_flags_path"/req-attention ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" "QPKG cannot be managed with $(ShowAsTitleName)"
fi
if [[ -e "$r_report_flags_path"/state-notinstallable ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" 'QPKG cannot be installed'
fi
if [[ -e "$r_report_flags_path"/action-pending ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange pending)" 'QPKG is waiting to run an action. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-stopping ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange stopping)" 'QPKG is stopping. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-slow ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange slow)" 'application is alive, but was slow to respond to the status request. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-starting ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange starting)" 'QPKG is starting. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/result-in-progress ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange in-progress))" 'an action is in-progress. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-unknown ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange unknown)" 'application status could not be determined'
fi
if [[ -e "$r_report_flags_path"/repo-other ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '* URL')" 'another repository is managing this QPKG'
fi
if [[ -e "$r_report_flags_path"/state-enabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen enabled)" 'QPKG will be started at bootup'
fi
if [[ -e "$r_report_flags_path"/result-ok ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightGreen OK))" 'previous action was successful'
fi
if [[ -e "$r_report_flags_path"/status-active ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen active)" 'application is alive (and responsive if a daemon)'
fi
if [[ -e "$r_report_flags_path"/repo-sherpa ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen sherpa)" "$(ShowAsTitleName) is managing this QPKG"
fi
if [[ -e "$r_report_flags_path"/app-dynamic ]];then
DisplayAsIndentQuotedInfoItem dynamic 'application version is the latest available'
fi
if [[ -e "$r_report_flags_path"/app-static ]];then
DisplayAsIndentQuotedInfoItem static 'application version auto-update is disabled or unsupported'
fi
if [[ -e "$r_report_flags_path"/app-final ]];then
DisplayAsIndentQuotedInfoItem final 'application version is the last available'
fi
if [[ -e "$r_report_flags_path"/na ]];then
DisplayAsIndentQuotedInfoItem N/A 'not applicable'
fi
if [[ -e "$r_report_flags_path"/action-not-found ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey not-found)" 'action tracking files were not found'
fi
if [[ -e "$r_report_flags_path"/action-unsupported ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey unsupported)" 'action tracking is unsupported by this QPKG'
fi
})
if [[ -n $a ]];then
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s\n' "$a"
fi
fi
if [[ -e $r_report_flags_path/deps ]];then
DisplayAsHelpTitle "QPKG dependencies are automatically installed/started/stopped/restarted as-required by $(ShowAsTitleName)."
fi
if [[ $(FileCountSpec "$r_report_flags_path/backup-file-*") -gt 0 ]];then
DisplayAsIndentItem "backups are listed oldest-first."
DisplayAsIndentItem "all $(ShowAsTitleName) backup files are stored here: $r_qpkg_bu_path"
fi
DisplayAsProjSynIndentExam 'to disable this report information panel' 'report-info off';}
GenerateReportHeadingsInfo(){
[[ $useropt_show_report_info = true ]]||return
DisplayAsHelpTitle 'column headings:'
local a=''
a=$({
DisplayAsIndentQuotedInfoItem 'Independ?' 'is independent of other QPKGs'
DisplayAsIndentQuotedInfoItem 'Optional?' 'is an optional addon for another QPKG'
DisplayAsIndentQuotedInfoItem 'Depend?' 'is dependent on other QPKGs'
DisplayAsIndentQuotedInfoItem 'Enhanced?' "$(ShowAsTitleName) enhanced service actions are supported"
DisplayAsIndentQuotedInfoItem 'CanBack?' "application config 'backup' and 'restore' are supported"
DisplayAsIndentQuotedInfoItem 'CanClean?' "application 'clean' is supported"
DisplayAsIndentQuotedInfoItem 'StartUpd?' 'application restart-to-update is supported'
DisplayAsIndentQuotedInfoItem 'AutoUpdate?' 'application restart-to-update is enabled'
DisplayAsIndentQuotedInfoItem 'LiveTest?' "has a built-in 'status' check, and can test for daemon live status"
DisplayAsIndentQuotedInfoItem 'UniqUnpack?' "QPKG unpacks to a unique path during 'install'/'reinstall'/'upgrade'"
})
[[ -n $a ]]||return
if IsOsCanAutowidthTableColumns;then
printf '%s' "$a"|Tableise
else
printf '%s\n' "$a"
fi;}
ShowReport(){
if [[ -s $r_report_output_pathfile ]];then
if [[ $generate_report_headers = true ]];then
DisplayFileInViewport "$r_report_output_pathfile" headers:on
else
DisplayFileInViewport "$r_report_output_pathfile"
fi
else
ShowAsError 'report not found'
fi;}
ShowVersionsList(){
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: $(ConvertAsSmartDate "$r_this_package_ver")"
Display "manager: $(ConvertAsSmartDate "$r_script_built_epoch")"
Display "objects: $(ConvertAsSmartDate "${r_objects_epoch:-not loaded}")"
Display "packages: $(ConvertAsSmartDate "${r_packages_epoch:-not loaded}")"
return 0;}
ShowQPKGLists(){
[[ ${packages_loaded:=false} = true ]]||return
local a=''
for a in "${r_qpkg_basic_states[@]}";do
case $a in
complete)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsComplete)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtComplete)"
ShowQPKGList AClist-to
return
fi;;
enabled)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsEnabled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtEnabled)"
ShowQPKGList AClist-to
return
fi;;
installed)
if QPKGs.AClistIS${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsIsValidInstalled)"
ShowQPKGList AClist-to
return
elif QPKGs.AClistISNT${a}.IsSet;then
QPKGs-AClist-to:Add "$(GetQpkgsNtInstalled)"
ShowQPKGList AClist-to
return
fi
esac
done
for a in "${r_qpkg_extended_states[@]}";do
case $a in
downloaded|signed)
:;;
*)if QPKGs.AClistIS${a}.IsSet;then
ShowQPKGList IS${a}
return
elif QPKGs.AClistISNT${a}.IsSet;then
ShowQPKGList ISNT${a}
return
fi
esac
done
for a in "${r_qpkg_is_groups[@]}";do
case $a in
canbackup|canrestarttoupdate)
:;;
*)if QPKGs.AClistGR${a}.IsSet;then
ShowQPKGList GR${a}
return
fi
esac
done
for a in "${r_qpkg_isnt_groups[@]}";do
case $a in
all|canbackup|canrestarttoupdate)
:;;
*)if QPKGs.AClistGRNT${a}.IsSet;then
ShowQPKGList GRNT${a}
return
fi
esac
done;}
ShowQPKGList(){
[[ -n ${1:-} ]]||return
local qpkg_name=''
DisableDebugToArchiveAndFile
EraseThisLine
if IsFuncExist QPKGs-$1.IsAny &&QPKGs-$1.IsAny;then
for qpkg_name in $(QPKGs-$1:Array);do
Display "$qpkg_name"
done
else
ShowAsError 'unable to find any matching QPKGs'
fi
return 0;}
SendParentCommand(){
WriteToMsgPipe run "${1:-}";}
SendPackageStateChange(){
[[ -n ${1:-} ]]||return
WriteToMsgPipe change "$1" package "$qpkg_name";}
SendActionStateUpdate(){
[[ -n ${1:-} ]]||return
WriteToMsgPipe update "$1" package "$qpkg_name";}
WriteToMsgPipe(){
[[ $action_msg_pipe_fd != none &&-e /proc/$$/fd/$action_msg_pipe_fd ]]&&echo "${1:-null}|${2:-null}|${3:-null}|${4:-null}">&$action_msg_pipe_fd
return 0;}
ReadFromMsgPipe(){
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value<&$action_msg_pipe_fd
eval "$1='${_msg1_key:-null}' $2='${_msg1_value:-null}' $3='${_msg2_key:-null}' $4='${_msg2_value:-null}'"
return 0;}
FindNextFD(){
local -i fd=-1
for fd in {10..100};do
if [[ ! -e /proc/$$/fd/$fd ]];then
printf '%s' "$fd"
return 0
fi
done
return 1;}
MarkActionForkAsQueued(){
IncrementActionForkIndex
[[ -n $proc_queued_pathfile ]]&&/bin/touch "$proc_queued_pathfile";}
MarkActionForkAsEntry(){
[[ -n ${proc_queued_pathfile:-} &&-e $proc_queued_pathfile ]]&&mv "$proc_queued_pathfile" "$proc_working_pathfile"
SendActionStateUpdate en;}
MarkActionForkAsExit(){
SendActionStateUpdate ex;}
MarkActionForkAsDoneOk(){
[[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_done_ok_pathfile ]]&&mv "$proc_working_pathfile" "$proc_done_ok_pathfile"
SendActionStateUpdate ok;}
MarkActionForkAsDoneError(){
[[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_done_fail_pathfile ]]&&mv "$proc_working_pathfile" "$proc_done_fail_pathfile"
SendActionStateUpdate er;}
MarkActionForkAsSkippedOk(){
[[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_ok_pathfile ]]&&mv "$proc_working_pathfile" "$proc_skip_ok_pathfile"
SendActionStateUpdate sk;}
MarkActionForkAsSkippedAbort(){
[[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_abort_pathfile ]]&&mv "$proc_working_pathfile" "$proc_skip_abort_pathfile"
SendActionStateUpdate sa;}
MarkActionForkAsSkippedError(){
[[ -n $proc_working_pathfile &&-e $proc_working_pathfile &&-n $proc_skip_error_pathfile ]]&&mv "$proc_working_pathfile" "$proc_skip_error_pathfile"
SendActionStateUpdate se;}
NoteIpkAcAsOk(){
IPKs-AC"$2"-to:Remove "${1:-}"
IPKs-AC"$2"-ok:Add "${1:-}"
return 0;}
NoteIpkAcAsEr(){
local a="failing request to $2 $(FormatPackageName "${1:-}")"
[[ -n ${3:-} ]]&&a+=' as '$3
DebugAsError "$a">&2
IPKs-AC"$2"-to:Remove "${1:-}"
IPKs-AC"$2"-er:Add "${1:-}"
return 0;}
ModPathToEntware(){
local a=''
local b=/opt/bin:/opt/sbin
if IsQpkgEnabled Entware;then
! [[ $PATH =~ $b ]]||return
a=$(/bin/sed "s|${b}:||"<<<"$PATH:")
export PATH=$b:${a%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $b ]]||return
a=$(/bin/sed "s|${b}:||"<<<"$PATH:")
export PATH=${a%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0;}
GetHardwareCPUInfo(){
if /bin/grep '^model name' /proc/cpuinfo &>/dev/null;then
/bin/grep '^model name' /proc/cpuinfo|head -n1|/bin/sed 's/^.*: //'|tr -s ' '
elif /bin/grep '^Processor name' /proc/cpuinfo &>/dev/null;then
/bin/grep '^Processor name' /proc/cpuinfo|head -n1|/bin/sed 's/^.*: //'|tr -s ' '
else
printf unknown
return 1
fi
return 0;}
GetHardwareCPUBenchmark(){
local a=''
local -i b=16
local -i c=-20
if [[ ! -x $r_gnu_dd_cmd ]];then
printf "unable to measure, GNU 'dd' is unavailable"
return 1
fi
if [[ -x $r_gnu_nice_cmd ]];then
a=$({ $r_gnu_nice_cmd -$c $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b|/bin/sha1sum>/dev/null;} 2>&1)
elif [[ -x /bin/renice ]];then
/bin/renice $c $$ &>/dev/null
a=$({ $r_gnu_dd_cmd if=/dev/zero bs=1MB count=$b|/bin/sha1sum>/dev/null;} 2>&1)
/bin/renice 0 $$ &>/dev/null
fi
a=$(/bin/grep copied<<<"$a"|cut -d, -f4)
a=${a//[[:blank:]]/}
if [[ -z $a ]];then
printf 'unable to measure'
return 1
fi
printf '%s' "$a"
return 0;}
GetHardwareVolumeBenchmark(){
local a=''
local b=10k
local -i c=-20
local d=$(GetUserDefVol)/zero
if [[ -d $(/usr/bin/dirname "$d") ]];then
[[ -e $d ]]&&rm -f "$d"
if [[ ! -x $r_gnu_dd_cmd ]];then
printf "unable to measure, GNU 'dd' is unavailable"
return 1
fi
if [[ -x $r_gnu_nice_cmd ]];then
a=$($r_gnu_nice_cmd -$c $r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$b 2>&1)
elif [[ -x /bin/renice ]];then
/bin/renice $c $$ &>/dev/null
a=$($r_gnu_dd_cmd if=/dev/zero of=$d bs=8k count=$b 2>&1)
/bin/renice 0 $$ &>/dev/null
fi
[[ -e $d ]]&&rm -f "$d"
fi
a=$(/bin/grep copied<<<"$a"|cut -d, -f4)
a=${a//[[:blank:]]/}
if [[ -z $a ]];then
printf 'unable to measure'
return 1
fi
printf '%s' "$a"
return 0;}
GetNasArch(){
/bin/uname -m;}
GetCpuDataWidth(){
local a=''
case $r_nas_arch in
x86_64|aarch64)
a=64b;;
i686|x86)
a=32b;;
armv7l)
case $r_nas_platform in
ARM_AL|ARM_MS)
a=32b;;
*)a=unknown
esac;;
armv5tel)
a=16b/32b;;
*)a=unknown
esac
printf '%s (%s)' "$r_nas_arch" "$a";}
GetOsKernelName(){
/bin/uname -o||/bin/uname
} 2>/dev/null
GetOsKernelVersion(){
/bin/uname -r;}
GetOsKernelPageSize(){
if [[ -x /sbin/hal_app ]];then
echo -n "$(/sbin/hal_app --get_pagesize)B"
else
/bin/grep KernelPageSize /proc/1/smaps|head -n1|cut -f2 -d':'|tr -d ' '|/bin/sed 's/kB/kiB/'
fi;}
GetHardwarePlatform(){
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf;}
GetUserDefVol(){
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info;}
GetRepoURLFromStoreID(){
[[ -n ${1:-} ]]||return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf;}
GetOsUptime(){
local n=$(</proc/uptime)
ConvertSecondsToDuration "${n%%.*}";}
GetUserLIBC(){
local a=$(/sbin/ldd --version|head -n1)
printf '%s' "${a:4}";}
GetUserLIBCCopyright(){
/sbin/ldd --version|/bin/grep -i copyright|/bin/sed 's/\$//';}
GetBusyBoxVersion(){
/bin/busybox|head -n1;}
GetBusyBoxCopyright(){
/bin/busybox|head -n2|tail -n1;}
GetBusyBoxFunctionCount(){
local a=''
a=$(/bin/busybox --list 2>/dev/null|/usr/bin/wc -l)
if [[ -n $a ]]&&IsNumber $a &&[[ $a -gt 0 ]];then
printf '%s' "$a"
else
a=$(/bin/busybox)
a=${a//[!\,]/}
printf '%s' "${#a}"
fi
} 2>/dev/null
GetOsSysLoadAverages(){
/usr/bin/uptime|/bin/sed 's/.*load average: //'|/bin/awk -F', ' '{print $1" (1m), "$2" (5m), "$3" (15m)"}';}
GetOsSysLoad1MinAverage(){
/usr/bin/uptime|/bin/sed 's/.*load average: //'|/bin/awk -F', ' '{print $1}';}
GetHardwareCPUCores(){
local n=$(/bin/grep -c '^processor' /proc/cpuinfo)
[[ $n -eq 0 ]]&&n=$(/bin/grep -c '^Processor' /proc/cpuinfo)
printf '%s' "$n";}
GetHardwareInstalledRAMkb(){
/bin/grep MemTotal /proc/meminfo|/bin/sed 's/.*: //;s/kB//;s/ //g';}
GetHardwareInstalledRAMgb(){
local a=$(/bin/grep MemTotal /proc/meminfo|/bin/sed 's/.*: //;s/kB//;s/ //g')
local b=$((((a/1024)*1000)/1024))
local c=${b%???}.${b:${#b}<3?0:-3}
printf '%.2f' "$c";}
GetOsFirmwareVersion(){
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf;}
GetOsFirmwareVer(){
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf|tr -d '.';}
GetOsFirmwareBuild(){
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf;}
GetOsFirmwareDate(){
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf;}
GetOsName(){
if IsQuTS;then
printf 'QuTS hero'
else
printf QTS
fi;}
GetQpkgArch(){
if [[ $(get_display_name) = 'TS-269H' ]];then
printf i53
return
fi
SetNasArch
SetOsFirmwareVer
SetHardwarePlatform
case $r_nas_arch in
x86_64)
[[ $r_nas_firmware_ver -ge 430 ]]&&printf i64||printf i86;;
i686|x86)
printf i86;;
armv5tel)
printf a19;;
armv7l)
case $r_nas_platform in
ARM_MS)
printf a31;;
ARM_AL)
printf a41;;
*)printf unknown
esac;;
aarch64)
printf a64;;
*)printf unknown
esac;}
DecodeQpkgArch(){
[[ -n ${1:-} ]]||return
case $1 in
a19)
printf ARMv5tel;;
a31|a41)
printf ARMv7l;;
a64)
printf aarch64;;
i53)
printf 'Intel x86_CE53xx';;
i64)
printf 'Intel x86-64';;
i86)
printf 'Intel x86';;
*)printf unknown
esac;}
GetQpkgEntwareType(){
if IsQpkgInstalled Entware;then
if [[ -e /opt/etc/passwd ]];then
if [[ -L /opt/etc/passwd ]];then
printf std
else
printf alt
fi
else
printf none
fi
else
printf 'not-installed'
fi
} 2>/dev/null
GetUserSudoUID(){
printf '%s' "${SUDO_UID:-undefined}";}
GetOsState(){
local a=''
if IsOsStarting;then
a=booting
fi
if IsOsStartingPackages;then
[[ -n $a ]]&&a+=', '
a+='starting QPKGs'
fi
if IsOsStopping;then
a='shutting-down'
fi
if IsOsStoppingPackages;then
[[ -n $a ]]&&a+=', '
a+='stopping QPKGs'
fi
[[ -z $a ]]&&a=online
printf '%s' "$a";}
GetUserGitBranch(){
/sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf;}
GetGnuLessVersion(){
if [[ -x $r_gnu_less_cmd ]];then
$r_gnu_less_cmd -V|head -n1|cut -d' ' -f2
else
printf unknown
fi;}
ShowZeroQpkgs(){
[[ ${packages_loaded:=false} = true ]]||return
local a=''
local b=''
for a in "${r_qpkg_is_states[@]}";do
for b in "${r_user_qpkg_actions[@]}";do
[[ $b = list ]]&&continue
QPKGs.AC${b}IS${a}.IsSet &&QPKGs-AC${b}-ok.IsNone &&ShowAsWarn "no QPKGs were able to $(Lowercase "$b")"
done
done
return 0;}
ClaimLockfile(){
local a=''
readonly r_lock_pathfile=/var/lock/sherpa.pid
for a in sherpa-manager.sh sherpa-manager.source;do
if [[ -e $r_lock_pathfile &&-d /proc/$(<$r_lock_pathfile) &&$(</proc/"$(<$r_lock_pathfile)"/cmdline) =~ $a ]];then
ShowAsAbort "a running $(ShowAsTitleName) instance was found $(Parenthesise "PID:$(<"$r_lock_pathfile")"), please wait for it to complete"
release_lock=false
return 1
fi
done
echo "$$">"$r_lock_pathfile"
return 0;}
ReleaseLockfile(){
[[ ${release_lock:=true} = true ]]||return
[[ -n ${r_lock_pathfile:-} ]]&&rm -f "$r_lock_pathfile" 2>/dev/null;}
EnableVerbose(){
useropt_verbose=true
DebugVar useropt_verbose
useropt_terse=false
ShowKeystrokes
ShowCursor;}
EnableDebugToArchiveAndFile(){
useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward;}
DisableDebugToArchiveAndFile(){
archive_debug_afterward=false
useropt_debug=false;}
SaveActionResultMetrics(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_};var_safe_name=${var_safe_name//:/_}
local -r r_package_type=${1:?${FUNCNAME[0]}(): $e_nopty}
local -r r_name=${2:?${FUNCNAME[0]}(): $e_nopnm}
local -r r_action=${3:?${FUNCNAME[0]}(): $e_noact}
local -r r_qty=${4:-1}
local -r r_clean_action=${r_action//\"/}
local -r r_result_code=${5:?${FUNCNAME[0]}(): $e_nores}
local -r r_reason=${6:-}
local -r r_starttime=$(ConvertNanosecondsToMilliseconds "${!var_safe_name}")
local -r r_duration=$(CalcAmountDiff "$r_starttime" "$(ConvertNowToMilliseconds)")
local -r r_action_times_pathfile=$r_action_times_path/$r_clean_action.milliseconds
echo "$r_starttime|$r_action|$r_qty|$r_name|$r_package_type|$r_result_code|$r_duration|$r_reason">>"$r_action_results_pathfile"
if [[ -s $r_action_times_pathfile ]]&&/bin/grep "^$r_name|"<"$r_action_times_pathfile" &>/dev/null;then
/bin/sed -i "/^$r_name|/d" "$r_action_times_pathfile"
fi
echo "$r_name|$r_duration">>"$r_action_times_pathfile"
case $r_result_code in
ok)
DebugAsInfo "$r_reason";;
sk)
DebugAsWarn "$r_reason";;
er|se|sa)
DebugAsError "$r_reason"
esac
return 0;}
_QPKG:status_(){
[[ $useropt_verbose != true ]]&&exec &>/dev/null
FuncForkInit
local action=status
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit
DebugAsProc "status $(FormatPackageName)"
local a=$(GetQpkgDbActiveTest)
local b=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_status_log_file
[[ $useropt_debug = true ]]&&b+='DEBUG_QPKG=true '
if [[ $a = builtin ]];then
local -r r_local_pathfile=$(GetQpkgServicePathFile)
if [[ -x $r_gnu_timeout_cmd ]];then
$r_gnu_timeout_cmd "$r_qpkg_status_check_timeout_seconds" /bin/sh -c "$b \"$r_local_pathfile\" status"
z=$?
else
Executer "$b \"$r_local_pathfile\" status" "$r_log_pathfile" log:failure-only
z=$?
fi
elif [[ $a != none ]];then
eval "$a" &>/dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive;;
1)
SendPackageStateChange ISNTactive;;
124)
SendPackageStateChange ISslow;;
*)SendPackageStateChange ISunknown
esac
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "returned: $z"
MarkActionForkAsDoneOk
FuncForkExit $z;}
_QPKG:rebuild_(){
FuncForkInit
local action=meta-rebuild
local -i z=0
if IsQpkgProhibited;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsValidQpkgInstalled;then
if IsQpkgBackupExist;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "already installed, please use 'restore' instead"
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already installed & backup file unavailable'
fi
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgBackupExist &&! (QPKGs-ACbackup-to.Exist "O$qpkg_name" &&QPKGs-ACuninstall-to.Exist "O$qpkg_name");then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'backup file unavailable'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "meta-rebuilding $(FormatPackageName)"
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
FuncForkExit $z;}
_QPKG:reassign_(){
FuncForkInit
local action=reassign
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif [[ $(GetQpkgInstalledStoreID) = sherpa ||$(GetQpkgInstalledStoreID) = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already assigned to sherpa'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "reassigning $(FormatPackageName)"
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reassign_log_file
Executer "/sbin/setcfg -e $qpkg_name store -f /etc/config/qpkg.conf" "$r_log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:download_(){
FuncForkInit
local action=download
local -r r_remote_hash=$(GetQpkgDbHash)
local -r r_remote_url=$(GetQpkgDbURL)
local -r r_remote_filename=$(/usr/bin/basename "$r_remote_url")
local -r r_local_pathfile=$r_qpkg_download_path/$r_remote_filename
local -r r_local_filename=$(/usr/bin/basename "$r_local_pathfile")
local -i z=0
if IsQpkgProhibited;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'prohibited package'
IsOsCanManageSignedPackages &&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinOSVerOk ||! IsQpkgDbMaxOSVerOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "incompatible $(GetOsName) version"
IsOsCanManageSignedPackages &&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinRAMOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'insufficient installed RAM'
IsOsCanManageSignedPackages &&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgConflicts &&! QPKGs-ACuninstall-to.Exist "O$qpkg_name";then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'conflicting package installed'
IsOsCanManageSignedPackages &&SendParentCommand "QPKGs-ACsign-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACreinstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACupgrade-to:Remove $qpkg_name"
MarkActionForkAsSkippedOk
z=2
elif IsFile "$r_local_pathfile";then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already downloaded'
MarkActionForkAsSkippedOk
z=2
else
DebugInfo "deleting $(FormatFileName "$r_local_filename") as checksum is incorrect"
rm -f "$r_local_pathfile" 2>/dev/null
fi
fi
[[ $z -eq 0 ]]||FuncForkExit $z
if IsNtFile "$r_local_pathfile";then
DebugAsProc "downloading $(FormatFileName "$r_remote_filename")"
local curl_insecure_opt=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_download_log_file
IsOsCanSecureDownload ||curl_insecure_opt='--insecure'
rm -f "$r_log_pathfile" 2>/dev/null
Executer "/sbin/curl $curl_insecure_opt --location --output \"$r_local_pathfile\" \"$r_remote_url\"" "$r_log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
[[ $(Lowercase "${r_local_pathfile##*.}") = zip ]]&&/usr/bin/unzip -nq "$r_local_pathfile" -d "$r_qpkg_download_path"
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
SendPackageStateChange ISdownloaded
MarkActionForkAsDoneOk
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "cache file $(FormatFileName "$r_local_filename") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkActionForkAsDoneError
z=1
fi
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$z"
MarkActionForkAsDoneError
z=1
fi
fi
FuncForkExit $z;}
_QPKG:install_(){
FuncForkInit
local action=install
local -r r_local_pathfile=$(GetQpkgDbPathFilename)
local -i z=0
if IsQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "already installed, please use 'reinstall' instead"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinOSVerOk ||! IsQpkgDbMaxOSVerOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbMinRAMOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'insufficient installed RAM'
MarkActionForkAsSkippedOk
z=2
elif IsQpkgConflicts;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'conflicting package installed'
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
if [[ $qpkg_name = Entware ]]&&IsNtValidQpkgInstalled Entware &&QPKGs-ACinstall-to.Exist Entware;then
if [[ -d $r_external_apps_path &&! -L $r_external_apps_path &&! -e $r_external_apps_temp_path ]];then
DebugAsProc "move-aside $r_external_apps_path"
mv "$r_external_apps_path" "$r_external_apps_temp_path"
DebugAsDone complete
fi
fi
DebugAsProc "installing $(FormatPackageName)"
local a='INSTALL_QPKG=true '
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_install_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
[[ ${QPKGs_were_installed_name[*]:-} = *"$qpkg_name"* ]]&&a+="QINSTALL_PATH=$(GetQpkgInstalledOriginalPath "$qpkg_name") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if [[ $z -eq 0 ||$z -eq 10 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "v$(GetQpkgInstalledVer)"
if [[ $qpkg_name = Entware ]];then
SendParentCommand ModPathToEntware
SendParentCommand _UpdateEntwarePackageList_
PatchEntwareService
if [[ -L $r_external_apps_path &&-d $r_external_apps_temp_path ]];then
DebugAsProc "restore-into $r_external_apps_path"
(shopt -s dotglob;mv "$r_external_apps_temp_path"/* "$r_external_apps_path"/)
rm -rf "${r_external_apps_temp_path:?${FUNCNAME[0]}(): $e_nopth}"
DebugAsDone complete
fi
fi
MarkActionForkAsDoneOk
z=0
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reinstall_(){
FuncForkInit
local action=reinstall
local -r r_local_pathfile=$(GetQpkgDbPathFilename)
local -i z=0
if IsNtQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "not already installed, please use 'install' instead"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "reinstalling $(FormatPackageName)"
local a='REINSTALL_QPKG=true '
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reinstall_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
IsValidQpkgInstalled &&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath)") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if [[ $z -eq 0 ||$z -eq 10 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "v$(GetQpkgInstalledVer)"
IsQpkgDbCanClean &&SendParentCommand "QPKGs-ACclean-to:Add $qpkg_name"
MarkActionForkAsDoneOk
z=0
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:upgrade_(){
FuncForkInit
local action=upgrade
local -r r_local_pathfile=$(GetQpkgDbPathFilename)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsQpkgProhibited;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'prohibited package'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif ! QPKGs-ISupgradable.Exist "$qpkg_name";then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'no new QPKG is available'
MarkActionForkAsSkippedOk
z=2
elif [[ -z $r_local_pathfile ||! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'installation package unavailable'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "upgrading $(FormatPackageName)"
local a='UPGRADE_QPKG=true '
local prev_ver=$(GetQpkgInstalledVer)
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_upgrade_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
IsValidQpkgInstalled &&a+="QINSTALL_PATH=$(/usr/bin/dirname "$(GetQpkgInstalledPath "$qpkg_name")") "
KludgeExecuter "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only 10
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
[[ $qpkg_name = Entware ]]&&IsNtCriticalFile $r_opkg_cmd &&z=1
if [[ $z -eq 0 ||$z -eq 10 ]];then
SendPackageStateChange ISNTupgradable
IsQpkgDbCanClean &&SendParentCommand "QPKGs-ACclean-to:Add $qpkg_name"
local current_ver=$(GetQpkgInstalledVer)
if [[ $current_ver = "$prev_ver" ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "v$current_ver"
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "v$prev_ver -> v$current_ver"
fi
MarkActionForkAsDoneOk
z=0
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:uninstall_(){
FuncForkInit
local action=uninstall
local -r r_local_pathfile=$(GetQpkgInstalledPath)/.uninstall.sh
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "it's needed here! 😉"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se "$(FormatFileName '.uninstall.sh') undefined"
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$(FormatFileName '.uninstall.sh') not found"
MarkActionForkAsDoneError
z=1
fi
[[ $z -eq 0 ]]||FuncForkExit $z
[[ $qpkg_name = Entware ]]&&SaveIpkAndPipList
local current_ver=$(GetQpkgInstalledVer)
DebugAsProc "uninstalling $(FormatPackageName)"
local a='UNINSTALL_QPKG=true '
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_uninstall_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a /bin/sh \"$r_local_pathfile\"" "$r_log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
[[ -x /sbin/qpkg_cli ]]&&! QPKGs-ACinstall-to.Exist "$qpkg_name" &&/sbin/qpkg_cli --remove "$qpkg_name" &>/dev/null
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok "v$current_ver"
/sbin/rmcfg "$qpkg_name" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $qpkg_name = Entware ]];then
SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISNTactive
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:activate_(){
FuncForkInit
local action=activate
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "disabled, please 'enable' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "activating $(FormatPackageName)"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_activate_log_file
local timeout=''
IsOsCanQpkgTimeout &&timeout='-t '$r_qpkg_start_timeout_seconds
if [[ $useropt_debug = true ]];then
a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" start" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
Executer "/sbin/qpkg_service $timeout start $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk &&z=0||z=1
else
Executer "\"$r_local_pathfile\" start" "$r_log_pathfile" log:failure-only
z=$?
fi
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
if [[ $qpkg_name = Entware ]];then
SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISactive
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
SendPackageStateChange ISNTactive
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:reactivate_(){
FuncForkInit
local action=reactivate
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "disabled, please 'enable' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "reactivating $(FormatPackageName)"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_reactivate_log_file
local timeout=''
IsOsCanQpkgTimeout &&timeout='-t '$r_qpkg_restart_timeout_seconds
if [[ $useropt_debug = true ]];then
a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" restart" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
Executer "/sbin/qpkg_service $timeout restart $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk &&z=0||z=1
else
Executer "\"$r_local_pathfile\" restart" "$r_log_pathfile" log:failure-only
z=$?
fi
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
SendParentCommand "QPKGs-ACactivate-to:Remove $qpkg_name"
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:deactivate_(){
FuncForkInit
local action=deactivate
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_deactivate_log_file
local timeout=''
IsOsCanQpkgTimeout &&timeout='-t '$r_qpkg_stop_timeout_seconds
DebugAsProc "deactivating $(FormatPackageName)"
if [[ $useropt_debug = true ]];then
a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" stop" "$r_log_pathfile" log:failure-only
z=$?
elif IsQpkgDbWillLog;then
Executer "/sbin/qpkg_service $timeout stop $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgServiceResultWasOk &&z=0||z=1
else
Executer "\"$r_local_pathfile\" stop" "$r_log_pathfile" log:failure-only
z=$?
fi
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
if [[ $qpkg_name = Entware ]];then
SendParentCommand ModPathToEntware
SendParentCommand SetCapabilities
SetCapabilities
fi
SendPackageStateChange ISNTactive
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:enable_(){
FuncForkInit
local action=enable
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsQpkgEnabled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already enabled'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_enable_log_file
local timeout=''
IsOsCanQpkgTimeout &&timeout='-t '$r_qpkg_enable_timeout_seconds
DebugAsProc "enabling $(FormatPackageName)"
Executer "/sbin/qpkg_service $timeout enable $qpkg_name" "$r_log_pathfile" log:failure-only
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:disable_(){
FuncForkInit
local action=disable
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgEnabled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already disabled'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_disable_log_file
local timeout=''
IsOsCanQpkgTimeout &&timeout='-t '$r_qpkg_disable_timeout_seconds
DebugAsProc "disabling $(FormatPackageName)"
Executer "/sbin/qpkg_service $timeout disable $qpkg_name" "$r_log_pathfile" log:failure-only
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:enableau_(){
FuncForkInit
local action=enableau
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanRestartToUpdate;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'unsupported by this QPKG'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "'auto-update' is always enabled"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "enabling auto-update $(FormatPackageName)"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_enableau_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" enable-auto-update" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:disableau_(){
FuncForkInit
local action=disableau
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanRestartToUpdate;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'unsupported by this QPKG'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "'auto-update' cannot be disabled"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "disabling auto-update $(FormatPackageName)"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_disableau_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" disable-auto-update" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:backup_(){
FuncForkInit
local action=backup
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanBackup;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'unsupported by this QPKG'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "backing-up $(FormatPackageName) configuration"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_backup_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" backup" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
SendPackageStateChange ISbackedup
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
SendParentCommand "QPKGs-ACuninstall-to:Remove $qpkg_name"
SendParentCommand "QPKGs-ACrestore-to:Remove $qpkg_name"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:restore_(){
FuncForkInit
local action=restore
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
if IsQpkgBackupExist;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "not installed, try 'rebuild' instead"
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed & backup file unavailable'
fi
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanBackup;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'unsupported by this QPKG'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgBackupExist;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'backup file unavailable'
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "restoring $(FormatPackageName) configuration"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_restore_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" restore" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
_QPKG:clean_(){
FuncForkInit
local action=clean
local -r r_local_pathfile=$(GetQpkgServicePathFile)
local -i z=0
if IsNtValidQpkgInstalled;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'not installed'
MarkActionForkAsSkippedOk
z=2
elif ! IsQpkgDbCanClean;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'unsupported by this QPKG'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgAuthorOk;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'incompatible author'
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ $r_local_pathfile = undefined ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file undefined'
MarkActionForkAsSkippedError
z=4
elif [[ ! -s $r_local_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' se 'QPKG service-script file not found'
MarkActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "cleaning $(FormatPackageName)"
local a=''
local -r r_log_pathfile=$r_action_log_path/$qpkg_name.$r_clean_log_file
[[ $useropt_debug = true ]]&&a+='DEBUG_QPKG=true '
Executer "$a \"$r_local_pathfile\" clean" "$r_log_pathfile" log:failure-only
z=$?
LogQpkgServiceResult
IsQpkgDbWillLog &&! QpkgServiceResultWasOk &&z=1
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
MarkActionForkAsDoneOk
else
local b=$(GetQpkgServiceExplanation) ||b=$z
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$b"
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:sign_(){
[[ ! -e $r_abort_actions_pathfile ]]||exit
FuncForkInit
local action='"sign"'
local -i z=0
if ! IsOsCanManageSignedPackages;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ ! -s $r_cert_db_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sa "$(GetOsName) QPKG certificate database unavailable, no further signing will occur"
MarkActionForkAsSkippedAbort
z=3
elif IsQpkgSigned;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already signed'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "\"signing\" $(FormatPackageName)"
local a=''
local b=''
local -i retries=0
a="INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$qpkg_name','$r_qpkg_certificate','$r_qpkg_signature')"
read -r -d '' b<<EOB
import sqlite3, sys
try:
    sqliteConnection = sqlite3.connect('$r_cert_db_pathfile')
    cursor = sqliteConnection.cursor()
    sqlite_add_query = """$a"""
    cursor.execute(sqlite_add_query)
    sqliteConnection.commit()
    cursor.close()
    sys.exit()
finally:
    if sqliteConnection:
        sqliteConnection.close()
EOB
for((retries=0;retries<10;retries++));do
/usr/local/bin/python2 -c "$b"
z=$?
case $z in
5)
sleep 0.5;;
*)break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
SendPackageStateChange ISsigned
MarkActionForkAsDoneOk
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$(Parenthesise "$z") but don't know why. Please report this as a bug"
SendParentCommand 'show_suggest_raise_issue=true'
MarkActionForkAsDoneError
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z;}
_QPKG:unsign_(){
[[ ! -e $r_abort_actions_pathfile ]]||exit
FuncForkInit
local action='"unsign"'
local -i z=0
if ! IsOsCanManageSignedPackages;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "incompatible $(GetOsName) version"
MarkActionForkAsSkippedOk
z=2
elif IsNtQpkgRepoSelfManaged;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk "assigned to another repository, please 'reassign' it first"
MarkActionForkAsSkippedOk
z=2
elif [[ ! -s $r_cert_db_pathfile ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sa "$(GetOsName) QPKG certificate database unavailable, no further unsigning will occur"
MarkActionForkAsSkippedAbort
z=3
elif IsNtQpkgSigned;then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' sk 'already unsigned'
MarkActionForkAsSkippedOk
z=2
fi
[[ $z -eq 0 ]]||FuncForkExit $z
DebugAsProc "\"unsigning\" $(FormatPackageName)"
local a=''
local b=''
local -i retries=0
a="DELETE from Certificate WHERE QpkgName = '$qpkg_name'"
read -r -d '' b<<EOB
import sqlite3, sys
try:
    sqliteConnection = sqlite3.connect('$r_cert_db_pathfile')
    cursor = sqliteConnection.cursor()
    sqlite_delete_query = """$a"""
    cursor.execute(sqlite_delete_query)
    sqliteConnection.commit()
    cursor.close()
    sys.exit()
finally:
    if sqliteConnection:
        sqliteConnection.close()
EOB
for((retries=0;retries<10;retries++));do
/usr/local/bin/python2 -c "$b"
z=$?
case $z in
5)
sleep 0.5;;
*)z=0
break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' ok
SendPackageStateChange ISsigned
MarkActionForkAsDoneOk
else
SaveActionResultMetrics QPKG "$qpkg_name" "$action" '' er "$(Parenthesise "$z") but don't know why. Please report this as a bug"
SendParentCommand 'show_suggest_raise_issue=true'
MarkActionForkAsDoneError
fi
FuncForkExit $z;}
ClearQpkgInstalledAppCenterNotifier(){
[[ -x /sbin/qpkg_cli ]]&&/sbin/qpkg_cli --cancel "$qpkg_name"
IsValidQpkgInstalled||return
/sbin/setcfg "$qpkg_name" Status complete -f /etc/config/qpkg.conf
return 0
} &>/dev/null
LogQpkgServiceResult(){
local a=$r_qpkg_service_result_path/$qpkg_name.log
if ! local b=$(GetQpkgServiceResult);then
DebugAsWarn "unable to get status of $(FormatPackageName) service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $b in
failed)
if [[ -s $a ]];then
DebugAsError "$(FormatPackageName) service action failed. Check $(FormatFileName "$a") for more information"
AddExtLogToSessLog "$a"
else
DebugAsError "$(FormatPackageName) service action failed"
fi;;
in-progress)
DebugInfo "$(FormatPackageName) service action is in-progress";;
ok)
DebugInfo "$(FormatPackageName) service action completed OK";;
*)DebugAsWarn "$(FormatPackageName) service status is unrecognised or unsupported"
esac
return 0;}
GetQpkgInstalledPath(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Install_Path -d undefined -f /etc/config/qpkg.conf;}
GetQpkgServicePathFile(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Shell -d undefined -f /etc/config/qpkg.conf;}
GetQpkgDbApplVer(){
local a=''
local -i i=0
if [[ $qpkg_index -gt 0 ]];then
a=${r_qpkg_appl_version[$qpkg_index]}
[[ $a = version ]]&&a=${r_qpkg_version[$qpkg_index]}
[[ $a != none ]]||return
else
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$qpkg_name" ]];then
a=${r_qpkg_appl_version[$i]}
[[ $a = version ]]&&a=${r_qpkg_version[$i]}
[[ $a != none ]]||return
break
fi
done
fi
[[ -n $a ]]||return
[[ $a = dynamic ]]&&IsValidQpkgInstalled &&! IsQpkgAutoUpdate &&a=static
printf '%s' "$a"
return 0;}
GetQpkgDbVer(){
local a=''
local -i i=0
a=${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}
if [[ -n $a ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$a" ]];then
printf '%s' "${r_qpkg_version[$i]}"
return 0
fi
done
fi
return 1;}
GetQpkgInstalledVer(){
/sbin/getcfg "${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}" Version -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledStoreID(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" store -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledDate(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" date -d undefined -f /etc/config/qpkg.conf;}
GetQpkgInstalledOriginalPath(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]];then
for i in "${!QPKGs_were_installed_name[@]}";do
[[ ${QPKGs_were_installed_name[$i]} = "$a" ]]||continue
printf '%s' "${QPKGs_were_installed_path[$i]}"
return 0
done
fi
return 1;}
GetQpkgDbPathFilename(){
local a=''
a=$(GetQpkgDbURL)
[[ -n $a ]]||return
[[ $(Lowercase "${a##*.}") != qpkg ]]&&a=${a%.*}.qpkg
printf '%s' "$r_qpkg_download_path/$(/usr/bin/basename "$a")"
return 0;}
GetQpkgDbHash(){
[[ -n $qpkg_name &&$qpkg_index -gt 0 ]]||return
local a=''
a=${r_qpkg_hash[$qpkg_index]}
[[ $a != none ]]||return
printf '%s' "$a"
return 0;}
GetQpkgDbURL(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$1" ]];then
printf '%s' "${r_qpkg_url[$i]}"
return 0
fi
done
return 1
else
a=${r_qpkg_url[$qpkg_index]}
[[ -n $a ]]||a=none
printf '%s' "$a"
fi
return 0;}
GetQpkgDbMinRAM(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_min_ram_kb[$i]}
break
done
else
a=${r_qpkg_min_ram_kb[$qpkg_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMinOSVer(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_min_os_version[$i]}
break
done
else
a=${r_qpkg_min_os_version[$qpkg_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbMaxOSVer(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_max_os_version[$i]}
break
done
else
a=${r_qpkg_max_os_version[$qpkg_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbAuthor(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
printf '%s' "${r_qpkg_author[$i]}"
return 0
done
return 1;}
GetQpkgAuthor(){
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Author -f /etc/config/qpkg.conf;}
GetQpkgDbDesc(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_description[$i]}
break
done
else
a=${r_qpkg_description[$qpkg_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbAbbrvs(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_abbrvs[$i]}
break
done
else
a=${r_qpkg_abbrvs[$qpkg_index]}
fi
[[ -n $a ]]||a=none
printf '%s' "$a"
return 0;}
GetQpkgDbDependencies(){
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${r_qpkg_depends_on[$qpkg_index]}
[[ $g = none ]]&&return 1
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=' '$x
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first &&-n $alt ]]&&first=$alt
out+=' '$alt
found=true
break
done
[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then
out+=' '$first
first=''
fi
done
printf '%s' "$out"
return 0;}
GetQpkgDbOptDependencies(){
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${r_qpkg_opt_depends_on[$qpkg_index]}
[[ $g = none ]]&&return 1
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=' '$x
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first &&-n $alt ]]&&first=$alt
out+=' '$alt
found=true
break
done
[[ $IFS != "$oldIFS" ]]&&IFS=$oldIFS
if [[ $found = false ]];then
out+=' '$first
first=''
fi
done
printf '%s' "$out"
return 0;}
GetQpkgDbDependents(){
[[ -n $qpkg_name &&$qpkg_index -gt 0 ]]||return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRindependent.Exist "$qpkg_name";then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_depends_on[$i]} =~ $re ]];then
[[ ${ar[@]+"${ar[@]}"} != "${r_qpkg_name[$i]}" ]]&&ar+=(${r_qpkg_name[$i]})
fi
done
fi
if [[ -n ${ar[@]+"${ar[@]}"} ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1;}
GetQpkgDbOptionals(){
[[ -n $qpkg_name &&$qpkg_index -gt 0 ]]||return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRoptional.Exist "$qpkg_name";then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_opt_depends_on[$i]} =~ $re ]];then
[[ ${ar[@]+"${ar[@]}"} != "${r_qpkg_name[$i]}" ]]&&ar+=(${r_qpkg_name[$i]})
fi
done
fi
if [[ -n ${ar[@]+"${ar[@]}"} ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1;}
GetQpkgConflicts(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_conflicts_with[$i]}
break
done
else
a=${r_qpkg_conflicts_with[$qpkg_index]}
fi
[[ -n $a ]]||a=none
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgDbIPKs(){
[[ -n $qpkg_name &&$qpkg_index -gt 0 ]]||return
local a=${r_qpkg_requires_ipks[$qpkg_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgDbActiveTest(){
[[ -n $qpkg_name &&$qpkg_index -gt 0 ]]||return
local a=${r_qpkg_test_for_active[$qpkg_index]}
[[ $a = none ]]&&return 1
printf '%s' "$a"
return 0;}
GetQpkgServiceAction(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local b=$r_qpkg_service_result_path/$a.action
if [[ -s $b ]];then
printf '%s' "$(<$b)"
return 0
else
printf not-found
return 1
fi;}
GetQpkgServiceExplanation(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local b=$r_qpkg_service_result_path/$a.explanation
if [[ -s $b ]];then
printf '%s' "$(<$b)"
return 0
else
printf not-found
return 1
fi;}
GetQpkgServiceResult(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local b=$r_qpkg_service_result_path/$a.result
if [[ -s $b ]];then
printf '%s' "$(<$b)"
return 0
else
printf not-found
return 1
fi;}
GetQpkgsIsInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgInstalled||continue
echo "$qpkg_name"
done;}
GetQpkgsIsValidInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsValidQpkgInstalled||continue
echo "$qpkg_name"
done;}
GetQpkgsNtInstalled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsNtQpkgInstalled||continue
echo "$qpkg_name"
done;}
GetQpkgsIsEnabled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgEnabled||continue
echo "$qpkg_name"
done;}
GetQpkgsNtEnabled(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsValidQpkgInstalled||continue
IsNtQpkgEnabled||continue
echo "$qpkg_name"
done;}
GetQpkgsIsComplete(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgComplete||continue
echo "$qpkg_name"
done;}
GetQpkgsNtComplete(){
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
IsQpkgInstalled||continue
IsNtQpkgComplete||continue
echo "$qpkg_name"
done;}
QpkgServiceResultWasOk(){
[[ -n ${qpkg_name:-} ]]||return
[[ $(GetQpkgServiceResult) = ok ]];}
QpkgMatchAbbrv(){
[[ -n ${1:-} ]]||return
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!r_qpkg_name[@]}";do
ar=(${r_qpkg_abbrvs[$i]})
for j in "${!ar[@]}";do
[[ ${ar[$j]} = "$1" ]]||continue
printf '%s' "${r_qpkg_name[$i]}"
z=0
break 2
done
done
return $z;}
IsUserOk(){
if ! IsUserSU;then
if IsOsCanSudo;then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${r_chars_sudo_prompt}sherpa $r_args_raw">&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again"
fi
return 1
fi
return 0;}
IsUserSU(){
[[ $EUID -eq 0 ]];}
IsCriticalFile(){
[[ -n ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]||exit
local a=${1%% *}
if ! [[ -f $a ||-L $a ]];then
ShowAsAbort "a required NAS system file $(FormatFileName "$a") is missing"
return 1
fi
return 0;}
IsNtCriticalFile(){
! IsCriticalFile "${1:?${FUNCNAME[0]}(): $e_nopfi}";}
IsFile(){
[[ -n ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]||exit
local a=${1%% *}
[[ -f $a &&-s $a ]];}
IsNtFile(){
! IsFile "${1:?${FUNCNAME[0]}(): $e_nopfi}";}
IsFileRecent(){
[[ -e ${1:-} &&$((($(ConvertNowToSeconds)-$(FileLastStatusChangeEpoch "$1"))/60)) -le ${2:-1440} ]];}
IsFileNewer(){
[[ -n ${1:-} &&-e $1 ]]||return
[[ -n ${2:-} &&-e $2 ]]||return 0
[[ $(FileLastModifiedEpoch "$1") -gt $(FileLastModifiedEpoch "$2") ]];}
IsEntwareUpgradable(){
local a=$(GetQpkgInstalledDate Entware)
if [[ $a = undefined ||${a//[!0-9]/} -lt $r_entware_packages_last_updated ]];then
case $r_nas_arch in
armv5tel|i686|x86)
:;;
*)return
esac
fi
false;}
IsNonStatusActionRequested(){
local action=''
for action in "${r_qpkg_actions[@]}";do
if QPKGs-AC${action}-to.IsAny;then
[[ $action != status ]]||continue
return
fi
done
false;}
IsOsOk(){
if ! IsOsQNAP;then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0;}
IsOsQNAP(){
[[ -s /etc/init.d/functions ]];}
IsQuTS(){
/bin/grep zfs /proc/filesystems
} &>/dev/null
IsOsSupported(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 400 ]];}
IsOsCanAsyncQpkgActions(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 520 ]];}
IsOsCanSecureDownload(){
SetQpkgArch
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 455 ]]&&[[ $r_nas_qpkg_arch != a41 ]];}
IsOsCanQpkgTimeout(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 430 &&$r_nas_firmware_ver -le 519 &&$r_nas_qpkg_arch != i86 ]];}
IsOsCanManageSignedPackages(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -ge 437 ]];}
IsOsCanUnofficialPackages(){
SetOsFirmwareVer
[[ $r_nas_firmware_ver -gt 426 &&$r_nas_firmware_ver -le 436 ]];}
IsOsCanSudo(){
[[ -x /usr/bin/sudo ]];}
IsOsCanSedExtRegex(){
[[ $(echo -en "\033[1;97ma"|/bin/sed -r 's/\x1b\[[0-9;]*m//g'|/usr/bin/wc -c) -eq 1 ]];}
IsOsCanDecimalSleepSeconds(){
/bin/sleep .01
} &>/dev/null
IsOsCanAutowidthTableColumns(){
[[ -x $r_gnu_awk_cmd ]];}
IsOsCompatibleWithSigned(){
SetOsFirmwareDate
[[ $r_nas_firmware_date -lt 20201015 ||$r_nas_firmware_date -gt 20201020 ]];}
IsOsRequireSignedPackages(){
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert -u -d FALSE) = FALSE ]];}
IsOsAllowUnofficialPackages(){
[[ $(/sbin/getcfg 'QPKG Management' Check_Official -u -d TRUE) = FALSE ]];}
IsOsStarting(){
/bin/ps|/bin/grep '/bin/sh /etc/init.d/rcS'|/bin/grep -v grep
} &>/dev/null
IsOsStopping(){
/bin/ps|/bin/grep '/bin/sh /etc/init.d/rcK'|/bin/grep -v grep
} &>/dev/null
IsOsStartingPackages(){
if IsOsCanAsyncQpkgActions;then
/bin/ps|/bin/grep '/usr/local/sbin/qpkg_service start'|/bin/grep -v grep
else
IsOsStarting
fi
} &>/dev/null
IsOsStoppingPackages(){
if IsOsCanAsyncQpkgActions;then
/bin/ps|/bin/grep '/usr/local/sbin/qpkg_service stop'|/bin/grep -v grep
else
IsOsStopping
fi
} &>/dev/null
IsOsOnline(){
[[ $(GetOsState) = online ]];}
IsOsStdKernelPageSize(){
SetOsKernelPageSize
[[ $r_kernel_page_size = 4096B ||$r_kernel_page_size = 4kiB ]];}
IsOsNonStdKernelPageSize(){
! IsOsStdKernelPageSize;}
IsOsLoadAverageElevated(){
IsOsLoadAverageAboveTrigger 2;}
IsOsLoadAverageHigh(){
IsOsLoadAverageAboveTrigger 4;}
IsOsLoadAverageInsane(){
IsOsLoadAverageAboveTrigger 8;}
IsOsLoadAverageAboveTrigger(){
local a=${1:-1}
local b=$(GetOsSysLoad1MinAverage);b=${b/./}
local c=$((r_cpu_cores*a*100))
[[ $((10#$b)) -ge $((10#$c)) ]];}
IsOsSedExtRegexSupported(){
[[ ${sed_ext_regex_supported:-unset} = unset ]]&&SetOsSedRegexSupport
[[ $sed_ext_regex_supported -eq 0 ]];}
IsOsDecimalSleepSecondsSupported(){
[[ ${sleep_decimal_seconds_supported:-unset} = unset ]]&&SetOsDecimalSleepSecondsSupport
[[ $sleep_decimal_seconds_supported -eq 0 ]];}
IsInTerminal(){
[[ -t 0 ]];}
IsError(){
[[ ${_script_error_flag_:=false} = true ]];}
IsNtError(){
[[ ${_script_error_flag_:=false} != true ]];}
IsQpkgRepoSelfManaged(){
local a=$(GetQpkgInstalledStoreID "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ -z $a ||$a = undefined ||$a = sherpa ]];}
IsNtQpkgRepoSelfManaged(){
! IsQpkgRepoSelfManaged "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgBackupExist(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}.config.tar.gz
local old=$r_qpkg_bu_path/O$a
local new=$r_qpkg_bu_path/$a
if [[ -e $old &&! -e $new ]];then
if [[ $(/usr/bin/stat -c %s "$old") -le $((500*(2**20))) ]];then
cp "$old" "$new"
else
mv "$old" "$new"
fi
fi
[[ -e $new ]];}
IsQpkgUpgradable(){
IsValidQpkgInstalled&&IsQpkgRepoSelfManaged&&IsNtQpkgProhibited&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk &&[[ $(GetQpkgInstalledVer) != "$(GetQpkgDbVer)" ]];}
IsQpkgInstallable(){
IsNtQpkgInstalled&&IsNtValidQpkgInstalled&&IsNtQpkgProhibited&&IsQpkgDbMinOSVerOk&&IsQpkgDbMaxOSVerOk&&IsQpkgDbMinRAMOk;}
IsQpkgDbDependent(){
[[ $qpkg_index -gt 0 ]]||return
local a=''
a=${r_qpkg_depends_on[$qpkg_index]}
[[ $a != none ]];}
IsQpkgDbIndependent(){
! IsQpkgDbOptional &&! IsQpkgDbDependent;}
IsQpkgDbOptional(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local -i i=0
local re=\\b${a}\\b
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_opt_depends_on[$i]} =~ $re ]]||continue
return 0
done
return 1;}
IsQpkgDbMinRAMOk(){
local a=$(GetQpkgDbMinRAM "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ -n $a ]]&&[[ $a = none ||$r_nas_ram_kb -ge $a ]];}
IsQpkgDbMinOSVerOk(){
local a=$(GetQpkgDbMinOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
SetOsFirmwareVer
[[ -n $a ]]&&[[ $a = none ||$r_nas_firmware_ver -ge $a ]];}
IsQpkgDbMaxOSVerOk(){
local a=$(GetQpkgDbMaxOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
SetOsFirmwareVer
[[ -n $a ]]&&[[ $a = none ||$r_nas_firmware_ver -le $a ]];}
IsQpkgDbCanBackup(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_can_backup[$i]}
break
done
else
a=${r_qpkg_can_backup[$qpkg_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbCanRestartToUpdate(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
${r_qpkg_can_restart_to_update[$i]}&&return 0||break
done
return 1;}
IsQpkgDbCanClean(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]]||continue
${r_qpkg_can_clean[$i]}&&return 0||break
done
return 1;}
IsQpkgDbSherpaCompatible(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_is_sherpa_compatible[$i]}
break
done
else
a=${r_qpkg_is_sherpa_compatible[$qpkg_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbUniqueUnpack(){
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]]||continue
a=${r_qpkg_is_unique_unpack[$i]}
break
done
else
a=${r_qpkg_is_unique_unpack[$qpkg_index]}
fi
[[ -n $a ]]||a=none
[[ $a = true ]];}
IsQpkgDbWillLog(){
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" ]]||continue
${r_qpkg_will_log[$i]}&&return 0||break
done
return 1;}
IsQpkgAutoUpdate(){
[[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Auto_Update -u -f /etc/config/qpkg.conf) = TRUE ]];}
IsQpkgAuthorOk(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(GetQpkgDbAuthor "$a") = "$(GetQpkgAuthor "$a")" ]];}
IsNtQpkgAuthorOk(){
! IsQpkgAuthorOk "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsValidQpkgInstalled(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
IsQpkgInstalled "$a"&&IsQpkgAuthorOk "$a";}
IsNtValidQpkgInstalled(){
! IsValidQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgInstalled(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(/sbin/getcfg "$a" Name -d undefined -f /etc/config/qpkg.conf) = "$a" ]]
}>/dev/null
IsNtQpkgInstalled(){
! IsQpkgInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgProhibited(){
local re=\\b${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}\\b
[[ ${r_qpkgs_name_prohibited[*]} =~ $re ]];}
IsNtQpkgProhibited(){
! IsQpkgProhibited "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgConflicts(){
local a=''
for a in $(GetQpkgConflicts "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}");do
IsQpkgInstalled "$a"&&return
done
return 1;}
IsQpkgMissing(){
local a=$(GetQpkgInstalledPath "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}")
[[ $a != undefined &&! -d $a ]];}
IsQpkgComplete(){
local a=${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}
[[ $(/sbin/getcfg "$a" Status -d undefined -f /etc/config/qpkg.conf) = complete ]]&&[[ $(/sbin/getcfg "$a" Incomplete_Conf -d undefined -f /etc/config/qpkg.conf) != 1 ]];}
IsNtQpkgComplete(){
! IsQpkgComplete "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgEnabled(){
[[ $(/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}" Enable -u -d undefined -f /etc/config/qpkg.conf) = TRUE ]];}
IsNtQpkgEnabled(){
! IsQpkgEnabled "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgSigned(){
[[ -s $r_cert_db_pathfile ]]||return
local a="SELECT 1 from Certificate WHERE QpkgName = '${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}'"
local b=''
read -r -d '' b<<EOB
import sqlite3, sys
try:
    sqliteConnection = sqlite3.connect('$r_cert_db_pathfile')
    cursor = sqliteConnection.cursor()
    sqlite_select_query = """$a"""
    cursor.execute(sqlite_select_query)
    records = cursor.fetchall()
    sys.exit(len(records) == 0)
    cursor.close()
finally:
    if sqliteConnection:
        sqliteConnection.close()
EOB
/usr/local/bin/python2 -c "$b";}
IsNtQpkgSigned(){
! IsQpkgSigned "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
IsQpkgTimeoutsIncreased(){
[[ -e /usr/local/sbin/qpkg_service.orig ]];}
IsNumber(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
[[ ${#a} -gt 0 ]];}
IsAnsiStrippingSupported(){
if IsOsSedExtRegexSupported;then
true
elif [[ -x /opt/bin/sed &&-L /opt/etc/passwd ]];then
true
else
false
fi;}
IsHaveSingleQuote(){
/bin/grep "'"<<<"${1:-}"
} &>/dev/null
IsGnuLessSupportHeaders(){
local a=$(GetGnuLessVersion)
IsNumber $a &&[[ $a -ge 685 ]];}
IsReportLargerThanViewport(){
[[ -n ${1:-} &&-e $1 ]]||return
[[ $(/usr/bin/wc -l<"$1") -ge $r_sess_rows ||$(StripANSICodes "$(<$1)"|/usr/bin/wc -L) -gt $r_sess_columns ]];}
IsFuncExist(){
[[ -n ${1:-} &&$(type -t "$1") = function ]];}
CreatePidFile(){
pidfile=$(/bin/mktemp "$r_async_procs_path"/proc_XXXXXX);}
WritePidFile(){
[[ -n ${1:-} &&-n ${pidfile:-} ]]||return
echo "$1">"$pidfile";}
RemovePidFile(){
[[ -n ${pidfile:-} &&-e $pidfile ]]||return
rm -f "$pidfile";}
LoadQpkgSigningCert(){
r_qpkg_certificate=''
r_qpkg_signature=''
read -r -d '' r_qpkg_certificate<<EOB
-----BEGIN CERTIFICATE-----
MIIDwzCCAqugAwIBAgIERBKryDANBgkqhkiG9w0BAQsFADCBgDELMAkGA1UEBhMC
VFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYDVQQKDARR
TkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMMB1FOQVBfQ0ExIDAeBgkqhkiG9w0B
CQEWEXNlY3VyaXR5QHFuYXAuY29tMB4XDTI1MDUwMjA4MTczNloXDTI4MDUwMTA4
MTczNlowgYcxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcM
BlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwDTkFTMRcwFQYDVQQDDA5N
YWx3YXJlUmVtb3ZlcjEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20w
ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCyU72V6jrH6P1Zw4ERF9qz
7hgsQOsidKQFj9mVLPzPTCPVjtmRBDhCWVa1lmzs2iuKCh3NIL5P0d22xgiuo8Ea
3xjDH51D7jJnx4G4L2TawV0Wy/xV58kCjwmwtEK6i6NXYu7QQ1EP0sWw9rb41M8R
srDMHesnyGT2QCgt0HR+BTbKmRIdcSipF1yZOKJP3QTyrNZmwMFi/Hvh5SyAWuuN
8dDKGzmMvdpFpLBuhWV3a/ehelv3HGwyWdYwlCYgy7W5xFdSA8uiX/tQxOVh/kpZ
1pmmkgFIUtt6V/xF5/9rWV/NZkoYhR6DqjP1LGeCwA9NJTLPXXy4FsSGzUh7OMjV
AgMBAAGjPDA6MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFw
LmNvbS9jcmwvcXRzX3YxLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAIGkp1GiM1oGU
uDvwq3P6RiZJodYBSsZUuRqmTSfM2qJO4+IH9berAv3To+9XyRCufxxmuvOepAoQ
60gNnd2GujQRGjdElwC7c0LmP38AO6u3FLxA3kQLihaDndVskx/lTaZCtKZBPIVM
9jaokthGTPt6bvP6Gu/xMMwJDibJKdw0v35Pht7jszraRT74b7oSKYajv7IVk/aY
EeNVa4M6Harqv0Phub/gHjqT+cZ4lQf3BiBavlxgRP0n7CAqlL0uc6FwER1WeGN1
A0di5BktcxJnOO/6xGbgqGK/E0DETnN1td8QEDTZA15l9y1Lpqm6p7utJ5l2eVwB
xCqLA4ZLBw==
-----END CERTIFICATE-----
EOB
read -r -d '' r_qpkg_signature<<EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename=\"smime.p7m\"
Content-Type: application/pkcs7-mime;smime-type=signed-data;name=\"smime.p7m\"
Content-Transfer-Encoding: base64

MIIGswYJKoZIhvcNAQcCoIIGpDCCBqACAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFO0ijyace1a2VNKYTHBpMC0thmvLoIIDxzCCA8MwggKroAMCAQIC
BEQSq8gwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYTAlRXMQ8wDQYDVQQIDAZU
YWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwEUU5BUDEMMAoGA1UECwwD
TkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcNAQkBFhFzZWN1cml0eUBx
bmFwLmNvbTAeFw0yNTA1MDIwODE3MzZaFw0yODA1MDEwODE3MzZaMIGHMQswCQYD
VQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNV
BAoMBFFOQVAxDDAKBgNVBAsMA05BUzEXMBUGA1UEAwwOTWFsd2FyZVJlbW92ZXIx
IDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tMIIBIjANBgkqhkiG9w0B
AQEFAAOCAQ8AMIIBCgKCAQEAslO9leo6x+j9WcOBERfas+4YLEDrInSkBY/ZlSz8
z0wj1Y7ZkQQ4QllWtZZs7NorigodzSC+T9HdtsYIrqPBGt8Ywx+dQ+4yZ8eBuC9k
2sFdFsv8VefJAo8JsLRCuoujV2Lu0ENRD9LFsPa2+NTPEbKwzB3rJ8hk9kAoLdB0
fgU2ypkSHXEoqRdcmTiiT90E8qzWZsDBYvx74eUsgFrrjfHQyhs5jL3aRaSwboVl
d2v3oXpb9xxsMlnWMJQmIMu1ucRXUgPLol/7UMTlYf5KWdaZppIBSFLbelf8Ref/
a1lfzWZKGIUeg6oz9SxngsAPTSUyz118uBbEhs1IezjI1QIDAQABozwwOjA4BgNV
HR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5hcC5jb20vY3JsL3F0c192
MS5jcmwwDQYJKoZIhvcNAQELBQADggEBACBpKdRojNaBlLg78Ktz+kYmSaHWAUrG
VLkapk0nzNqiTuPiB/W3qwL906PvV8kQrn8cZrrznqQKEOtIDZ3dhro0ERo3RJcA
u3NC5j9/ADurtxS8QN5EC4oWg53VbJMf5U2mQrSmQTyFTPY2qJLYRkz7em7z+hrv
8TDMCQ4mySncNL9+T4be47M62kU++G+6EimGo7+yFZP2mBHjVWuDOh2q6r9D4bm/
4B46k/nGeJUH9wYgWr5cYET9J+wgKpS9LnOhcBEdVnhjdQNHYuQZLXMSZzjv+sRm
4KhivxNAxE5zdbXfEBA02QNeZfctS6apuqe7rSeZdnlcAcQqiwOGSwcxggKaMIIC
lgIBATCBiTCBgDELMAkGA1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UE
BwwGVGFpcGVpMQ0wCwYDVQQKDARRTkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMM
B1FOQVBfQ0ExIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tAgREEqvI
MAsGCWCGSAFlAwQCAaCB5DAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
SIb3DQEJBTEPFw0yNTEwMjMwNzE5NThaMC8GCSqGSIb3DQEJBDEiBCCrmyG37kI+
85m2y/KY5bu3UaJWqlFNZJmc6/xjSo/QmjB5BgkqhkiG9w0BCQ8xbDBqMAsGCWCG
SAFlAwQBKjALBglghkgBZQMEARYwCwYJYIZIAWUDBAECMAoGCCqGSIb3DQMHMA4G
CCqGSIb3DQMCAgIAgDANBggqhkiG9w0DAgIBQDAHBgUrDgMCBzANBggqhkiG9w0D
AgIBKDANBgkqhkiG9w0BAQEFAASCAQB5VyrwJ0nAjTbOymDd2zkKa3EGnoJmX5US
ixSIO17TkGBl5oMpEmX8BmAsiaD1+E8Ofee05RmXXiVxxssYsZ2U1rVodZtZwVae
Lgv3KqXV9clfy2GNA9trPBQEvONjCH9zFZI9aDFtrRtbZ6oUK1CsEAOej0w7+VSb
o3AS7tBWnsyad1YxFZHohvT9dJUcv3+pEETlZDeheNqUORYaKT/Onpb6ZLe4M19g
7hkjjLqlOwaclDpU3Kqh7hsKSYG2CbsbGdRyEyiW/ToVRuR0lbcCANuLm8/9VAmt
cxnd+h9TKGqRAyqpYFjA8LcW6jMZ1RO8vmho2rtVSOJy1/ebNne/
EOB
readonly r_qpkg_certificate
readonly r_qpkg_signature;}
MakePath(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nopth"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_norea"||return
if ! mkdir -p "$1";then
ShowAsError "unable to create $2 path $(FormatFileName "$1") $(FormatExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0;}
ClearPath(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nopth"||return
ConfirmVarIsDefined 2 "${2:-}" "$e_nopth"||return
local parent=$1
local target=$(/usr/bin/basename "$2")
ConfirmVarIsDefined target "${target:-}" "$e_nopth"||return
[[ -d $parent/$target ]]&&rm -rf "${parent:?}/${target:?}"/*;}
ConfirmVarIsDefined(){
local -i backdepth=1
local first=${1:-undefined}
local second=${2:-undefined}
local third=${3:-undefined}
[[ $second != undefined ]]||{ ShowAsBug "${FUNCNAME[$backdepth]}" "\$$first: '$third'";return;}
return 0;}
FileCountAll(){
[[ -n ${1:-} ]]||return
compgen -G "$1/*"|/usr/bin/wc -l|/bin/sed 's/^ *//';}
FileCountSpec(){
[[ -n ${1:-} ]]||return
compgen -G "$1"|/usr/bin/wc -l|/bin/sed 's/^ *//';}
Executer(){
[[ -n ${1:?${FUNCNAME[0]}(): $e_nocmd} &&-n ${2:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
FuncInit
local a=$(tr -s ' '<<<"$1")
local exec_msg='exec:'
local -r r_log_pathfile=$(/bin/mktemp "$r_run_logs_path"/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
if IsHaveSingleQuote "$a";then
exec_msg+=" \"$a\""
else
exec_msg+=" '$a'"
fi
DebugAsProc "$exec_msg"
FormatCommand "$a">"$2"
if [[ $useropt_verbose = true ]];then
eval "$a 2>&1|/usr/bin/tee $r_log_pathfile"
z=${PIPESTATUS[0]}
else
eval "$a">"$r_log_pathfile" 2>&1
z=$?
fi
if [[ -s $r_log_pathfile ]];then
ShowAsResultAndStdout "$z" "$(<"$r_log_pathfile")">>"$2"
rm -f "$r_log_pathfile" 2>/dev/null
else
ShowAsResultAndStdout "$z" '<null>'>>"$2"
fi
exec_msg='exec: completed'
case $z in
0)
[[ ${3:-} != log:failure-only ||$useropt_debug = true ]]&&AddExtLogToSessLog "$2"
DebugAsDone "$exec_msg OK ($z)"
[[ $useropt_debug = false ]]&&rm -f "$2" 2>/dev/null;;
"${4:-}")
[[ ${3:-} != log:failure-only ||$useropt_debug = true ]]&&AddExtLogToSessLog "$2"
DebugAsWarn "$exec_msg with permitted errors ($z)"
[[ $useropt_debug = false ]]&&rm -f "$2" 2>/dev/null;;
*)AddExtLogToSessLog "$2"
DebugAsError "$exec_msg with errors ($z)"
esac
FuncExit $z;}
KludgeExecuter(){
[[ -n ${1:?${FUNCNAME[0]}(): $e_nocmd} &&-n ${2:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
FuncInit
local a=$(tr -s ' '<<<"$1")
local -i pid=0
local -i z=0
if [[ $useropt_verbose = true ]];then
eval "$a 2>&1|/usr/bin/tee $2" &
else
eval "$a">"$2" 2>&1 &
fi
pid=$!
if [[ $pid -gt 1 ]];then
wait $pid 2>/dev/null
z=$?
fi
pid=$(FindPid '/bin/sh' "$r_local_pathfile")
if [[ $pid -gt 1 ]];then
while [[ -e /proc/$pid ]];do
sleep .5
done
fi
FuncExit $z;}
FindPid(){
ConfirmVarIsDefined 1 "${1:-}" "$e_nopfi"||return
local -i a=0
local b=''
[[ -n ${2:-} &&$2 != undefined ]]&&b=$2
for a in $(/bin/pidof "$(/usr/bin/basename "$1")");do
[[ $a -gt 1 ]]||continue
[[ -d /proc/$a ]]||continue
[[ -e /proc/$a/cmdline &&-L /proc/$a/exe ]]||continue
[[ $(</proc/$a/cmdline) =~ $1 ||$(/usr/bin/readlink /proc/$a/exe) = "$1" ]]||continue
if [[ -n $b ]];then
[[ $(</proc/$a/cmdline) =~ $b ]]||continue
fi
printf '%s' "$a"
return
done
return 1;}
DeDupeWords(){
[[ -n ${1:-} ]]||return
tr ' ' '\n'<<<"$1"|/usr/bin/sort|/bin/uniq|tr '\n' ' '|/bin/sed 's/^[[:blank:]]*//;s/[[:blank:]]*$//';}
SortNames(){
[[ -n ${1:-} ]]||return
local a=''
local b=''
local c=''
local d=''
if (/usr/bin/sort -f</dev/null &>/dev/null);then
tr ' ' '\n'<<<"$1"|/usr/bin/sort -f|/bin/uniq|tr '\n' ' '
else
a=$(tr ' ' '\n'<<<"$(Lowercase "$1")"|/usr/bin/sort|/bin/uniq|tr '\n' ' ')
for b in $a;do
for c in $1;do
[[ $(Lowercase "$c") = "$b" ]]||continue
d+=" $c"
break
done
done
[[ -n $d ]]&&tr '\n' ' '<<<"$d"
fi;}
FileMatchesMD5(){
[[ $(GenerateMD5 "${1:?${FUNCNAME[0]}(): $e_nopfi}") = "${2:?${FUNCNAME[0]}(): $e_nochk}" ]];}
FileLastModifiedEpoch(){
[[ -n ${1:-} &&-e $1 ]]||return
/usr/bin/stat "$1" -c %Y;}
FileLastStatusChangeEpoch(){
[[ -n ${1:-} &&-e $1 ]]||return
/usr/bin/stat "$1" -c %Z;}
GenerateMD5(){
[[ -e ${1:?${FUNCNAME[0]}(): $e_nopfi} ]]&&/bin/md5sum "${1:?${FUNCNAME[0]}(): $e_nopfi}"|cut -f1 -d' ';}
Pluralise(){
[[ ${1:-0} -ne 1 ]]&&printf s;}
Capitalise(){
[[ -n ${1:-} ]]||return
if [[ $1 == sherpa* ]];then
printf '%s' "$1"
else
printf '%s' "$(Uppercase ${1:0:1})${1:1}"
fi;}
Parenthesise(){
printf '(%s)' "${1:-}";}
Bracketise(){
[[ -n ${1:-} ]]||return
printf '[%s]' "$1";}
AddPeriod(){
[[ -n ${1:-} ]]||return
[[ ${1: -1} != ':' &&${1: -1} != '?' &&${1: -1} != '.' ]]&&printf '%s.' "$1"||printf '%s' "$1";}
Uppercase(){
[[ -n ${1:-} ]]||return
tr 'a-z' 'A-Z'<<<"$1";}
Lowercase(){
[[ -n ${1:-} ]]||return
tr 'A-Z' 'a-z'<<<"$1";}
LTrim(){
[[ -n ${1:-} ]]||return
printf '%s' "${1##+(' ')}";}
RTrim(){
[[ -n ${1:-} ]]||return
printf '%s' "${1%%+(' ')}";}
Trim(){
[[ -n ${1:-} ]]||return
RTrim "$(LTrim "$1")";}
FormatAsThous(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
local b=''
local c=''
while [[ ${#a} -gt 0 ]];do
b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then
c=$b
else
c=$b,$c
fi
if [[ ${#b} -eq 3 ]];then
a=${a%???}
else
break
fi
done
printf '%s' "$c"
return 0;}
FormatAsIsoBytes(){
/bin/awk 'BEGIN{ u[0]="B";u[1]="kB";u[2]="MB";u[3]="GB"} { n = $1;i = 0;while(n>1000) { i+=1;n= int((n/1000)+0.5) } print n u[i] } '<<<"${1:-}";}
ShowTitle(){
[[ $show_title = true &&$title_shown = false &&$useropt_verbose = false ]]||return
EraseThisLine
if [[ -z ${r_args_raw[*]} ]];then
Display "$(ShowTitleArt)"
title_art_shown=true
else
Display "$(ShowAsTitleName) $(ShowAsVersion)"
fi
title_shown=true;}
ShowAsTitleName(){
TextBrightWhite sherpa;}
ShowTitleArt(){
Display "$(TextBrightOrange '     _')"
Display "$(TextBrightOrange ' ___| |__   ___ _ __ _ __   __ _')"
Display "$(TextBrightOrange "/ __| '_ \ / _ \ '__| '_ \ / _\` |")  $(ShowAsDescription)"
Display "$(TextBrightOrange '\__ \ | | |  __/ |  | |_) | (_| |')  $(ShowAsCopyrightBasic)"
Display "$(TextBrightOrange '|___/_| |_|\___|_|  | .__/ \__,_|')  $(ShowAsVersion)"
Display "$(TextBrightOrange '                    |_|')";}
ShowAsDescription(){
printf '%s' 'a mini-package-manager for QNAP NAS';}
ShowAsCopyrightBasic(){
printf '%s' 'Copyright (C) 2017-2026 OneCD';}
ShowAsVersion(){
printf '%s' "v$r_this_script_ver";}
ShowAsAction(){
TextBrightYellow "$(Bracketise action)";}
ShowAsSetting(){
TextBrightYellow "$(Bracketise setting)";}
ShowAsPackages(){
TextBrightOrange "$(Bracketise packages)";}
ShowAsPackageGroup(){
TextBrightOrange "$(Bracketise 'package group')";}
ShowAsOptions(){
TextBrightRed "$(Bracketise options)";}
FormatPackageName(){
printf '%s' "${1:-${qpkg_name:?${FUNCNAME[0]}(): $e_nopnm}}";}
FormatFileName(){
printf '%s' "'${1:?${FUNCNAME[0]}(): $e_nofil}'";}
ShowAsURL(){
TextUnderlinedCyan "${1:?${FUNCNAME[0]}(): $e_nourl}";}
FormatExitcode(){
printf '%s' "'${1:?${FUNCNAME[0]}(): $e_noext}'";}
FormatLogFilename(){
printf '%s' "${r_chars_results}log file: '${1:?${FUNCNAME[0]}(): $e_nofil}'";}
FormatCommand(){
echo "${r_chars_results}command: '${1:?${FUNCNAME[0]}(): $e_nocmd}'";}
ShowAsResultAndStdout(){
[[ -n ${1:-} &&-n ${2:-} ]]||return
local a=$r_chars_results
[[ ${1:-0} -ne 0 ]]&&a=$r_chars_alert
echo "${a}result: $(FormatExitcode "$1")"
echo "${a}────────── stdout/stderr begins below ──────────"
echo "$2"
echo "${a}────────── stdout/stderr is complete ──────────";}
DisplayProcReport(){
[[ ${report_title_shown:=false} = false ]]||return
local a=''
[[ -n ${1:-} ]]&&a=$1' '
ShowAsProc "${a}report"
report_title_shown=true;}
DebugInfoMajSepr(){
DebugInfo "$(eval printf '%0.s=' "{1..$r_debug_log_width}")";}
DebugInfoMinSepr(){
DebugInfo "$(eval printf '%0.s-' "{1..$r_debug_log_width}")";}
DebugExtLogMinSepr(){
DebugAsLog "$(eval printf '%0.s-' "{1..$r_debug_log_width}")";}
DebugHardware(){
DebugItem "${1:-}" hardware "${2:-}" "${3:-}";}
DebugKernel(){
DebugItem "${1:-}" kernel "${2:-}" "${3:-}";}
DebugFirmware(){
DebugItem "${1:-}" firmware "${2:-}" "${3:-}";}
DebugOS(){
DebugItem "${1:-}" os "${2:-}" "${3:-}";}
DebugUserspace(){
DebugItem "${1:-}" userspace "${2:-}" "${3:-}";}
DebugStorage(){
DebugItem "${1:-}" storage "${2:-}" "${3:-}";}
DebugScript(){
DebugItem "${1:-}" script "${2:-}" "${3:-}";}
DebugIpk(){
DebugItem "${1:-}" ipk "${2:-}" "${3:-}";}
DebugQpkg(){
DebugItem "${1:-}" qpkg "${2:-}" "${3:-}";}
DebugItem(){
[[ -n ${1:-} &&-n ${2:-} &&-n ${3:-} &&-n ${4:-} ]]||return
local a=$(Uppercase "$2")
case $1 in
error)
DebugErrorTabld "$a" "$3" "$4";;
warning)
DebugWarningTabld "$a" "$3" "$4";;
info)
DebugInfoTabld "$a" "$3" "$4";;
*)DebugDetectTabld "$a" "$3" "$4"
esac;}
DebugDetectTabld(){
if [[ ${3:-} = N/A ]];then
DebugAsNA "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" N/A)"
elif [[ -z ${3:-} ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugInfoTabld(){
if [[ -z ${3:-} ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugWarningTabld(){
if [[ -z ${3:-} ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugErrorTabld(){
if [[ -z ${3:-} ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$(/bin/sed 's/ *$//'<<<"${3:-}")")"
else
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi;}
DebugVar(){
if [[ -n ${!1:-} ]];then
DebugAsVar "\$$1: '${!1}'"
else
DebugAsVar "\$$1: null"
fi;}
DebugArray(){
[[ -n ${1:-} ]]||return
if [[ -n ${2:-} ]];then
DebugAsArray "\$$1: ['$2']"
else
DebugAsArray "\$$1: null"
fi;}
DebugInfo(){
[[ -n ${1:-} ]]||return
if [[ ${2:-} = ' ' ||${2:-} = "'' " ]];then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi;}
FuncInit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn;}
FuncExit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
return ${1:-0};}
FuncForkInit(){
[[ -n ${pidfile:?${FUNCNAME[0]}(): $e_nopfi} ]]||return
trap '[[ -n ${pidfile:-} &&-e $pidfile ]]&&rm -f "$pidfile" 2>/dev/null;exit' SIGINT
orig_session_active_log_pathfile=$session_active_log_pathfile
session_active_log_pathfile=$(/bin/mktemp "$r_action_log_path"/"${FUNCNAME[1]}"_XXXXXX)
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn
[[ ${FUNCNAME[1]} != _ExecOneActionWithManyForks_ ]]&&MarkActionForkAsEntry;}
FuncForkExit(){
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
[[ ${FUNCNAME[1]} != _ExecOneActionWithManyForks_ ]]&&MarkActionForkAsExit
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
if [[ -n ${session_active_log_pathfile:-} &&-e $session_active_log_pathfile ]];then
if [[ -s $session_active_log_pathfile ]];then
/bin/cat "$session_active_log_pathfile">>"$orig_session_active_log_pathfile"
fi
rm -f "$session_active_log_pathfile"
fi
RemovePidFile
exit ${1:-0}
} 2>/dev/null
CalcAmountDiff(){
if [[ $2 -gt $1 ]];then
printf '%s' "$(($2-$1))"
else
printf '%s' "$(($1-$2))"
fi
} 2>/dev/null
CalcMillisecondsDiffFromNanoseconds(){
printf '%s' "$((($2-$1)/(10**6)))"
} 2>/dev/null
ConvertSecondsToFullDate(){
/bin/date -d @"${1:-}" "$r_full_datetime_format"
} 2>/dev/null
ConvertSecondsToDatecode(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
if [[ ${#a} -ne 10 ]];then
printf 000000
return 1
fi
/bin/date -d @"$a" '+%y%m%d'
} 2>/dev/null
ConvertSecondsToTime(){
/bin/date -d @"${1:-}" '+%-l:%M:%S %p'|tr -s ' '
} 2>/dev/null
ConvertSecondsToDuration(){
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
if [[ $h -gt 0 ]];then
printf '%01dh:%02dm:%02ds' "$h" "$m" "$s"
elif [[ $m -gt 0 ]];then
printf '%01dm:%02ds' "$m" "$s"
else
[[ $s -eq 0 ]]&&s=1
if [[ $s -eq 1 ]];then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
fi
} 2>/dev/null
ConvertMillisecondsToSeconds(){
printf '%s' "$(($1/(10**3)))"
} 2>/dev/null
ConvertMillisecondsToDuration(){
ConvertSecondsToDuration "$(ConvertMillisecondsToSeconds "${1:-}")"
} 2>/dev/null
ConvertMillisecondsToFuncDuration(){
if [[ ${1:-0} -lt 30000 ]];then
printf '%s' "$(FormatAsThous "${1:-0}")ms"|/usr/bin/tail -n1
else
ConvertMillisecondsToDuration "$1"
fi
} 2>/dev/null
ConvertNanosecondsToMilliseconds(){
printf '%s' "$(($1/(10**6)))"
} 2>/dev/null
ConvertLongDateAsHuman(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
if [[ ${#a} -ne 8 ]];then
printf 'invalid longdate code length'
return 1
fi
local b=${a:6:2}
local c=''
if((b>= 1 &&b<= 10));then
c=early
elif((b>= 11 &&b<= 20));then
c=mid
elif((b>= 21 &&b<= 31));then
c=late
else
printf 'invalid day code'
return 1
fi
b=${a:4:2}
if((b<1 ||b>12));then
printf 'invalid month code'
return 1
fi
printf '%s-%s %s' "$c" "$(/bin/date -d 2025-$b-01 '+%B')" "${a::4}";}
ConvertAsSmartDate(){
[[ -n ${1:-} ]]||return
local a=${1//[!0-9]/}
local b=''
case ${#a} in
6)
b=$(/bin/date -d "${a::2}-${a:2:2}-${a:4:2}" "$r_extended_datetime_format");;
7)
b=$(/bin/date -d "${a:1:2}-${a:3:2}-${a:5:2}" "$r_extended_datetime_format");;
8)
b=$(/bin/date -d ${a::4}-${a:4:2}-${a:6:2} "$r_extended_datetime_format");;
10)
b=$(/bin/date -d @"$a" "$r_full_datetime_format")
esac
if [[ -n $b ]];then
printf '%s (%s)' "$1" "$b"
else
printf '%s' "$1"
fi
return
} 2>/dev/null
ConvertNowToFullDate(){
/bin/date "$r_full_datetime_format"
} 2>/dev/null
ConvertNowToSeconds(){
/bin/date +%s
} 2>/dev/null
ConvertNowToMilliseconds(){
ConvertNanosecondsToMilliseconds "$(ConvertNowToNanoseconds)"
} 2>/dev/null
ConvertNowToNanoseconds(){
/bin/date +%s%N
} 2>/dev/null
DebugAsFuncEn(){
DebugThis "$(Parenthesise '>>') ${FUNCNAME[2]}()";}
DebugAsFuncEx(){
DebugThis "$(Parenthesise '<<') ${FUNCNAME[2]}()|${1:-0}|${2:-}";}
DebugAsProc(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '--') $1";}
DebugAsDone(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '==') $1";}
DebugAsDetect(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise '**') $1";}
DebugAsInfo(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise II) $1";}
DebugAsWarn(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise "$(TextBrightOrange WW)") $(TextBrightOrange "$1")";}
DebugAsError(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise "$(TextBrightRed EE)") $(TextBrightRed "$1")";}
DebugAsLog(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise LL) $1";}
DebugAsVar(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise vv) $1";}
DebugAsArray(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise aa) $1";}
DebugAsNA(){
[[ -n ${1:-} ]]&&DebugThis "$(Parenthesise "$(TextDarkGrey NA)") $(TextDarkGrey "$1")";}
DebugThis(){
[[ -n ${1:-} ]]||return
local a=dbug
local b=$1
[[ ${useropt_verbose:-false} = true ]]&&ShowAsDebug "$b"
if [[ ${useropt_show_about:=false} = false &&${useropt_show_aboutall:=false} = false ]];then
WriteToLog "$a" "$b"
fi;}
AddExtLogToSessLog(){
local a=''
local b=false
if [[ $useropt_verbose = true ]];then
b=true
useropt_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(FormatLogFilename "${1:?${FUNCNAME[0]}(): $e_nopfi}")"
while read -r a;do
DebugAsLog "$a"
done<"$1"
DebugExtLogMinSepr
useropt_verbose=$b;}
ShowAsProcLong(){
[[ -n ${1:-} ]]&&ShowAsProc "${1:-} (might take a while)" "${2:-}"
}>&2
ShowAsProc(){
[[ -n ${1:-} ]]||return
local a=proc
local b=$1
local c=''
[[ -n ${2:-} ]]&&c=$2
local d="$b ... $c"
if [[ -z ${r_inhibit_display_pathfile:-} ]]||[[ -n ${r_inhibit_display_pathfile:-} &&! -e $r_inhibit_display_pathfile ]];then
if [[ ${useropt_verbose:=false} = false &&${useropt_terse:=true} = true ]]||[[ ${useropt_verbose:=false} = false &&-n $c ]];then
OpStepClearWait "$(TextBrightYellow "$a")" "$d"
else
OpStepClear "$(TextBrightYellow "$a")" "$d"
fi
fi
WriteToLog "$a" "$d"
}>&2
ShowAsDebug(){
[[ -n ${1:-} ]]&&OpStepClear "$(TextBlackOnCyan dbug)" "$1";}
ShowAsNote(){
[[ -n ${1:-} ]]||return
local a=note
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightYellow "$a")" "$b"
WriteToLog "$a" "$b"
}>&2
ShowAsDone(){
[[ -n ${1:-} ]]||return
local a='done'
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightGreen "$a")" "$b"
WriteToLog "$a" "$b"
}>&2
ShowAsNews(){
[[ -n ${1:-} ]]||return
local a=news
local b=$1
OpStepClear "$(TextBrightWhiteBlink "$a")" "$b"
WriteToLog "$a" "$b"
}>&2
ShowAsWarn(){
[[ -n ${1:-} ]]||return
local a=warn
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightOrange "$a")" "$b"
WriteToLog "$a" "$b"
}>&2
ShowAsAbort(){
[[ -n ${1:-} ]]||return
local a=bort
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError
}>&2
ShowAsFail(){
[[ -n ${1:-} ]]||return
local a=fail
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
}>&2
ShowAsError(){
[[ -n ${1:-} ]]||return
local a=derp
local b=$(AddPeriod "$1")
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError
}>&2
ShowAsBug(){
[[ -n ${1:-} &&-n ${2:-} ]]||return
local a=buug
local b='fstack: '
local c=' '
local -i i=0
for((i=${#FUNCNAME[@]}-1;i>=0;i--));do
[[ $i -ne $((${#FUNCNAME[@]}-1)) ]]&&b+="${c}>${c}"
if [[ ${FUNCNAME[$i]} = "$1" ]];then
b+="${FUNCNAME[$i]}($2)"
else
b+="${FUNCNAME[$i]}()"
fi
done
OpStepClear "$(TextBrightRed "$a")" "$b"
WriteToLog "$a" "$b"
SetError
}>&2
ShowAsQuiz(){
[[ -n ${1:-} ]]||return
local a=quiz
local b=$1:
OpStepClearWait "$(TextBrightOrangeBlink "$a")" "$b"
WriteToLog "$a" "$b";}
ShowAsQuizDone(){
[[ -n ${1:-} ]]||return
local a=quiz
local b=$1
OpStepClear "$(TextBrightOrange "$a")" "$b";}
ShowAsPercentProgress(){
local -r r_a=${1:-}
local -i b=${3:-0}
local -i c=${4:-0}
local -i d=${5:-0}
local -i e=${6:-0}
local -r r_f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then
ShowAsProc "$r_a" "$r_f"
else
ShowAsProcLong "$r_a" "$r_f"
fi
[[ $((b+c+d)) -ge $e ]]&&sleep 0.5
return 0
}>&2
PercFrac(){
local -i a=$((${1:-0}+${2:-0}+${3:-0}))
local -i b=${4:-0}
local c=''
[[ $b -gt 0 ]]||return
if [[ $a -gt $b ]];then
a=$b
c='100%'
else
c=$((200*(a+1)/(b+1)%2+100*(a+1)/(b+1)))%
fi
printf '%s' "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0
} 2>/dev/null
ShowAsIterativeProgress(){
ConfirmVarIsDefined 1 "${1:-}" "$e_noopr"||return
ConfirmVarIsDefined 3 "${3:-}" "$e_nostr"||return
ConfirmVarIsDefined 5 "${5:-}" "$e_nostr"||return
local -r r_a=$1
local -i b=${2:-0}
local -r r_c=$3
local -i d=${4:-0}
local -r r_e=$5
local f=''
f="$(TextBrightWhite "$b") ${r_c}$(Pluralise "$b") ($(TextBrightWhite "$d") ${r_e}$(Pluralise "$d"))"
if [[ ${6:-short} != long ]];then
ShowAsProc "$r_a" "$f"
else
ShowAsProcLong "$r_a" "$f"
fi
return 0;}
ShowAsActionLogDetail(){
ConfirmVarIsDefined 2 "${2:-}" "$e_nopnm"||return
ConfirmVarIsDefined 7 "${7:-}" "$e_nostr"||return
local package_type=''
local quantity_msg=''
package_type=$7$(Pluralise "$8")
case $8 in
0)
quantity_msg='no ';;
1)
:;;
*)quantity_msg=$8' '
esac
ConfirmVarIsDefined 8 "${8:-}" "$e_noval"||return
case ${4:-} in
failed)
if [[ -n "${6:-}" ]];then
case $3 in
download|?(reas)sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6";;
*)if IsQpkgDbWillLog "$2";then
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "for more information: /etc/init.d/$(/usr/bin/basename "$(GetQpkgServicePathFile "$2")") log"
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
fi
esac
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" 'no reason was provided by the service-script'
fi;;
skipped*)if [[ -n "${6:-}" ]];then
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "$6"
else
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "no reason provided"
fi;;
*)DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" "$5" "$6"
esac
return 0;}
OpStepClearWait(){
local -i n=4
[[ ${colourful:=$r_colourful_default} = true ]]&&n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
OpStepClear(){
local -i n=4
[[ $colourful = true ]]&&n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0;}
WriteToLog(){
[[ -n ${1:-} &&-n ${2:-} ]]||return
[[ ${useropt_debug:=false} = true &&-n ${session_active_log_pathfile:-} ]]&&printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")">>"$session_active_log_pathfile";}
TextBrightGreen(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightYellow(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
#TextBrightYellowBlink()
TextBrightOrange(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrangeBlink(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRed(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRedBlink(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextDarkGrey(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextUnderlinedCyan(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBlackOnCyan(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightWhite(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightWhiteBlink(){
[[ -n ${1:-} ]]||return
if [[ $colourful = true ]];then
printf '\033[1;5;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
Tableise(){
[[ -x $r_gnu_awk_cmd ]]||return
$r_gnu_awk_cmd '{
nf[NR]=NF
for (i = 1;i<= NF;i++) {
cell[NR,i] = $i
gsub(/\033\[[0-9;]*[mK]/, "", $i)
len[NR,i] = l = length($i)
if (l>max[i]) max[i] = l;}
}
END {
for (row = 1;row<= NR;row++) {
for (col = 1;col<nf[row];col++)
printf "%s%*s%s", cell[row,col], max[col]-len[row,col], "", OFS
print cell[row,nf[row]];}
}' FS='|' OFS="$(printf "%$((r_report_column_spacing))s")";}
StripANSICodes(){
if IsOsSedExtRegexSupported;then
echo -en "${1:-}"|/bin/sed -r 's/\x1b\[[0-9;]*m//g'
elif [[ -x /opt/bin/sed &&-L /opt/etc/passwd ]];then
echo -en "${1:-}"|/opt/bin/sed -r 's/\x1b\[[0-9;]*m//g'
else
echo -en "${1:-}"
fi
} 2>/dev/null
SetQpkgIndex(){
[[ -n ${qpkg_name:-} ]]||return
SetQpkgArch
for qpkg_index in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$qpkg_index]} = "$qpkg_name" ]]||continue
return 0
done
qpkg_index=0
return 1;}
SetError(){
run_package_actions=false
IsError&&return
_script_error_flag_=true
DebugVar _script_error_flag_;}
SetHardwareCPUCores(){
[[ ${r_cpu_cores:-unset} = unset ]]&&readonly r_cpu_cores=$(GetHardwareCPUCores);}
SetHardwareInstalledRAM(){
[[ ${r_nas_ram_kb:-unset} = unset ]]&&readonly r_nas_ram_kb=$(GetHardwareInstalledRAMkb)
[[ ${r_nas_ram_gb:-unset} = unset ]]&&readonly r_nas_ram_gb=$(GetHardwareInstalledRAMgb);}
SetHardwarePlatform(){
[[ ${r_nas_platform:-unset} = unset ]]&&readonly r_nas_platform=$(GetHardwarePlatform);}
SetCapabilities(){
SetColourisation
UpdateOsSedRegexSupport
UpdateOsDecimalSleepSupport;}
SetColourisation(){
if [[ $r_colourful_default = true ]];then
colourful=true
SendParentCommand 'colourful=true'
else
colourful=false
SendParentCommand 'colourful=false'
fi;}
SetOsSedRegexSupport(){
IsOsCanSedExtRegex
sed_ext_regex_supported=$?;}
SetOsDecimalSleepSecondsSupport(){
IsOsCanDecimalSleepSeconds
sleep_decimal_seconds_supported=$?;}
SetOsKernelPageSize(){
[[ ${r_kernel_page_size:-unset} = unset ]]&&readonly r_kernel_page_size=$(GetOsKernelPageSize);}
SetOsFirmwareVersion(){
[[ ${r_nas_firmware_version:-unset} = unset ]]&&readonly r_nas_firmware_version=$(GetOsFirmwareVersion);}
SetOsFirmwareVer(){
[[ ${r_nas_firmware_ver:-unset} = unset ]]&&readonly r_nas_firmware_ver=$(GetOsFirmwareVer);}
SetOsFirmwareDate(){
[[ ${r_nas_firmware_date:-unset} = unset ]]&&readonly r_nas_firmware_date=$(GetOsFirmwareDate);}
SetOsFirmwareBuild(){
[[ ${r_nas_firmware_build:-unset} = unset ]]&&readonly r_nas_firmware_build=$(GetOsFirmwareBuild);}
SetNasArch(){
[[ ${r_nas_arch:-unset} = unset ]]&&readonly r_nas_arch=$(GetNasArch);}
SetQpkgArch(){
[[ ${r_nas_qpkg_arch:-unset} = unset ]]&&readonly r_nas_qpkg_arch=$(GetQpkgArch);}
UpdateOsSedRegexSupport(){
unset sed_ext_regex_supported
SetOsSedRegexSupport;}
UpdateOsDecimalSleepSupport(){
unset sleep_decimal_seconds_supported
SetOsDecimalSleepSecondsSupport;}
HideCursor(){
[[ ${useropt_verbose:=false} = false ]]&&printf '\033[?25l';}
ShowCursor(){
printf '\033[?25h';}
HideKeystrokes(){
[[ ${useropt_verbose:=false} = false &&-n ${r_gnu_stty_cmd:-} &&-x $r_gnu_stty_cmd ]]&&IsInTerminal &&$r_gnu_stty_cmd '-echo';}
ShowKeystrokes(){
[[ -n ${r_gnu_stty_cmd:-} &&-x $r_gnu_stty_cmd ]]&&IsInTerminal &&$r_gnu_stty_cmd 'echo';}
sleep(){
local n=${1:-}
[[ ${n//.} -eq 0 ]]&&n=1
if IsOsDecimalSleepSecondsSupported;then
/bin/sleep "$n"
elif [[ -x $r_gnu_sleep_cmd &&-L /opt/etc/passwd ]];then
$r_gnu_sleep_cmd "$n"
else
/bin/sleep "$((${n%.*}+1))"
fi
return 0
} 2>/dev/null
RefreshArchive(){
ConfirmVarIsDefined archive_name "${archive_name:-}" "$e_nonam"||return
ConfirmVarIsDefined archive_pathfile "${archive_pathfile:-}" "$e_nopfi"||return
ConfirmVarIsDefined archive_url "${archive_url:-}" "$e_nourl"||return
ConfirmVarIsDefined dont_refresh_pathfile "${dont_refresh_pathfile:-}" "$e_nopfi"||return
ConfirmVarIsDefined target_pathfile "${target_pathfile:-}" "$e_nopfi"||return
FuncInit
local curl_insecure_opt=''
local download=false
local downloaded=false
local extract=false
extracted=false
local new_archive_checksum=''
local orig_archive_checksum=''
if IsFile "$archive_pathfile";then
DebugAsDetect "'$archive_name' archive found"
orig_archive_checksum=$(GenerateMD5 "$archive_pathfile")
if IsFileRecent "$archive_pathfile" "$r_file_change_threshold_minutes";then
DebugAsDetect "'$archive_name' archive is recent"
else
DebugAsDetect "'$archive_name' archive is not recent"
download=true
fi
else
DebugAsDetect "'$archive_name' archive missing ($archive_pathfile)"
download=true
fi
if [[ $download = true &&-e $dont_refresh_pathfile ]];then
DebugAsInfo "ignoring request to download because '$dont_refresh_pathfile' exists"
download=false
fi
if [[ $download = true ]];then
DebugAsProc "download '$archive_name' archive"
DebugVar archive_url
IsOsCanSecureDownload ||curl_insecure_opt=' --insecure'
/sbin/curl --silent --location --fail $curl_insecure_opt "$archive_url">"$archive_pathfile" 2>/dev/null
if IsFile "$archive_pathfile";then
DebugAsDone "download '$archive_name' archive OK"
downloaded=true
else
DebugAsWarn "download '$archive_name' archive failed"
fi
fi
if IsFile "$archive_pathfile";then
new_archive_checksum=$(GenerateMD5 "$archive_pathfile")
if [[ $downloaded = true ]];then
if [[ $orig_archive_checksum = "$new_archive_checksum" ]];then
DebugAsDetect "downloaded '$archive_name' archive is same as previous archive"
else
DebugAsDetect "downloaded '$archive_name' archive is different to previous archive"
extract=true
fi
else
if [[ $orig_archive_checksum = "$new_archive_checksum" ]];then
DebugAsDetect "'$archive_name' archive is unchanged"
else
DebugAsDetect "'$archive_name' archive is different"
extract=true
fi
fi
else
DebugAsWarn "'$archive_name' archive missing"
fi
if IsFile "$target_pathfile";then
DebugAsDetect "'$archive_name' found"
else
DebugAsDetect "'$archive_name' missing"
extract=true
fi
if [[ $extract = true &&-e $dont_refresh_pathfile ]];then
DebugAsInfo "ignoring request to extract because '$dont_refresh_pathfile' exists"
extract=false
fi
if [[ $extract = true ]];then
if IsFile "$archive_pathfile";then
DebugAsProc "extract '$archive_name' from archive"
/bin/tar --extract --gzip --no-same-owner --file="$archive_pathfile" --directory="$r_cache_path"
if IsFile "$target_pathfile";then
DebugAsDone "extract '$archive_name' from archive OK"
extracted=true
else
DebugAsWarn "extract '$archive_name' from archive failed"
fi
elif IsNtFile "$target_pathfile";then
ShowAsAbort "no '$archive_name' archive exists to extract from, can't continue"
FuncExit 1;exit
fi
fi
if IsFile "$target_pathfile";then
if [[ $extracted = true ]];then
DebugAsInfo "continue with extracted '$archive_name'"
else
DebugAsInfo "continue with original '$archive_name'"
fi
else
ShowAsAbort "'$archive_name' missing, can't continue"
FuncExit 1;exit
fi
FuncExit;}
LoadObjects(){
[[ ${objects_loaded:=false} = false ]]||return 0
FuncInit
LoadLists
ShowAsProc objects
local archive_name=objects
local archive_pathfile=$r_objects_archive_pathfile
local archive_url=$r_objects_archive_url
local dont_refresh_pathfile=$PWD/dont-refresh-objects
local extracted=false
local target_pathfile=$r_objects_pathfile
if ! RefreshArchive;then
FuncExit 1;exit
fi
unset r_objects_epoch
r_objects_epoch=undefined
. "$r_objects_pathfile"
objects_loaded=true
readonly r_objects_epoch
DebugVar r_objects_epoch
FuncExit;}
LoadDatabase(){
[[ ${packages_loaded:=false} = false ]]||return 0
FuncInit
LoadObjects
ShowAsProc database
local archive_name=database
local archive_pathfile=$r_packages_archive_pathfile
local archive_url=$r_packages_archive_url
local dont_refresh_pathfile=$PWD/dont-refresh-database
local extracted=false
local target_pathfile=$r_packages_pathfile
if ! RefreshArchive;then
FuncExit 1;exit
fi
if [[ $extracted = true ]];then
InitQPKGsTiers
InitQPKGsStates
fi
unset r_qpkg_abbrvs
unset r_qpkg_appl_author
unset r_qpkg_appl_author_email
unset r_qpkg_appl_version
unset r_qpkg_author
unset r_qpkg_author_email
unset r_qpkg_can_backup
unset r_qpkg_can_clean
unset r_qpkg_can_restart_to_update
unset r_qpkg_conflicts_with
unset r_qpkg_depends_on
unset r_qpkg_description
unset r_qpkg_hash
unset r_qpkg_is_sherpa_compatible
unset r_qpkg_is_unique_unpack
unset r_qpkg_max_os_version
unset r_qpkg_min_os_version
unset r_qpkg_min_ram_kb
unset r_qpkg_name
unset r_qpkg_opt_depends_on
unset r_qpkg_requires_ipks
unset r_qpkg_test_for_active
unset r_qpkg_url
unset r_qpkg_version
unset r_qpkg_will_log
unset r_base_pips
unset r_base_qpkg_conflicts_with
unset r_base_qpkg_warnings
unset r_essential_ipks
unset r_exclusion_pips
unset r_packages_epoch
r_packages_epoch=undefined
r_qpkg_abbrvs+=('')
r_qpkg_appl_author+=('')
r_qpkg_appl_author_email+=('')
r_qpkg_appl_version+=('')
r_qpkg_author+=('')
r_qpkg_author_email+=('')
r_qpkg_can_backup+=('')
r_qpkg_can_clean+=('')
r_qpkg_can_restart_to_update+=('')
r_qpkg_conflicts_with+=('')
r_qpkg_depends_on+=('')
r_qpkg_description+=('')
r_qpkg_hash+=('')
r_qpkg_is_sherpa_compatible+=('')
r_qpkg_is_unique_unpack+=('')
r_qpkg_max_os_version+=('')
r_qpkg_min_os_version+=('')
r_qpkg_min_ram_kb+=('')
r_qpkg_name+=('')
r_qpkg_opt_depends_on+=('')
r_qpkg_requires_ipks+=('')
r_qpkg_test_for_active+=('')
r_qpkg_url+=('')
r_qpkg_version+=('')
r_qpkg_will_log+=('')
. "$r_packages_pathfile"
packages_loaded=true
r_qpkgs_name_prohibited=(OMedusa OqBittorrent OReadarr OSickGear OSonarr OTautulli OTransmission OWhisparr)
readonly r_qpkg_abbrvs
readonly r_qpkg_appl_author
readonly r_qpkg_appl_author_email
readonly r_qpkg_appl_version
readonly r_qpkg_author
readonly r_qpkg_author_email
readonly r_qpkg_can_backup
readonly r_qpkg_can_clean
readonly r_qpkg_can_restart_to_update
readonly r_qpkg_conflicts_with
readonly r_qpkg_depends_on
readonly r_qpkg_description
readonly r_qpkg_hash
readonly r_qpkg_is_sherpa_compatible
readonly r_qpkg_is_unique_unpack
readonly r_qpkg_max_os_version
readonly r_qpkg_min_os_version
readonly r_qpkg_min_ram_kb
readonly r_qpkg_name
readonly r_qpkg_opt_depends_on
readonly r_qpkg_requires_ipks
readonly r_qpkg_test_for_active
readonly r_qpkg_url
readonly r_qpkg_version
readonly r_qpkg_will_log
readonly r_base_pips
readonly r_base_qpkg_conflicts_with
readonly r_base_qpkg_warnings
readonly r_essential_ipks
readonly r_exclusion_pips
readonly r_packages_epoch
readonly r_qpkgs_name_prohibited
DebugVar r_packages_epoch
QPKGs-GRall:Add "$(SortNames "${r_qpkg_name[*]}")"
BuildQPKGsTiers
FuncExit;}
CaughtSIGINT(){
trap - SIGINT
[[ -n ${r_inhibit_display_pathfile:-} ]]&&/bin/touch "$r_inhibit_display_pathfile"
[[ -n ${r_abort_actions_pathfile:-} ]]&&/bin/touch "$r_abort_actions_pathfile"
EraseThisLine
ShowAsAbort 'caught SIGINT'
CloseMsgPipe
exit;}
CaughtEXIT(){
trap - EXIT
ShowKeystrokes
ShowCursor
ReleaseLockfile;}
readonly r_script_startseconds=$(ConvertNowToSeconds)
trap CaughtSIGINT SIGINT
trap CaughtEXIT EXIT
Init||exit
ProcActions
ShowResults
IsNtError
