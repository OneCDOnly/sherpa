#!/usr/bin/env bash
#* Please don't edit this file directly, it was built/modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#* sherpa-manager.sh
#* Copyright (C) 2017-2024 OneCD - one.cd.only@gmail.com
#*   So, blame OneCD if it all goes horribly wrong. ;)
#* Description:
#*   This is the management script for the sherpa mini-package-manager.
#*   It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#* Project:
#*	 https://git.io/sherpa
#* Forum:
#*	 https://forum.qnap.com/viewtopic.php?f=320&t=132373
#* Tested on:
#*	 GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	 GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	   Copyright (C) 2007 Free Software Foundation, Inc.
#* ... and periodically on:
#*	 GNU bash, version 5.0.17(1)-release (aarch64-openwrt-linux-gnu)
#*	   Copyright (C) 2019 Free Software Foundation, Inc.
#* License:
#*   This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
set -o nounset -o pipefail
readonly USER_ARGS_RAW=$*
readonly SCRIPT_STARTSECONDS=$(/bin/date +%s)
Self:Init()
{
OS.IsOk || return
Consts:Load
Vars:Load
User.IsOk || return
CMDs:Load
CMDs.IsOk || return
Keystrokes:Hide
Cursor:Hide
Env:Load
Self.LockFile:Claim || return
trap RunOnEXIT EXIT
trap RunOnSIGINT INT
sess_active_pathfile=$THIS_PACKAGE_PATH/session.$$.active.log
rm -f "$REPORT_OUTPUT_PATHFILE" "$RAMDISKS_FREESPACE_PATHFILE" "$DISPLAY_INHIBIT_PATHFILE"
[[ ! -e /dev/fd ]] && ln -s /proc/self/fd /dev/fd
[[ -e $PYTHON3_CMD && ! -L $PYTHON_CMD ]] && ln -s "$PYTHON3_CMD" "$PYTHON_CMD"
EnableVerboseIfRequested
EnableDebugIfRequested
Lists:Load
CreatePaths || return
ArchivePriorSessLogs
EnableResetIfRequested
TerminalDimensions:Load
Debug.Log:Init
Objects:Load || return
QPKG.IsInstalled Entware && [[ $ENTWARE_VER = none ]] && DebugAsWarn "$(ShowAsPackageName Entware) appears to be installed but is inactive. Consider 'start'ing the Entware QPKG if-possible."
if [[ -z $USER_ARGS_RAW ]]; then
opts_show_basic_help=true
skip_package_actions=true
DisableDebugToArchiveAndFile
else
Packages:Load || return
ParseArgs
fi
EraseThisLine
ShowTitleLine
if ! QPKGs.Conflicts:Check; then
skip_package_actions=true
return 1
fi
QPKGs.Warnings:Check
ArgSuggestions:Show
Debug.Log:Env
Self.Tasks:Check
Self:Validate
}
Self.Results:Show()
{
Func:Init
display_last_action_datetime=false
if ARGs-unknown.IsNone; then
if [[ $opts_show_abbreviations = true ]]; then
Report.Abbreviations:Show
elif [[ $opts_show_actions = true ]]; then
Report.Actions:Show
elif [[ $opts_show_reassign = true ]]; then
Report.Action.Reassign:Show
elif [[ $opts_show_actions_all = true ]]; then
Report.ActionsAll:Show
elif [[ $opts_show_options = true ]]; then
Report.Options:Show
elif [[ $opts_show_problems = true ]]; then
Report.Problems:Show
elif [[ $opts_show_groups = true ]]; then
Report.Groups:Show
elif [[ $opts_show_versions = true ]]; then
Report.Versions:Show
fi
if [[ $opts_show_backups = true ]]; then
Report.Backups:Show
fi
if [[ $opts_show_dependencies = true ]]; then
Report.Dependencies:Show
fi
if [[ $opts_show_packages = true ]]; then
Report.Packages:Show
fi
if [[ $opts_show_repos = true ]]; then
Report.Repos:Show
fi
if [[ $opts_show_results = true ]]; then
display_last_action_datetime=true
opts_show_packages_ok=true
opts_show_packages_skipped=true
opts_show_packages_failed=true
fi
if [[ $opts_show_status = true ]]; then
Report.Statuses:Show
opts_show_packages_ok=false
opts_show_packages_skipped=false
opts_show_packages_failed=false
fi
if [[ $opts_show_tips = true ]]; then
Report.Tips:Show
fi
if [[ $opts_paste_log_last = true ]]; then
Log.Last:Paste
elif [[ $opts_paste_log_tail = true ]]; then
Log.Tail:Paste
elif [[ $opts_show_log_last = true ]]; then
Self.LockFile:Release
Log.Last:View
elif [[ $opts_show_log_tail = true ]]; then
Self.LockFile:Release
Log.Tail:View
fi
if QPKGs.AClist.ISbackedup.IsSet; then
QPKGs.IsBackedUp:Show
elif QPKGs.AClist.ISNTbackedup.IsSet; then
QPKGs.IsNtBackedUp:Show
elif QPKGs.AClist.ISinstalled.IsSet; then
QPKGs.IsInstalled:Show
elif QPKGs.AClist.ISNTinstalled.IsSet; then
QPKGs.IsNtInstalled:Show
elif QPKGs.AClist.ISactive.IsSet; then
QPKGs.IsActive:Show
elif QPKGs.AClist.ISNTactive.IsSet; then
QPKGs.IsNtActive:Show
elif QPKGs.AClist.SCinstallable.IsSet; then
QPKGs.ScInstallable:Show
elif QPKGs.AClist.SCupgradable.IsSet; then
QPKGs.ScUpgradable:Show
elif QPKGs.AClist.SCindependent.IsSet; then
QPKGs.ScIndependent:Show
elif QPKGs.AClist.SCdependent.IsSet; then
QPKGs.ScDependent:Show
fi
fi
if [[ $opts_show_basic_help = true ]]; then
Help.Basic:Show
Help.Basic.Examples:Show
fi
[[ $opts_show_packages_ok = true ]] && Report.Results:Show ok
[[ $opts_show_packages_skipped = true ]] && Report.Results:Show skipped
[[ $opts_show_packages_failed = true ]] && Report.Results:Show failed
[[ $opts_show_backuploc = true ]] && Help.BackupLocation:Show
[[ $show_zero_qpkgs = true ]] && ShowZeroQpkgs
[[ $show_suggest_raise_issue = true ]] && Help.Issue:Show
DebugInfoMinSepr
DebugScript finished "$(/bin/date)"
DebugScript 'elapsed time' "$(FormatSecsToHoursMinutesSecs "$(($(/bin/date +%s)-SCRIPT_STARTSECONDS))")"
DebugInfoMajSepr
Func:Exit
[[ $self_archive_debug_afterward = true ]] && ArchiveActiveSessLog
ResetActiveSessLog
[[ $hide_title = false && $opts_verbose = false ]] && WriteEmptyLineIfNoneExists
}
Debug.Log:Init()
{
DebugInfoMajSepr
DebugScript started "$(/bin/date -d @"$SCRIPT_STARTSECONDS" | tr -s ' ')"
DebugScript PID "$$"
DebugInfoMinSepr
DebugInfo 'Markers: (**) detected, (II) information, (WW) warning, (EE) error, (LL) log file, (--) processing,'
DebugInfo '(==) done, (>>) f entry, (<<) f exit, (vv) variable name & value, ($1) positional argument value'
DebugInfoMinSepr
DebugVar THIS_PACKAGE_VER
DebugVar THIS_SCRIPT_VER
DebugVar LOADER_SCRIPT_VER
}
Consts:Load()
{
readonly QPKG_DISABLE_TIMEOUT_SECONDS=10
readonly QPKG_ENABLE_TIMEOUT_SECONDS=10
readonly QPKG_RESTART_TIMEOUT_SECONDS=1800
readonly QPKG_START_TIMEOUT_SECONDS=1500
readonly QPKG_STATUS_CHECK_TIMEOUT_SECONDS=15
readonly QPKG_STOP_TIMEOUT_SECONDS=300
readonly ACTION_RESULT_INDENT=6
readonly FILE_NAME_COL_WIDTH=33
readonly HELP_DESC_INDENT=3
readonly HELP_SYNTAX_INDENT=6
readonly PACKAGE_ABBS_COL_WIDTH=84
readonly PACKAGE_APP_VER_COL_WIDTH=16
readonly PACKAGE_ARCH_COL_WIDTH=15
readonly PACKAGE_AUTHOR_COL_WIDTH=40
readonly PACKAGE_DEPENDENCIES_COL_WIDTH=29
readonly PACKAGE_DESCRIPTION_COL_WIDTH=10
readonly PACKAGE_ENABLED_COL_WIDTH=12
readonly PACKAGE_INSTALL_DATE_COL_WIDTH=18
readonly PACKAGE_INSTALLED_COL_WIDTH=14
readonly PACKAGE_MAX_OS_COL_WIDTH=11
readonly PACKAGE_MIN_OS_COL_WIDTH=11
readonly PACKAGE_MIN_RAM_COL_WIDTH=16
readonly PACKAGE_NAME_COL_WIDTH=21
readonly PACKAGE_PATH_COL_WIDTH=48
readonly PACKAGE_REPO_COL_WIDTH=40
readonly PACKAGE_STATUS_COL_WIDTH=23
readonly PACKAGE_VER_COL_WIDTH=17
readonly CHARS_DROPEND='└─ '
readonly CHARS_ELLIPSIS='...'
readonly CHARS_NOTE='* '
readonly CHARS_REGULAR_PROMPT='$ '
readonly CHARS_SUDO_PROMPT="${CHARS_REGULAR_PROMPT}sudo "
readonly CHARS_RESULTS='= '
readonly CHAR_SPACER=' '
readonly CHARS_ALERT="${CHAR_SPACER}! "
readonly CHARS_ATTENTION="${CHAR_SPACER}* "
readonly CHARS_BLANK="${CHAR_SPACER}  "
readonly CHARS_NORMAL="${CHAR_SPACER}- "
readonly CHARS_BULLET='• '
readonly CHARS_SUPER_PROMPT='# '
readonly DEBUG_LOG_DATAWIDTH=101
readonly DEBUG_LOG_FIRST_COL_WIDTH=9
readonly DEBUG_LOG_SECOND_COL_WIDTH=22
readonly DEBUG_LOG_THIRD_COL_WIDTH=$((DEBUG_LOG_DATAWIDTH-DEBUG_LOG_FIRST_COL_WIDTH-DEBUG_LOG_SECOND_COL_WIDTH-4))
if OS.IsSupportSudo; then
if [[ $(GetSudoUID) = undefined ]]; then
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
else
readonly HELP_SYNTAX_PREFIX=$CHARS_REGULAR_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUDO_PROMPT
fi
else
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
fi
readonly FILE_CHANGE_THRESHOLD_MINUTES=60
readonly LOG_TAIL_LINES=5000
}
Vars:Load()
{
action_msg_pipe_fd=none
backup_stdin_fd=none
colourful=true
hide_title=false
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
linespace_visible=false
pips_install=false
qpkg_timeouts_increased=false
self_archive_debug_afterward=false
show_suggest_raise_issue=false
show_zero_qpkgs=true
skip_package_actions=false
title_shown=false
opts_check=false
opts_debug=false
opts_verbose=false
opts_paste_log_last=false
opts_paste_log_tail=false
opts_show_abbreviations=false
opts_show_actions=false
opts_show_actions_all=false
opts_show_backuploc=false
opts_show_backups=false
opts_show_basic_help=false
opts_show_dependencies=false
opts_show_groups=false
opts_show_log_last=false
opts_show_log_tail=false
opts_show_options=false
opts_show_packages=false
opts_show_packages_failed=false
opts_show_packages_ok=false
opts_show_packages_skipped=false
opts_show_problems=false
opts_show_reassign=false
opts_show_repos=false
opts_show_results=false
opts_show_status=false
opts_show_tips=false
opts_show_versions=false
fork_pid=''
package_ver_final_col_width=0
prev_msg=' '
proc_counts_path=''
OS.IsSupportSecureDownload && curl_insecure_arg='' || curl_insecure_arg=' --insecure'
UpdateColourisation
}
CMDs:Load()
{
readonly GNU_FIND_CMD=/opt/bin/find
readonly GNU_GREP_CMD=/opt/bin/grep
readonly GNU_LESS_CMD=/opt/bin/less
readonly GNU_SED_CMD=/opt/bin/sed
readonly GNU_SLEEP_CMD=/opt/bin/sleep
readonly GNU_SORT_CMD=/opt/bin/sort
readonly GNU_STTY_CMD=/opt/bin/stty
readonly GNU_TIMEOUT_CMD=/opt/bin/timeout
readonly OPKG_CMD=/opt/bin/opkg
readonly PERL_CMD=/opt/bin/perl
readonly PYTHON_CMD=/opt/bin/python
readonly PYTHON3_CMD=/opt/bin/python3
readonly PIP_CMD="$PYTHON3_CMD -m pip"
readonly AWK_CMD=/bin/awk
readonly BASENAME_CMD=/usr/bin/basename
readonly CAT_CMD=/bin/cat
readonly CURL_CMD=/sbin/curl
readonly DF_CMD=/bin/df
readonly DIRNAME_CMD=/usr/bin/dirname
readonly DU_CMD=/usr/bin/du
readonly GREP_CMD=/bin/grep
readonly HEAD_CMD=/usr/bin/head
readonly LESS_CMD=/bin/less
readonly MD5SUM_CMD=/bin/md5sum
readonly MKNOD_CMD=/bin/mknod
readonly MKTEMP_CMD=/bin/mktemp
readonly MORE_CMD=/bin/more
readonly PS_CMD=/bin/ps
readonly READLINK_CMD=/usr/bin/readlink
readonly SCREEN_CMD=/usr/sbin/screen
readonly SED_CMD=/bin/sed
readonly SH_CMD=/bin/sh
readonly SLEEP_CMD=/bin/sleep
readonly SORT_CMD=/usr/bin/sort
readonly TAIL_CMD=/usr/bin/tail
readonly TAR_CMD=/bin/tar
readonly TEE_CMD=/usr/bin/tee
readonly TOUCH_CMD=/bin/touch
readonly UNAME_CMD=/bin/uname
readonly UNIQ_CMD=/bin/uniq
readonly UNZIP_CMD=/usr/bin/unzip
readonly UPTIME_CMD=/usr/bin/uptime
readonly WC_CMD=/usr/bin/wc
}
CMDs.IsOk()
{
IsSysFileExist $AWK_CMD || return
IsSysFileExist $BASENAME_CMD || return
IsSysFileExist $CAT_CMD || return
IsSysFileExist $CURL_CMD || return
IsSysFileExist $DF_CMD || return
IsSysFileExist $DIRNAME_CMD || return
IsSysFileExist $DU_CMD || return
IsSysFileExist $GREP_CMD || return
IsSysFileExist $HEAD_CMD || return
IsSysFileExist $MD5SUM_CMD || return
IsSysFileExist $MKNOD_CMD || return
IsSysFileExist $MKTEMP_CMD || return
IsSysFileExist $PS_CMD || return
IsSysFileExist $READLINK_CMD || return
IsSysFileExist $SCREEN_CMD || return
IsSysFileExist $SED_CMD || return
IsSysFileExist $SH_CMD || return
IsSysFileExist $TAIL_CMD || return
IsSysFileExist $TAR_CMD || return
IsSysFileExist $TEE_CMD || return
IsSysFileExist $TOUCH_CMD || return
IsSysFileExist $UNAME_CMD || return
IsSysFileExist $UNIQ_CMD || return
IsSysFileExist $UNZIP_CMD || return
IsSysFileExist $UPTIME_CMD || return
IsSysFileExist $WC_CMD || return
if [[ ! -e $GNU_SLEEP_CMD ]]; then
IsSysFileExist $SLEEP_CMD || return
fi
[[ ! -e $SORT_CMD ]] && ln -s /bin/busybox "$SORT_CMD"
readonly DECIMAL_SLEEP_SECONDS_SUPPORTED=$($SLEEP_CMD .01 &>/dev/null && echo true || echo false)
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled HybridBackup; then
SQLITE_CMD=$(QPKG.GetInstallationPath HybridBackup)/CloudConnector3/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled CacheMount; then
SQLITE_CMD=$(QPKG.GetInstallationPath CacheMount)/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
[[ -z ${SQLITE_CMD:-} ]] && SQLITE_CMD=/opt/bin/sqlite3
readonly SQLITE_CMD
return 0
}
Env:Load()
{
ShowAsProc 'loading environment'
readonly ACTION_MSG_PIPE=/var/run/sherpa.action.messages.pipe
readonly CERT_DB_PATHFILE=/etc/config/nas_sign_qpkg.db
readonly CPU_CORES=$(GetCPUCores)
readonly CONCURRENCY=$CPU_CORES
readonly ENTWARE_VER=$(GetEntwareType)
readonly KERNEL_PAGE_SIZE=$(GetKernelPageSize)
readonly NAS_ARCH=$(GetArch)
readonly NAS_FIRMWARE_BUILD=$(GetFirmwareBuild)
readonly NAS_FIRMWARE_DATE=$(GetFirmwareDate)
readonly NAS_FIRMWARE_VER=$(GetFirmwareVer)
readonly NAS_PLATFORM=$(GetPlatform)
readonly NAS_QPKG_ARCH=$(GetQpkgArch)
readonly NAS_RAM_KB=$(GetInstalledRAM)
readonly NAS_UPSTATE=$(GetUpState)
source_branch=stable
local test_branch=$(/sbin/getcfg sherpa Git_Branch -d unknown -f /etc/config/qpkg.conf)
if [[ $test_branch = unknown ]]; then
/sbin/setcfg sherpa Git_Branch $source_branch -f /etc/config/qpkg.conf
else
source_branch=$test_branch
fi
readonly OBJECTS_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$source_branch/objects.tar.gz
readonly PACKAGES_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$source_branch/packages.tar.gz
readonly QPKG_BU_PATH=$(GetDefVol)/.qpkg_config_backup
readonly THIS_PACKAGE_PATH=$(QPKG.GetInstallationPath)
readonly CACHE_PATH=$THIS_PACKAGE_PATH/cache
readonly ACTION_TIMES_PATH=$CACHE_PATH/action.times
readonly DISPLAY_INHIBIT_PATHFILE=$CACHE_PATH/display.inhibit
readonly IPK_CACHE_PATH=$CACHE_PATH/IPKs
readonly IPK_DL_PATH=$CACHE_PATH/IPKs.downloads
readonly IPK_DOWNGRADE_DL_PATH=$CACHE_PATH/IPKs.downgrade
readonly PIP_CACHE_PATH=$CACHE_PATH/PIPs
readonly OBJECTS_ARCHIVE_PATHFILE=$CACHE_PATH/objects.tar.gz
readonly OBJECTS_PATHFILE=$CACHE_PATH/objects
readonly PACKAGES_ARCHIVE_PATHFILE=$CACHE_PATH/packages.tar.gz
readonly PACKAGES_PATHFILE=$CACHE_PATH/packages
readonly PREV_IPK_LIST=$CACHE_PATH/ipk.list.save
readonly PREV_PIP_LIST=$CACHE_PATH/pip.list.save
readonly QPKG_DL_PATH=$CACHE_PATH/QPKGs.downloads
readonly LOGS_PATH=$THIS_PACKAGE_PATH/logs
readonly RAMDISKS_FREESPACE_PATHFILE=$LOGS_PATH/ramdisks.freespace
readonly SCREEN_SESSIONS_PATHFILE=$LOGS_PATH/screen.sessions
readonly SESS_ACTIONS_RESULTS_PATHFILE=$LOGS_PATH/session.action.results.log
readonly SESS_ARCHIVE_PATHFILE=$LOGS_PATH/session.archive.log
readonly SESS_LAST_PATHFILE=$LOGS_PATH/session.last.log
readonly SESS_TAIL_PATHFILE=$LOGS_PATH/session.tail.log
readonly REPORTS_PATH=$THIS_PACKAGE_PATH/reports
readonly REPORT_OUTPUT_PATHFILE=$REPORTS_PATH/report.ansi
readonly THIS_PACKAGE_VER=$(QPKG.Local.GetVer)
readonly THIS_SCRIPT_VER='240123'-$source_branch
readonly EXTERNAL_PACKAGES_ARCHIVE_PATHFILE=/opt/var/opkg-lists/entware
readonly EXTERNAL_PACKAGES_PATHFILE=$CACHE_PATH/Packages
}
Lists:Load()
{
PACKAGE_TIERS=(independent auxiliary dependent)
QPKG_IS_STATES=(active backedup downloaded enabled installed missing signed slow unknown)
QPKG_ISNT_STATES=(active backedup downloaded enabled installed signed)
QPKG_STATES_TRANSIENT=(starting stopping restarting)
QPKG_SERVICE_RESULTS=(ok failed)
IPK_STATES=(downloaded installed reinstalled upgraded)
PIP_ACTIONS=(download uninstall upgrade reinstall install)
IPK_ACTIONS=(download uninstall upgrade reinstall install)
QPKG_ACTIONS=(status rebuild reassign download backup deactivate disable uninstall upgrade reinstall install restore clean enable activate reactivate sign)
USER_QPKG_SC_GROUPS=(all canbackup canclean canrestarttoupdate dependent hasdependents installable independent upgradable)
USER_QPKG_SCNT_GROUPS=(canclean installable upgradable)
USER_QPKG_IS_STATES=(active backedup enabled installed missing)
USER_QPKG_ISNT_STATES=(active backedup enabled installed)
USER_QPKG_ACTIONS=(activate backup clean enable deactivate disable install list reactivate reassign rebuild reinstall restore status uninstall upgrade)
readonly PACKAGE_TIERS
readonly QPKG_IS_STATES
readonly QPKG_ISNT_STATES
readonly QPKG_STATES_TRANSIENT
readonly QPKG_SERVICE_RESULTS
readonly IPK_STATES
readonly PIP_ACTIONS
readonly IPK_ACTIONS
readonly QPKG_ACTIONS
readonly USER_QPKG_SC_GROUPS
readonly USER_QPKG_SCNT_GROUPS
readonly USER_QPKG_IS_STATES
readonly USER_QPKG_ISNT_STATES
readonly USER_QPKG_ACTIONS
local action=''
for action in "${QPKG_ACTIONS[@]}" check debug downgrade update; do
readonly "$(Uppercase "$action")"_LOG_FILE=$action.log
done
}
CreatePaths()
{
rm -rf /root/.cache /root/.local/share/virtualenv
rm -rf "$IPK_CACHE_PATH" "$IPK_DL_PATH" "$PIP_CACHE_PATH"
MakePath "$ACTION_TIMES_PATH" 'action times' || return
MakePath "$CACHE_PATH" cache || return
MakePath "$IPK_CACHE_PATH" 'IPK cache' || return
MakePath "$IPK_DL_PATH" 'IPK download' || return
MakePath "$IPK_DOWNGRADE_DL_PATH" 'IPK downgrade' || return
MakePath "$LOGS_PATH" logs || return
MakePath "$PIP_CACHE_PATH" 'PIP cache' || return
MakePath "$REPORTS_PATH" reports || return
MakePath "$QPKG_BU_PATH" 'QPKG backup' || return
MakePath "$QPKG_DL_PATH" 'QPKG download' || return
}
Debug.Log:Env()
{
[[ $skip_package_actions = false ]] || return 0
[[ $opts_debug = true ]] || return 0
Func:Init
ShowAsProc 'logging environment'
DebugInfoMinSepr
DebugHardware ok model "$(get_display_name)"
DebugHardware ok CPU "$(GetCPUInfo)"
DebugHardware ok 'CPU cores' "$CPU_CORES"
DebugHardware ok 'CPU architecture' "$NAS_ARCH"
DebugHardware ok RAM "$(FormatAsThous "$NAS_RAM_KB")kiB"
DebugFirmware ok OS "$(GetQnapOS)"
if OS.IsSupported; then
DebugFirmware ok version "$NAS_FIRMWARE_VER.$NAS_FIRMWARE_BUILD"
else
DebugFirmware warning version "$NAS_FIRMWARE_VER"
fi
if OS.IsCompatibleWithSigned; then
DebugFirmware ok 'build date' "$NAS_FIRMWARE_DATE"
else
DebugFirmware warning 'build date' "$NAS_FIRMWARE_DATE"
fi
DebugFirmware ok 'kernel version' "$(GetKernelVersion)"
if OS.IsStdKernelPageSize; then
DebugFirmware ok 'kernel page size' "$KERNEL_PAGE_SIZE"
else
DebugFirmware warning 'kernel page size' "$KERNEL_PAGE_SIZE"
fi
DebugFirmware ok platform "$NAS_PLATFORM"
case $NAS_UPSTATE in
starting-up|shutting-down)
DebugFirmware warning 'OS state' "$NAS_UPSTATE"
;;
*)
DebugFirmware ok 'OS state' "$NAS_UPSTATE"
esac
DebugFirmware ok 'OS uptime' "$(GetUptime)"
DebugFirmware ok 'system load' "$(GetSysLoadAverages)"
DebugUserspace ok timezone "$(GetTimezone)"
if OS.IsSupportSudo; then
DebugUserspace ok '$SUDO_UID' "$(GetSudoUID)"
else
DebugUserspace ok '$SUDO_UID' 'N/A'
fi
DebugUserspace ok '$EUID' "$EUID"
DebugUserspace ok 'time in shell' "$(GetTimeInShell)"
DebugUserspace ok '$BASH_VERSION' "$BASH_VERSION"
DebugUserspace ok 'default volume' "$(GetDefVol)"
DebugUserspace ok '/opt' "$($READLINK_CMD /opt 2>/dev/null || echo 'not present')"
local public_share=$(/sbin/getcfg SHARE_DEF defPublic -d Qpublic -f /etc/config/def_share.info)
if [[ -L /share/$public_share ]]; then
DebugUserspace ok "'$public_share' share" "/share/$public_share"
else
DebugUserspace warning "'$public_share' share" 'not present'
fi
if [[ ${#PATH} -le $DEBUG_LOG_THIRD_COL_WIDTH ]]; then
DebugUserspace ok '$PATH' "$PATH"
else
DebugUserspace ok '$PATH (LHS-only)' "${PATH:0:$((DEBUG_LOG_THIRD_COL_WIDTH-${#CHARS_ELLIPSIS}))}${CHARS_ELLIPSIS}"
fi
DebugBinPathVerAndMinVer python "$(GetPythonVer)" "$MIN_PYTHON_VER"
DebugBinPathVerAndMinVer python3 "$(GetPython3Ver)" "$MIN_PYTHON_VER"
DebugBinPathVerAndMinVer perl "$(GetPerlVer)" "$MIN_PERL_VER"
DebugScript 'source branch' "$source_branch"
DebugScript 'cache path' "$CACHE_PATH"
DebugScript 'logs path' "$LOGS_PATH"
DebugScript 'reports path' "$REPORTS_PATH"
DebugScript 'action concurrency' "$CONCURRENCY"
if OS.IsSupportSignedPackages; then
if OS.IsAllowUnsignedPackages; then
DebugQpkg detect 'allow unsigned' yes
else
DebugQpkg detect 'allow unsigned' no
fi
else
DebugQpkg detect 'allow unsigned' 'N/A'
fi
DebugQpkg detect architecture "$NAS_QPKG_ARCH"
DebugQpkg detect "$(ShowAsPackageName Entware) type" "$ENTWARE_VER"
DebugQpkg detect "$(ShowAsPackageName Entware) install date" "$(QPKG.GetInstallDate Entware)"
if QPKG.IsInstalled SortMyQPKGs; then
DebugQpkg detect "$(ShowAsPackageName SortMyQPKGs)" installed
else
DebugQpkg warning "$(ShowAsPackageName SortMyQPKGs)" 'not installed'
fi
if OS.IsSupportQpkgTimeout; then
if QPKG.IsInstalled IncreaseTimeouts; then
if QPKGs.IsTimeoutsIncreased; then
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" 'N/A'
fi
DebugInfoMinSepr
RunAndLog "$DF_CMD -h | $GREP_CMD '^Filesystem\|^none\|^tmpfs\|ram'" "$RAMDISKS_FREESPACE_PATHFILE"
DebugInfoMinSepr
RunAndLog "$SCREEN_CMD -ls" "$SCREEN_SESSIONS_PATHFILE" '' 1
DebugInfoMinSepr
Func:Exit
}
Self.Tasks:Check()
{
[[ $skip_package_actions = false ]] || return 0
Func:Init
ShowAsProc 'checking'
local action=''
local group=''
local state=''
local something_to_do=false
if [[ $opts_check = true || $opts_show_status = true || $opts_show_versions = true ]]; then
something_to_do=true
else
for action in "${USER_QPKG_ACTIONS[@]}"; do
[[ $action = list ]] && continue
if QPKGs-AC${action}-to.IsAny; then
something_to_do=true
break
fi
for group in "${USER_QPKG_SC_GROUPS[@]}"; do
if QPKGs.AC${action}.SC${group}.IsSet; then
something_to_do=true
break 2
fi
done
for group in "${USER_QPKG_SCNT_GROUPS[@]}"; do
if QPKGs.AC${action}.SCNT${group}.IsSet; then
something_to_do=true
break 2
fi
done
for state in "${USER_QPKG_IS_STATES[@]}"; do
if QPKGs.AC${action}.IS${state}.IsSet; then
something_to_do=true
break 2
fi
done
for state in "${USER_QPKG_ISNT_STATES[@]}"; do
if QPKGs.AC${action}.ISNT${state}.IsSet; then
something_to_do=true
break 2
fi
done
done
fi
if [[ $something_to_do = false ]]; then
hide_title=false; ShowTitleLine
ShowAsError "supplied arguments were incomplete, or didn't make sense. Please check the argument list again."
opts_show_basic_help=true
skip_package_actions=true
Func:Exit 1; return
fi
QPKGs.States:Build
Func:Exit
}
Self:Validate()
{
[[ $skip_package_actions = false ]] || return 0
Func:Init
ShowAsProc validating
local installed_ver=''
local package=''
local action=''
local prospect=''
local target_packages=''
if [[ $opts_check = true ]] || QPKGs-ACupgrade-to.Exist Entware; then
ipks_upgrade=true
ipks_install=true
pips_install=true
if [[ -e $PYTHON3_CMD ]]; then
installed_ver=$(GetPython3Ver "$PYTHON3_CMD")
if [[ ${installed_ver//./} -lt $MIN_PYTHON_VER ]]; then
ShowAsInfo "the $(TextBrightOrange Python) environment will be auto-upgraded."
IPKs-ACuninstall-to:Add 'python*'
fi
fi
if [[ -e $PERL_CMD ]]; then
installed_ver=$(GetPerlVer "$PERL_CMD")
if [[ ${installed_ver//./} -lt $MIN_PERL_VER ]]; then
ShowAsInfo "the $(TextBrightOrange Perl) environment will be auto-upgraded."
IPKs-ACuninstall-to:Add 'perl*'
fi
fi
fi
if OS.IsNonStdKernelPageSize; then
case $NAS_QPKG_ARCH in
a41|a64)
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($OPKG_CMD list-installed | $GREP_CMD "^${target_packages%% *} *" | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]]; then
ipks_downgrade=true
ShowAsInfo "IPKs will be downgraded to suit $KERNEL_PAGE_SIZE kernel page size."
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
esac
fi
QPKGs.IsCanBackup:Build
QPKGs.IsCanRestartToUpdate:Build
QPKGs.IsCanClean:Build
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-SCupgradable.Exist sherpa; then
ShowAsInfo "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded."
QPKGs-ACupgrade-to:Add sherpa
fi
ShowAsProc 'continuing validation'
if QPKG.IsInstalled Entware; then
local entware_install_date=$(QPKG.GetInstallDate Entware)
if [[ $entware_install_date = undefined || ${entware_install_date//[!0-9]/} -le 20230604 ]]; then
ShowAsInfo "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were updated early June 2023)."
QPKGs-ACreinstall-to:Add Entware
fi
fi
if QPKGs-ACrebuild-to.IsAny; then
for package in $(QPKGs-ACrebuild-to:Array); do
QPKGs-ACinstall-to:Add "$package"
QPKGs-ACrestore-to:Add "$package"
QPKGs-ACrebuild-to:Remove "$package"
done
fi
for action in upgrade reinstall install; do
for package in $(QPKGs-AC${action}-to:Array); do
for prospect in $(QPKG.GetDependencies "$package"); do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
done
done
for package in $(QPKGs-ISinstalled:Array); do
if [[ $opts_check = true ]] || QPKGs-ACactivate-to.Exist "$package"; then
for prospect in $(QPKG.GetDependencies "$package"); do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for package in $(QPKGs-ACreinstall-to:Array) $(QPKGs-ACreactivate-to:Array); do
if QPKGs-SCindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package"; then
for prospect in $(QPKG.GetDependents "$package"); do
if QPKGs-ISenabled.Exist "$prospect"; then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for package in $(QPKGs-ACdeactivate-to:Array) $(QPKGs-ACuninstall-to:Array); do
if QPKGs-SCindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package"; then
for prospect in $(QPKG.GetDependents "$package"); do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
for package in $(QPKGs-ACuninstall-to:Array); do
if QPKGs-SCindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package"; then
if QPKGs-ACinstall-to.Exist "$package"; then
for prospect in $(QPKG.GetDependents "$package"); do
if QPKGs-ISenabled.Exist "$prospect"; then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
fi
done
if QPKGs-ACreinstall-to.Exist Entware; then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for action in reinstall install activate reactivate; do
for package in $(QPKGs-AC${action}-to:Array); do
for prospect in $(QPKG.GetDependencies "$package"); do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
done
done
done
for action in activate reactivate; do
for package in $(QPKGs-AC${action}-to:Array); do
QPKGs-ISinstalled.Exist "$package" && QPKGs-ISNTenabled.Exist "$package" && QPKGs-ACenable-to:Add "$package"
done
done
if QPKGs.ACuninstall.SCall.IsSet; then
QPKGs-ACdeactivate-to:Init
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACdeactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
for action in reinstall install reactivate; do
QPKGs-ACactivate-to:Remove "$(QPKGs-AC${action}-to:Array)"
done
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny; then
for package in $(QPKGs-ACuninstall-to:Array); do
if QPKGs-ISinstalled.Exist "$package" && QPKGs-ACinstall-to.Exist "$package"; then
QPKGs_were_installed_name+=("$package")
QPKGs_were_installed_path+=("$($DIRNAME_CMD "$(QPKG.GetInstallationPath "$package")")")
fi
done
fi
QPKGs-ACupgrade-to.Exist sherpa && QPKGs-ACreactivate-to:Add sherpa
QPKGs-ACupgrade-to.Exist Entware && QPKGs-ACreactivate-to:Add Entware
QPKGs-ACdownload-to:Add "$(QPKGs-ACupgrade-to:Array) $(QPKGs-ACreinstall-to:Array) $(QPKGs-ACinstall-to:Array)"
if [[ $opts_check = true ]]; then
QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
for package in $(QPKGs-SCdependent:Array); do
QPKGs-ISenabled.Exist "$package" && QPKGs-ACreactivate-to:Add "$package"
done
fi
Func:Exit
}
Actions:Proc()
{
[[ $skip_package_actions = false ]] || return 0
Func:Init
ShowAsProc 'package actions'
local tier=''
local action=''
local -i tier_index=0
rm -f "$SESS_ACTIONS_RESULTS_PATHFILE"
Action:Proc status all QPKG statusing statused
Action:Proc reassign all QPKG reassigning reassigned
Action:Proc download all QPKG downloading downloaded
Action:Proc backup all QPKG backing-up backed-up
for ((tier_index=${#PACKAGE_TIERS[@]}-1; tier_index>=0; tier_index--)); do
tier=${PACKAGE_TIERS[$tier_index]}
case $tier in
independent|dependent)
Action:Proc deactivate $tier QPKG deactivating deactivated
Action:Proc disable $tier QPKG disabling disabled
Action:Proc uninstall $tier QPKG uninstalling uninstalled
esac
done
for tier in "${PACKAGE_TIERS[@]}"; do
case $tier in
independent|dependent)
Action:Proc upgrade $tier QPKG upgrading upgraded
Action:Proc reinstall $tier QPKG reinstalling reinstalled
Action:Proc install $tier QPKG installing installed
Action:Proc restore $tier QPKG restoring restored
Action:Proc clean $tier QPKG cleaning cleaned
Action:Proc enable $tier QPKG enabling enabled
Action:Proc reactivate $tier QPKG reactivating reactivated
Action:Proc activate $tier QPKG activating activated
;;
auxiliary)
for action in install reinstall upgrade activate; do
if (QPKGs-ACinstall-ok.Exist Entware) || QPKGs-AC${action}-to.IsAny && QPKGs-ISenabled.Exist Entware; then
ipks_upgrade=true
ipks_install=true
ipks_downgrade=true
pips_install=true
break
fi
done
if QPKGs-ISenabled.Exist Entware; then
ModPathToEntware
Action:Proc upgrade $tier IPK upgrading upgraded
Action:Proc install $tier IPK installing installed
Action:Proc downgrade $tier IPK downgrading downgraded
Action:Proc install $tier PIP installing installed
fi
esac
done
if OS.IsSupportSignedPackages; then
Action:Proc sign all QPKG '"signing"' '"signed"'
fi
if [[ $opts_debug = true ]]; then
IPKs.Actions:List
QPKGs.Actions:List
fi
Func:Exit
}
Action:Proc()
{
Func:Init
local -r TARGET_ACTION=${1:?${FUNCNAME[0]}'()': undefined}
local -r TIER=${2:?${FUNCNAME[0]}'()': undefined}
local -r PACKAGE_TYPE=${3:?${FUNCNAME[0]}'()': undefined}
local -r ACTION_PRESENT_MSG=${4:?${FUNCNAME[0]}'()': undefined}
local -r ACTION_PAST=${5:?${FUNCNAME[0]}'()': undefined}
total_count=0
local package=''
local state=''
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local -i package_index=0
local -a target_packages=()
local original_colourful=$colourful
DebugVar TARGET_ACTION
DebugVar TIER
DebugVar PACKAGE_TYPE
case $PACKAGE_TYPE in
QPKG)
TARGET_OBJECT_NAME=AC${TARGET_ACTION}-to
if [[ $TIER = all ]]; then
target_packages=($(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array))
else
for package in $(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array); do
${PACKAGE_TYPE}s-SC${TIER}.Exist "$package" && target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]]; then
DebugInfo 'nothing to process'
Func:Exit; return
fi
if [[ $total_count -eq 1 ]]; then
ShowAsProc "$ACTION_PRESENT_MSG ${target_packages[0]}"
else
ShowAsProc "$ACTION_PRESENT_MSG $([[ $TIER != all ]] && echo "$TIER ")$(Uppercase "$PACKAGE_TYPE")$(Pluralise "$total_count")"
fi
AdjustMaxForks "$TARGET_ACTION"
InitForkCounts
OpenActionMsgPipe
re=\\bEntware\\b
if [[ $TARGET_ACTION = uninstall && ${target_packages[*]} =~ $re ]]; then
Keystrokes:Show
fi
_ActionForks:Launch_ "_${PACKAGE_TYPE}:${TARGET_ACTION}_" "${target_packages[@]}" &
fork_pid=$!
while [[ ${#target_packages[@]} -gt 0 ]]; do
ReadMsgFromActionPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
env)
eval "$msg1_value"
;;
change)
while true; do
for group in "${USER_QPKG_SC_GROUPS[@]}"; do
case $msg1_value in
"SC${group}")
[[ $(type -t QPKGs-SCNT${group}:Init) = function ]] && QPKGs-SCNT${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-SC${group}:Init) = function ]] && QPKGs-SC${group}:Add "$msg2_value"
break 2
esac
done
for group in "${USER_QPKG_SCNT_GROUPS[@]}"; do
case $msg1_value in
"SCNT${group}")
[[ $(type -t QPKGs-SC${group}:Init) = function ]] && QPKGs-SC${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-SCNT${group}:Init) = function ]] && QPKGs-SCNT${group}:Add "$msg2_value"
break 2
esac
done
for state in "${QPKG_IS_STATES[@]}"; do
case $msg1_value in
"IS${state}")
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${QPKG_ISNT_STATES[@]}"; do
case $msg1_value in
"ISNT${state}")
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change in message queue: '$msg1_value'"
break
done
;;
status)
case $msg1_value in
ok)
((ok_count++))
;;
so)
((skip_ok_count++))
;;
sk)
((skip_count++))
;;
se)
((skip_error_count++))
;;
er)
((fail_count++))
esac
case $msg1_value in
ok|so|sk|se|er)
[[ $(type -t QPKGs-AC${TARGET_ACTION}-to:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-to:Remove "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-${msg1_value}:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-${msg1_value}:Add "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-dn:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-dn:Add "$msg2_value"
;;
ex)
for package_index in "${!target_packages[@]}"; do
if [[ ${target_packages[package_index]} = "$msg2_value" ]]; then
unset 'target_packages[package_index]'
break
fi
done
;;
*)
DebugAsWarn "unidentified status in message queue: '$msg1_value'"
esac
;;
*)
DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
done
[[ $ok_count -gt 0 ]] && opts_show_packages_ok=true
[[ $skip_count -gt 0 || $skip_error_count -gt 0 ]] && opts_show_packages_skipped=true
[[ $fail_count -gt 0 ]] && opts_show_packages_failed=true
[[ ${#target_packages[@]} -gt 0 ]] && KillActiveFork
wait 2>/dev/null
CloseActionMsgPipe
;;
IPK|PIP)
if [[ $ipks_upgrade = true || $ipks_install = true || $ipks_downgrade || $pips_install = true ]]; then
InitForkCounts
${PACKAGE_TYPE}s:${TARGET_ACTION}
fi
esac
EraseForkCountPaths
Func:Exit
Self.Error.IsNt
}
OpenActionMsgPipe()
{
[[ -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE"
[[ ! -p $ACTION_MSG_PIPE ]] && mknod "$ACTION_MSG_PIPE" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd<>$ACTION_MSG_PIPE"
}
CloseActionMsgPipe()
{
[[ $backup_stdin_fd != none ]] && eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]] && eval "exec $backup_stdin_fd>&-"
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd>&-"
[[ -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE"
}
AdjustMaxForks()
{
max_forks=$CONCURRENCY
local reason=''
if [[ $opts_debug = true ]]; then
max_forks=1
reason='debug mode is active'
else
case ${1:-} in
clean)
max_forks=$(((max_forks+1)/2))
reason="'$1'"
;;
install|reinstall|upgrade)
max_forks=1
reason="'$1'"
;;
sign)
max_forks=1
reason="'$1'"
;;
backup|deactivate|download|uninstall)
max_forks=4
reason="'$1'"
;;
disable|enable|status)
max_forks=8
reason="'$1'"
esac
[[ -n $reason ]] && reason+=' action was requested'
fi
[[ -n $reason ]] && DebugInfo "limiting \$max_forks to $max_forks because $reason"
DebugVar max_forks
}
ParseArgs()
{
Func:Init
ShowAsProc arguments
DebugVar USER_ARGS_RAW
local user_args_fixed=$(Lowercase "${USER_ARGS_RAW//,/ }")
local -a user_args=(${user_args_fixed/--/})
local arg=''
local arg_identified=false
local action=''
local action_force=false
local group=''
local group_identified=false
local package=''
for arg in "${user_args[@]}"; do
arg_identified=false
case $arg in
backup|clean|enable|disable|reassign|rebuild|reinstall|restore)
action=${arg}
arg_identified=true
group=''
group_identified=false
;;
paste)
action=paste
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=true
;;
activate|start)
action=activate
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
add|install)
action=install
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
c|check)
action=check
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
deactivate|stop)
action=deactivate
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
display|help|list|show|view)
action=help
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=true
;;
reactivate|restart)
action=reactivate
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
rm|remove|uninstall)
action=uninstall
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
s|status|statuses)
action=status
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
;;
update|upgrade)
action=upgrade
arg_identified=true
group=''
group_identified=false
hide_title=false
skip_package_actions=false
esac
if [[ -z $action ]]; then
case $arg in
a|abs|action|actions|actions-all|alias|aliases|all-actions|b|backups|d|deps|dependencies|dependent|dependents|disabled|enabled|failed|groups|inactive|indeps|independent|independents|installable|installed|l|last|log|missing|new|not-installed|o|ok|option|options|p|package|packages|problems|r|repo|repos|results|skipped|stopped|tail|tips|updatable|updateable|upgradable|version|versions|whole)
action=help
arg_identified=true
group=''
group_identified=false
skip_package_actions=true
esac
DebugVar action
fi
if [[ -n $action ]]; then
case $arg in
backedup|installable|installed|missing|ok|problems|results|skipped|tail|tips)
group=${arg}
;;
failed)
group=NTok
;;
not-backedup)
group=NTbackedup
;;
not-installed)
group=NTinstalled
;;
a|abs|alias|aliases)
group=abs
;;
actions-all|all-actions)
group=all-actions
;;
action|actions)
group=actions
;;
active|started)
group=active
;;
all|entire|everything)
group=all
;;
b|backups)
group=backups
;;
d|dependencies)
group=dependencies
;;
deps|dependent|dependents)
group=dependent
;;
disabled)
group=NTenabled
;;
group|groups)
group=groups
;;
inactive|not-active|stopped)
group=NTactive
;;
l|last)
group=last
;;
log)
group=log
;;
new|updatable|updateable|upgradable)
group=upgradable
;;
o|option|options)
group=options
;;
p|package|packages)
group=packages
;;
r|repo|repos)
group=repos
;;
independent|independents|indeps)
group=independent
;;
version|versions)
group=versions
esac
if [[ -n $group ]]; then
group_identified=true
arg_identified=true
fi
fi
case $arg in
v|debug|dbug|verbose)
group_identified=true
arg_identified=true
;;
force)
action_force=true
arg_identified=true
esac
package=$(QPKG.MatchAbbrv "$arg")
if [[ -n $package ]]; then
group_identified=true
arg_identified=true
fi
[[ $arg_identified = false ]] && ARGs-unknown:Add "$arg"
case $action in
activate|backup|clean|deactivate|disable|enable|install|reactivate|reassign|rebuild|reinstall|restore|upgrade)
case $group in
all|dependent|independent|upgradable)
QPKGs.AC${action}.SC${group}:Set
group=''
;;
installed|NTinstalled|active|NTactive)
QPKGs.AC${action}.IS${group}:Set
group=''
;;
*)
QPKGs-AC${action}-to:Add "$package"
esac
;;
check)
opts_check=true
;;
help)
case $group in
abs)
opts_show_abbreviations=true
;;
actions)
opts_show_actions=true
;;
all-actions|all)
opts_show_actions_all=true
;;
backedup|installed|NTbackedup|NTinstalled)
QPKGs.AClist.IS${group}:Set
hide_title=true
;;
backups)
opts_show_backups=true
;;
dependencies)
opts_show_dependencies=true
;;
dependent|installable|independent|upgradable)
QPKGs.AClist.SC${group}:Set
hide_title=true
;;
failed)
opts_show_packages_failed=true
;;
groups)
opts_show_groups=true
;;
last)
opts_show_log_last=true
hide_title=true
;;
log)
opts_show_log_tail=true
hide_title=true
;;
ok)
opts_show_packages_ok=true
;;
options)
opts_show_options=true
;;
packages)
opts_show_packages=true
;;
problems)
opts_show_problems=true
;;
reassign)
opts_show_reassign=true
;;
repos)
opts_show_repos=true
;;
results)
opts_show_results=true
;;
skipped)
opts_show_packages_skipped=true
;;
status)
opts_show_status=true
;;
tips)
opts_show_tips=true
;;
versions)
opts_show_versions=true
hide_title=true
esac
skip_package_actions=true
;;
paste)
case $group in
all|log|tail)
opts_paste_log_tail=true
action=''
;;
last)
opts_paste_log_last=true
action=''
esac
skip_package_actions=true
;;
status)
case $group in
all|dependent|independent|upgradable)
QPKGs.AC${action}.SC${group}:Set
group=''
;;
installed)
QPKGs.AC${action}.IS${group}:Set
group=''
;;
*)
QPKGs-AC${action}-to:Add "$package"
esac
opts_show_status=true
;;
uninstall)
case $group in
all)
if [[ $action_force = true ]]; then
QPKGs.AC${action}.SC${group}:Set
group=''
action_force=false
fi
;;
dependent|independent)
QPKGs.AC${action}.SC${group}:Set
group=''
action_force=false
;;
installed)
if [[ $action_force = true ]]; then
QPKGs.AC${action}.IS${group}:Set
group=''
action_force=false
fi
;;
upgradable)
QPKGs.AC${action}.IS${group}:Set
group=''
action_force=false
;;
*)
QPKGs-AC${action}-to:Add "$package"
esac
esac
done
if [[ -n $action && $group_identified = false ]]; then
case $action in
help|paste)
opts_show_basic_help=true
esac
fi
if [[ $opts_show_status = true ]] && QPKGs-ACstatus-to.IsNone; then
QPKGs.ACstatus.SCall:Set
fi
if ARGs-unknown.IsAny; then
opts_show_basic_help=true
skip_package_actions=true
hide_title=false
fi
Func:Exit
}
ArgSuggestions:Show()
{
Func:Init
local arg=''
if ARGs-unknown.IsAny; then
ShowAsError "unknown argument$(Pluralise "$(ARGs-unknown:Count)"): \"$(ARGs-unknown:List)\". Please check the argument list again."
for arg in $(ARGs-unknown:Array); do
case $arg in
all)
DisplayAsProjSynExam "please provide a valid $(ShowAction) before 'all' like" 'activate all'
opts_show_basic_help=false
;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed package configurations, use' 'backup all'
opts_show_basic_help=false
;;
dependent)
DisplayAsProjSynExam "please provide a valid $(ShowAction) before 'dependent' like" 'activate dependents'
opts_show_basic_help=false
;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all packages, use' 'reactivate all'
opts_show_basic_help=false
;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed package configurations, use' 'restore all'
opts_show_basic_help=false
;;
independent)
DisplayAsProjSynExam "please provide a valid $(ShowAction) before 'independent' like" 'activate independents'
opts_show_basic_help=false
;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all packages, use' 'activate all'
opts_show_basic_help=false
;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all packages, use' 'stop all'
opts_show_basic_help=false
;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all packages, use' 'force uninstall all'
opts_show_basic_help=false
;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all packages, use' 'upgrade all'
opts_show_basic_help=false
esac
done
fi
Func:Exit
}
AllocPackGroupsToAcs()
{
Func:Init
ShowAsProc 'matching QPKG groups to actions'
local action=''
local group=''
local state=''
local prospect=''
local found=false
for action in "${USER_QPKG_ACTIONS[@]}"; do
for group in "${USER_QPKG_SC_GROUPS[@]}"; do
found=false
if QPKGs.AC${action}.SC${group}.IsSet; then
case $action in
clean)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-SC${group}:Array); do
QPKG.IsCanClean "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "specified group '$group' has no handler for specified action '$action'"
esac
;;
install|status)
case $group in
all|dependent|independent)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-SC${group}:Array)"
;;
*)
DebugAsWarn "specified group '$group' has no handler for specified action '$action'"
esac
;;
activate|deactivate|enable|disable|reactivate|reinstall|stop|uninstall)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-SC${group}:Array); do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "specified group '$group' has no handler for specified action '$action'"
esac
;;
rebuild)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-SC${group}:Array); do
QPKGs-SCcanbackup.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "specified group '$group' has no handler for specified action '$action'"
esac
;;
upgrade)
case $group in
all|dependent|independent|upgradable)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-SCupgradable:Array)"
for prospect in $(QPKGs-SC${group}:Array); do
QPKGs-SCcanrestarttoupdate.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACupgrade-to:Array)"
;;
*)
DebugAsWarn "specified group '$group' has no handler for specified action '$action'"
esac
;;
*)
DebugAsWarn "specified action '$action' has no handler"
esac
if [[ $found = false ]]; then
QPKGs-AC${action}-to:Add "$(QPKGs-SC${group}:Array)"
fi
if QPKGs-AC${action}-to.IsAny; then
DebugAsDone "action: '$action', group: '$group': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any packages to $(Lowercase "$action")"
fi
fi
done
for group in "${USER_QPKG_SCNT_GROUPS[@]}"; do
found=false
if QPKGs.AC${action}.SCNT${group}.IsSet; then
if [[ $found = false ]]; then
QPKGs-AC${action}-to:Add "$(QPKGs-SCNT${group}:Array)"
fi
if QPKGs-AC${action}-to.IsAny; then
DebugAsDone "action: '$action', group: 'NT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any packages to $(Lowercase "$action")"
fi
fi
done
done
Func:Exit
}
AllocPackStatesToAcs()
{
Func:Init
ShowAsProc 'matching QPKG states to actions'
local action=''
local state=''
local prospect=''
local found=false
for action in "${USER_QPKG_ACTIONS[@]}"; do
for state in "${USER_QPKG_IS_STATES[@]}"; do
found=false
if QPKGs.AC${action}.IS${state}.IsSet; then
case $action in
backup|clean|uninstall|upgrade)
case $state in
backedup|cleaned|downloaded|enabled|installed)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
;;
*)
DebugAsWarn "specified state '$state' has no handler for specified action '$action'"
esac
;;
*)
DebugAsWarn "specified action '$action' has no handler"
esac
if [[ $found = false ]]; then
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny; then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
DebugAsWarn "unable to find any packages to $(Lowercase "$action")"
fi
fi
done
for state in "${USER_QPKG_ISNT_STATES[@]}"; do
found=false
if QPKGs.AC${action}.ISNT${state}.IsSet; then
case $action in
activate|backup|clean|install|uninstall)
case $state in
enabled|installed)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
;;
*)
DebugAsWarn "specified state '$state' has no handler for specified action '$action'"
esac
;;
*)
DebugAsWarn "specified action '$action' has no handler"
esac
if [[ $found = false ]]; then
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny; then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any packages to $(Lowercase "$action")"
fi
fi
done
done
Func:Exit
}
ResetArchivedLogs()
{
if [[ -n $LOGS_PATH && -d $LOGS_PATH ]]; then
rm -rf "${LOGS_PATH:?}"/*
echo 'log reset' > "$sess_active_pathfile"
ShowAsDone 'logs cleared'
fi
return 0
}
ResetCachePath()
{
if [[ -n $CACHE_PATH && -d $CACHE_PATH ]]; then
rm -rf "${CACHE_PATH:?}"/*
ShowAsDone 'package cache cleared'
fi
return 0
}
ResetReportsPath()
{
if [[ -n $REPORTS_PATH && -d $REPORTS_PATH ]]; then
rm -rf "${REPORTS_PATH:?}"/*
ShowAsDone 'reports cleared'
fi
return 0
}
Quiz()
{
local prompt=${1:?${FUNCNAME[0]}'()': undefined}
local response=''
ShowAsQuiz "$prompt"
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD igncr
read -rn1 response
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD -igncr
DebugVar response
ShowAsQuizDone "$prompt: $response"
case ${response:0:1} in
y|Y)
return 0
;;
*)
return 1
esac
}
PatchEntwareService()
{
local -r TAB=$'\t'
local -r PREFIX='# the following line was inserted by sherpa: https://git.io/sherpa'
local -r PACKAGE_INIT_PATHFILE=$(QPKG.GetServicePathFile Entware)
local find=''
local insert=''
if $GREP_CMD -q 'opt.orig' "$PACKAGE_INIT_PATHFILE"; then
DebugInfo 'patch: do the "/opt shuffle" - already done'
else
find='# sym-link $QPKG_DIR to /opt'
insert='opt_path="/opt"; opt_backup_path="/opt.orig"; [[ -d "$opt_path" \&\& ! -L "$opt_path" \&\& ! -e "$opt_backup_path" ]] \&\& mv "$opt_path" "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
find='/bin/ln -sf $QPKG_DIR /opt'
insert='[[ -L "$opt_path" \&\& -d "$opt_backup_path" ]] \&\& cp "$opt_backup_path"/* --target-directory "$opt_path" \&\& rm -r "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
DebugAsDone 'patch: do the "opt shuffle"'
fi
return 0
}
UpdateEntwarePackageList()
{
if IsNtSysFileExist $OPKG_CMD; then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${ENTWARE_PACKAGE_LIST_UPTODATE:-false} = false ]] || return 0
local -i z=0
if ! IsThisFileRecent "$EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES" || [[ ! -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE || $opts_check = true ]]; then
DebugAsProc "updating $(ShowAsPackageName Entware) package list"
RunAndLog "$OPKG_CMD update" "$LOGS_PATH/Entware.$UPDATE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
DebugAsDone "updated $(ShowAsPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(ShowAsPackageName Entware) package list $(ShowAsExitcode "$z")"
fi
else
DebugInfo "$(ShowAsPackageName Entware) package list was updated less-than $FILE_CHANGE_THRESHOLD_MINUTES minutes ago: skipping update"
fi
[[ -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE && ! -f $EXTERNAL_PACKAGES_PATHFILE ]] && OpenIpkArchive
readonly ENTWARE_PACKAGE_LIST_UPTODATE=true
return 0
}
IsThisFileRecent()
{
if [[ -e $1 && -e $GNU_FIND_CMD ]]; then
if [[ -z $($GNU_FIND_CMD "$1" -cmin +${2:-1440}) ]]; then
return 0
fi
fi
return 1
}
SaveEntwarePackageList()
{
$PIP_CMD freeze > "$PREV_PIP_LIST"
[[ -e $PREV_PIP_LIST ]] && DebugAsDone "saved current PIP module list to $(ShowAsFileName "$PREV_PIP_LIST")"
$OPKG_CMD list-installed > "$PREV_IPK_LIST"
[[ -e $PREV_IPK_LIST ]] && DebugAsDone "saved current $(ShowAsPackageName Entware) IPK list to $(ShowAsFileName "$PREV_IPK_LIST")"
} 2>/dev/null
LoadEntwarePackageList()
{
local packname=''
local sep=''
local version=''
if [[ -e $PREV_IPK_LIST ]]; then
while read -r packname sep version; do
IPKs-ACinstall-to:Add "$packname"
done < "$PREV_IPK_LIST"
fi
}
CalcIpkDepsToInstall()
{
IsSysFileExist $GNU_GREP_CMD || return
Func:Init
local -a this_list=()
local -a dep_acc=()
local -i requested_count=0
local -i pre_exclude_count=0
local -i iterations=0
local -r ITERATION_LIMIT=20
local req_list=''
local pre_exclude_list=''
local element=''
local complete=false
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$($WC_CMD -w <<< "$req_list")
if [[ $requested_count -eq 0 ]]; then
DebugAsWarn 'no IPKs requested'
Func:Exit 1; return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while [[ $iterations -lt $ITERATION_LIMIT ]]; do
ShowAsIterativeProgress 'resolving IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique package'
((iterations++))
local ipk_titles=$(printf '^Package: %s$\|' "${this_list[@]}")
ipk_titles=${ipk_titles%??}
this_list=($($GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD -vG '^Section:\|^Version:' | $GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator "$ipk_titles" | $GNU_GREP_CMD -vG "$ipk_titles" | $GNU_GREP_CMD -vG '^Package: ' | $SED_CMD 's|^Depends: ||;s|, |\n|g' | $SORT_CMD | $UNIQ_CMD))
ShowAsIterativeProgress 'resolving IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique package'
if [[ ${#this_list[@]} -eq 0 ]]; then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
if [[ $complete = true ]]; then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$ITERATION_LIMIT [$ITERATION_LIMIT]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$($WC_CMD -w <<< "$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]]; then
ShowAsProc 'excluding IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list; do
if [[ $element != 'ca-certs' && $element != 'python3-gdbm' ]]; then
if [[ $element != 'libjpeg' ]]; then
if ! $OPKG_CMD status "$element" | $GREP_CMD -q "Status:.*installed"; then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $OPKG_CMD status 'libjpeg-turbo' | $GREP_CMD -q "Status:.*installed"; then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
Func:Exit
}
CalcIpkDownloadSize()
{
Func:Init
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]]; then
ShowAsProc "calculating size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($GNU_GREP_CMD -w '^Package:\|^Size:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD --after-context 1 --no-group-separator ": $($SED_CMD 's/ /$ /g;s/\$ /\$\\\|: /g' <<< "$(IPKs-ACdownload-to:List)")" | $GREP_CMD '^Size:' | $SED_CMD 's|^Size: ||'))
IPKs-ACdownload-to:Size = "$(IFS=+; echo "$((${size_array[*]}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
Func:Exit
}
IPKs:upgrade()
{
[[ $ipks_upgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
UpdateEntwarePackageList
Self.Error.IsNt || return
Func:Init
local desc=''
local log_pathfile=$LOGS_PATH/ipks.$UPGRADE_LOG_FILE
local -i z=0
local -i total_count=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($OPKG_CMD list-upgradable | cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]]; then
desc="$total_count auxiliary IPK module$(Pluralise "$total_count")"
ShowAsProc "upgrading $desc"
_DirSize:Monitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillActiveFork
if [[ $z -eq 0 ]]; then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultToLog IPK "$desc" upgrade ok "$z"
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultToLog IPK "$desc" upgrade failed "$z"
fi
fi
Func:Exit $z
}
IPKs:install()
{
[[ $ipks_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
UpdateEntwarePackageList
Self.Error.IsNt || return
Func:Init
local desc=''
local -i i=0
local log_pathfile=$LOGS_PATH/ipks.$INSTALL_LOG_FILE
local -i z=0
local -i total_count=0
local previous=''
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware || ([[ $opts_check = true ]] && QPKG.IsInstalled Entware); then
IPKs-ACinstall-to:Add "$ESSENTIAL_IPKS"
if [[ -e $PREV_IPK_LIST ]]; then
LoadEntwarePackageList
mv "$PREV_IPK_LIST" "$PREV_IPK_LIST.installing"
fi
fi
if QPKGs.ACinstall.SCall.IsSet; then
for i in "${!QPKG_NAME[@]}"; do
[[ $previous = "${QPKG_NAME[$i]}" ]] && continue || previous=${QPKG_NAME[$i]}
IPKs-ACinstall-to:Add "$(QPKG.GetIPKs "${QPKG_NAME[$i]}" "$i")"
done
else
for i in "${!QPKG_NAME[@]}"; do
[[ $previous = "${QPKG_NAME[$i]}" ]] && continue || previous=${QPKG_NAME[$i]}
if QPKGs-ACinstall-to.Exist "${QPKG_NAME[$i]}" || QPKGs-ISinstalled.Exist "${QPKG_NAME[$i]}" || QPKGs-ACreinstall-to.Exist "${QPKG_NAME[$i]}" || (QPKGs-ACactivate-to.Exist "${QPKG_NAME[$i]}" && (QPKGs-ACinstall-to.Exist "${QPKG_NAME[$i]}" || QPKGs-ISinstalled.Exist "${QPKG_NAME[$i]}" || QPKGs-ACreinstall-to.Exist "${QPKG_NAME[$i]}")); then
QPKG.IsMinOSVerOk "${QPKG_NAME[$i]}" || continue
QPKG.IsMinRAMOk "${QPKG_NAME[$i]}" || continue
IPKs-ACinstall-to:Add "$(QPKG.GetIPKs "${QPKG_NAME[$i]}" "$i")"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]]; then
desc="$total_count auxiliary IPK module$(Pluralise "$total_count")"
ShowAsProc "installing $desc"
_DirSize:Monitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD install --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillActiveFork
if [[ $z -eq 0 ]]; then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultToLog IPK "$desc" install ok "$z"
Keystrokes:Hide
UpdateColourisation
if [[ -e $PREV_IPK_LIST.installing ]]; then
rm "$PREV_IPK_LIST.installing"
fi
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultToLog IPK "$desc" install failed "$z"
if [[ -e $PREV_IPK_LIST.installing ]]; then
mv "$PREV_IPK_LIST.installing" "$PREV_IPK_LIST"
fi
fi
fi
Func:Exit $z
}
IPKs:downgrade()
{
[[ $ipks_downgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
UpdateEntwarePackageList
Self.Error.IsNt || return
Func:Init
local desc=''
local -i fail_count=0
local log_pathfile=''
local -i ok_count=0
local name=''
local package_type=''
local remote_url=''
local -i z=0
local -i total_count=0
local url_prefix=''
local url_suffix=''
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
if [[ $total_count -gt 0 ]]; then
package_type='auxiliary IPK module'
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNLOAD_LOG_FILE
ShowAsProc "downloading $desc"
if OS.IsNonStdKernelPageSize; then
url_prefix=http://bin.entware.net
url_suffix=_2.38-1
case $NAS_QPKG_ARCH in
a64)
url_prefix+='/aarch64-k3.10'
url_suffix+='_aarch64-3.10'
;;
a41)
url_prefix+='/armv7sf-k3.2'
url_suffix+='_armv7-3.2'
esac
url_prefix+=/archive/
url_suffix+=.ipk
for name in $(IPKs-ACdowngrade-to:Array); do
ShowAsPercentProgress "downloading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$IPK_DOWNGRADE_DL_PATH/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD${curl_insecure_arg} --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "downloading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
total_count=1
ok_count=0
fail_count=0
package_type='auxiliary IPK group'
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNGRADE_LOG_FILE
ShowAsProc "downgrading $desc"
ShowAsPercentProgress "downgrading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
RunAndLog "$OPKG_CMD install --force-downgrade --cache $IPK_CACHE_PATH --tmp-dir $IPK_DOWNGRADE_DL_PATH $IPK_DOWNGRADE_DL_PATH/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
((ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultToLog IPK "$desc" downgrade ok "$z"
else
((fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultToLog IPK "$desc" downgrade failed "$z"
fi
ShowAsPercentProgress "downgrading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
Func:Exit $z
}
PIPs:install()
{
[[ $pips_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
$OPKG_CMD status python3-pip | $GREP_CMD -q "Status:.*installed" || return
Self.Error.IsNt || return
Func:Init
local desc=''
local exec_cmd=''
local -i fail_count=0
local log_pathfile=$LOGS_PATH/pypi.$INSTALL_LOG_FILE
local -i ok_count=0
local package_type='auxiliary PyPI group'
local -i z=0
local -i total_count=0
if [[ $opts_check = true ]] || IPKs-ACinstall-ok.Exist python3-pip; then
((total_count++))
exec_cmd="$PIP_CMD install --upgrade --no-input $ESSENTIAL_PIPS --cache-dir $PIP_CACHE_PATH 2> >($GREP_CMD -v \"Running pip as the 'root' user\") >&2"
desc='auxiliary PyPI modules'
ShowAsPercentProgress "installing $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 0 "$total_count"
RunAndLog "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
((ok_count++))
DebugAsDone "installed $desc"
SaveActionResultToLog PIP "$desc" install ok "$z"
else
((fail_count++))
SaveActionResultToLog PIP "$desc" install failed "$z"
fi
ShowAsPercentProgress "installing $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
Func:Exit $z
}
OpenIpkArchive()
{
if [[ ! -e $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE ]]; then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
RunAndLog "/usr/local/sbin/7z e -o$($DIRNAME_CMD "$EXTERNAL_PACKAGES_PATHFILE") $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$CACHE_PATH/ipk.archive.extract" log:failure-only
if [[ ! -e $EXTERNAL_PACKAGES_PATHFILE ]]; then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0
}
CloseIpkArchive()
{
rm -f "$EXTERNAL_PACKAGES_PATHFILE"
}
_ActionForks:Launch_()
{
local package=''
local target_function=${1:-function null}
shift
local -a target_packages=("$@")
for package in "${target_packages[@]}"; do
while [[ $fork_count -ge $max_forks ]]; do
sleep .2
UpdateForkProgress
done
IncForkProgressIndex
MarkThisActionForkAsStarted
$target_function "$package" &
DebugAsDone "forked $target_function() for '$package'"
UpdateForkProgress
done
while [[ $fork_count -gt 0 ]]; do
sleep .2
UpdateForkProgress
done
}
_DirSize:Monitor_()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] || exit
[[ -n ${2:?${FUNCNAME[0]}'()': undefined} ]] || exit
[[ -d $1 && $2 -gt 0 ]] || exit
IsSysFileExist $GNU_FIND_CMD || exit
local -i current_bytes=-1
local -i total_bytes=$2
local -i last_bytes=0
local -i stall_seconds=0
local -i stall_seconds_threshold=4
local perc_msg=''
local progress_msg=''
local stall_msg=''
InitProgress
while [[ $current_bytes -lt $total_bytes ]]; do
current_bytes=$($GNU_FIND_CMD "$1" -type f -name '*.ipk' -exec $DU_CMD --bytes --total --apparent-size {} + 2>/dev/null | $GREP_CMD total$ | cut -f1)
[[ -z $current_bytes ]] && current_bytes=0
if [[ $current_bytes -ne $last_bytes ]]; then
stall_seconds=0
last_bytes=$current_bytes
else
((stall_seconds++))
fi
perc_msg="$((200*(current_bytes)/(total_bytes)%2+100*(current_bytes)/(total_bytes)))%"
[[ $current_bytes -lt $total_bytes && $perc_msg = '100%' ]] && perc_msg='99%'
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$total_bytes")"))"
if [[ $stall_seconds -ge $stall_seconds_threshold ]]; then
stall_msg=' stalled for '
if [[ $stall_seconds -lt 60 ]]; then
stall_msg+="$stall_seconds seconds"
else
stall_msg+=$(FormatSecsToHoursMinutesSecs "$stall_seconds")
fi
if [[ $stall_seconds -ge 90 ]]; then
stall_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stall_seconds -ge 90 ]]; then
stall_msg=$(TextBrightRed "$stall_msg")
elif [[ $stall_seconds -ge 45 ]]; then
stall_msg=$(TextBrightOrange "$stall_msg")
elif [[ $stall_seconds -ge 20 ]]; then
stall_msg=$(TextBrightYellow "$stall_msg")
fi
progress_msg+=$stall_msg
fi
[[ ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
WriteMsgInPlace "$progress_msg"
sleep 1
done
[[ -n $progress_msg ]] && WriteMsgInPlace 'done!'
}
WriteMsgInPlace()
{
local -i blanking_length=0
local squeezed_msg=$(tr -s ' ' <<< "${1:-}")
local clean_msg=$(StripANSICodes "$squeezed_msg")
if [[ $clean_msg != "$prev_clean_msg" ]]; then
if [[ ${#clean_msg} -lt ${#prev_clean_msg} ]]; then
blanking_length=$((${#clean_msg}-${#prev_clean_msg}))
printf "%${#prev_clean_msg}s" | tr ' ' '\b'; echo -en "$squeezed_msg"; printf "%${blanking_length}s"; printf "%${blanking_length}s" | tr ' ' '\b'
else
printf "%${#prev_clean_msg}s" | tr ' ' '\b'; echo -en "$squeezed_msg"
fi
prev_clean_msg=$clean_msg
fi
}
KillActiveFork()
{
if [[ -n ${fork_pid:-} && ${fork_pid:-0} -gt 0 && -d /proc/$fork_pid ]]; then
sleep .2
set +m
kill -9 "$fork_pid"
set -m
wait
fi
} &>/dev/null
EnableResetIfRequested()
{
local re=''
re=\\breset\\b
if [[ $USER_ARGS_RAW =~ $re ]]; then
ResetCachePath
ResetReportsPath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
exit 0
fi
return 1
}
EnableVerboseIfRequested()
{
local re=''
for re in \\bverbose\\b \\bv\\b; do
if [[ $USER_ARGS_RAW =~ $re ]]; then
Self.Verbose:Enable
EnableDebugToArchiveAndFile
return 0
fi
done
return 1
}
EnableDebugIfRequested()
{
local re=''
for re in \\bdebug\\b \\bdbug\\b; do
if [[ $USER_ARGS_RAW =~ $re ]]; then
EnableDebugToArchiveAndFile
return 0
fi
done
return 1
}
User.IsOk()
{
if ! User.IsSU; then
if OS.IsSupportSudo; then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${CHARS_SUDO_PROMPT}sherpa $USER_ARGS_RAW" >&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again."
fi
return 1
fi
return 0
}
User.IsSU()
{
[[ $EUID -eq 0 ]]
}
TerminalDimensions:Load()
{
if [[ -e $GNU_STTY_CMD && -t 0 ]]; then
local terminal_dimensions=$($GNU_STTY_CMD size)
readonly SESS_ROWS=${terminal_dimensions% *}
readonly SESS_COLS=${terminal_dimensions#* }
else
readonly SESS_ROWS=40
readonly SESS_COLS=156
fi
return 0
}
DebugBinPathVerAndMinVer()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] || return
local bin_path=$(GetThisBinPath "$1")
if [[ -n $bin_path ]]; then
DebugUserspace ok "'$1' path" "$bin_path"
else
DebugUserspace warning "'$1' path" 'not present'
fi
if [[ -n ${2:-} ]]; then
[[ -n ${3:?${FUNCNAME[0]}'()': undefined} ]] || return
if [[ ${2//./} -ge ${3//./} ]]; then
DebugUserspace ok "'$1' version" "$2"
else
DebugUserspace warning "'$1' version" "$2"
fi
else
DebugUserspace warning "'$1' version" 'undefined'
fi
return 0
}
IsSysFileExist()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] || exit
if ! [[ -f $1 || -L $1 ]]; then
ShowAsAbort "a required NAS system file is missing $(ShowAsFileName "$1")"
return 1
fi
return 0
}
IsNtSysFileExist()
{
! IsSysFileExist "${1:?${FUNCNAME[0]}'()': undefined}"
}
LenANSIDiff()
{
local original=${1:-}
local stripped=$(StripANSICodes "$original")
echo "$((${#original}-${#stripped}))"
return 0
}
CalcMaxStatusReportCols()
{
local col3_width=$((${#CHAR_SPACER}+${#CHARS_BULLET}+PACKAGE_VER_COL_WIDTH))
if QPKGs-SCupgradable.IsAny; then
package_ver_final_col_width=$((PACKAGE_VER_COL_WIDTH+6))
((col3_width+6))
else
package_ver_final_col_width=$PACKAGE_VER_COL_WIDTH
fi
return 0
}
DisplayAsProjSynExam()
{
WriteEmptyLineIfNoneExists
printf "${CHARS_BULLET}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf "\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}%s\n" '' "sherpa ${2:-}"
linespace_visible=false
}
DisplayAsProjSynIndentExam()
{
if [[ -n $1	]]; then
printf "\n%${HELP_DESC_INDENT}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf '\n'
fi
printf "%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}%s\n" '' "sherpa ${2:-}"
linespace_visible=false
}
DisplayAsSynExam()
{
printf "\n${CHARS_BULLET}%s:\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_PREFIX}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}"
linespace_visible=false
}
DisplayAsPackagesReportTitleLine()
{
local a=''
WriteEmptyLineIfNoneExists
if [[ $maxcols -ge 1 ]]; then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 2 ]]; then
a="${CHARS_BULLET}App version:"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 3 ]]; then
a="${CHARS_BULLET}Description:"
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'; linespace_visible=false
}
DisplayAsPackagesReportLine()
{
local name=${1:?${FUNCNAME[0]}'()': undefined}
local name_msg=$CHARS_NORMAL
local app_ver_msg=$CHARS_BLANK
local description=$(QPKG.GetDesc "$name")
local description_msg=$CHARS_BLANK
local notes=$(QPKG.GetNote "$name")
local notes_msg="${notes}."
local mode=''
if QPKG.IsMissing "$name"; then
mode=highlighted
elif QPKG.IsNtInstalled "$name"; then
mode=muted
else
mode=normal
fi
name_msg+=$name
app_ver_msg+=$(QPKG.App.GetVer "$name")
description_msg+="$(Capitalise "$description")."
case $mode in
muted)
name_msg=$(TextDarkGrey "$name_msg")
app_ver_msg=$(TextDarkGrey "$app_ver_msg")
description_msg=$(TextDarkGrey "$description_msg")
;;
highlighted)
name_msg=$(TextBrightRed "$name_msg")
esac
if [[ $maxcols -ge 1 && -n $name_msg ]]; then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $maxcols -ge 2 && -n $app_ver_msg ]]; then
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
fi
if [[ $maxcols -ge 3 && -n $description ]]; then
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+$(LenANSIDiff "$description_msg")))s" "$description_msg"
if [[ -n $notes ]]; then
printf "\n%$((${#CHARS_BLANK}+PACKAGE_NAME_COL_WIDTH+PACKAGE_APP_VER_COL_WIDTH))s$(TextBrightOrange "${CHARS_DROPEND}${CHARS_NOTE}")%s" '' "$notes_msg"
fi
fi
printf '\n'; linespace_visible=false
WriteEmptyLineIfNoneExists
}
DisplayAsStatusReportTitleLine()
{
local a=''
WriteEmptyLineIfNoneExists
if [[ $maxcols -ge 1 ]]; then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 2 ]]; then
a="${CHARS_BULLET}QPKG statuses:"
printf "%-$((PACKAGE_STATUS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 3 ]]; then
a="${CHARS_BULLET}QPKG version"
QPKGs-SCupgradable.IsAny && a+=" ($(TextBrightOrange new))"
a+=':'
printf "%-$((package_ver_final_col_width+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 4 ]]; then
a="${CHARS_BULLET}App version:"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 5 ]]; then
a="${CHARS_BULLET}QPKG installation path:"
printf "%-$((PACKAGE_PATH_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'; linespace_visible=false
}
DisplayAsStatusReportLine()
{
local name=${1:?${FUNCNAME[0]}'()': undefined}
local name_msg=$CHARS_BLANK
local status=''
local status_msg=''
local ver_msg=$CHARS_BLANK
local app_ver_msg=$CHARS_BLANK
local upgrade_ver=''
local path_msg=$CHARS_BLANK
local mode=''
if QPKG.IsMissing "$name"; then
mode=highlighted
elif QPKG.IsNtInstalled "$name"; then
mode=muted
else
mode=normal
fi
case $mode in
normal)
if QPKGs-ISenabled.Exist "$name"; then
status+=" $(TextBrightGreen enabled)"
else
status+=" $(TextBrightRed disabled)"
fi
if QPKGs-ACstatus-ok.Exist "$name"; then
if QPKGs-ISactive.Exist "$name"; then
status+=" $(TextBrightGreen active)"
elif QPKGs-ISslow.Exist "$name"; then
status+=" $(TextBrightOrange slow)"
elif QPKGs-ISstarting.Exist "$name"; then
status+=" $(TextBrightOrange starting)"
elif QPKGs-ISstopping.Exist "$name"; then
status+=" $(TextBrightOrange stopping)"
elif QPKGs-ISrestarting.Exist "$name"; then
status+=" $(TextBrightOrange restarting)"
elif QPKGs-ISunknown.Exist "$name"; then
status+=" $(TextBrightOrange unknown)"
else
status+=" $(TextBrightRed inactive)"
fi
else
status+=" $(TextBrightOrange unknown)"
fi
if [[ -n $status ]]; then
status=$(Trim "$status")
status_msg=${status// /, }
fi
status_msg=${CHARS_NORMAL}${status_msg}
QPKG.IsUpgradable "$name" && upgrade_ver=$(QPKG.Avail.GetVer "$name")
ver_msg+=$(QPKG.Local.GetVer "$name")
if [[ -n $upgrade_ver ]]; then
ver_msg+=" ($(TextBrightOrange "$upgrade_ver"))"
name_msg+=$(TextBrightOrange "$name")
else
name_msg+=$name
fi
app_ver_msg+=$(QPKG.App.GetVer "$name")
path_msg+=$(QPKG.GetInstallationPath "$name")
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name"; then
status='incompatible arch'
ver_msg=''
app_ver_msg=''
elif ! QPKG.IsMinOSVerOk "$name"; then
status="incompatible $(GetQnapOS) version"
ver_msg=''
app_ver_msg=''
elif ! QPKG.IsMinRAMOk "$name"; then
status='insufficient RAM'
ver_msg=''
app_ver_msg=''
else
status='not installed'
ver_msg+=$(TextDarkGrey "$(QPKG.Avail.GetVer "$name")")
app_ver_msg+=$(TextDarkGrey "$(QPKG.App.GetVer "$name")")
fi
status_msg=$(TextDarkGrey "${CHARS_NORMAL}${status}")
path_msg=''
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
status_msg=$(TextBrightRedBlink "${CHARS_ALERT}missing")
ver_msg+=$(TextBrightRed "$(QPKG.Local.GetVer "$name")")
app_ver_msg+=$(TextBrightRed "$(QPKG.App.GetVer "$name")")
path_msg=$(TextBrightRedBlink "${CHARS_ALERT}$(QPKG.GetInstallationPath "$name")")
esac
if [[ $maxcols -ge 1 && -n $name_msg ]]; then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $maxcols -ge 2 && -n $status_msg ]]; then
printf "%-$((PACKAGE_STATUS_COL_WIDTH+$(LenANSIDiff "$status_msg")))s" "$status_msg"
fi
if [[ $maxcols -ge 3 && -n $ver_msg ]]; then
printf "%-$((package_ver_final_col_width+$(LenANSIDiff "$ver_msg")))s" "$ver_msg"
fi
if [[ $maxcols -ge 4 && -n $app_ver_msg ]]; then
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
fi
if [[ $maxcols -ge 5 && -n $path_msg ]]; then
printf "%-$((PACKAGE_PATH_COL_WIDTH+$(LenANSIDiff "$path_msg")))s" "$path_msg"
fi
printf '\n'; linespace_visible=false
}
DisplayAsReposReportTitleLine()
{
local a=''
WriteEmptyLineIfNoneExists
if [[ $maxcols -ge 1 ]]; then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 2 ]]; then
a="${CHARS_BULLET}install date:"
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 3 ]]; then
a="${CHARS_BULLET}repository:"
printf "%-$((PACKAGE_REPO_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'; linespace_visible=false
}
DisplayAsReposReportLine()
{
local name=${1:?${FUNCNAME[0]}'()': undefined}
local name_msg=$CHARS_BLANK
local install_date=$(QPKG.GetInstallDate "$name")
local install_date_msg=$CHARS_BLANK
local store_id=$(QPKG.GetStoreID "$name")
local assigned_repo=$(GetRepoURLFromStoreID "$store_id")
local assigned_repo_msg=$CHARS_NORMAL
local mode=''
if QPKG.IsMissing "$name"; then
mode=highlighted
elif QPKG.IsNtInstalled "$name"; then
mode=muted
else
mode=normal
fi
if [[ $store_id = sherpa ]]; then
assigned_repo=sherpa
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
else
assigned_repo_msg+=$assigned_repo
fi
case $mode in
normal)
name_msg+=$name
case $install_date in
sherpa)
install_date_msg+=$(TextBrightGreen "$install_date")
;;
unassigned)
install_date_msg+=$(TextBrightOrange "$install_date")
;;
*)
install_date_msg+=$install_date
esac
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name"; then
assigned_repo='incompatible arch'
elif ! QPKG.IsMinOSVerOk "$name"; then
assigned_repo="incompatible $(GetQnapOS) version"
elif ! QPKG.IsMinRAMOk "$name"; then
assigned_repo='insufficient RAM'
else
assigned_repo='not installed'
fi
install_date_msg+=$(TextDarkGrey "$assigned_repo")
assigned_repo=''
assigned_repo_msg=''
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
install_date_msg+=$install_date
esac
if [[ $maxcols -ge 1 && -n $name_msg ]]; then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $maxcols -ge 2 && -n $install_date_msg ]]; then
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+$(LenANSIDiff "$install_date_msg")))s" "$install_date_msg"
fi
if [[ $maxcols -ge 3 && -n $assigned_repo_msg ]]; then
printf "%-$((PACKAGE_REPO_COL_WIDTH+$(LenANSIDiff "$assigned_repo_msg")))s" "$assigned_repo_msg"
fi
printf '\n'; linespace_visible=false
}
DisplayAsAbsReportTitleLine()
{
local a=''
WriteEmptyLineIfNoneExists
if [[ $maxcols -ge 1 ]]; then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 2 ]]; then
a="${CHARS_BULLET}acceptable QPKG name abbreviations and aliases:"
printf "%-$((PACKAGE_ABBS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'; linespace_visible=false
}
DisplayAsAbsReportLine()
{
local name=${1:?${FUNCNAME[0]}'()': undefined}
local name_msg=$CHARS_BLANK
local abs=''
local abs_msg=$CHARS_NORMAL
local mode=''
if QPKG.IsMissing "$name"; then
mode=highlighted
elif QPKG.IsNtInstalled "$name"; then
mode=muted
else
mode=normal
fi
abs=$(QPKG.GetAbbrvs "$name")
if [[ -n $abs ]]; then
abs=$(Trim "$abs")
abs=${abs// /, }
fi
case $mode in
normal)
name_msg+=$name
abs_msg+=$abs
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name"; then
abs_msg+='(incompatible arch)'
elif ! QPKG.IsMinOSVerOk "$name"; then
abs_msg+="(incompatible $(GetQnapOS) version)"
elif ! QPKG.IsMinRAMOk "$name"; then
abs_msg+='(insufficient RAM)'
else
abs_msg+=$abs
fi
abs_msg=$(TextDarkGrey "$abs_msg")
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
abs_msg=$(TextBrightRedBlink "${CHARS_ALERT}${abs}")
esac
if [[ $maxcols -ge 1 && -n $name_msg ]]; then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $maxcols -ge 2 && -n $abs_msg ]]; then
printf "%-$((PACKAGE_ABBS_COL_WIDTH+$(LenANSIDiff "$abs_msg")))s" "$abs_msg"
fi
printf '\n'; linespace_visible=false
}
DisplayAsDepsReportTitleLine()
{
local a=''
WriteEmptyLineIfNoneExists
if [[ $maxcols -ge 1 ]]; then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 2 ]]; then
a="${CHARS_BULLET}dependencies:"
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 3 ]]; then
a="${CHARS_BULLET}installed?"
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 4 ]]; then
a="${CHARS_BULLET}enabled?"
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 5 ]]; then
a="${CHARS_BULLET}min RAM:"
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 6 ]]; then
a="${CHARS_BULLET}min OS:"
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 7 ]]; then
a="${CHARS_BULLET}max OS:"
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $maxcols -ge 8 ]]; then
a="${CHARS_BULLET}supported arch?"
printf "%-$((PACKAGE_ARCH_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'; linespace_visible=false
}
DisplayAsDepsReportLine()
{
local name=${1:?${FUNCNAME[0]}'()': undefined}
local name_msg=$CHARS_BLANK
local package_deps_raw=$(QPKG.GetDependencies "$name")
[[ -z $package_deps_raw ]] && package_deps_raw=none
local package_deps=''
local package_deps_msg=$CHARS_NORMAL
local package_enabled_msg=$CHARS_BLANK
local package_installed_msg=$CHARS_BLANK
local dep=''
local package_min_ram=$(QPKG.GetMinRAM "$name")
local package_min_ram_msg=$CHARS_BLANK
if [[ $package_min_ram != none ]]; then
package_min_ram=$(FormatAsThous "$package_min_ram")kB
fi
local package_min_os=$(QPKG.GetMinOSVer "$name")
[[ -n $package_min_os && $package_min_os != none && ${#package_min_os} -eq 3 ]] && package_min_os=${package_min_os:0:1}.${package_min_os:1:1}.${package_min_os:2:1}
local package_min_os_msg=$CHARS_BLANK
local package_max_os=$(QPKG.GetMaxOSVer "$name")
[[ -n $package_max_os && $package_max_os != none && ${#package_max_os} -eq 3 ]] && package_max_os=${package_max_os:0:1}.${package_max_os:1:1}.${package_max_os:2:1}
local package_max_os_msg=$CHARS_BLANK
local package_arch_msg=$CHARS_BLANK
local mode=''
if QPKG.IsMissing "$name"; then
mode=highlighted
elif QPKG.IsNtInstalled "$name"; then
mode=muted
else
mode=normal
fi
case $mode in
normal)
name_msg+=$name
if [[ $package_deps_raw != none ]]; then
for dep in $package_deps_raw; do
[[ -n $package_deps ]] && package_deps+=' '
if QPKG.IsInstalled "$dep" && QPKG.IsEnabled "$dep"; then
package_deps+=$(TextBrightGreen "$dep")
else
package_deps+=$(TextBrightRed "$dep")
package_deps_msg=$(TextBrightRed "$CHARS_ALERT")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
done
else
package_deps+=$(TextBrightGreen "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /, }
if QPKG.IsInstalled "$name"; then
package_installed_msg+=$(TextBrightGreen true)
else
package_installed_msg+=false
fi
if QPKG.IsEnabled "$name"; then
package_enabled_msg+=$(TextBrightGreen true)
else
package_enabled_msg=$(TextBrightRed "$CHARS_ALERT")
package_enabled_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMinRAMOk "$name"; then
package_min_ram_msg+=$(TextBrightGreen "$package_min_ram")
else
package_min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_ram_msg+=$(TextBrightRed "$package_min_ram")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMinOSVerOk "$name"; then
package_min_os_msg+=$(TextBrightGreen "$package_min_os")
else
package_min_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_os_msg+=$(TextBrightRed "$package_min_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMaxOSVerOk "$name"; then
package_max_os_msg+=$(TextBrightGreen "$package_max_os")
else
package_max_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_max_os_msg+=$(TextBrightRed "$package_max_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsArchOK "$name"; then
package_arch_msg+=$(TextBrightGreen true)
else
package_arch_msg=$(TextBrightRed "$CHARS_ALERT")
package_arch_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
;;
muted)
name_msg+=$(TextDarkGrey "$name")
package_deps_msg=$(TextDarkGrey "$CHARS_NORMAL")
if [[ $package_deps_raw != none ]]; then
for dep in $package_deps_raw; do
[[ -n $package_deps ]] && package_deps+=' '
package_deps+=$(TextDarkGrey "$dep")
done
else
package_deps+=$(TextDarkGrey "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /$(TextDarkGrey ', ')}
package_installed_msg+=$(TextDarkGrey false)
package_enabled_msg+=$(TextDarkGrey 'N/A')
if QPKG.IsMinRAMOk "$name"; then
package_min_ram_msg+=$(TextDarkGrey "$package_min_ram")
else
package_min_ram_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_min_ram_msg+=$(TextBrightOrange "$package_min_ram")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsMinOSVerOk "$name"; then
package_min_os_msg+=$(TextDarkGrey "$package_min_os")
else
package_min_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_min_os_msg+=$(TextBrightOrange "$package_min_os")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsMaxOSVerOk "$name"; then
package_max_os_msg+=$(TextDarkGrey "$package_max_os")
else
package_max_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_max_os_msg+=$(TextBrightOrange "$package_max_os")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsArchOK "$name"; then
package_arch_msg+=$(TextDarkGrey true)
else
package_arch_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_arch_msg+=$(TextBrightOrange false)
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
if [[ $package_deps_raw != none ]]; then
for dep in $package_deps_raw; do
[[ -n $package_deps ]] && package_deps+=' '
if QPKG.IsInstalled "$dep" && QPKG.IsEnabled "$dep"; then
package_deps+=$(TextBrightGreen "$dep")
else
package_deps+=$(TextBrightRed "$dep")
fi
done
else
package_deps+=$(TextBrightGreen "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /, }
package_installed_msg=$(TextBrightRedBlink "$CHARS_ALERT")
package_installed_msg+=$(TextBrightRedBlink 'missing')
if QPKG.IsEnabled "$name"; then
package_enabled_msg+=$(TextBrightGreen true)
else
package_enabled_msg=$(TextBrightRedBlink "$CHARS_ALERT")
package_enabled_msg+=$(TextBrightRed 'false')
fi
if QPKG.IsMinRAMOk "$name"; then
package_min_ram_msg+=$(TextBrightGreen "$package_min_ram")
else
package_min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_ram_msg+=$(TextBrightRed "$package_min_ram")
fi
if QPKG.IsMinOSVerOk "$name"; then
package_min_os_msg+=$(TextBrightGreen "$package_min_os")
else
package_min_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_os_msg+=$(TextBrightRed "$package_min_os")
fi
if QPKG.IsMaxOSVerOk "$name"; then
package_max_os_msg+=$(TextBrightGreen "$package_max_os")
else
package_max_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_max_os_msg+=$(TextBrightRed "$package_max_os")
fi
if QPKG.IsArchOK "$name"; then
package_arch_msg+=$(TextBrightGreen true)
else
package_arch_msg=$(TextBrightRed "$CHARS_ALERT")
package_arch_msg+=$(TextBrightRed false)
fi
esac
if [[ $maxcols -ge 1 && -n $name_msg ]]; then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $maxcols -ge 2 && -n $package_deps_msg ]]; then
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+$(LenANSIDiff "$package_deps_msg")))s" "$package_deps_msg"
fi
if [[ $maxcols -ge 3 && -n $package_installed_msg ]]; then
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+$(LenANSIDiff "$package_installed_msg")))s" "$package_installed_msg"
fi
if [[ $maxcols -ge 4 && -n $package_enabled_msg ]]; then
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+$(LenANSIDiff "$package_enabled_msg")))s" "$package_enabled_msg"
fi
if [[ $maxcols -ge 5 && -n $package_min_ram_msg ]]; then
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+$(LenANSIDiff "$package_min_ram_msg")))s" "$package_min_ram_msg"
fi
if [[ $maxcols -ge 6 && -n $package_min_os_msg ]]; then
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+$(LenANSIDiff "$package_min_os_msg")))s" "$package_min_os_msg"
fi
if [[ $maxcols -ge 7 && -n $package_max_os_msg ]]; then
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+$(LenANSIDiff "$package_max_os_msg")))s" "$package_max_os_msg"
fi
if [[ $maxcols -ge 8 && -n $package_arch_msg ]]; then
printf "%-$((PACKAGE_ARCH_COL_WIDTH+$(LenANSIDiff "$package_arch_msg")))s" "$package_arch_msg"
fi
printf '\n'; linespace_visible=false
}
DisplayAsHelpTitleFileNamePlusSomething()
{
WriteEmptyLineIfNoneExists
printf "${CHARS_BULLET}%-${FILE_NAME_COL_WIDTH}s ${CHARS_BULLET}%s\n" "$(Capitalise "${1:-}"):" "$(Capitalise "${2:-}"):"
linespace_visible=false
}
DisplayAsHelpTitle()
{
WriteEmptyLineIfNoneExists
printf "${CHARS_BULLET}%s\n" "$(Capitalise "${1:-}" | tr -s ' ')"
linespace_visible=false
}
DisplayAsHelpTitleHighlighted()
{
WriteEmptyLineIfNoneExists
printf "$(TextBrightOrange "${CHARS_BULLET}%s\n")" "$(Capitalise "${1:-}")"
linespace_visible=false
}
DisplayAsIndentPrefixActionResultDurationReason()
{
local duration=''
[[ -n ${4:-} ]] && duration=$(FormatMillisecsToMinutesSecs "$4")
printf "%${ACTION_RESULT_INDENT}s" ''
if [[ -z ${5:-} ]]; then
printf "%s%s %s%s" "${1:-}" "$(Lowercase "${2:-}")" "${3:-}" "$([[ -n $duration ]] && printf ' in %s' "$duration")"
else
printf "%s%s %s%s: %s" "${1:-}" "$(Lowercase "${2:-}")" "${3:-}" "$([[ -n $duration ]] && printf ' in %s' "$duration")" "$5"
fi
printf '\n'; linespace_visible=false
}
EraseThisLine()
{
[[ ${opts_verbose:=false} = false ]] && printf '\033[2K\r'
linespace_visible=true
} >&2
Display()
{
echo -e "${1:-}"
linespace_visible=false
}
DisplayWait()
{
printf '%s' "${1:-}"
}
Report.Actions:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAction) usage examples:"
DisplayAsProjSynIndentExam 'show package statuses' status
DisplayAsProjSynIndentExam '' s
DisplayAsProjSynIndentExam 'show current package repository assignments' repos
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'ensure all application dependencies are installed' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'show QPKG dependencies' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'install these packages' "install $(ShowPackages)"
DisplayAsProjSynIndentExam 'uninstall these packages' "uninstall $(ShowPackages)"
DisplayAsProjSynIndentExam 'reinstall these packages' "reinstall $(ShowPackages)"
DisplayAsProjSynIndentExam "rebuild these packages ('install' packages, then 'restore' configuration backups)" "rebuild $(ShowPackages)"
DisplayAsProjSynIndentExam 'upgrade these packages (this will upgrade internal applications where-supported)' "upgrade $(ShowPackages)"
DisplayAsProjSynIndentExam 'enable these packages' "enable $(ShowPackages)"
DisplayAsProjSynIndentExam 'disable these packages (disabling will prevent them activating on reboot)' "disable $(ShowPackages)"
DisplayAsProjSynIndentExam 'enable, then activate these packages (this will upgrade internal applications where-supported)' "activate $(ShowPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowPackages)"
DisplayAsProjSynIndentExam 'deactivate these packages' "deactivate $(ShowPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowPackages)"
DisplayAsProjSynIndentExam 'reactivate these packages (this will upgrade internal applications where-supported)' "reactivate $(ShowPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowPackages)"
Report.Action.Reassign:Show
DisplayAsProjSynIndentExam 'clear local repository files from these packages' "clean $(ShowPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'list backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam "list $(ShowTitleName) object version numbers" 'list versions'
DisplayAsProjSynExam "$(ShowAction)s to affect all packages can be seen with" 'all-actions'
DisplayAsProjSynExam "multiple $(ShowAction)s are supported like this" "$(ShowAction) $(ShowPackages) $(ShowAction) $(ShowPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Report.Action.Reassign:Show()
{
DisplayAsProjSynIndentExam "reassign packages to $(ShowTitleName). Use this action to detach QPKGs previously installed via an online repository from further management by that repository" "reassign $(ShowPackages)"
}
Report.ActionsAll:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle "the 'all' group applies to all installed packages. If $(ShowAction) is 'install all' then all available packages will be installed."
DisplayAsHelpTitle "$(ShowAction) $(ShowPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'uninstall everything!' 'force uninstall all'
DisplayAsProjSynIndentExam 'reinstall all installed packages' 'reinstall all'
DisplayAsProjSynIndentExam "rebuild all packages with backups ('install' packages and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'upgrade all installed packages (and internal applications where-supported)' 'upgrade all'
DisplayAsProjSynIndentExam 'enable all installed packages (allow them to activate on reboot)' 'enable all'
DisplayAsProjSynIndentExam 'disable all installed packages (prevent them activating on reboot)' 'disable all'
DisplayAsProjSynIndentExam 'enable, then activate all installed packages (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'deactivate all installed packages' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'reactivate packages (this will upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam 'clear local repository files from all packages' 'clean all'
DisplayAsProjSynIndentExam 'list all available packages' 'list all'
DisplayAsProjSynIndentExam 'list only installed packages' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only packages that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only packages that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable packages' 'list upgradable'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.BackupLocation:Show()
{
DisplayAsSynExam 'the backup location can be accessed by running' "cd $QPKG_BU_PATH"
return 0
}
Help.Basic:Show()
{
DisplayAsHelpTitle "usage: sherpa $(ShowAction) $(ShowPackages) $(ShowPackageGroup) $(ShowOptions)"
return 0
}
Help.Basic.Examples:Show()
{
DisplayAsProjSynIndentExam "to list available $(ShowAction)s" 'help actions'
DisplayAsProjSynIndentExam "to list available $(ShowPackages)" 'help packages'
DisplayAsProjSynIndentExam '' p
DisplayAsProjSynIndentExam "to list available $(ShowPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL "https://github.com/OneCDOnly/sherpa/wiki")"
return 0
}
Report.Groups:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAction) all"
DisplayAsProjSynIndentExam 'select only independent packages (these do not depend on other QPKGs)' "$(ShowAction) independent"
DisplayAsProjSynIndentExam '' "$(ShowAction) independents"
DisplayAsProjSynIndentExam 'select only dependent packages (these require another QPKG to be installed and active)' "$(ShowAction) dependent"
DisplayAsProjSynIndentExam 'select only active packages' "$(ShowAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAction) started"
DisplayAsProjSynIndentExam 'select only inactive packages' "$(ShowAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAction) stopped"
DisplayAsProjSynIndentExam 'select only installed packages' "$(ShowAction) installed"
DisplayAsProjSynIndentExam 'select only packages that are not installed' "$(ShowAction) not-installed"
DisplayAsProjSynIndentExam 'select only packages that are backed-up' "$(ShowAction) backedup"
DisplayAsProjSynIndentExam 'select only packages that are not backed-up' "$(ShowAction) not-backedup"
DisplayAsProjSynIndentExam 'select only packages that are upgradable' "$(ShowAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAction) new"
DisplayAsProjSynIndentExam 'select only missing packages (these are partly installed and broken)' "$(ShowAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAction) $(ShowPackageGroup) $(ShowPackageGroup)"
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Issue:Show()
{
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub:\n\thttps://github.com/OneCDOnly/sherpa/issues."
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum:\n\thttps://forum.qnap.com/viewtopic.php?f=320&t=132373"
DisplayAsProjSynIndentExam "view only the most recent $(ShowTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowTitleName) $(TextBrightOrange 'log for analysis!')"
return 0
}
Report.Results:Show()
{
local -i datetime=0
local action=''
local package_name=''
local result=''
local -i duration=0
local reason=''
local package_type=''
local found=false
local singular='this action'
local plural='these actions'
DisplayWritingReport
{
if [[ -e $SESS_ACTIONS_RESULTS_PATHFILE ]]; then
local IFS='|'
while read -r datetime action package_name result duration reason package_type; do
if [[ $display_last_action_datetime = true ]]; then
DisplayAsHelpTitle "the following package actions were run: $(/bin/date -d @"$datetime")"
display_last_action_datetime=false
fi
if [[ $result = "$1" ]] || [[ $1 = skipped && $result = 'skipped-error' ]]; then
case $result in
ok)
[[ $found = false ]] && DisplayAsHelpTitle "$plural completed $(TextBrightGreen OK):"
;;
skipped|skipped-ok|skipped-error)
[[ $found = false ]] && DisplayAsHelpTitle "$plural were $(TextBrightOrange skipped):"
;;
failed)
[[ $found = false ]] && DisplayAsHelpTitle "$plural $(TextBrightRed failed):"
esac
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason"
found=true
fi
done < "$SESS_ACTIONS_RESULTS_PATHFILE"
fi
if [[ $found = false ]]; then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK)."
;;
skipped)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped)."
;;
failed)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
[[ -e $REPORT_OUTPUT_PATHFILE ]] && $CAT_CMD "$REPORT_OUTPUT_PATHFILE"
return 0
}
Report.Options:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowOptions) usage examples:"
DisplayAsProjSynIndentExam 'show package statuses' status
DisplayAsProjSynIndentExam '' s
DisplayAsProjSynIndentExam 'show package repositories' repos
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show live debugging information, and record it to file' "$(ShowAction) $(ShowPackages) verbose"
DisplayAsProjSynIndentExam '' v
DisplayAsProjSynIndentExam 'record debugging information to file-only' "$(ShowAction) $(ShowPackages) debug"
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Report.Problems:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'show package statuses' status
DisplayAsProjSynIndentExam '' s
DisplayAsProjSynIndentExam 'show live debugging information, and record it to file' "$(ShowAction) $(ShowPackages) verbose"
DisplayAsProjSynIndentExam '' v
DisplayAsProjSynIndentExam 'record debugging information to file-only' "$(ShowAction) $(ShowPackages) debug"
DisplayAsProjSynIndentExam 'ensure all dependencies exist for installed packages' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clear local repository files from these packages' "clean $(ShowPackages)"
DisplayAsProjSynIndentExam "remove all cached $(ShowTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'reactivate all installed packages (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'enable then activate these packages' "activate $(ShowPackages)"
DisplayAsProjSynIndentExam 'stop then disable these packages (disabling will prevent them starting on reboot)' "stop $(ShowPackages)"
DisplayAsProjSynIndentExam "view only the most recent $(ShowTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowTitleName) $(TextBrightOrange "log for analysis!")"
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Report.Tips:Show()
{
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowTitleName) packages" 'install all'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all installed packages (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only packages that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive packages' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowPackages)"
Help.BackupLocation:Show
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
return 0
}
Log.Last:View()
{
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $SESS_LAST_PATHFILE ]]; then
DisplayFileInViewport "$SESS_LAST_PATHFILE" linenumbers
else
ShowAsError 'no last session log to display'
fi
return 0
}
Log.Tail:View()
{
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]]; then
DisplayFileInViewport "$SESS_TAIL_PATHFILE" linenumbers
else
ShowAsError 'no session log tail to display'
fi
return 0
}
DisplayFileInViewport()
{
local showlinenumbers=false
local jumptoend=false
local wraplines=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local filename=${1:-}
if [[ ! -e $filename ]]; then
echo "filename '$filename' not found"
return 1
fi
case 'linenumbers' in
${2:-}|${3:-}|${4:-})
showlinenumbers=true
esac
case 'jumptoend' in
${2:-}|${3:-}|${4:-})
jumptoend=true
esac
case 'wrap' in
${2:-}|${3:-}|${4:-})
wraplines=true
esac
if [[ $opts_verbose = true ]]; then
if [[ -e $CAT_CMD ]]; then
$CAT_CMD "$filename"
return
else
echo "$(<$1)"
return
fi
fi
if [[ $($WC_CMD -l < "$filename") -ge $SESS_ROWS ]]; then
if [[ -e $GNU_LESS_CMD ]]; then
options=' --quit-on-intr --tilde --mouse --RAW-CONTROL-CHARS --shift 4 --redraw-on-quit --quit-if-one-screen'
[[ $wraplines = false ]] && options+=' --chop-long-lines'
[[ $showlinenumbers = true ]] && options+=' --LINE-NUMBERS'
[[ $jumptoend = true ]] && options+=' +G'
LESSSECURE=1 ${GNU_LESS_CMD}${options} --prompt "$prompt" "$filename"
return
fi
if [[ -e $LESS_CMD ]]; then
options=' -~'
[[ $wraplines = false ]] && options+='S'
[[ $showlinenumbers = true ]] && options+='N'
${LESS_CMD}${options} "$filename"
return
fi
fi
if [[ -e $CAT_CMD ]]; then
[[ $showlinenumbers = true ]] && options+=' --number'
${CAT_CMD}${options} "$filename"
return
elif [[ -e $MORE_CMD ]]; then
$MORE_CMD "$filename"
return
fi
echo "$(<$1)"
}
Log.Last:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $SESS_LAST_PATHFILE ]]; then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowTitleName) log to a public pastebin, or any other key to abort"; then
ShowAsProc "uploading $(ShowTitleName) log"
link=$($CAT_CMD --number "$SESS_LAST_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999; $CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]]; then
ShowAsDone "your $(ShowTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month."
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_zero_qpkgs=false
return 1
fi
else
ShowAsError 'no last session log found.'
fi
return 0
}
Log.Tail:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]]; then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowTitleName) log to a public pastebin, or any other key to abort"; then
ShowAsProc "uploading $(ShowTitleName) log"
link=$($CAT_CMD --number "$SESS_TAIL_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999; $CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]]; then
ShowAsDone "your $(ShowTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month."
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_zero_qpkgs=false
return 1
fi
else
ShowAsError 'no session log tail found.'
fi
return 0
}
GetLogSessStartLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*started:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | $HEAD_CMD -n1 | cut -d':' -f1)-1))
[[ $linenum -lt 1 ]] && linenum=1
echo $linenum
}
GetLogSessFinishLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*finished:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | cut -d':' -f1)+2))
[[ $linenum -eq 2 ]] && linenum=3
echo $linenum
}
ArchiveActiveSessLog()
{
[[ -n ${sess_active_pathfile:-} && -e $sess_active_pathfile ]] && $CAT_CMD "$sess_active_pathfile" >> "$SESS_ARCHIVE_PATHFILE"
}
ArchivePriorSessLogs()
{
local log_pathfile=''
for log_pathfile in "$THIS_PACKAGE_PATH/session."*".active.log"; do
if [[ -f $log_pathfile && $log_pathfile != "$sess_active_pathfile" ]]; then
$CAT_CMD "$log_pathfile" >> "$SESS_ARCHIVE_PATHFILE"
rm -f "$log_pathfile"
fi
done
}
ResetActiveSessLog()
{
rm -f "$sess_active_pathfile"
}
ExtractPrevSessFromTail()
{
local -i start_line=0
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]]; then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]]; do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]] && break
done
$SED_CMD "$start_line,$end_line!d" "$SESS_TAIL_PATHFILE" > "$SESS_LAST_PATHFILE"
else
rm -f "$SESS_LAST_PATHFILE"
fi
return 0
}
ExtractTailFromLog()
{
if [[ -e $SESS_ARCHIVE_PATHFILE ]]; then
$TAIL_CMD -n${LOG_TAIL_LINES} "$SESS_ARCHIVE_PATHFILE" > "$SESS_TAIL_PATHFILE"
else
rm -f "$SESS_TAIL_PATHFILE"
fi
return 0
}
Report.Versions:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: ${THIS_PACKAGE_VER:-undefined}"
Display "manager: ${THIS_SCRIPT_VER:-undefined}"
Display "loader: ${LOADER_SCRIPT_VER:-undefined}"
Display "objects: ${OBJECTS_VER:-undefined}"
Display "packages: ${PACKAGES_VER:-undefined}"
return 0
}
InitForkCounts()
{
proc_counts_path=$($MKTEMP_CMD -d /var/run/"${FUNCNAME[1]}"_XXXXXX)
[[ -n ${proc_counts_path:?undefined proc counts path} ]] || return
EraseForkCountPaths
proc_fork_count_path=$proc_counts_path/fork.count
proc_ok_count_path=$proc_counts_path/ok.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_skip_count_path=$proc_counts_path/skip.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_fail_count_path=$proc_counts_path/fail.count
mkdir -p "$proc_fork_count_path"
mkdir -p "$proc_ok_count_path"
mkdir -p "$proc_skip_ok_count_path"
mkdir -p "$proc_skip_count_path"
mkdir -p "$proc_skip_error_count_path"
mkdir -p "$proc_fail_count_path"
InitProgress
}
IncForkProgressIndex()
{
((progress_index++))
local a=$(printf '%02d' "$progress_index")
proc_fork_pathfile=$proc_fork_count_path/$a
proc_ok_pathfile=$proc_ok_count_path/$a
proc_skipok_pathfile=$proc_skip_ok_count_path/$a
proc_skip_pathfile=$proc_skip_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_fail_pathfile=$proc_fail_count_path/$a
}
RefreshForkCounts()
{
fork_count=$(ls -A -1 "$proc_fork_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
ok_count=$(ls -A -1 "$proc_ok_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_ok_count=$(ls -A -1 "$proc_skip_ok_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_count=$(ls -A -1 "$proc_skip_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_error_count=$(ls -A -1 "$proc_skip_error_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
fail_count=$(ls -A -1 "$proc_fail_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
} &>/dev/null
EraseForkCountPaths()
{
[[ -n $proc_counts_path && -d $proc_counts_path ]] && rm -r "$proc_counts_path"
} &>/dev/null
InitProgress()
{
progress_index=0
prev_clean_msg=''
RefreshForkCounts
}
UpdateForkProgress()
{
local a=''
RefreshForkCounts
[[ $opts_verbose = true ]] && return
[[ ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
a=$(PercFrac "$ok_count" "$((skip_count+skip_ok_count+skip_error_count))" "$fail_count" "$total_count")
if [[ $ok_count -gt 0 ]]; then
[[ -n $a ]] && a+=', '
a+="$(TextBrightGreen "$ok_count") OK"
fi
if [[ $skip_count -gt 0 || $skip_error_count -gt 0 ]]; then
[[ -n $a ]] && a+=', '
a+="$(TextBrightOrange "$((skip_count+skip_error_count))") skipped"
fi
if [[ $fail_count -gt 0 ]]; then
[[ -n $a ]] && a+=', '
a+="$(TextBrightRed "$fail_count") failed"
fi
if [[ $fork_count -gt 0 ]]; then
[[ -n $a ]] && a+=', '
a+="$(TextBrightYellow "$fork_count") in-progress"
fi
[[ -n $a ]] && WriteMsgInPlace "$a"
return 0
} >&2
QPKGs.Missing:Show()
{
local -a packages=()
local -i i=0
local a=''
local premsg=''
local sufmsg=''
local name_limit=2
[[ $hide_title = false ]] || return
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]]; then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for ((i=0; i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]]; then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]]; then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]]; then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]]; then
premsg=' is'
sufmsg='it'
else
premsg='s are'
sufmsg='them'
fi
ShowAsInfo "$a QPKG${premsg} missing or broken. Please reinstall $sufmsg."
return 1
}
QPKGs.NewVers:Show()
{
local -a packages=()
local -i i=0
local a=''
local name_limit=2
[[ $hide_title = false ]] || return
if [[ $(QPKGs-SCupgradable:Count) -eq 0 ]]; then
return 0
else
packages+=($(QPKGs-SCupgradable:Array))
fi
for ((i=0; i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]]; then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]]; then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]]; then
a+=' & '
fi
done
ShowAsInfo "new QPKG version$(Pluralise "${#packages[@]}") available for $a."
return 1
}
QPKGs.Conflicts:Check()
{
local package=''
if [[ -n ${BASE_QPKG_CONFLICTS_WITH:-} ]]; then
for package in "${BASE_QPKG_CONFLICTS_WITH[@]}"; do
if QPKG.IsEnabled "$package"; then
ShowAsError "the '$package' QPKG is enabled. $(ShowTitleName) is incompatible with this package. Please consider 'stop'ing this QPKG in your App Center."
return 1
fi
done
fi
return 0
}
QPKGs.Warnings:Check()
{
local package=''
if [[ -n ${BASE_QPKG_WARNINGS:-} ]]; then
for package in "${BASE_QPKG_WARNINGS[@]}"; do
if QPKG.IsEnabled "$package"; then
ShowAsWarn "the '$package' QPKG is enabled. This may cause problems with $(ShowTitleName) applications. Please consider 'stop'ing this QPKG in your App Center."
fi
done
fi
return 0
}
PIPs.Actions:List()
{
[[ $opts_debug = true ]] || return
Func:Init
local action=''
DebugInfoMinSepr
for action in "${PIP_ACTIONS[@]}"; do
PIPs-AC${action}-ok.IsAny && DebugPipInfo "AC${action}-ok" "($(PIPs-AC${action}-ok:Count)) $(PIPs-AC${action}-ok:ListCSV) "
PIPs-AC${action}-er.IsAny && DebugPipError "AC${action}-er" "($(PIPs-AC${action}-er:Count)) $(PIPs-AC${action}-er:ListCSV) "
done
DebugInfoMinSepr
Func:Exit
}
IPKs.Actions:List()
{
[[ $opts_debug = true ]] || return
Func:Init
local action=''
local border_shown=false
for action in "${IPK_ACTIONS[@]}"; do
if IPKs-AC${action}-ok.IsAny; then
if [[ $border_shown = false ]]; then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${action}-ok" "($(IPKs-AC${action}-ok:Count)) $(IPKs-AC${action}-ok:ListCSV) "
fi
if IPKs-AC${action}-er.IsAny; then
if [[ $border_shown = false ]]; then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${action}-er" "($(IPKs-AC${action}-er:Count)) $(IPKs-AC${action}-er:ListCSV) "
fi
done
[[ $border_shown = true ]] && DebugInfoMinSepr
Func:Exit
}
QPKGs.Actions:List()
{
[[ $opts_debug = true ]] || return
Func:Init
local action=''
local prefix=''
local border_shown=false
for action in "${QPKG_ACTIONS[@]}"; do
for prefix in ok er sk; do
if QPKGs-AC${action}-${prefix}.IsAny; then
if [[ $border_shown = false ]]; then
DebugInfoMinSepr
border_shown=true
fi
case $prefix in
ok)
DebugQpkg info "AC${action}-${prefix}" "($(QPKGs-AC${action}-${prefix}:Count)) $(QPKGs-AC${action}-${prefix}:ListCSV) "
;;
sk)
DebugQpkg warning "AC${action}-${prefix}" "($(QPKGs-AC${action}-${prefix}:Count)) $(QPKGs-AC${action}-${prefix}:ListCSV) "
;;
er)
DebugQpkg error "AC${action}-${prefix}" "($(QPKGs-AC${action}-${prefix}:Count)) $(QPKGs-AC${action}-${prefix}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]] && DebugInfoMinSepr
Func:Exit
}
QPKGs.Actions:ListAll()
{
Func:Init
local action=''
local prefix=''
DebugInfoMinSepr
for action in "${QPKG_ACTIONS[@]}"; do
for prefix in to ok er sk; do
if QPKGs-AC${action}-${prefix}.IsAny; then
DebugQpkg info "AC${action}=${prefix}" "($(QPKGs-AC${action}-${prefix}:Count)) $(QPKGs-AC${action}-${prefix}:ListCSV) "
fi
done
done
DebugInfoMinSepr
Func:Exit
}
QPKGs.States:List()
{
[[ $opts_debug = true ]] || return
Func:Init
local state=''
local prefix=''
QPKGs.States:Build "${1:-}"
DebugInfoMinSepr
for state in "${QPKG_IS_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}"; do
[[ $state = installed ]] && continue
if [[ $state = unknown ]]; then
QPKGs-IS${state}.IsAny && DebugQpkg warning "IS${state}" "($(QPKGs-IS${state}:Count)) $(QPKGs-IS${state}:ListCSV) "
else
QPKGs-IS${state}.IsAny && DebugQpkg info "IS${state}" "($(QPKGs-IS${state}:Count)) $(QPKGs-IS${state}:ListCSV) "
fi
done
for state in "${QPKG_ISNT_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}"; do
[[ $state = installed ]] && continue
if [[ $state = ok ]]; then
QPKGs-ISNT${state}.IsAny && DebugQpkg error "ISNT${state}" "($(QPKGs-ISNT${state}:Count)) $(QPKGs-ISNT${state}:ListCSV) "
elif [[ $state = backedup ]]; then
QPKGs-ISNT${state}.IsAny && DebugQpkg warning "ISNT${state}" "($(QPKGs-ISNT${state}:Count)) $(QPKGs-ISNT${state}:ListCSV) "
else
QPKGs-ISNT${state}.IsAny && DebugQpkg info "ISNT${state}" "($(QPKGs-ISNT${state}:Count)) $(QPKGs-ISNT${state}:ListCSV) "
fi
done
for state in "${QPKG_STATES_TRANSIENT[@]}"; do
QPKGs-IS${state}.IsAny && DebugQpkg info "IS${state}" "($(QPKGs-IS${state}:Count)) $(QPKGs-IS${state}:ListCSV) "
done
DebugInfoMinSepr
Func:Exit
}
QPKGs.IndependentDependent:Build()
{
local package=''
for package in "${QPKG_NAME[@]}"; do
if QPKG.IsDependent "$package"; then
QPKGs-SCdependent:Add "$package"
else
QPKGs-SCindependent:Add "$package"
fi
done
return 0
}
QPKGs.States:Build()
{
Func:Init
local state=''
if [[ ${1:-} = rebuild ]]; then
DebugAsProc 'clearing existing state lists'
for state in "${USER_QPKG_IS_STATES[@]}" "${QPKG_STATES_TRANSIENT[@]}"; do
[[ $state = active ]] && continue
QPKGs-IS${state}:Init
done
for state in "${USER_QPKG_ISNT_STATES[@]}"; do
[[ $state = active ]] && continue
QPKGs-ISNT${state}:Init
done
DebugAsDone 'cleared existing state lists'
qpkgs_states_built=false
fi
if [[ ${qpkgs_states_built:=false} = true ]]; then
DebugAsDone "don't need to build states: already built"
Func:Exit; return
fi
local package=''
local prev=''
OS.IsStarting && ShowAsWarn "$(GetQnapOS) is starting QPKGs ... check again in a few minutes."
OS.IsStopping && ShowAsWarn "$(GetQnapOS) is shutting-down and all QPKGs are stopping."
ShowAsProc 'QPKG states'
for package in $(QPKGs-SCall:Array); do
[[ $package = "$prev" ]] && continue || prev=$package
if QPKG.IsInstalled "$package"; then
QPKGs-ISinstalled:Add "$package"
if QPKG.IsMissing "$package"; then
QPKGs-ISmissing:Add "$package"
QPKGs-ISNTok:Add "$package"
continue
fi
if QPKG.IsUpgradable "$package"; then
QPKGs-SCupgradable:Add "$package"
else
QPKGs-SCNTupgradable:Add "$package"
fi
if QPKG.IsEnabled "$package"; then
QPKGs-ISenabled:Add "$package"
else
QPKGs-ISNTenabled:Add "$package"
fi
if [[ -e /var/run/$package.last.operation ]]; then
case $(</var/run/$package.last.operation) in
start)
QPKGs-ISstarting:Add "$package"
;;
restart)
QPKGs-ISrestarting:Add "$package"
;;
stop)
QPKGs-ISstopping:Add "$package"
;;
failed)
QPKGs-ISNTok:Add "$package"
;;
ok)
QPKGs-ISok:Add "$package"
esac
fi
else
QPKGs-ISNTinstalled:Add "$package"
QPKG.IsInstallable "$package" && QPKGs-SCinstallable:Add "$package"
fi
if QPKG.IsCanBackup "$package"; then
if QPKG.IsBackupExist "$package"; then
QPKGs-ISbackedup:Add "$package"
else
QPKGs-ISNTbackedup:Add "$package"
fi
fi
done
qpkgs_states_built=true
if [[ ${1:-} != rebuild ]]; then
QPKGs.Missing:Show
QPKGs.NewVers:Show
fi
Func:Exit
}
QPKGs.IsCanBackup:Build()
{
Func:Init
local package=''
for package in $(QPKGs-SCall:Array); do
QPKG.IsCanBackup "$package" && QPKGs-SCcanbackup:Add "$package"
done
Func:Exit
}
QPKGs.IsCanRestartToUpdate:Build()
{
Func:Init
local package=''
for package in $(QPKGs-SCall:Array); do
QPKG.IsCanRestartToUpdate "$package" && QPKGs-SCcanrestarttoupdate:Add "$package"
done
Func:Exit
}
QPKGs.IsCanClean:Build()
{
Func:Init
local package=''
for package in $(QPKGs-SCall:Array); do
QPKG.IsCanClean "$package" && QPKGs-SCcanclean:Add "$package"
done
Func:Exit
}
QPKGs.IsTimeoutsIncreased()
{
[[ -e /usr/local/sbin/qpkg_service.orig ]]
}
Report.Abbreviations:Show()
{
Func:Init
local a=''
local -i n=0
maxcols=2
local -i t=$(QPKGs-SCall:Count)
DisplayWritingReport
DisableDebugToArchiveAndFile
[[ -n $REPORTS_PATH && -d $REPORTS_PATH ]] && rm -f "$REPORTS_PATH/*"
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowTitleName) can recognise various abbreviations and aliases as $(ShowPackages)."
DisplayAsAbsReportTitleLine
} >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-SCall:Array); do
((n++))
DisplayAsAbsReportLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1; n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && ac+="$(<$f)\n"
done
[[ -n $ac ]] && echo -e "$ac" >>"$REPORT_OUTPUT_PATHFILE"
{
DisplayAsProjSynExam "example: to install $(ShowAsPackageName SABnzbd), $(ShowAsPackageName Mylar3) and $(ShowAsPackageName nzbToMedia) all-at-once" 'install sab my nzb2'
Display
} >> "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Backups:Show()
{
Func:Init
local epochtime=0
local filename=''
local highlight_older_than='2 weeks ago'
local format=''
DisableDebugToArchiveAndFile
DisplayWritingReport
{
DisplayAsHelpTitle "the location for $(ShowTitleName) backups is: $QPKG_BU_PATH"
if [[ -e $GNU_FIND_CMD ]]; then
DisplayAsHelpTitle "backups are listed oldest-first, and those shown in $(TextBrightRed '! red') were last updated more than $highlight_older_than."
DisplayAsHelpTitleFileNamePlusSomething 'backup file' 'last backup date'
while read -r epochtime filename; do
[[ -z $epochtime || -z $filename ]] && break
if [[ ${epochtime%.*} -lt $(/bin/date --date="$highlight_older_than" +%s) ]]; then
format=$(TextBrightRed "%${HELP_DESC_INDENT}s%-${FILE_NAME_COL_WIDTH}s - !%s\n")
else
format="%${HELP_DESC_INDENT}s%-${FILE_NAME_COL_WIDTH}s - %s\n"
fi
printf "$format" '' "$filename" "$(/bin/date -d @"$epochtime" +%c)"
done <<< "$($GNU_FIND_CMD "$QPKG_BU_PATH"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f\n' 2>/dev/null | $SORT_CMD)"
else
DisplayAsHelpTitle 'backups are listed oldest-first.'
Display
(cd "$QPKG_BU_PATH" && ls -1 ./*.config.tar.gz 2>/dev/null)
fi
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
[[ -e $REPORT_OUTPUT_PATHFILE ]] && $CAT_CMD "$REPORT_OUTPUT_PATHFILE"
Func:Exit
}
Report.Dependencies:Show()
{
Func:Init
local a=''
local -i n=0
maxcols=8
local -i t=$(QPKGs-SCall:Count)
DisplayWritingReport
DisableDebugToArchiveAndFile
[[ -n $REPORTS_PATH && -d $REPORTS_PATH ]] && rm -f "$REPORTS_PATH/*"
{
DisplayAsHelpTitle "$(ShowTitleName) will automatically install/start/stop/restart package dependencies as-required."
DisplayAsHelpTitle "requirements shown in \"$(TextBrightOrange '* orange')\" prevent the package being installed."
DisplayAsHelpTitle "those shown in \"$(TextBrightRed '! red')\" are preventing the package from working correctly."
DisplayAsDepsReportTitleLine
} >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-SCall:Array); do
((n++))
DisplayAsDepsReportLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1; n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && ac+="$(<$f)\n"
done
[[ -n $ac ]] && echo -e "$ac" >>"$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Packages:Show()
{
Func:Init
local name=''
maxcols=3
DisableDebugToArchiveAndFile
DisplayWritingReport
{
Help.Basic:Show
DisplayAsHelpTitle "one-or-more $(ShowPackages) may be specified at-once."
DisplayAsPackagesReportTitleLine
for name in $(QPKGs-SCall:Array); do
DisplayAsPackagesReportLine "$name"
done
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
Display
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
Func:Exit
}
Report.Repos:Show()
{
Func:Init
local a=''
local -i n=0
maxcols=3
local -i t=$(QPKGs-SCall:Count)
DisplayWritingReport
DisableDebugToArchiveAndFile
[[ -n $REPORTS_PATH && -d $REPORTS_PATH ]] && rm -f "$REPORTS_PATH/*"
DisplayAsReposReportTitleLine >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-SCall:Array); do
((n++))
DisplayAsReposReportLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1; n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && ac+="$(<$f)\n"
done
[[ -n $ac ]] && echo -e "$ac" >>"$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Statuses:Show()
{
Func:Init
local a=''
local ac=''
local f=''
local -i n=0
local -i m=0
maxcols=5
local -i t=$(QPKGs-SCall:Count)
DisplayWritingReport
[[ -n $REPORTS_PATH && -d $REPORTS_PATH ]] && rm -f "$REPORTS_PATH/*"
CalcMaxStatusReportCols
DisplayAsStatusReportTitleLine >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-SCall:Array); do
((n++))
DisplayAsStatusReportLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1; n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && ac+="$(<$f)\n"
done
[[ -n $ac ]] && echo -e "$ac" >>"$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if QPKGs-ISslow.IsAny; then
{
DisplayAsHelpTitle "statuses shown as '$(TextBrightOrange slow)' are usually because the application has been page-swapped to disk and must be reloaded into RAM to respond to a status request. Requesting the QPKG status again shortly afterward should return a useful status result."
} >>"$REPORT_OUTPUT_PATHFILE"
fi
if [[ -e $REPORT_OUTPUT_PATHFILE ]]; then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
QPKGs.IsBackedUp:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISbackedup:Array); do
Display "$package"
done
return 0
}
QPKGs.IsNtBackedUp:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISNTbackedup:Array); do
Display "$package"
done
return 0
}
QPKGs.IsInstalled:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISinstalled:Array); do
Display "$package"
done
return 0
}
QPKGs.ScAll:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-SCall:Array); do
Display "$package"
done
return 0
}
QPKGs.ScInstallable:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-SCinstallable:Array); do
Display "$package"
done
return 0
}
QPKGs.IsNtInstalled:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISNTinstalled:Array); do
Display "$package"
done
return 0
}
QPKGs.IsActive:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISactive:Array); do
Display "$package"
done
return 0
}
QPKGs.IsNtActive:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-ISNTactive:Array); do
Display "$package"
done
return 0
}
QPKGs.ScUpgradable:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-SCupgradable:Array); do
Display "$package"
done
return 0
}
QPKGs.ScIndependent:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-SCindependent:Array); do
Display "$package"
done
return 0
}
QPKGs.ScDependent:Show()
{
local package=''
DisableDebugToArchiveAndFile
EraseThisLine
for package in $(QPKGs-SCdependent:Array); do
Display "$package"
done
return 0
}
SendParentChangeEnv()
{
WriteMsgToActionPipe env "$1" '' ''
}
SendPackageStateChange()
{
WriteMsgToActionPipe change "$1" package "$PACKAGE_NAME"
}
SendActionStatus()
{
WriteMsgToActionPipe status "$1" package "$PACKAGE_NAME"
}
WriteMsgToActionPipe()
{
[[ $action_msg_pipe_fd != none && -e /proc/$$/fd/$action_msg_pipe_fd ]] && echo "$1|$2|$3|$4" >&$action_msg_pipe_fd
return 0
}
ReadMsgFromActionPipe()
{
local _msg1_key
local _msg1_value
local _msg2_key
local _msg2_value
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value <&$action_msg_pipe_fd
eval "$1='$_msg1_key' $2='$_msg1_value' $3='$_msg2_key' $4='$_msg2_value'"
return 0
}
FindNextFD()
{
local -i fd=-1
for fd in {10..100}; do
if [[ ! -e /proc/$$/fd/$fd ]]; then
echo "$fd"
return 0
fi
done
return 1
}
MarkThisActionForkAsStarted()
{
[[ -n $proc_fork_pathfile ]] && $TOUCH_CMD "$proc_fork_pathfile"
}
MarkThisActionForkAsOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_ok_pathfile"
SendActionStatus ok
}
MarkThisActionForkAsSkippedOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skipok_pathfile"
SendActionStatus so
}
MarkThisActionForkAsSkipped()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_pathfile"
SendActionStatus sk
}
MarkThisActionForkAsSkippedError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_error_pathfile"
SendActionStatus se
}
MarkThisActionForkAsFailed()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_fail_pathfile"
SendActionStatus er
}
NoteIpkAcAsOk()
{
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-ok:Add "$1"
return 0
}
NoteIpkAcAsEr()
{
local msg="failing request to $2 $(ShowAsPackageName "$1")"
[[ -n ${3:-} ]] && msg+=" as $3"
DebugAsError "$msg" >&2
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-er:Add "$1"
return 0
}
ModPathToEntware()
{
local -r OPKG=/opt/bin:/opt/sbin
local temp=''
if QPKGs-ISenabled.Exist Entware; then
! [[ $PATH =~ $OPKG ]] || return
temp=$($SED_CMD "s|$OPKG:||" <<< "$PATH:")
export PATH=$OPKG:${temp%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $OPKG ]] || return
temp=$($SED_CMD "s|$OPKG:||" <<< "$PATH:")
export PATH=${temp%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0
}
GetCPUInfo()
{
if $GREP_CMD -q '^model name' /proc/cpuinfo; then
$GREP_CMD '^model name' /proc/cpuinfo | $HEAD_CMD -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
elif $GREP_CMD -q '^Processor name' /proc/cpuinfo; then
$GREP_CMD '^Processor name' /proc/cpuinfo | $HEAD_CMD -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
else
echo unknown
return 1
fi
return 0
}
GetArch()
{
$UNAME_CMD -m
}
GetKernelVersion()
{
$UNAME_CMD -r
}
GetKernelPageSize()
{
$GREP_CMD KernelPageSize /proc/1/smaps | $HEAD_CMD -n1 | cut -f2 -d':' | tr -d ' '
}
GetPlatform()
{
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf
}
GetDefVol()
{
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info
}
GetPython3Ver()
{
GetPythonVer "${1:-python3}"
}
GetPythonVer()
{
GetThisBinPath ${1:-python} &>/dev/null && ${1:-python} -V 2>&1 | $SED_CMD 's|^Python ||'
}
GetPerlVer()
{
GetThisBinPath ${1:-perl} &>/dev/null && ${1:-perl} -e 'print "$^V\n"' 2>/dev/null | $SED_CMD 's|v||'
}
GetThisBinPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] && command -v "$1" 2>&1
}
GetRepoURLFromStoreID()
{
[[ -n ${1:-} ]] || return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf
}
GetUptime()
{
raw=$(</proc/uptime)
FormatSecsToHoursMinutesSecs "${raw%%.*}"
}
GetTimeInShell()
{
local duration=0
if [[ -n ${LOADER_SCRIPT_PPID:-} ]]; then
duration=$($PS_CMD -o pid,etime | $GREP_CMD $LOADER_SCRIPT_PPID | $HEAD_CMD -n1)
fi
FormatLongMinutesSecs "${duration:6}"
}
GetSysLoadAverages()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print "1m:"$1", 5m:"$2", 15m:"$3}'
}
GetCPUCores()
{
local num=$($GREP_CMD -c '^processor' /proc/cpuinfo)
[[ $num -eq 0 ]] && num=$($GREP_CMD -c '^Processor' /proc/cpuinfo)
echo "$num"
}
GetInstalledRAM()
{
$GREP_CMD MemTotal /proc/meminfo | $SED_CMD 's|.*: ||;s|kB||;s| ||g'
}
GetFirmwareVer()
{
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf
}
GetFirmwareBuild()
{
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf
}
GetFirmwareDate()
{
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf
}
GetQnapOS()
{
if $GREP_CMD -q zfs /proc/filesystems; then
echo 'QuTS hero'
else
echo QTS
fi
}
GetQpkgArch()
{
case $NAS_ARCH in
x86_64)
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]] && echo i64 || echo i86
;;
i686|x86)
echo i86
;;
armv5tel)
echo a19
;;
armv7l)
case $NAS_PLATFORM in
ARM_MS)
echo a31
;;
ARM_AL)
echo a41
;;
*)
echo none
esac
;;
aarch64)
echo a64
;;
*)
echo none
esac
}
GetEntwareType()
{
if QPKG.IsInstalled Entware; then
if [[ -e /opt/etc/passwd ]]; then
if [[ -L /opt/etc/passwd ]]; then
echo std
else
echo alt
fi
else
echo none
fi
else
echo 'not-installed'
fi
} 2>/dev/null
GetSudoUID()
{
echo "${SUDO_UID:-undefined}"
}
GetUpState()
{
if OS.IsStarting; then
echo -n 'starting-up'
elif OS.IsStopping; then
echo -n 'shutting-down'
else
echo -n stable
fi
}
GetTimezone()
{
/bin/date +%z
}
OS.IsOk()
{
if ! OS.IsQNAP; then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0
}
OS.IsQNAP()
{
[[ -e /etc/init.d/functions ]]
}
OS.IsCompatibleWithSigned()
{
[[ $NAS_FIRMWARE_DATE -lt 20201015 || $NAS_FIRMWARE_DATE -gt 20201020 ]]
}
OS.IsSupported()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 400 ]]
}
OS.IsSupportSecureDownload()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 426 ]]
}
OS.IsSupportQpkgTimeout()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]]
}
OS.IsSupportSignedPackages()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 435 ]]
}
OS.IsSupportSudo()
{
[[ -e /usr/bin/sudo ]]
}
OS.IsAllowUnsignedPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert) = TRUE ]]
}
OS.IsStarting()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcS' | $GREP_CMD -v grep
} &>/dev/null
OS.IsStopping()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcK' | $GREP_CMD -v grep
} &>/dev/null
OS.IsStdKernelPageSize()
{
[[ ${KERNEL_PAGE_SIZE:=$(GetKernelPageSize)} = 4kB ]]
}
OS.IsNonStdKernelPageSize()
{
! OS.IsStdKernelPageSize
}
Self.Error:Set()
{
skip_package_actions=true
Self.Error.IsSet && return
_script_error_flag_=true
DebugVar _script_error_flag_
}
Self.Error.IsSet()
{
[[ ${_script_error_flag_:=false} = true ]]
}
Self.Error.IsNt()
{
[[ ${_script_error_flag_:=false} != true ]]
}
ShowZeroQpkgs()
{
local state=''
local action=''
for state in "${USER_QPKG_IS_STATES[@]}"; do
for action in "${USER_QPKG_ACTIONS[@]}"; do
[[ $action = list ]] && continue
QPKGs.AC${action}.IS${state}.IsSet && QPKGs-AC${action}-ok.IsNone && ShowAsWarn "no QPKGs were able to $(Lowercase "$action")"
done
done
return 0
}
Self.LockFile:Claim()
{
readonly LOCK_PATHFILE=/var/run/sherpa.lock
local a=''
for a in sherpa-manager.sh sherpa-manager.source; do
if [[ -e $LOCK_PATHFILE && -d /proc/$(<"$LOCK_PATHFILE") && $(</proc/"$(<"$LOCK_PATHFILE")"/cmdline) =~ $a ]]; then
ShowAsAbort "another sherpa instance was found (PID:$(<"$LOCK_PATHFILE")), can't continue."
return 1
fi
done
echo "$$" > "$LOCK_PATHFILE"
return 0
}
Self.LockFile:Release()
{
rm -f "$LOCK_PATHFILE"
}
Self.Verbose:Enable()
{
opts_verbose=true
DebugVar opts_verbose
Keystrokes:Show
Cursor:Show
}
EnableDebugToArchiveAndFile()
{
opts_debug=true
DebugVar opts_debug
self_archive_debug_afterward=true
DebugVar self_archive_debug_afterward
}
DisableDebugToArchiveAndFile()
{
opts_debug=false
self_archive_debug_afterward=false
}
SaveActionResultToLog()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
local -r PACKAGE_TYPE=${1:?${FUNCNAME[0]}'()': undefined}
local -r PACKAGE_NAME=${2:?${FUNCNAME[0]}'()': undefined}
local -r ACTION=${3:?${FUNCNAME[0]}'()': undefined}
local -r CLEAN_ACTION=${ACTION//\"/}
local -r RESULT=${4:?${FUNCNAME[0]}'()': undefined}
local -r REASON=${5:-}
local -r DURATION=$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")
local -r ACTION_TIMES_PATHFILE=$ACTION_TIMES_PATH/$CLEAN_ACTION.milliseconds
if [[ $2 = undefined ]]; then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
echo "$(/bin/date +%s)|$ACTION|$PACKAGE_NAME|$RESULT|$DURATION|$REASON|$PACKAGE_TYPE" >> "$SESS_ACTIONS_RESULTS_PATHFILE"
if [[ -e $ACTION_TIMES_PATHFILE ]] && $GREP_CMD -q "^$PACKAGE_NAME|" < "$ACTION_TIMES_PATHFILE"; then
$SED_CMD -i "/^$PACKAGE_NAME|/d" "$ACTION_TIMES_PATHFILE"
fi
echo "$PACKAGE_NAME|$DURATION" >> "$ACTION_TIMES_PATHFILE"
case $4 in
ok|skipped-ok)
DebugAsInfo "$REASON"
;;
skipped)
DebugAsWarn "$REASON"
;;
failed|skipped-error)
DebugAsError "$REASON"
esac
return 0
}
_QPKG:reassign_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign skipped 'not installed'
z=2
elif [[ $(QPKG.GetStoreID "$PACKAGE_NAME") = sherpa ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign skipped 'already assigned to sherpa'
z=2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "reassigning $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/setcfg -e $PACKAGE_NAME store -f /etc/config/qpkg.conf" "$LOGS_PATH/$PACKAGE_NAME.$REASSIGN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign failed "$z"
z=1
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:download_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local -r REMOTE_URL=$(QPKG.GetURL "$PACKAGE_NAME")
local -r REMOTE_FILENAME=$($BASENAME_CMD "$REMOTE_URL")
local -r REMOTE_HASH=$(QPKG.GetHash "$PACKAGE_NAME")
local -r LOCAL_PATHFILE=$QPKG_DL_PATH/$REMOTE_FILENAME
local -r LOCAL_FILENAME=$($BASENAME_CMD "$LOCAL_PATHFILE")
local -r LOG_PATHFILE=$LOGS_PATH/$LOCAL_FILENAME.$DOWNLOAD_LOG_FILE
local -i z=0
if [[ -z $REMOTE_URL || -z $REMOTE_HASH ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" download skipped 'NAS arch is incompatible'
MarkThisActionForkAsSkipped
z=2
elif [[ -f $LOCAL_PATHFILE ]]; then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" download skipped-ok "existing file $(ShowAsFileName "$LOCAL_FILENAME") checksum correct"
MarkThisActionForkAsSkippedOk
FuncFork:Exit 0
else
DebugInfo "deleting $(ShowAsFileName "$LOCAL_FILENAME") as checksum is incorrect"
rm -f "$LOCAL_PATHFILE"
fi
fi
if [[ $z -gt 0 ]]; then
FuncFork:Exit $z
fi
if [[ ! -f $LOCAL_PATHFILE ]]; then
DebugAsProc "downloading $(ShowAsFileName "$REMOTE_FILENAME")"
rm -f "$LOG_PATHFILE"
RunAndLog "$CURL_CMD${curl_insecure_arg} --location --output $LOCAL_PATHFILE $REMOTE_URL" "$LOG_PATHFILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH"; then
[[ $(Lowercase "${LOCAL_PATHFILE##*.}") = zip ]] && $UNZIP_CMD -nq "$LOCAL_PATHFILE" -d "$QPKG_DL_PATH"
SaveActionResultToLog QPKG "$PACKAGE_NAME" download ok
SendPackageStateChange ISdownloaded
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" download failed "downloaded file $(ShowAsFileName "$LOCAL_FILENAME") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
z=1
MarkThisActionForkAsFailed
fi
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" download failed "$z"
z=1
MarkThisActionForkAsFailed
fi
fi
FuncFork:Exit $z
}
_QPKG:install_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'already installed'
z=2
elif ! QPKG.IsArchOK "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'NAS arch is incompatible'
z=2
elif ! QPKG.IsMinOSVerOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped "$(GetQnapOS) version is incompatible"
z=2
elif ! QPKG.IsMinRAMOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'NAS has insufficient RAM'
z=2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped-error 'no local file found for processing: please report this issue'
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $PACKAGE_NAME = Entware ]] && ! QPKGs-ISinstalled.Exist Entware && QPKGs-ACinstall-to.Exist Entware; then
local -r OPT_PATH=/opt
local -r OPT_BU_PATH=/opt.orig
if [[ -d $OPT_PATH && ! -L $OPT_PATH && ! -e $OPT_BU_PATH ]]; then
DebugAsProc 'backup original /opt'
mv "$OPT_PATH" "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
local target_path=''
DebugAsProc "installing $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
[[ ${QPKGs_were_installed_name[*]:-} = *"$PACKAGE_NAME"* ]] && target_path="QINSTALL_PATH=$(QPKG.GetOriginalPath "$PACKAGE_NAME") "
RunAndLog "${b}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$INSTALL_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]]; then
QPKG.ServiceStatus:Log
SendPackageStateChange ISinstalled
if QPKG.IsEnabled "$PACKAGE_NAME"; then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$PACKAGE_NAME" install ok "version $(QPKG.Local.GetVer "$PACKAGE_NAME")"
if [[ $PACKAGE_NAME = Entware ]]; then
SendParentChangeEnv ModPathToEntware
PatchEntwareService
if [[ -L ${OPT_PATH:-} && -d ${OPT_BU_PATH:-} ]]; then
DebugAsProc 'restoring original /opt'
mv "$OPT_BU_PATH"/* "$OPT_PATH" && rm -rf "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
SendParentChangeEnv "QPKGs-ACsign-to:Add $PACKAGE_NAME"
z=0
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" install failed "$z"
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:reinstall_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped "not installed, please use 'install' instead."
MarkThisActionForkAsSkipped
FuncFork:Exit 2
fi
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped-error 'no local file found for processing, please report this issue.'
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
local target_path=''
DebugAsProc "reinstalling $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
QPKG.IsInstalled "$PACKAGE_NAME" && target_path="QINSTALL_PATH=$($DIRNAME_CMD "$(QPKG.GetInstallationPath $PACKAGE_NAME)") "
RunAndLog "${b}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$REINSTALL_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]]; then
QPKG.ServiceStatus:Log
if QPKG.IsEnabled "$PACKAGE_NAME"; then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall ok "version $current_ver"
z=0
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall failed "$z"
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:upgrade_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped 'not installed'
z=2
elif ! QPKGs-SCupgradable.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped 'no new package is available'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped-error 'no local file found for processing, please report this issue'
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
local prev_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
local target_path=''
DebugAsProc "upgrading $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
QPKG.IsInstalled "$PACKAGE_NAME" && target_path="QINSTALL_PATH=$($DIRNAME_CMD "$(QPKG.GetInstallationPath "$PACKAGE_NAME")") "
RunAndLog "${b}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$UPGRADE_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]]; then
QPKG.ServiceStatus:Log
SendPackageStateChange SCNTupgradable
if QPKG.IsEnabled "$PACKAGE_NAME"; then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
if [[ $current_ver = "$prev_ver" ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade ok "version $current_ver"
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade ok "upgraded from version $prev_ver to version $current_ver"
fi
z=0
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade failed "$z"
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:uninstall_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped 'not installed'
z=2
elif [[ $PACKAGE_NAME = sherpa ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped "it's needed here! 😉"
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
local -r QPKG_UNINSTALLER_PATHFILE=$(QPKG.GetInstallationPath "$PACKAGE_NAME")/.uninstall.sh
[[ $PACKAGE_NAME = Entware ]] && SaveEntwarePackageList
if [[ -e $QPKG_UNINSTALLER_PATHFILE ]]; then
DebugAsProc "uninstalling $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
RunAndLog "${b}${SH_CMD} $QPKG_UNINSTALLER_PATHFILE" "$LOGS_PATH/$PACKAGE_NAME.$UNINSTALL_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
[[ -e /sbin/qpkg_cli ]] && ! QPKGs-ACinstall-to.Exist "$PACKAGE_NAME" && /sbin/qpkg_cli --remove "$PACKAGE_NAME" &>/dev/null
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall ok
/sbin/rmcfg "$PACKAGE_NAME" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $PACKAGE_NAME = Entware ]]; then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISNTinstalled
SendPackageStateChange ISNTactive
SendPackageStateChange ISNTenabled
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall failed "$z"
z=1
MarkThisActionForkAsFailed
fi
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall failed '.uninstall.sh script is missing'
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:activate_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped 'not installed'
MarkThisActionForkAsSkipped
FuncFork:Exit 2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$ACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_START_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "activating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped "service script file undefined"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
elif [[ $opts_debug = true ]]; then
b='DEBUG_QPKG=true '
RunAndLog "${b}${service_pathfile} start" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog; then
RunAndLog "/sbin/qpkg_service${timeout} start $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile start" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate ok
if [[ $PACKAGE_NAME = Entware ]]; then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISactive
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate failed "$z"
SendPackageStateChange ISNTactive
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:reactivate_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped 'not installed'
MarkThisActionForkAsSkipped
FuncFork:Exit 2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$REACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_RESTART_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "reactivating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped "service script file undefined"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
elif [[ $opts_debug = true ]]; then
b='DEBUG_QPKG=true '
RunAndLog "${b}${service_pathfile} restart" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog; then
RunAndLog "/sbin/qpkg_service${timeout} restart $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile restart" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate failed "$z"
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:deactivate_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped 'not installed'
z=2
elif [[ $PACKAGE_NAME = sherpa ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped "it's needed here! 😉"
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$DEACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_STOP_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "deactivating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped "service script file undefined"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
elif [[ $opts_debug = true ]]; then
b='DEBUG_QPKG=true '
RunAndLog "${b}${service_pathfile} stop" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog; then
RunAndLog "/sbin/qpkg_service${timeout} stop $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile stop" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate ok
if [[ $PACKAGE_NAME = Entware ]]; then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISNTactive
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate failed "$z"
z=1
MarkThisActionForkAsFailed
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:enable_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped 'not installed'
z=2
elif QPKGs-ISenabled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped 'already enabled'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$ENABLE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_ENABLE_TIMEOUT_SECONDS"
DebugAsProc "enabling $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/qpkg_service${timeout} enable $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.IsEnabled "$PACKAGE_NAME" && SendPackageStateChange ISenabled
QPKG.AppCenterNotifier:Clear
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable ok
MarkThisActionForkAsOk
FuncFork:Exit $z
}
_QPKG:disable_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped 'not installed'
z=2
elif QPKGs-ISNTenabled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped 'already disabled'
z=2
elif [[ $PACKAGE_NAME = sherpa ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped "it's needed here! 😉"
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$DISABLE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_DISABLE_TIMEOUT_SECONDS"
DebugAsProc "disabling $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/qpkg_service${timeout} disable $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
! QPKG.IsEnabled "$PACKAGE_NAME" && SendPackageStateChange ISNTenabled
QPKG.AppCenterNotifier:Clear
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable ok
MarkThisActionForkAsOk
FuncFork:Exit $z
}
_QPKG:backup_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped 'not installed'
z=2
elif ! QPKG.IsCanBackup; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped 'does not support backup'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "backing-up $(ShowAsPackageName "$PACKAGE_NAME") configuration"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
RunAndLog "${b}$(QPKG.GetServicePathFile) backup" "$LOGS_PATH/$PACKAGE_NAME.$BACKUP_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup ok
SendPackageStateChange ISbackedup
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup failed "$z"
z=1
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:restore_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped 'not installed'
z=2
elif ! QPKG.IsCanBackup; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped 'does not support restore'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "restoring $(ShowAsPackageName "$PACKAGE_NAME") configuration"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
RunAndLog "${b}$(QPKG.GetServicePathFile) restore" "$LOGS_PATH/$PACKAGE_NAME.$RESTORE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore ok
SendPackageStateChange ISrestored
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore failed "$z"
z=1
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:clean_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local b=''
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped 'not installed'
z=2
elif ! QPKG.IsCanClean; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped 'does not support cleaning'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "cleaning $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
RunAndLog "${b}$(QPKG.GetServicePathFile) clean" "$LOGS_PATH/$PACKAGE_NAME.$CLEAN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]]; then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean failed "$z"
z=1
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:sign_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local -r PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local cert=''
local cmd=''
local signature=''
local -i z=0
DebugVar SQLITE_CMD
if ! OS.IsSupportSignedPackages; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'not required: firmware < 4.3.5'
z=2
elif ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'not installed'
z=2
elif [[ ! -e $SQLITE_CMD ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'sqlite3 unavailable'
z=2
elif [[ ! -e $CERT_DB_PATHFILE ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'certificate database not found'
z=2
fi
if ! QPKG.IsRepoOk "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped "assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkippedError
FuncFork:Exit 2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "\"signing\" $(ShowAsPackageName "$PACKAGE_NAME")"
read -r -d '' cert << EOB
-----BEGIN CERTIFICATE-----
MIIDwzCCAqugAwIBAgIFALhDVuwwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYT
AlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwE
UU5BUDEMMAoGA1UECwwDTkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcN
AQkBFhFzZWN1cml0eUBxbmFwLmNvbTAeFw0yMjAzMTgwNzM5MTRaFw0yNTAzMTcw
NzM5MTRaMIGGMQswCQYDVQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQH
DAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsMA05BUzEWMBQGA1UEAwwN
TGljZW5zZUNlbnRlcjEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20w
ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC/bAgbZryVvBXfpBHNUKQV
sAkAfvDXjKnxa7lKHrRIcFcOnf+voUZcP1Ly9qWb782gB2eUHsUS1Xqj4CF/dUJf
FEnOBrQUo9+Q9B3x4oTRpMdky7acP4dxAbt4T92swgaReQXAewy9s9//a52HIBca
1dAA4JPwplqiZ/oh18GDCKxh84Iu9Gcu2J5e+VXEI/KUxCwKUd22aDTpv128MSoq
dYexCerCJtQbgM3cwkkMiDnFpjrsta5iFpyrNKdLoBJ7YbY3d5Onkqy4DjE8hwR7
0j7Qd+3xbMqv3FOCKeLLLn6N03IXHKP/big/MdXKY1dJQVA3/ks/knPH8mhcOM0d
AgMBAAGjPDA6MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFw
LmNvbS9jcmwvcXRzX3YxLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAWlT1GDH6v8G3
laIAs2/RdxhPgtKX4aL+fnTEFNF5V2yH0G4luyq5tHQw+VCHtDM6Z3GXWhciKPAR
upbRcHq744JCFaUb6i8z1w1KVJDaQ38EVE5+JtpoPMrrnb+hKB/gGmi4PoMSpnvX
VCxLbCbBnwi19o6t/MnPbz0shvUB2NDngnal6lYQFw/F8Sr6cSjV6GAY4TOZotdu
+gunwqQtYUycEVfNyiWVk/flgED8R8oxTPl9ZoDGen+OgjkZrvgynKnqPLHyxZSd
hYSoWyWcZWkMCQ+69kOgJVvrRa7z9F9y30uAHXIUrsLV2d/dImVjApMHbZ60iALG
AVIlas0e4g==
-----END CERTIFICATE-----
EOB
read -r -d '' signature << EOB
MIME-Version: 1.0
Content-Disposition: attachment; filename="smime.p7m"
Content-Type: application/pkcs7-mime; smime-type=signed-data; name="smime.p7m"
Content-Transfer-Encoding: base64

MIIGtAYJKoZIhvcNAQcCoIIGpTCCBqECAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFAkoseBaFir08zCz63r2YA82DXzxoIIDxzCCA8MwggKroAMCAQIC
BQC4Q1bsMA0GCSqGSIb3DQEBCwUAMIGAMQswCQYDVQQGEwJUVzEPMA0GA1UECAwG
VGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsM
A05BUzEQMA4GA1UEAwwHUU5BUF9DQTEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlA
cW5hcC5jb20wHhcNMjIwMzE4MDczOTE0WhcNMjUwMzE3MDczOTE0WjCBhjELMAkG
A1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYD
VQQKDARRTkFQMQwwCgYDVQQLDANOQVMxFjAUBgNVBAMMDUxpY2Vuc2VDZW50ZXIx
IDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tMIIBIjANBgkqhkiG9w0B
AQEFAAOCAQ8AMIIBCgKCAQEAv2wIG2a8lbwV36QRzVCkFbAJAH7w14yp8Wu5Sh60
SHBXDp3/r6FGXD9S8valm+/NoAdnlB7FEtV6o+Ahf3VCXxRJzga0FKPfkPQd8eKE
0aTHZMu2nD+HcQG7eE/drMIGkXkFwHsMvbPf/2udhyAXGtXQAOCT8KZaomf6IdfB
gwisYfOCLvRnLtieXvlVxCPylMQsClHdtmg06b9dvDEqKnWHsQnqwibUG4DN3MJJ
DIg5xaY67LWuYhacqzSnS6ASe2G2N3eTp5KsuA4xPIcEe9I+0Hft8WzKr9xTgini
yy5+jdNyFxyj/24oPzHVymNXSUFQN/5LP5Jzx/JoXDjNHQIDAQABozwwOjA4BgNV
HR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5hcC5jb20vY3JsL3F0c192
MS5jcmwwDQYJKoZIhvcNAQELBQADggEBAFpU9Rgx+r/Bt5WiALNv0XcYT4LSl+Gi
/n50xBTReVdsh9BuJbsqubR0MPlQh7QzOmdxl1oXIijwEbqW0XB6u+OCQhWlG+ov
M9cNSlSQ2kN/BFROfibaaDzK652/oSgf4BpouD6DEqZ711QsS2wmwZ8ItfaOrfzJ
z289LIb1AdjQ54J2pepWEBcPxfEq+nEo1ehgGOEzmaLXbvoLp8KkLWFMnBFXzcol
lZP35YBA/EfKMUz5fWaAxnp/joI5Ga74Mpyp6jyx8sWUnYWEqFslnGVpDAkPuvZD
oCVb60Wu8/Rfct9LgB1yFK7C1dnf3SJlYwKTB22etIgCxgFSJWrNHuIxggKbMIIC
lwIBATCBijCBgDELMAkGA1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UE
BwwGVGFpcGVpMQ0wCwYDVQQKDARRTkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMM
B1FOQVBfQ0ExIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tAgUAuENW
7DALBglghkgBZQMEAgGggeQwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
hkiG9w0BCQUxDxcNMjIxMjAyMDMwOTE3WjAvBgkqhkiG9w0BCQQxIgQgvtdZSm+m
c7QevdJma9Em5ycFr3I7Wo4aG40Vcx/mT5IweQYJKoZIhvcNAQkPMWwwajALBglg
hkgBZQMEASowCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBAjAKBggqhkiG9w0DBzAO
BggqhkiG9w0DAgICAIAwDQYIKoZIhvcNAwICAUAwBwYFKw4DAgcwDQYIKoZIhvcN
AwICASgwDQYJKoZIhvcNAQEBBQAEggEAuInAOUj+ebOkTqlqg3cf7v2FdKeCvZZn
cunx1xRnHJRVAAvcH/UZ3t7RF6MV5NmEQdVN79NBZl0KU1x7K3zyvcXnkacNuHnI
t+6neKKKkxJmB4hh4ljeYtx9a1RBgwH+PiYyH8+58S7+MF3MVhSH8jEiomgSbvsK
BroOCFQDoYWk14K/VIXW1scmvpNvFNBWwm19pYwi977rF+lPWzMHx/0jVXspFSEd
U48h9xKvPg6CsIlyfuKetHBjZZI6iSCvh2FZOWsD1/W2oGYkkY9Hdff24B34/res
cKXk/K9/JFAONWBbXUpxtzpBCeVJlZS1wQgu4Q+Fr6imaBXJkiyiNg==
EOB
cmd="DELETE FROM Certificate WHERE QpkgName = '$PACKAGE_NAME'; INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$PACKAGE_NAME','$cert','$signature');"
$SQLITE_CMD "$CERT_DB_PATHFILE" "$cmd"
z=$?
if [[ $z -eq 0 ]]; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' ok
SendPackageStateChange ISsigned
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' failed "($z) check the sherpa debug log for more information"
z=1
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:status_()
{
[[ $opts_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined}
local -i z=0
local a=''
local b=''
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME"; then
SaveActionResultToLog QPKG "$PACKAGE_NAME" status skipped 'not installed'
z=2
fi
if [[ $z -gt 0 ]]; then
MarkThisActionForkAsSkipped
FuncFork:Exit $z
fi
DebugAsProc "statusing $(ShowAsPackageName "$PACKAGE_NAME")"
a=$(QPKG.GetActiveTest "$PACKAGE_NAME")
if [[ $a = builtin ]]; then
[[ $opts_debug = true ]] && b='DEBUG_QPKG=true '
if [[ -e $GNU_TIMEOUT_CMD ]]; then
$GNU_TIMEOUT_CMD "$QPKG_STATUS_CHECK_TIMEOUT_SECONDS" /bin/bash -c "${b}$(QPKG.GetServicePathFile) status"
z=$?
else
RunAndLog "${b}$(QPKG.GetServicePathFile) status" "$LOGS_PATH/$PACKAGE_NAME.$STATUS_LOG_FILE" log:failure-only
z=$?
fi
elif [[ $a != none ]]; then
eval "$a" &>/dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive
;;
124)
SendPackageStateChange ISslow
;;
130)
SendPackageStateChange ISunknown
;;
*)
SendPackageStateChange ISNTactive
esac
SaveActionResultToLog QPKG "$PACKAGE_NAME" status ok
MarkThisActionForkAsOk
FuncFork:Exit
}
QPKG.AppCenterNotifier:Clear()
{
[[ -e /sbin/qpkg_cli ]] && /sbin/qpkg_cli --cancel "$PACKAGE_NAME"
QPKG.IsNtInstalled "$PACKAGE_NAME" && return 0
/sbin/setcfg "$PACKAGE_NAME" Status complete -f /etc/config/qpkg.conf
return 0
} &>/dev/null
QPKG.ServiceStatus:Clear()
{
rm -f "/var/run/$PACKAGE_NAME.last.operation"
}
QPKG.LastResultWasOk()
{
[[ $(QPKG.GetServiceStatus "$PACKAGE_NAME") = ok ]]
}
QPKG.ServiceStatus:Log()
{
if ! local a=$(QPKG.GetServiceStatus "$PACKAGE_NAME"); then
DebugAsWarn "unable to get status of $(ShowAsPackageName "$PACKAGE_NAME") service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $a in
start|stop|restart)
DebugInfo "$(ShowAsPackageName "$PACKAGE_NAME") service is $a"
;;
ok)
DebugInfo "$(ShowAsPackageName "$PACKAGE_NAME") service action completed OK"
;;
failed)
if [[ -e /var/log/$PACKAGE_NAME.log ]]; then
DebugAsError "$(ShowAsPackageName "$PACKAGE_NAME") service action failed. Check $(ShowAsFileName "/var/log/$PACKAGE_NAME.log") for more information"
AddExtLogToSessLog /var/log/$PACKAGE_NAME.log
else
DebugAsError "$(ShowAsPackageName "$PACKAGE_NAME") service action failed"
fi
;;
*)
DebugAsWarn "$(ShowAsPackageName "$PACKAGE_NAME") service status is unrecognised or unsupported"
esac
return 0
}
QPKG.GetInstallationPath()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Install_Path -d undefined -f /etc/config/qpkg.conf
}
QPKG.GetServicePathFile()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Shell -d undefined -f /etc/config/qpkg.conf
}
QPKG.App.GetVer()
{
local -i i=-1
local a=''
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] && i=$2 || i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
a=${QPKG_APP_VERSION[$i]}
[[ $a = default ]] && a=${QPKG_APP_VERSION[$(QPKG.GetDefaultArchIndex "$1")]}
[[ $a = version ]] && a=${QPKG_VERSION[$(QPKG.GetDefaultArchIndex "$1")]}
echo "$a"
return 0
}
QPKG.Avail.GetVer()
{
local a=''
local b=''
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
a=${QPKG_NAME[$i]}
[[ $a = "$b" ]] && continue || b=$a
if [[ ${1:-${PACKAGE_NAME:-sherpa}} = "$a" ]]; then
echo "${QPKG_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.Local.GetVer()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Version -d undefined -f /etc/config/qpkg.conf
}
QPKG.GetStoreID()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" store -d sherpa -f /etc/config/qpkg.conf
return 0
}
QPKG.IsRepoOk()
{
local a=$(QPKG.GetStoreID "${1:-${PACKAGE_NAME:-sherpa}}")
[[ -z $a || $a = sherpa ]]
}
QPKG.GetInstallDate()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" date -d undefined -f /etc/config/qpkg.conf
return 0
}
QPKG.IsBackupExist()
{
[[ -e $QPKG_BU_PATH/${1:?${FUNCNAME[0]}'()': undefined}.config.tar.gz ]]
}
QPKG.IsDependent()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
a=${QPKG_DEPENDS_ON[$i]}
[[ $a = default ]] && a=${QPKG_DEPENDS_ON[$(QPKG.GetDefaultArchIndex "${QPKG_NAME[$i]}")]}
[[ $a = none ]] && break
[[ -n $a ]] && return
fi
done
return 1
}
QPKG.IsUpgradable()
{
local a=${1:-$PACKAGE_NAME}
QPKG.IsInstalled "$a" && QPKG.IsRepoOk "$a" && [[ $(QPKG.Local.GetVer "$a") != "$(QPKG.Avail.GetVer "$a")" ]] && QPKG.IsArchOK "$a" && QPKG.IsMinOSVerOk "$a" && QPKG.IsMinRAMOk "$a"
}
QPKG.IsInstallable()
{
local a=${1:-$PACKAGE_NAME}
! QPKG.IsInstalled "$a" && QPKG.IsRepoOk "$a" && QPKG.IsArchOK "$a" && QPKG.IsMinOSVerOk "$a" && QPKG.IsMinRAMOk "$a"
}
QPKG.GetOriginalPath()
{
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]]; then
for i in "${!QPKGs_were_installed_name[@]}"; do
if [[ ${QPKGs_were_installed_name[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKGs_were_installed_path[$i]}"
return 0
fi
done
fi
return 1
}
QPKG.MatchAbbrv()
{
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!QPKG_NAME[@]}"; do
ar=(${QPKG_ABBRVS[$i]})
for j in "${!ar[@]}"; do
if [[ ${ar[$j]} = "$1" ]]; then
Display "${QPKG_NAME[$i]}"
z=0
break 2
fi
done
done
return $z
}
QPKG.GetPathFilename()
{
local a=$(QPKG.GetURL "${1:?${FUNCNAME[0]}'()': undefined}")
[[ -n $a ]] || return
[[ $(Lowercase "${a##*.}") != qpkg ]] && a=${a%.*}.qpkg
echo "$QPKG_DL_PATH/$($BASENAME_CMD "$a")"
return 0
}
QPKG.GetHash()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]] && [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]]; then
echo "${QPKG_HASH[$i]}"
return 0
fi
done
return 1
}
QPKG.GetURL()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]] && [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]]; then
echo "${QPKG_URL[$i]}"
return 0
fi
done
return 1
}
QPKG.IsArchOK()
{
local a=$(QPKG.GetURL "${1:-$PACKAGE_NAME}")
[[ -n $a && $a != none ]]
}
QPKG.GetMinRAM()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_MIN_RAM_KB[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMinRAMOk()
{
local a=$(QPKG.GetMinRAM "${1:?${FUNCNAME[0]}'()': undefined}")
[[ -n $a ]] && [[ $a = none || $NAS_RAM_KB -ge $a ]]
}
QPKG.GetMinOSVer()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_MIN_OS_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMinOSVerOk()
{
local a=$(QPKG.GetMinOSVer "${1:?${FUNCNAME[0]}'()': undefined}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -ge $a ]]
}
QPKG.GetMaxOSVer()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_MAX_OS_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMaxOSVerOk()
{
local a=$(QPKG.GetMaxOSVer "${1:?${FUNCNAME[0]}'()': undefined}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -le $a ]]
}
QPKG.GetAuthor()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_AUTHOR[$i]}"
return 0
fi
done
return 1
}
QPKG.GetAuthorEmail()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_AUTHOR_EMAIL[$i]}"
return 0
fi
done
return 1
}
QPKG.GetAppAuthor()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_APP_AUTHOR[$i]}"
return 0
fi
done
return 1
}
QPKG.GetAppAuthorEmail()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_APP_AUTHOR_EMAIL[$i]}"
return 0
fi
done
return 1
}
QPKG.GetDesc()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_DESC[$i]}"
return 0
fi
done
return 1
}
QPKG.GetNote()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
a=${QPKG_NOTE[$i]}
[[ $a != none ]] && echo "$a"
return 0
fi
done
return 1
}
QPKG.GetAbbrvs()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "${QPKG_ABBRVS[$i]}"
return 0
fi
done
return 1
}
QPKG.GetArchIndex()
{
local -i i=-1
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
if [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]]; then
echo "$i"
return
fi
fi
done
echo "$i"
return 1
}
QPKG.GetDefaultArchIndex()
{
local -i i=-1
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
echo "$i"
return
fi
done
echo "$i"
return 1
}
QPKG.GetDependencies()
{
local alt=''
local first=''
local found=false
local g=''
local -i i=-1
local oldIFS=$IFS
local out=''
local x=''
i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
g=${QPKG_DEPENDS_ON[$i]}
[[ $g = none ]] && return 1
[[ $g = default ]] && g=${QPKG_DEPENDS_ON[$(QPKG.GetDefaultArchIndex "$1")]}
if [[ $g != *'|'* ]]; then
echo "$g"
return 0
fi
IFS=' '
for x in $g; do
found=false
if [[ $x != *'|'* ]]; then
out+=" $x"
continue
fi
IFS='|'
for alt in $x; do
[[ -z $first && -n $alt ]] && first=$alt
if QPKG.IsArchOK "$alt"; then
out+=" $alt"
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]] && IFS=$oldIFS
if [[ $found = false ]]; then
out+=" $first"
first=''
fi
done
echo "$out"
return 0
}
QPKG.GetIPKs()
{
local -i i=-1
local a=''
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] && i=$2 || i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
a=${QPKG_REQUIRES_IPKS[$i]}
[[ $a = default ]] && a=${QPKG_REQUIRES_IPKS[$(QPKG.GetDefaultArchIndex "$1")]}
[[ $a = none ]] && return 1
echo "$a"
return 0
}
QPKG.GetDependents()
{
local -a ar=()
local -i i=-1
local re=\\b${1:-}\\b
if QPKGs-SCindependent.Exist "$1"; then
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_DEPENDS_ON[$i]} =~ $re ]]; then
[[ ${ar[*]:-} != "${QPKG_NAME[$i]}" ]] && ar+=(${QPKG_NAME[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]]; then
echo "${ar[@]}"
return 0
fi
return 1
}
QPKG.IsCanBackup()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]]; then
if ${QPKG_CAN_BACKUP[$i]}; then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanRestartToUpdate()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
if ${QPKG_CAN_RESTART_TO_UPDATE[$i]}; then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanClean()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]]; then
if ${QPKG_CAN_CLEAN[$i]}; then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanLog()
{
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]]; then
if ${QPKG_CAN_LOG_SERVICE_OPERATIONS[$i]}; then
return 0
else
break
fi
fi
done
return 1
}
QPKG.GetActiveTest()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}"; do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined}" ]]; then
a=${QPKG_TEST_FOR_ACTIVE[$i]}
[[ -n $a ]] || break
echo "$a"
return 0
fi
done
return 1
}
QPKG.IsInstalled()
{
$GREP_CMD -q "^\[${1:?${FUNCNAME[0]}'()': undefined}\]" /etc/config/qpkg.conf
}
QPKG.IsNtInstalled()
{
! QPKG.IsInstalled "${1:?${FUNCNAME[0]}'()': undefined}"
}
QPKG.IsMissing()
{
local a=$(QPKG.GetInstallationPath "${1:?${FUNCNAME[0]}'()': undefined}")
[[ $a != undefined && ! -d $a ]]
}
QPKG.IsEnabled()
{
[[ $(/sbin/getcfg "${1:?${FUNCNAME[0]}'()': undefined}" Enable -u -f /etc/config/qpkg.conf) = TRUE ]]
}
QPKG.GetServiceStatus()
{
local a=${1:?${FUNCNAME[0]}'()': undefined}
[[ -e /var/run/$a.last.operation ]] && echo "$(</var/run/"$a".last.operation)"
}
MakePath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] || return
[[ -n ${2:?${FUNCNAME[0]}'()': undefined} ]] || return
if ! mkdir -p "$1"; then
ShowAsError "unable to create $2 path $(ShowAsFileName "$1") $(ShowAsExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0
}
RunAndLog()
{
Func:Init
local -r LOG_PATHFILE=$($MKTEMP_CMD /var/log/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
[[ -n ${1:?${FUNCNAME[0]}'()': undefined} ]] || return
[[ -n ${2:?${FUNCNAME[0]}'()': undefined} ]] || return
ShowAsCommand "$1" > "$2"
DebugAsProc "exec: '$1'"
if [[ $opts_verbose = true ]]; then
eval "$1 > >($TEE_CMD $LOG_PATHFILE) 2>&1"
z=$?
else
(eval "$1" > "$LOG_PATHFILE" 2>&1)
z=$?
fi
if [[ -e $LOG_PATHFILE ]]; then
ShowAsResultAndStdout "$z" "$(<"$LOG_PATHFILE")" >> "$2"
rm -f "$LOG_PATHFILE"
else
ShowAsResultAndStdout "$z" '<null>' >> "$2"
fi
case $z in
0|"${4:-}")
[[ ${3:-} != log:failure-only || $opts_debug = true ]] && AddExtLogToSessLog "$2"
DebugAsDone 'exec: complete'
[[ $opts_debug = false ]] && rm -f "$2"
;;
*)
AddExtLogToSessLog "$2"
DebugAsError 'exec: complete, but with errors'
esac
Func:Exit $z
}
DeDupeWords()
{
[[ -n ${1:-} ]] || return
tr ' ' '\n' <<< "$1" | $SORT_CMD | $UNIQ_CMD | tr '\n' ' ' | $SED_CMD 's|^[[:blank:]]*||;s|[[:blank:]]*$||'
}
FileMatchesMD5()
{
[[ $($MD5SUM_CMD "${1:?${FUNCNAME[0]}'()': undefined}" | cut -f1 -d' ') = "${2:?${FUNCNAME[0]}'()': undefined}" ]]
}
Pluralise()
{
[[ ${1:-0} -ne 1 ]] && echo s
}
Capitalise()
{
[[ -n ${1:-} ]] || return
if [[ $1 == sherpa* ]]; then
echo "$1"
else
echo "$(Uppercase ${1:0:1})${1:1}"
fi
}
Uppercase()
{
tr 'a-z' 'A-Z' <<< "${1:-}"
}
Lowercase()
{
tr 'A-Z' 'a-z' <<< "${1:-}"
}
LTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob; echo -n "${1##+(' ')}")
}
RTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob; echo -n "${1%%+(' ')}")
}
Trim()
{
[[ -n ${1:-} ]] || return
RTrim "$(LTrim "$1")"
}
FormatAsThous()
{
local a=$($SED_CMD 's/[^0-9]*//g' <<< "${1:-}")
local b=''
local out=''
while [[ ${#a} -gt 0 ]]; do
b=${a:${#a}<3?0:-3}
if [[ -z $out ]]; then
out=$b
else
out=$b,$out
fi
if [[ ${#b} -eq 3 ]]; then
a=${a%???}
else
break
fi
done
echo "$out"
return 0
}
FormatAsIsoBytes()
{
$AWK_CMD 'BEGIN{ u[0]="B"; u[1]="kB"; u[2]="MB"; u[3]="GB"} { n = $1; i = 0; while(n > 1000) { i+=1; n= int((n/1000)+0.5) } print n u[i] } ' <<< "$1"
}
ShowTitleLine()
{
[[ $title_shown = false ]] || return
[[ $hide_title = false && $opts_verbose = false ]] || return
EraseThisLine
Display "$(ShowTitleName) $(ShowVersion) $(ShowDescription)"
title_shown=true
WriteEmptyLineIfNoneExists
}
ShowTitleName()
{
TextBrightWhite sherpa
}
ShowVersion()
{
echo -n "$THIS_SCRIPT_VER"
}
ShowDescription()
{
echo -n "${CHARS_BULLET}a mini-package-manager for QNAP NAS"
}
ShowAction()
{
TextBrightYellow '[action]'
}
ShowPackages()
{
TextBrightOrange '[packages]'
}
ShowPackageGroup()
{
TextBrightOrange '[package group]'
}
ShowOptions()
{
TextBrightRed '[options]'
}
ShowAsPackageName()
{
echo -n "'${1:?${FUNCNAME[0]}'()': undefined}'"
}
ShowAsFileName()
{
echo -n "${1:?${FUNCNAME[0]}'()': undefined}"
}
ShowAsURL()
{
TextUnderlinedCyan "${1:?${FUNCNAME[0]}'()': undefined}"
}
ShowAsExitcode()
{
echo -n "[${1:?${FUNCNAME[0]}'()': undefined}]"
}
ShowAsLogFilename()
{
echo -n "${CHARS_RESULTS}log file: '${1:?${FUNCNAME[0]}'()': undefined}'"
}
ShowAsCommand()
{
echo "${CHARS_RESULTS}command: '${1:?${FUNCNAME[0]}'()': undefined}'"
}
ShowAsResultAndStdout()
{
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] || return
local a=$CHARS_RESULTS
[[ ${1:-0} -ne 0 ]] && a=$CHARS_ALERT
echo "${a}result_code: $(ShowAsExitcode "$1") ***** stdout/stderr begins below *****"
echo "$2"
echo "${a}***** stdout/stderr is complete *****"
}
WriteEmptyLineIfNoneExists()
{
if [[ $linespace_visible = false ]]; then
echo
linespace_visible=true
else
linespace_visible=false
fi
}
DisplayWritingReport()
{
if [[ ${report_title_shown:=false} = false ]]; then
ShowAsProc 'writing report'
report_title_shown=true
fi
}
DebugInfoMajSepr()
{
DebugInfo "$(eval printf '%0.s=' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugInfoMinSepr()
{
DebugInfo "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugExtLogMinSepr()
{
DebugAsLog "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugScript()
{
DebugDetectTabld SCRIPT "${1:-}" "${2:-}"
}
DebugHardware()
{
case ${1:-} in
warning)
DebugWarningTabld HARDWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld HARDWARE "${2:-}" "${3:-}"
esac
}
DebugFirmware()
{
case ${1:-} in
warning)
DebugWarningTabld FIRMWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld FIRMWARE "${2:-}" "${3:-}"
esac
}
DebugUserspace()
{
case ${1:-} in
warning)
DebugWarningTabld USERSPACE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld USERSPACE "${2:-}" "${3:-}"
esac
}
DebugIpk()
{
case ${1:-} in
error)
DebugErrorTabld IPK "${2:-}" "${3:-}"
;;
*)
DebugInfoTabld IPK "${2:-}" "${3:-}"
esac
}
DebugQpkg()
{
case ${1:-} in
error)
DebugErrorTabld QPKG "${2:-}" "${3:-}"
;;
warning)
DebugWarningTabld QPKG "${2:-}" "${3:-}"
;;
info)
DebugInfoTabld QPKG "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld QPKG "${2:-}" "${3:-}"
esac
}
DebugDetectTabld()
{
if [[ -z ${3:-} ]]; then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]]; then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]]; then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugInfoTabld()
{
if [[ -z ${3:-} ]]; then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]]; then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]]; then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugWarningTabld()
{
if [[ -z ${3:-} ]]; then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]]; then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]]; then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugErrorTabld()
{
if [[ -z ${3:-} ]]; then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]]; then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]]; then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugVar()
{
DebugAsVar "\$$1 : '${!1:-undefined}'"
}
DebugInfo()
{
[[ -n ${1:-} ]] || return
if [[ ${2:-} = ' ' || ${2:-} = "'' " ]]; then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]]; then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi
}
Func:Init()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(/bin/date +%s%N)"
DebugAsFuncEn
}
Func:Exit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ShowAsDuration "$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")")"
return ${1:-0}
}
FuncFork:Init()
{
original_sess_active_pathfile=$sess_active_pathfile
sess_active_pathfile=$($MKTEMP_CMD /var/log/"${FUNCNAME[1]}"_XXXXXX)
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(/bin/date +%s%N)"
DebugAsFuncEn
}
FuncFork:Exit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
SendActionStatus ex
DebugAsFuncEx "${1:-0}" "$(ShowAsDuration "$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")")"
if [[ -n $sess_active_pathfile && -e $sess_active_pathfile ]]; then
if [[ -s $sess_active_pathfile ]]; then
$CAT_CMD "$sess_active_pathfile" >> "$original_sess_active_pathfile"
fi
rm -f "$sess_active_pathfile"
fi
sess_active_pathfile=$original_sess_active_pathfile
original_sess_active_pathfile=''
exit ${1:-0}
}
CalcMilliDifference()
{
echo "$((($2-$1)/1000000))"
}
ShowAsDuration()
{
if [[ ${1:-0} -lt 30000 ]]; then
echo "$(FormatAsThous "${1:-0}")ms"
else
FormatSecsToHoursMinutesSecs "$(($1/1000))"
fi
}
DebugAsFuncEn()
{
DebugThis "(>>) ${FUNCNAME[2]}()"
}
DebugAsFuncEx()
{
DebugThis "(<<) ${FUNCNAME[2]}|${1:-0}|${2:-}"
}
DebugAsProc()
{
[[ -n $1 ]] && DebugThis "(--) $1"
}
DebugAsDone()
{
[[ -n $1 ]] && DebugThis "(==) $1"
}
DebugAsDetect()
{
[[ -n $1 ]] && DebugThis "(**) $1"
}
DebugAsInfo()
{
[[ -n $1 ]] && DebugThis "(II) $1"
}
DebugAsWarn()
{
[[ -n $1 ]] && DebugThis "(WW) $1"
}
DebugAsError()
{
[[ -n $1 ]] && DebugThis "(EE) $1"
}
DebugAsLog()
{
[[ -n $1 ]] && DebugThis "(LL) $1"
}
DebugAsVar()
{
[[ -n $1 ]] && DebugThis "(vv) $1"
}
DebugThis()
{
[[ -n ${1:-} ]] || return
[[ ${opts_verbose:-false} = true ]] && ShowAsDebug "$1"
WriteToLog dbug "$1"
}
AddExtLogToSessLog()
{
local linebuff=''
local original_verbose=false
if [[ $opts_verbose = true ]]; then
original_verbose=true
opts_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(ShowAsLogFilename "${1:?${FUNCNAME[0]}'()': undefined}")"
while read -r linebuff; do
DebugAsLog "$linebuff"
done < "$1"
DebugExtLogMinSepr
opts_verbose=$original_verbose
}
ShowAsProcLong()
{
ShowAsProc "${1:-} (might take a while)" "${2:-}"
} >&2
ShowAsProc()
{
[[ -n ${1:-} ]] || return
local suffix=''
[[ -n ${2:-} ]] && suffix=${2:-}
OpStepRewriteWait "$(TextBrightYellow proc)" "$1 $CHARS_ELLIPSIS $suffix"
WriteToLog proc "${1}${suffix}"
[[ ${opts_verbose:=false} = true ]] && Display
} >&2
ShowAsDebug()
{
[[ -n ${1:-} ]] || return
OpStep "$(TextBlackOnCyan dbug)" "$1"
}
ShowAsInfo()
{
[[ -n ${1:-} ]] || return
local capitalised=$(Capitalise "$1")
EraseThisLine
OpStep "$(TextBrightYellow note)" "$capitalised"
WriteToLog note "$capitalised"
} >&2
ShowAsQuiz()
{
[[ -n ${1:-} ]] || return
OpStepWait "$(TextBrightOrangeBlink quiz)" "$1:"
WriteToLog quiz "$1:"
}
ShowAsQuizDone()
{
[[ -n ${1:-} ]] || return
OpStep "$(TextBrightOrange quiz)" "$1"
}
ShowAsDone()
{
[[ -n ${1:-} ]] || return
EraseThisLine
OpStep "$(TextBrightGreen 'done')" "$1"
WriteToLog 'done' "$1"
} >&2
ShowAsWarn()
{
[[ -n ${1:-} ]] || return
EraseThisLine
OpStep "$(TextBrightOrange warn)" "$1"
WriteToLog warn "$1"
} >&2
ShowAsAbort()
{
[[ -n ${1:-} ]] || return
OpStep "$(TextBrightRed bort)" "$1"
WriteToLog bort "$1"
Self.Error:Set
} >&2
ShowAsFail()
{
[[ -n ${1:-} ]] || return
local capitalised=$(Capitalise "$1")
EraseThisLine
OpStep "$(TextBrightRed fail)" "$capitalised"
WriteToLog fail "$capitalised"
} >&2
ShowAsError()
{
[[ -n ${1:-} ]] || return
local capitalised=$(Capitalise "$1")
EraseThisLine
OpStep "$(TextBrightRed derp)" "$capitalised"
WriteToLog derp "$capitalised"
Self.Error:Set
} >&2
ShowAsPercentProgress()
{
local -r ACTION_PRESENT_MSG=${1:-}
local -r DURATION=${2:-}
declare -i -r OK_COUNT=${3:-0}
declare -i -r SKIP_COUNT=${4:-0}
declare -i -r FAIL_COUNT=${5:-0}
declare -i -r TOTAL_COUNT=${6:-0}
local -r PROGRESS_MSG=$(PercFrac "$OK_COUNT" "$SKIP_COUNT" "$FAIL_COUNT" "$TOTAL_COUNT")
if [[ $DURATION != long ]]; then
ShowAsProc "$ACTION_PRESENT_MSG" "$PROGRESS_MSG"
else
ShowAsProcLong "$ACTION_PRESENT_MSG" "$PROGRESS_MSG"
fi
[[ $((OK_COUNT+SKIP_COUNT+FAIL_COUNT)) -ge $TOTAL_COUNT ]] && sleep 0.5
return 0
} >&2
PercFrac()
{
declare -i -r OK_COUNT=${1:-0}
declare -i -r SKIP_COUNT=${2:-0}
declare -i -r FAIL_COUNT=${3:-0}
declare -i -r TOTAL_COUNT=${4:-0}
local -i progress_count=$((OK_COUNT+SKIP_COUNT+FAIL_COUNT))
local perc_msg=''
[[ $TOTAL_COUNT -gt 0 ]] || return
if [[ $progress_count -gt $TOTAL_COUNT ]]; then
progress_count=$TOTAL_COUNT
perc_msg='100%'
else
perc_msg="$((200*(progress_count+1)/(TOTAL_COUNT+1)%2+100*(progress_count+1)/(TOTAL_COUNT+1)))%"
fi
echo "$perc_msg ($(TextBrightWhite "$progress_count")/$(TextBrightWhite "$TOTAL_COUNT"))"
return 0
} 2>/dev/null
ShowAsIterativeProgress()
{
local -r ACTION=${1:?${FUNCNAME[0]}'()': undefined}
declare -i -r COUNT1=${2:-0}
local -r SUFFIX1=${3:?${FUNCNAME[0]}'()': undefined}
declare -i -r COUNT2=${4:-0}
local -r SUFFIX2=${5:?${FUNCNAME[0]}'()': undefined}
local -r DURATION=${6:-short}
local progress_msg=''
progress_msg="$(TextBrightWhite "$COUNT1") ${SUFFIX1}$(Pluralise "$COUNT1"): $(TextBrightWhite "$COUNT2") ${SUFFIX2}$(Pluralise "$COUNT2")"
if [[ $DURATION != long ]]; then
ShowAsProc "$ACTION" "$progress_msg"
else
ShowAsProcLong "$ACTION" "$progress_msg"
fi
return 0
}
ShowAsActionLogDetail()
{
if [[ $2 = undefined ]]; then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
case ${4:-} in
skipped|skipped-failed)
if [[ -n "${6:-}" ]]; then
DisplayAsIndentPrefixActionResultDurationReason '' "$3" "$2" '' "$6"
else
DisplayAsIndentPrefixActionResultDurationReason '' "$3" "$2" '' "no reason provided"
fi
;;
failed)
if [[ -n "${6:-}" ]]; then
if QPKG.IsCanLog "$2"; then
DisplayAsIndentPrefixActionResultDurationReason 'Unable to ' "$3" "$2" "$5" "For more information: /etc/init.d/$($BASENAME_CMD "$(QPKG.GetServicePathFile "$2")") log"
else
DisplayAsIndentPrefixActionResultDurationReason 'Unable to ' "$3" "$2" "$5" "$6"
fi
else
DisplayAsIndentPrefixActionResultDurationReason 'Unable to ' "$3" "$2" "$5" 'no reason provided by the service script'
fi
;;
*)
DisplayAsIndentPrefixActionResultDurationReason '' "$3" "$2" "$5"
esac
}
OpStepRewriteWait()
{
local -i typewidth=4
[[ $colourful = true ]] && typewidth=10
prev_msg=$(printf "%-${typewidth}s: %s" "${1:-}" "${2:-}")
DisplayWait "$(printf '\033[2K\r')$prev_msg"
return 0
}
OpStepWait()
{
local -i typewidth=4
[[ $colourful = true ]] && typewidth=10
prev_msg=$(printf "%-${typewidth}s: %s" "${1:-}" "${2:-}")
DisplayWait "$prev_msg"
return 0
}
OpStep()
{
local -i typewidth=4
local -i length=0
local -i blanking_length=0
local msg=''
local str=''
[[ ${colourful:=true} = true ]] && typewidth=10
msg=$(printf "%-${typewidth}s: %s" "${1:-}" "${2:-}")
if [[ $msg != "${prev_msg:=''}" ]]; then
prev_length=$((${#prev_msg}+1))
length=$((${#msg}+1))
str=$(echo -en "\r$msg ")
if [[ $length -lt $prev_length ]]; then
blanking_length=$((length-prev_length))
str+=$(printf "%${blanking_length}s")
fi
Display "$str"
fi
return 0
}
WriteToLog()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
[[ ${opts_debug:=false} = true && -n $sess_active_pathfile ]] && printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")" >> "$sess_active_pathfile"
}
TextBrightGreen()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightYellow()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrange()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrangeBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRed()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRedBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextDarkGrey()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextUnderlined()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[4m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextUnderlinedCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBlackOnCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightWhite()
{
[[ -n ${1:-} ]] || return
if [[ ${colourful:=true} = true ]]; then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
StripANSICodes()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd ]]; then
/opt/bin/sed -r 's/\x1b\[[0-9;]*m//g' <<< "${1:-}"
else
echo "${1:-}"
fi
} 2>/dev/null
UpdateColourisation()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd ]]; then
colourful=true
SendParentChangeEnv 'colourful=true'
else
colourful=false
SendParentChangeEnv 'colourful=false'
fi
} 2>/dev/null
Cursor:Hide()
{
[[ $opts_verbose = false ]] && printf '\033[?25l'
}
Cursor:Show()
{
printf '\033[?25h'
}
Keystrokes:Hide()
{
[[ $opts_verbose = false && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD '-echo'
}
Keystrokes:Show()
{
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD 'echo'
}
FormatMillisecsToMinutesSecs()
{
local seconds=$((${1:-0}/1000))
((m=(seconds%3600)/60))
((s=seconds%60))
[[ $s -eq 0 ]] && s=1
if [[ $m -eq 0 ]]; then
if [[ $s -eq 1 ]]; then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
else
printf '%dm:%02ds' "$m" "$s"
fi
} 2>/dev/null
FormatSecsToHoursMinutesSecs()
{
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
printf '%01dh:%02dm:%02ds\n' "$h" "$m" "$s"
} 2>/dev/null
FormatLongMinutesSecs()
{
local m=${1%%:*}
local s=${1#*:}
m=${m##* }
s=${s##* }
printf '%01dm:%02ds\n' "$((10#$m))" "$((10#$s))"
} 2>/dev/null
sleep()
{
local wait=${1:-}
[[ ${wait//.} -eq 0 ]] && wait=1
if [[ -e $GNU_SLEEP_CMD && -L /opt/etc/passwd ]]; then
$GNU_SLEEP_CMD "$wait"
elif [[ $DECIMAL_SLEEP_SECONDS_SUPPORTED = false ]]; then
$SLEEP_CMD "$((${wait%.*}+1))"
else
$SLEEP_CMD "$wait"
fi
return 0
} 2>/dev/null
Objects:Load()
{
[[ ${objects_loaded:=false} = true ]] && return
Func:Init
if [[ ! -e $PWD/dont-refresh-objects ]]; then
if [[ ! -e $OBJECTS_PATHFILE ]] || ! IsThisFileRecent "$OBJECTS_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES"; then
ShowAsProc 'downloading objects'
if $CURL_CMD --insecure --silent --fail "$OBJECTS_ARCHIVE_URL" > "$OBJECTS_ARCHIVE_PATHFILE"; then
$TAR_CMD --extract --gzip --no-same-owner --file="$OBJECTS_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
fi
fi
if [[ ! -e $OBJECTS_PATHFILE ]]; then
ShowAsAbort 'objects missing'
Func:Exit 1; exit
fi
ShowAsProc 'loading objects'
. "$OBJECTS_PATHFILE"
objects_loaded=true
readonly OBJECTS_VER
DebugVar OBJECTS_VER
Func:Exit
}
Packages:Load()
{
[[ ${packages_loaded:=false} = true ]] && return
Func:Init
if [[ ! -e $PWD/dont-refresh-packages ]]; then
if [[ ! -e $PACKAGES_PATHFILE ]] || ! IsThisFileRecent "$PACKAGES_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES"; then
ShowAsProc 'downloading QPKG list'
if $CURL_CMD --insecure --silent --fail "$PACKAGES_ARCHIVE_URL" > "$PACKAGES_ARCHIVE_PATHFILE"; then
$TAR_CMD --extract --gzip --no-same-owner --file="$PACKAGES_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
fi
fi
if [[ ! -e $PACKAGES_PATHFILE ]]; then
ShowAsAbort 'QPKG list missing'
Func:Exit 1; exit
fi
ShowAsProc 'loading QPKG list'
. "$PACKAGES_PATHFILE"
packages_loaded=true
readonly BASE_QPKG_CONFLICTS_WITH
readonly BASE_QPKG_WARNINGS
readonly ESSENTIAL_IPKS
readonly ESSENTIAL_PIPS
readonly MIN_PERL_VER
readonly MIN_PYTHON_VER
readonly PACKAGES_VER
readonly QPKG_ABBRVS
readonly QPKG_APP_AUTHOR
readonly QPKG_APP_AUTHOR_EMAIL
readonly QPKG_APP_VERSION
readonly QPKG_ARCH
readonly QPKG_AUTHOR
readonly QPKG_AUTHOR_EMAIL
readonly QPKG_CAN_BACKUP
readonly QPKG_CAN_CLEAN
readonly QPKG_CAN_LOG_SERVICE_OPERATIONS
readonly QPKG_CAN_RESTART_TO_UPDATE
readonly QPKG_CONFLICTS_WITH
readonly QPKG_DEPENDS_ON
readonly QPKG_DESC
readonly QPKG_HASH
readonly QPKG_MAX_OS_VERSION
readonly QPKG_MIN_OS_VERSION
readonly QPKG_MIN_RAM_KB
readonly QPKG_NAME
readonly QPKG_NOTE
readonly QPKG_REQUIRES_IPKS
readonly QPKG_TEST_FOR_ACTIVE
readonly QPKG_URL
readonly QPKG_VERSION
DebugVar PACKAGES_VER
QPKGs-SCall:Add "${QPKG_NAME[*]}"
QPKGs.IndependentDependent:Build
Func:Exit
}
RunOnSIGINT()
{
$TOUCH_CMD "$DISPLAY_INHIBIT_PATHFILE"
EraseThisLine
ShowAsAbort 'caught SIGINT'
KillActiveFork
CloseActionMsgPipe
exit
}
RunOnEXIT()
{
trap - INT
Keystrokes:Show
Cursor:Show
Self.LockFile:Release
}
Self:Init || exit
Actions:Proc
Self.Results:Show
Self.Error.IsNt
