#!/usr/bin/env bash
#* Please don't edit this file directly, it was built/modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#* sherpa-manager.sh
#* Copyright (C) 2017-2024 OneCD.
#* Contact:
#*   one.cd.only@gmail.com
#* Description:
#*   This is the management script for the sherpa mini-package-manager.
#*   It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#* Project:
#*	 https://git.io/sherpa
#* Forum:
#*	 https://forum.qnap.com/viewtopic.php?f=320&t=132373
#* Tested on:
#*	 GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	 GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	   Copyright (C) 2007 Free Software Foundation, Inc.
#*   ... and periodically on:
#*	 GNU bash, version 5.0.17(1)-release (aarch64-openwrt-linux-gnu)
#*	   Copyright (C) 2019 Free Software Foundation, Inc.
#* License:
#*   This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
set -o nounset -o pipefail
readonly ARGS_RAW=$*
readonly SCRIPT_STARTSECONDS=$(/bin/date +%s)
Init()
{
OS.IsOk || return
User.IsOk || return
Consts:Load
Vars:Load
CMDs:Load
CMDs.IsOk || return
Keystrokes:Hide
Cursor:Hide
Env:Load || return
LockFile:Claim || return
Traps:Set
Paths:Create || return
PrepareArgs
ParseManagementArgs || return
ParseHelpArgs || return
ArchivePriorSessLogs
Debug.Log:Init
ParseShowArgs || return
ParseListArgs || return
ParseActionArgs || return
Title:Show
ArgSuggestions:Show
QPKGs.Conflicts:Check || return
QPKGs.Warnings:Check
Debug.Log:Env
Tasks:Check
Env:Validate
QPKGs:AssignToActions
return 0
}
Results:Show()
{
Func:Init
display_last_action_datetime=false
if [[ $generate_show_report = true ]];then
if [[ $useropt_show_log_last = true ]];then
LockFile:Release
Log.Last:View
elif [[ $useropt_show_log_tail = true ]];then
LockFile:Release
Log.Tail:View
elif [[ $useropt_show_backups = true ]];then
Report.Backups:Show
elif [[ $useropt_show_versions = true ]];then
Report.Versions:Show
elif [[ $useropt_show_dependencies = true ]];then
Report.Dependencies:Show
elif [[ $useropt_show_packages = true ]];then
Report.Packages:Show
elif [[ $useropt_show_repos = true ]];then
Report.Repos:Show
elif [[ $useropt_show_status = true ]];then
Report.Statuses:Show
show_package_actions_ok=false
show_package_actions_skipped=false
show_package_actions_failed=false
fi
fi
if [[ $generate_list_report = true ]];then
if [[ ${packages_loaded:=false} = true ]];then
if QPKGs.AClist.ISbackedup.IsSet;then
QPKGs.IsBackedUp:Show
elif QPKGs.AClist.ISNTbackedup.IsSet;then
QPKGs.IsNtBackedUp:Show
elif QPKGs.AClist.ISinstalled.IsSet;then
QPKGs.IsInstalled:Show
elif QPKGs.AClist.ISNTinstalled.IsSet;then
QPKGs.IsNtInstalled:Show
elif QPKGs.AClist.ISactive.IsSet;then
QPKGs.IsActive:Show
elif QPKGs.AClist.ISNTactive.IsSet;then
QPKGs.IsNtActive:Show
elif QPKGs.AClist.GRinstallable.IsSet;then
QPKGs.GrInstallable:Show
elif QPKGs.AClist.GRNTinstallable.IsSet;then
QPKGs.GrNtInstallable:Show
elif QPKGs.AClist.GRupgradable.IsSet;then
QPKGs.GrUpgradable:Show
elif QPKGs.AClist.GRindependent.IsSet;then
QPKGs.GrIndependent:Show
elif QPKGs.AClist.GRdependent.IsSet;then
QPKGs.GrDependent:Show
fi
fi
fi
if [[ $useropt_paste_log_last = true ]];then
Log.Last:Paste
elif [[ $useropt_paste_log_tail = true ]];then
Log.Tail:Paste
fi
if [[ $useropt_help_basic = true ]];then
Help.Basic:Show
Help.Basic.Examples:Show
fi
if [[ $generate_help_report = true ]];then
if [[ $useropt_help_tips = true ]];then
Help.Tips:Show
elif [[ $useropt_help_abbreviations = true ]];then
Help.Abbreviations:Show
elif [[ $useropt_help_actions = true ]];then
Help.Actions:Show
elif [[ $useropt_help_actions_all = true ]];then
Help.ActionsAll:Show
elif [[ $useropt_help_lists = true ]];then
Help.Lists:Show
elif [[ $useropt_help_options = true ]];then
Help.Options:Show
elif [[ $useropt_help_packages = true ]];then
Help.Packages:Show
elif [[ $useropt_help_problems = true ]];then
Help.Problems:Show
elif [[ $useropt_help_upgrades = true ]];then
Help.Upgrades:Show
elif [[ $useropt_help_groups = true ]];then
Help.Groups:Show
fi
fi
if [[ $useropt_show_results = true ]];then
display_last_action_datetime=true
show_package_actions_failed=true
show_package_actions_ok=true
show_package_actions_skipped=true
fi
if [[ $generate_action_report = true || $generate_show_report = true ]];then
[[ $show_package_actions_ok = true ]] && Report.Results:Show ok
[[ $show_package_actions_skipped = true ]] && Report.Results:Show skipped
[[ $show_package_actions_failed = true ]] && Report.Results:Show failed
[[ $show_zero_qpkgs = true ]] && ShowZeroQpkgs
Display
fi
[[ $show_backuploc = true ]] && Help.BackupLocation:Show
[[ $show_suggest_raise_issue = true ]] && Help.Issue:Show
DebugInfoMinSepr
DebugScript finished "$(/bin/date)"
DebugScript 'elapsed time' "$(FormatSecsToHoursMinutesSecs "$(($(/bin/date +%s)-SCRIPT_STARTSECONDS))")"
DebugInfoMajSepr
Func:Exit
[[ $archive_debug_afterward = true ]] && ArchiveActiveSessLog
ResetActiveSessLog
}
Debug.Log:Init()
{
DebugInfoMajSepr
DebugScript started "$(/bin/date -d @"$SCRIPT_STARTSECONDS" | tr -s ' ')"
DebugScript PID "$$"
DebugInfoMinSepr
DebugInfo 'Markers: (**) detected, (II) information, (WW) warning, (EE) error, (LL) log file, (--) processing,'
DebugInfo '(==) done, (>>) f entry, (<<) f exit, (vv) variable name & value, ($1) positional argument value'
DebugInfoMinSepr
DebugVar THIS_PACKAGE_VER
DebugVar THIS_SCRIPT_VER
DebugVar LOADER_SCRIPT_VER
}
Consts:Load()
{
readonly QPKG_DISABLE_TIMEOUT_SECONDS=10
readonly QPKG_ENABLE_TIMEOUT_SECONDS=10
readonly QPKG_RESTART_TIMEOUT_SECONDS=1800
readonly QPKG_START_TIMEOUT_SECONDS=1500
readonly QPKG_STATUS_CHECK_TIMEOUT_SECONDS=15
readonly QPKG_STOP_TIMEOUT_SECONDS=300
readonly ACTION_RESULT_INDENT=6
readonly COLUMN_SPACING=2
readonly FILE_BYTES_COL_WIDTH=16
readonly FILE_CHANGE_DATE_COL_WIDTH=60
readonly HELP_DESC_INDENT=3
readonly HELP_SYNTAX_INDENT=6
readonly PACKAGE_ABBS_COL_WIDTH=84
readonly PACKAGE_APP_VER_COL_WIDTH=16
readonly PACKAGE_ARCH_COL_WIDTH=15
readonly PACKAGE_AUTHOR_COL_WIDTH=40
readonly PACKAGE_DEPENDENCIES_COL_WIDTH=29
readonly PACKAGE_DESCRIPTION_COL_WIDTH=10
readonly PACKAGE_ENABLED_COL_WIDTH=12
readonly PACKAGE_INSTALL_DATE_COL_WIDTH=18
readonly PACKAGE_INSTALLED_COL_WIDTH=14
readonly PACKAGE_MAX_OS_COL_WIDTH=11
readonly PACKAGE_MIN_OS_COL_WIDTH=11
readonly PACKAGE_MIN_RAM_COL_WIDTH=16
readonly PACKAGE_NAME_COL_WIDTH=21
readonly FILE_NAME_COL_WIDTH=$((PACKAGE_NAME_COL_WIDTH+14))
readonly PACKAGE_PATH_COL_WIDTH=48
readonly PACKAGE_REPO_COL_WIDTH=40
readonly PACKAGE_STATUS_COL_WIDTH=23
readonly PACKAGE_VER_COL_WIDTH=17
readonly CHARS_DROPEND='└─ '
readonly CHARS_ELLIPSIS='...'
readonly CHARS_NOTE='* '
readonly CHARS_REGULAR_PROMPT='$ '
readonly CHARS_SUDO_PROMPT="${CHARS_REGULAR_PROMPT}sudo "
readonly CHARS_RESULTS='= '
readonly CHAR_SPACER=' '
readonly CHARS_ALERT="${CHAR_SPACER}! "
readonly CHARS_ATTENTION="${CHAR_SPACER}* "
readonly CHARS_BLANK="${CHAR_SPACER}  "
readonly CHARS_NORMAL="${CHAR_SPACER}- "
readonly CHARS_BULLET='• '
readonly CHARS_SUPER_PROMPT='# '
readonly DEBUG_LOG_DATAWIDTH=101
readonly DEBUG_LOG_FIRST_COL_WIDTH=9
readonly DEBUG_LOG_SECOND_COL_WIDTH=22
readonly DEBUG_LOG_THIRD_COL_WIDTH=$((DEBUG_LOG_DATAWIDTH-DEBUG_LOG_FIRST_COL_WIDTH-DEBUG_LOG_SECOND_COL_WIDTH-4))
if OS.IsSupportSudo;then
if [[ $(GetSudoUID) = undefined ]];then
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
else
readonly HELP_SYNTAX_PREFIX=$CHARS_REGULAR_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUDO_PROMPT
fi
else
readonly HELP_SYNTAX_PREFIX=$CHARS_SUPER_PROMPT
readonly HELP_SYNTAX_SUDO_PREFIX=$CHARS_SUPER_PROMPT
fi
readonly FILE_CHANGE_THRESHOLD_MINUTES=60
readonly LOG_TAIL_LINES=5000
}
Vars:Load()
{
action_msg_pipe_fd=none
archive_debug_afterward=false
backup_stdin_fd=none
branch_default=stable
colourful_default=true
fork_pid=''
generate_action_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
proc_counts_path=''
qpkg_timeouts_increased=false
run_package_actions=false
show_backuploc=false
show_package_actions_failed=false
show_package_actions_ok=false
show_package_actions_skipped=false
show_suggest_raise_issue=false
show_title=true
show_zero_qpkgs=false
switch_colour=false
switch_branch=false
switch_terse=false
terse_default=true
title_shown=false
user_branch_value=''
user_colourful_value=''
user_terse_value=''
useropt_branch=$(LoadSetting Git_Branch "$branch_default")
useropt_check=false
useropt_colourful=$(LoadSetting Colourful "$colourful_default")
useropt_debug=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_paste_log_last=false
useropt_paste_log_tail=false
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_repos=false
useropt_show_results=false
useropt_show_status=false
useropt_show_versions=false
useropt_terse=$(LoadSetting Terse "$terse_default")
useropt_verbose=false
}
CMDs:Load()
{
readonly GNU_FIND_CMD=/opt/bin/find
readonly GNU_GREP_CMD=/opt/bin/grep
readonly GNU_LESS_CMD=/opt/bin/less
readonly GNU_SED_CMD=/opt/bin/sed
readonly GNU_SLEEP_CMD=/opt/bin/sleep
readonly GNU_SORT_CMD=/opt/bin/sort
readonly GNU_STTY_CMD=/opt/bin/stty
readonly GNU_TIMEOUT_CMD=/opt/bin/timeout
readonly OPKG_CMD=/opt/bin/opkg
readonly PERL_CMD=/opt/bin/perl
readonly PYTHON_CMD=/opt/bin/python
readonly PYTHON3_CMD=/opt/bin/python3
readonly PIP_CMD="$PYTHON3_CMD -m pip"
readonly AWK_CMD=/bin/awk
readonly BASENAME_CMD=/usr/bin/basename
readonly CAT_CMD=/bin/cat
CURL_CMD=/sbin/curl
readonly DF_CMD=/bin/df
readonly DIRNAME_CMD=/usr/bin/dirname
readonly DU_CMD=/usr/bin/du
readonly GREP_CMD=/bin/grep
readonly HEAD_CMD=/usr/bin/head
readonly LESS_CMD=/bin/less
readonly MD5SUM_CMD=/bin/md5sum
readonly MKNOD_CMD=/bin/mknod
readonly MKTEMP_CMD=/bin/mktemp
readonly MORE_CMD=/bin/more
readonly PS_CMD=/bin/ps
readonly READLINK_CMD=/usr/bin/readlink
readonly SCREEN_CMD=/usr/sbin/screen
readonly SED_CMD=/bin/sed
readonly SH_CMD=/bin/sh
readonly SLEEP_CMD=/bin/sleep
readonly SORT_CMD=/usr/bin/sort
readonly TAIL_CMD=/usr/bin/tail
readonly TAR_CMD=/bin/tar
readonly TEE_CMD=/usr/bin/tee
readonly TOUCH_CMD=/bin/touch
readonly UNAME_CMD=/bin/uname
readonly UNIQ_CMD=/bin/uniq
readonly UNZIP_CMD=/usr/bin/unzip
readonly UPTIME_CMD=/usr/bin/uptime
readonly WC_CMD=/usr/bin/wc
}
CMDs.IsOk()
{
IsSysFileExist $AWK_CMD || return
IsSysFileExist $BASENAME_CMD || return
IsSysFileExist $CAT_CMD || return
IsSysFileExist $CURL_CMD || return
IsSysFileExist $DF_CMD || return
IsSysFileExist $DIRNAME_CMD || return
IsSysFileExist $DU_CMD || return
IsSysFileExist $GREP_CMD || return
IsSysFileExist $HEAD_CMD || return
IsSysFileExist $MD5SUM_CMD || return
IsSysFileExist $MKNOD_CMD || return
IsSysFileExist $MKTEMP_CMD || return
IsSysFileExist $PS_CMD || return
IsSysFileExist $READLINK_CMD || return
IsSysFileExist $SCREEN_CMD || return
IsSysFileExist $SED_CMD || return
IsSysFileExist $SH_CMD || return
IsSysFileExist $TAIL_CMD || return
IsSysFileExist $TAR_CMD || return
IsSysFileExist $TEE_CMD || return
IsSysFileExist $TOUCH_CMD || return
IsSysFileExist $UNAME_CMD || return
IsSysFileExist $UNIQ_CMD || return
IsSysFileExist $UNZIP_CMD || return
IsSysFileExist $UPTIME_CMD || return
IsSysFileExist $WC_CMD || return
if [[ ! -e $GNU_SLEEP_CMD ]];then
IsSysFileExist $SLEEP_CMD || return
fi
[[ ! -e $SORT_CMD ]] && ln -s /bin/busybox "$SORT_CMD"
readonly DECIMAL_SLEEP_SECONDS_SUPPORTED=$($SLEEP_CMD .01 &>/dev/null && printf true || printf false)
LocateSQLiteBinary
return 0
}
LocateSQLiteBinary()
{
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled Entware;then
SQLITE_CMD=/opt/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled HybridBackup;then
SQLITE_CMD=$(QPKG.GetInstallationPath HybridBackup)/CloudConnector3/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled CacheMount;then
SQLITE_CMD=$(QPKG.GetInstallationPath CacheMount)/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled container-station;then
SQLITE_CMD=$(QPKG.GetInstallationPath container-station)/usr/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled qmiixagent;then
SQLITE_CMD=$(QPKG.GetInstallationPath qmiixagent)/bin/sqlite3
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled img2pdf;then
SQLITE_CMD="LD_LIBRARY_PATH=$(QPKG.GetInstallationPath img2pdf)/lib $(QPKG.GetInstallationPath img2pdf)/bin/sqlite3"
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled Qsirch;then
SQLITE_CMD="LD_LIBRARY_PATH=$(QPKG.GetInstallationPath Qsirch)/lib $(QPKG.GetInstallationPath Qsirch)/bin/sqlite3"
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
if [[ -z ${SQLITE_CMD:-} ]] && QPKG.IsInstalled OCR_Converter;then
SQLITE_CMD="LD_LIBRARY_PATH=$(QPKG.GetInstallationPath OCR_Converter)/lib $(QPKG.GetInstallationPath OCR_Converter)/bin/sqlite3"
[[ ! -e $SQLITE_CMD ]] && SQLITE_CMD=''
fi
[[ -z ${SQLITE_CMD:-} ]] && SQLITE_CMD=/opt/bin/sqlite3
readonly SQLITE_CMD
}
Env:Load()
{
ShowAsProc 'loading environment'
readonly CERT_DB_PATHFILE=/etc/config/nas_sign_qpkg.db
readonly CPU_CORES=$(GetCPUCores)
readonly CONCURRENCY=$CPU_CORES
readonly ENTWARE_VER=$(GetEntwareType)
readonly KERNEL_PAGE_SIZE=$(GetKernelPageSize)
readonly NAS_ARCH=$(GetArch)
readonly NAS_FIRMWARE_BUILD=$(GetFirmwareBuild)
readonly NAS_FIRMWARE_DATE=$(GetFirmwareDate)
readonly NAS_FIRMWARE_VER=$(GetFirmwareVer)
readonly NAS_PLATFORM=$(GetPlatform)
readonly NAS_QPKG_ARCH=$(GetQpkgArch)
readonly NAS_RAM_KB=$(GetInstalledRAM)
readonly NAS_UPSTATE=$(GetUpState)
OS.IsSupportSecureDownload || CURL_CMD+=' --insecure'
readonly CURL_CMD
args=()
args_incomplete=()
useropt_branch=$(/sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf)
readonly OBJECTS_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
readonly PACKAGES_ARCHIVE_URL='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/packages.tar.gz
readonly QPKG_BU_PATH=$(GetDefVol)/.qpkg_config_backup
readonly THIS_PACKAGE_PATH=$(QPKG.GetInstallationPath)
if [[ -z $THIS_PACKAGE_PATH || $THIS_PACKAGE_PATH = undefined || ! -d $THIS_PACKAGE_PATH ]];then
ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1
fi
readonly CACHE_PATH=$THIS_PACKAGE_PATH/cache
readonly ACTION_TIMES_PATH=$CACHE_PATH/action.times
readonly DISPLAY_INHIBIT_PATHFILE=$CACHE_PATH/display.inhibit
readonly IPK_CACHE_PATH=$CACHE_PATH/IPKs
readonly IPK_DL_PATH=$CACHE_PATH/IPKs.downloads
readonly IPK_DOWNGRADE_DL_PATH=$CACHE_PATH/IPKs.downgrade
readonly PIP_CACHE_PATH=$CACHE_PATH/PIPs
readonly OBJECTS_ARCHIVE_PATHFILE=$CACHE_PATH/objects.tar.gz
readonly OBJECTS_PATHFILE=$CACHE_PATH/objects
readonly PACKAGES_ARCHIVE_PATHFILE=$CACHE_PATH/packages.tar.gz
readonly PACKAGES_PATHFILE=$CACHE_PATH/packages
readonly PREV_IPK_LIST=$CACHE_PATH/ipk.list.save
readonly PREV_PIP_LIST=$CACHE_PATH/pip.list.save
readonly QPKG_DL_PATH=$CACHE_PATH/QPKGs.downloads
readonly LOGS_PATH=$THIS_PACKAGE_PATH/logs
readonly RAMDISKS_FREESPACE_PATHFILE=$LOGS_PATH/ramdisks.freespace
readonly SCREEN_SESSIONS_PATHFILE=$LOGS_PATH/screen.sessions
readonly SESS_ACTION_RESULTS_PATHFILE=$LOGS_PATH/session.action.results.log
readonly SESS_ARCHIVE_PATHFILE=$LOGS_PATH/session.archive.log
readonly SESS_LAST_PATHFILE=$LOGS_PATH/session.last.log
readonly SESS_TAIL_PATHFILE=$LOGS_PATH/session.tail.log
sess_active_pathfile=$THIS_PACKAGE_PATH/session.$$.active.log
readonly ACTION_FORKS_COUNT=/var/run/sherpa/actions/forks
readonly ACTION_LOGS_PATH=/var/log/sherpa/actions/logs
readonly QPKG_STATES_PATH=/var/run/sherpa/packages/states
readonly ACTION_ABORT_PATHFILE=$QPKG_STATES_PATH/abort.action
readonly ACTION_MSG_PIPE=$QPKG_STATES_PATH/action.messages.pipe
readonly REPORTS_PATH=/var/log/sherpa/reports
readonly REPORT_OUTPUT_PATHFILE=$REPORTS_PATH/report.ansi
readonly RUN_LOGS_PATH=/var/run/sherpa/run.logs
readonly THIS_PACKAGE_VER=$(QPKG.Local.GetVer)
readonly THIS_SCRIPT_VER='240303'-$useropt_branch
readonly EXTERNAL_PACKAGES_ARCHIVE_PATHFILE=/opt/var/opkg-lists/entware
readonly EXTERNAL_PACKAGES_PATHFILE=$CACHE_PATH/Packages
ln -fns /proc/self/fd /dev/fd
[[ -e $PYTHON3_CMD && ! -L $PYTHON_CMD ]] && ln -s "$PYTHON3_CMD" "$PYTHON_CMD"
rm -f "$REPORT_OUTPUT_PATHFILE" "$RAMDISKS_FREESPACE_PATHFILE" "$DISPLAY_INHIBIT_PATHFILE"
if [[ -e $GNU_STTY_CMD && -t 0 ]];then
local terminal_dimensions=$($GNU_STTY_CMD size)
readonly SESS_ROWS=${terminal_dimensions% *}
readonly SESS_COLS=${terminal_dimensions#* }
else
readonly SESS_ROWS=40
readonly SESS_COLS=156
fi
}
Lists:Load()
{
[[ ${lists_loaded:=false} = false ]] || return 0
PACKAGE_TIERS=(independent auxiliary dependent)
QPKG_IS_STATES=(active backedup downloaded enabled installed missing signed slow unknown)
QPKG_ISNT_STATES=(active backedup downloaded enabled installed missing signed)
QPKG_STATES_TRANSIENT=(starting stopping restarting)
QPKG_SERVICE_RESULTS=(ok failed)
IPK_STATES=(downgraded downloaded installed reinstalled upgraded)
QPKG_ACTIONS=(status list rebuild reassign download backup deactivate disable uninstall upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
IPK_ACTIONS=(downgrade download uninstall upgrade reinstall install)
PIP_ACTIONS=(download uninstall upgrade reinstall install)
USER_QPKG_ACTIONS=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall restore sign status uninstall upgrade)
USER_QPKG_IS_STATES=(active backedup enabled installed missing)
USER_QPKG_ISNT_STATES=(active backedup enabled installed missing)
USER_QPKG_IS_GROUPS=(all canbackup canclean canrestarttoupdate dependent hasdependents independent installable upgradable)
USER_QPKG_ISNT_GROUPS=(canclean installable upgradable)
readonly PACKAGE_TIERS
readonly QPKG_IS_STATES
readonly QPKG_ISNT_STATES
readonly QPKG_STATES_TRANSIENT
readonly QPKG_SERVICE_RESULTS
readonly IPK_STATES
readonly QPKG_ACTIONS
readonly IPK_ACTIONS
readonly PIP_ACTIONS
readonly USER_QPKG_ACTIONS
readonly USER_QPKG_IS_STATES
readonly USER_QPKG_ISNT_STATES
readonly USER_QPKG_IS_GROUPS
readonly USER_QPKG_ISNT_GROUPS
local action=''
for action in "${QPKG_ACTIONS[@]}" check debug downgrade update;do
readonly "$(Uppercase "$action")"_LOG_FILE=$action.log
done
lists_loaded=true
}
Paths:Create()
{
ClearPath "$CACHE_PATH" "$IPK_CACHE_PATH"
ClearPath "$CACHE_PATH" "$IPK_DL_PATH"
ClearPath "$CACHE_PATH" "$PIP_CACHE_PATH"
MakePath "$ACTION_TIMES_PATH" 'action times' || return
MakePath "$CACHE_PATH" cache || return
MakePath "$IPK_CACHE_PATH" 'IPK cache' || return
MakePath "$IPK_DL_PATH" 'IPK download' || return
MakePath "$IPK_DOWNGRADE_DL_PATH" 'IPK downgrade' || return
MakePath "$LOGS_PATH" logs || return
MakePath "$PIP_CACHE_PATH" 'PIP cache' || return
MakePath "$REPORTS_PATH" reports || return
MakePath "$QPKG_BU_PATH" 'QPKG backup' || return
MakePath "$QPKG_DL_PATH" 'QPKG download' || return
}
Debug.Log:Env()
{
[[ $run_package_actions = true ]] || return 0
[[ $useropt_debug = true ]] || return 0
Func:Init
ShowAsProc 'logging environment'
DebugInfoMinSepr
DebugHardware ok model "$(get_display_name)"
DebugHardware ok CPU "$(GetCPUInfo)"
DebugHardware ok 'CPU cores' "$CPU_CORES"
DebugHardware ok 'CPU architecture' "$NAS_ARCH"
DebugHardware ok RAM "$(FormatAsThous "$NAS_RAM_KB")kiB"
DebugFirmware ok OS "$(GetQnapOS)"
if OS.IsSupported;then
DebugFirmware ok version "$NAS_FIRMWARE_VER.$NAS_FIRMWARE_BUILD"
else
DebugFirmware warning version "$NAS_FIRMWARE_VER"
fi
if OS.IsCompatibleWithSigned;then
DebugFirmware ok 'build date' "$NAS_FIRMWARE_DATE"
else
DebugFirmware warning 'build date' "$NAS_FIRMWARE_DATE"
fi
DebugFirmware ok 'kernel version' "$(GetKernelVersion)"
if OS.IsStdKernelPageSize;then
DebugFirmware ok 'kernel page size' "$KERNEL_PAGE_SIZE"
else
DebugFirmware warning 'kernel page size' "$KERNEL_PAGE_SIZE"
fi
DebugFirmware ok platform "$NAS_PLATFORM"
case $NAS_UPSTATE in
starting-up|shutting-down)
DebugFirmware warning 'OS state' "$NAS_UPSTATE"
;;
*)
DebugFirmware ok 'OS state' "$NAS_UPSTATE"
esac
DebugFirmware ok 'OS uptime' "$(GetUptime)"
if OS.IsLoadAverageElevated;then
DebugFirmware warning 'system load' "$(GetSysLoadAverages)"
else
DebugFirmware ok 'system load' "$(GetSysLoadAverages)"
fi
if OS.IsSupportSudo;then
DebugUserspace ok '$SUDO_UID' "$(GetSudoUID)"
else
DebugUserspace ok '$SUDO_UID' 'N/A'
fi
DebugUserspace ok '$EUID' "$EUID"
DebugUserspace ok 'time in shell' "$(GetTimeInShell)"
DebugUserspace ok '$BASH_VERSION' "$BASH_VERSION"
DebugUserspace ok 'default volume' "$(GetDefVol)"
DebugUserspace ok '/opt' "$($READLINK_CMD /opt 2>/dev/null || printf 'not present')"
local public_share=$(/sbin/getcfg SHARE_DEF defPublic -d Qpublic -f /etc/config/def_share.info)
if [[ -L /share/$public_share ]];then
DebugUserspace ok "'$public_share' share" "/share/$public_share"
else
DebugUserspace warning "'$public_share' share" 'not present'
fi
if [[ ${#PATH} -le $DEBUG_LOG_THIRD_COL_WIDTH ]];then
DebugUserspace ok '$PATH' "$PATH"
else
DebugUserspace ok '$PATH (LHS-only)' "${PATH:0:$((DEBUG_LOG_THIRD_COL_WIDTH-${#CHARS_ELLIPSIS}))}${CHARS_ELLIPSIS}"
fi
DebugBinPathVerAndMinVer python "$(GetPythonVer)" "${MIN_PYTHON_VER:-undefined}"
DebugBinPathVerAndMinVer python3 "$(GetPython3Ver)" "${MIN_PYTHON_VER:-undefined}"
DebugBinPathVerAndMinVer perl "$(GetPerlVer)" "${MIN_PERL_VER:-undefined}"
DebugScript 'git branch' "$useropt_branch"
DebugScript 'logs path' "$LOGS_PATH"
DebugScript 'action concurrency' "$CONCURRENCY"
if OS.IsSupportSignedPackages;then
if OS.IsAllowUnsignedPackages;then
DebugQpkg detect 'allow unsigned' yes
else
DebugQpkg detect 'allow unsigned' no
fi
else
DebugQpkg detect 'allow unsigned' 'N/A'
fi
DebugQpkg detect architecture "$NAS_QPKG_ARCH"
DebugQpkg detect "$(ShowAsPackageName Entware) type" "$ENTWARE_VER"
DebugQpkg detect "$(ShowAsPackageName Entware) install date" "$(QPKG.GetInstallDate Entware)"
if QPKG.IsInstalled SortMyQPKGs;then
DebugQpkg detect "$(ShowAsPackageName SortMyQPKGs)" installed
else
DebugQpkg warning "$(ShowAsPackageName SortMyQPKGs)" 'not installed'
fi
if OS.IsSupportQpkgTimeout;then
if QPKG.IsInstalled IncreaseTimeouts;then
if QPKGs.IsTimeoutsIncreased;then
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" 'N/A'
fi
DebugInfoMinSepr
RunAndLog "$DF_CMD -h | $GREP_CMD '^Filesystem\|^none\|^tmpfs\|ram'" "$RAMDISKS_FREESPACE_PATHFILE"
DebugInfoMinSepr
RunAndLog "$SCREEN_CMD -ls" "$SCREEN_SESSIONS_PATHFILE" '' 1
DebugInfoMinSepr
Func:Exit
}
Tasks:Check()
{
if [[ $arg_problem = true || $useropt_help_basic = true ]];then
generate_action_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
run_package_actions=false
fi
[[ $get_qpkg_states = true ]] || return 0
Func:Init
local action=''
local build_states=false
local group=''
local state=''
if [[ $useropt_check = true || $useropt_show_status = true ]];then
build_states=true
elif [[ $useropt_show_dependencies = true || $useropt_show_packages = true || $useropt_show_repos = true ]];then
build_states=true
elif [[ $useropt_help_actions = true || $useropt_help_actions_all = true || $useropt_help_groups = true || $useropt_help_lists = true || $useropt_help_options = true || $useropt_help_packages = true || $useropt_help_problems = true || $useropt_help_tips = true || $useropt_help_upgrades = true || $useropt_show_results = true ]];then
:
else
Packages:Load
for action in "${USER_QPKG_ACTIONS[@]}";do
if QPKGs-AC${action}-to.IsAny;then
build_states=true
break
fi
for group in "${USER_QPKG_IS_GROUPS[@]}";do
if QPKGs.AC${action}.GR${group}.IsSet;then
build_states=true
break 2
fi
done
for group in "${USER_QPKG_ISNT_GROUPS[@]}";do
if QPKGs.AC${action}.GRNT${group}.IsSet;then
build_states=true
break 2
fi
done
for state in "${USER_QPKG_IS_STATES[@]}";do
if QPKGs.AC${action}.IS${state}.IsSet;then
build_states=true
break 2
fi
done
for state in "${USER_QPKG_ISNT_STATES[@]}";do
if QPKGs.AC${action}.ISNT${state}.IsSet;then
build_states=true
break 2
fi
done
done
fi
if [[ $build_states = true ]];then
QPKGs.States:Build
else
get_qpkg_states=false
run_package_actions=false
fi
Func:Exit
}
Env:Validate()
{
[[ $run_package_actions = true ]] || return 0
Func:Init
ShowAsProc 'validate environment'
local installed_ver=''
local target_packages=''
if QPKG.IsInstalled Entware;then
if [[ $ENTWARE_VER != none ]];then
UpdateEntwarePackageList &
else
DebugAsWarn "$(ShowAsPackageName Entware) appears to be installed but is inactive. Please consider starting the $(ShowAsPackageName Entware) QPKG."
fi
fi
if [[ $useropt_check = true ]] || QPKGs-ACupgrade-to.Exist Entware;then
ipks_upgrade=true
ipks_install=true
pips_install=true
if [[ -e $PYTHON3_CMD ]];then
installed_ver=$(GetPython3Ver "$PYTHON3_CMD")
if [[ ${installed_ver//./} -lt $MIN_PYTHON_VER ]];then
ShowAsNote "the $(TextBrightOrange Python) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'python*'
fi
fi
if [[ -e $PERL_CMD ]];then
installed_ver=$(GetPerlVer "$PERL_CMD")
if [[ ${installed_ver//./} -lt $MIN_PERL_VER ]];then
ShowAsNote "the $(TextBrightOrange Perl) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'perl*'
fi
fi
fi
if OS.IsNonStdKernelPageSize;then
case $NAS_QPKG_ARCH in
a41)
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($OPKG_CMD list-installed | $GREP_CMD "^${target_packages%% *} *" | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]];then
ipks_downgrade=true
ShowAsNote "IPKs will be downgraded to suit $KERNEL_PAGE_SIZE kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
esac
fi
QPKGs.IsCanBackup:Build
QPKGs.IsCanRestartToUpdate:Build
QPKGs.IsCanClean:Build
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-GRupgradable.Exist sherpa;then
ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded"
QPKGs-ACupgrade-to:Add sherpa
fi
wait 2>/dev/null
Func:Exit
}
QPKGs:AssignToActions()
{
[[ $run_package_actions = true ]] || return 0
Func:Init
ShowAsProc 'QPKG assignment'
local action=''
local package=''
local prospect=''
if QPKG.IsInstalled Entware;then
local entware_install_date=$(QPKG.GetInstallDate Entware)
if [[ $entware_install_date = undefined || ${entware_install_date//[!0-9]/} -le 20240224 ]];then
ShowAsNote "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were updated late February 2024)"
QPKGs-ACreinstall-to:Add Entware
fi
fi
if QPKGs-ACrebuild-to.IsAny;then
for package in $(QPKGs-ACrebuild-to:Array);do
if QPKGs-ISNTinstalled.Exist "$package" && QPKG.IsBackupExist "$package";then
QPKGs-ACinstall-to:Add "$package"
QPKGs-ACrestore-to:Add "$package"
fi
done
fi
for action in upgrade reinstall install;do
for package in $(QPKGs-AC${action}-to:Array);do
for prospect in $(QPKG.GetDependencies "$package");do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
done
done
for package in $(QPKGs-ISinstalled:Array);do
if [[ $useropt_check = true ]] || QPKGs-ACactivate-to.Exist "$package";then
for prospect in $(QPKG.GetDependencies "$package");do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for package in $(QPKGs-ACreinstall-to:Array) $(QPKGs-ACreactivate-to:Array) $(QPKGs-ACupgrade-to:Array);do
if QPKGs-GRindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package";then
for prospect in $(QPKG.GetDependents "$package");do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for package in $(QPKGs-ACdeactivate-to:Array) $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package";then
for prospect in $(QPKG.GetDependents "$package");do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
for package in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$package" && QPKGs-ISinstalled.Exist "$package";then
if QPKGs-ACinstall-to.Exist "$package";then
for prospect in $(QPKG.GetDependents "$package");do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
fi
done
if QPKGs-ACreinstall-to.Exist Entware;then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for action in reinstall install activate reactivate;do
for package in $(QPKGs-AC${action}-to:Array);do
for prospect in $(QPKG.GetDependencies "$package");do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
done
done
done
if QPKGs.ACuninstall.GRall.IsSet;then
QPKGs-ACdeactivate-to:Init
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACdeactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
QPKGs-ACactivate-to:Remove "$(QPKGs-ACreactivate-to:Array)"
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then
for package in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-ISinstalled.Exist "$package" && QPKGs-ACinstall-to.Exist "$package";then
QPKGs_were_installed_name+=("$package")
QPKGs_were_installed_path+=("$($DIRNAME_CMD "$(QPKG.GetInstallationPath "$package")")")
fi
done
fi
for package in sherpa Entware;do
QPKGs-ACupgrade-to.Exist "$package" && QPKGs-ACreactivate-to:Add "$package"
done
QPKGs-ACdownload-to:Add "$(QPKGs-ACupgrade-to:Array) $(QPKGs-ACreinstall-to:Array) $(QPKGs-ACinstall-to:Array)"
if [[ $useropt_check = true ]] && OS.IsSupportSignedPackages;then
QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
for package in $(QPKGs-GRdependent:Array);do
QPKGs-ISenabled.Exist "$package" && QPKGs-ACreactivate-to:Add "$package"
done
fi
if QPKGs-ACsign-to.IsAny || QPKGs-ACinstall-to.IsAny;then
QPKG.Signing:Load
fi
Func:Exit
}
Actions:Proc()
{
[[ $run_package_actions = true ]] || return
Func:Init
ShowAsProc 'package actions'
local tier=''
local action=''
local state=''
local -i tier_index=0
rm -f "$SESS_ACTION_RESULTS_PATHFILE"
Action:Proc status all QPKG statusing statused
if [[ $useropt_show_status = false ]];then
ShowAsProc 'assigning QPKGs by status'
for action in "${USER_QPKG_ACTIONS[@]}";do
for state in "${USER_QPKG_IS_STATES[@]}";do
QPKGs.AC${action}.IS${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
done
for state in "${USER_QPKG_ISNT_STATES[@]}";do
QPKGs.AC${action}.ISNT${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
done
done
fi
Action:Proc rebuild all QPKG meta-rebuilding meta-rebuilt
Action:Proc reassign all QPKG reassigning reassigned
Action:Proc download all QPKG downloading downloaded
Action:Proc backup all QPKG backing-up backed-up
for ((tier_index=${#PACKAGE_TIERS[@]}-1;tier_index>=0; tier_index--)); do
tier=${PACKAGE_TIERS[$tier_index]}
case $tier in
independent|dependent)
Action:Proc deactivate $tier QPKG deactivating deactivated
Action:Proc disable $tier QPKG disabling disabled
Action:Proc uninstall $tier QPKG uninstalling uninstalled
esac
done
for tier in "${PACKAGE_TIERS[@]}";do
case $tier in
independent|dependent)
Action:Proc upgrade $tier QPKG upgrading upgraded
Action:Proc reinstall $tier QPKG reinstalling reinstalled
Action:Proc install $tier QPKG installing installed
Action:Proc enableau $tier QPKG 'enabling auto-update' 'enabled auto-update'
Action:Proc disableau $tier QPKG 'disabling auto-update' 'disabled auto-update'
Action:Proc sign $tier QPKG '"signing"' '"signed"'
Action:Proc restore $tier QPKG restoring restored
Action:Proc clean $tier QPKG cleaning cleaned
Action:Proc enable $tier QPKG enabling enabled
Action:Proc reactivate $tier QPKG reactivating reactivated
Action:Proc activate $tier QPKG activating activated
;;
auxiliary)
for action in install reinstall upgrade activate;do
if (QPKGs-ACinstall-ok.Exist Entware) || QPKGs-AC${action}-to.IsAny && QPKGs-ISenabled.Exist Entware;then
ipks_upgrade=true
ipks_install=true
ipks_downgrade=true
pips_install=true
break
fi
done
if QPKGs-ISenabled.Exist Entware;then
ModPathToEntware
Action:Proc upgrade $tier IPK upgrading upgraded
Action:Proc install $tier IPK installing installed
Action:Proc downgrade $tier IPK downgrading downgraded
Action:Proc install $tier PIP installing installed
fi
esac
done
if [[ $useropt_debug = true ]];then
IPKs.Actions:List
QPKGs.Actions:List
fi
if [[ $title_shown = true ]];then
if Error.IsNt;then
ShowAsDone 'actions complete'
else
ShowAsFail 'actions complete with errors'
fi
fi
Func:Exit
}
Action:Proc()
{
Func:Init
local -r ACTION_PAST=${5:?${FUNCNAME[0]}'()': undefined action past}
local -r ACTION_PRESENT_MSG=${4:?${FUNCNAME[0]}'()': undefined action present}
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local original_colourful=$useropt_colourful
local package=''
local -i package_index=0
local -r PACKAGE_TYPE=${3:?${FUNCNAME[0]}'()': undefined package type}
local state=''
local -r TARGET_ACTION=${1:?${FUNCNAME[0]}'()': undefined action}
local -a target_packages=()
local -r TIER=${2:?${FUNCNAME[0]}'()': undefined tier}
total_count=0
DebugVar TARGET_ACTION
DebugVar TIER
DebugVar PACKAGE_TYPE
case $PACKAGE_TYPE in
QPKG)
TARGET_OBJECT_NAME=AC${TARGET_ACTION}-to
if [[ $TIER = all ]];then
target_packages=($(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array))
else
for package in $(${PACKAGE_TYPE}s-$TARGET_OBJECT_NAME:Array);do
${PACKAGE_TYPE}s-GR${TIER}.Exist "$package" && target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]];then
DebugInfo 'nothing to process'
Func:Exit;return
fi
if [[ $total_count -eq 1 ]];then
fork_progress_prefix="$ACTION_PRESENT_MSG ${target_packages[0]}"
else
fork_progress_prefix="$ACTION_PRESENT_MSG $([[ $TIER != all ]] && echo "$TIER ")$(Uppercase "$PACKAGE_TYPE")$(Pluralise "$total_count")"
fi
ShowAsProc "$fork_progress_prefix"
AdjustMaxForks "$TARGET_ACTION"
InitForkCounts
OpenActionMsgPipe
re=\\bEntware\\b
if [[ $TARGET_ACTION = uninstall && ${target_packages[*]} =~ $re ]];then
Keystrokes:Show
fi
_LaunchOneActionWithManyForks_ "_${PACKAGE_TYPE}:${TARGET_ACTION}_" "${target_packages[@]}" &
fork_pid=$!
while [[ ${#target_packages[@]} -gt 0 ]];do
ReadFromActionMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
env)
eval "$msg1_value"
;;
change)
while true;do
for group in "${USER_QPKG_IS_GROUPS[@]}";do
case $msg1_value in
"SC${group}")
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Add "$msg2_value"
break 2
esac
done
for group in "${USER_QPKG_ISNT_GROUPS[@]}";do
case $msg1_value in
"GRNT${group}")
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac
done
for state in "${QPKG_IS_STATES[@]}";do
case $msg1_value in
"IS${state}")
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${QPKG_ISNT_STATES[@]}";do
case $msg1_value in
"ISNT${state}")
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break
done
;;
status)
case $msg1_value in
ok)
[[ $TARGET_ACTION != status ]] && ((ok_count++))
;;
so)
((skip_ok_count++))
;;
sk)
((skip_count++))
;;
se)
((skip_error_count++))
;;
sa)
((skip_abort_count++))
$TOUCH_CMD "$ACTION_ABORT_PATHFILE"
break
;;
er)
((fail_count++))
esac
case $msg1_value in
ok|so|sk|se|sa|er)
[[ $(type -t QPKGs-AC${TARGET_ACTION}-to:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-to:Remove "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-${msg1_value}:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-${msg1_value}:Add "$msg2_value"
[[ $(type -t QPKGs-AC${TARGET_ACTION}-dn:Init) = function ]] && QPKGs-AC${TARGET_ACTION}-dn:Add "$msg2_value"
;;
ex)
for package_index in "${!target_packages[@]}";do
if [[ ${target_packages[package_index]} = "$msg2_value" ]];then
unset 'target_packages[package_index]'
break
fi
done
;;
*)
DebugAsWarn "unidentified status in message queue: '$msg1_value'"
esac
;;
*)
DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
done
[[ $fail_count -gt 0 ]] && show_package_actions_failed=true
[[ $ok_count -gt 0 ]] && show_package_actions_ok=true
[[ $skip_count -gt 0 || $skip_ok_count -gt 0 || $skip_error_count -gt 0 || $skip_abort_count -gt 0 ]] && show_package_actions_skipped=true
[[ ${#target_packages[@]} -gt 0 ]] && KillActiveFork
wait 2>/dev/null
CloseActionMsgPipe
;;
IPK|PIP)
if [[ $ipks_upgrade = true || $ipks_install = true || $ipks_downgrade || $pips_install = true ]];then
InitForkCounts
${PACKAGE_TYPE}s:${TARGET_ACTION}
fi
esac
EraseForkCountPaths
Func:Exit
Error.IsNt
}
OpenActionMsgPipe()
{
[[ -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE"
[[ ! -p $ACTION_MSG_PIPE ]] && mknod "$ACTION_MSG_PIPE" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd<>$ACTION_MSG_PIPE"
}
CloseActionMsgPipe()
{
[[ $backup_stdin_fd != none ]] && eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]] && eval "exec $backup_stdin_fd>&-"
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd>&-"
[[ -p $ACTION_MSG_PIPE ]] && rm -f "$ACTION_MSG_PIPE"
}
AdjustMaxForks()
{
max_forks=$CONCURRENCY
local reason=''
if [[ $useropt_verbose = true ]];then
max_forks=1
reason='verbose mode is active'
elif [[ $useropt_debug = true ]];then
max_forks=1
reason='debug mode is active'
else
case ${1:-} in
clean)
max_forks=$(((max_forks+1)/2))
reason="'$1'"
;;
install|reinstall|upgrade)
max_forks=1
reason="'$1'"
;;
backup|deactivate|download|uninstall)
max_forks=4
reason="'$1'"
;;
disable|disableau|enable|enableau|rebuild|sign|status)
max_forks=8
reason="'$1'"
esac
[[ -n $reason ]] && reason+=' action was requested'
fi
[[ -n $reason ]] && DebugInfo "limiting \$max_forks to $max_forks because $reason"
DebugVar max_forks
}
PrepareArgs()
{
local a=$(Lowercase "${ARGS_RAW//,/ }")
args=(${a/--/})
arg_problem=false
[[ -z $ARGS_RAW ]] && useropt_help_basic=true
}
ParseManagementArgs()
{
Func:Init
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local new_action=''
local requires_group=false
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
case $arg in
reset)
new_action=reset
requires_group=false
DeleteSetting Colourful
DeleteSetting Git_Branch
DeleteSetting Terse
Reset
;;
c|check)
generate_show_report=true
get_qpkg_states=true
new_action=check
requires_group=false
run_package_actions=true
useropt_check=true
;;
color|colour|colorful|colourful|follow|paste|terse)
new_action=$arg
requires_group=true
;;
debug|dbug)
new_action=debug
requires_group=false
EnableDebugToArchiveAndFile
;;
v|verbose)
new_action=verbose
requires_group=false
Verbose:Enable
EnableDebugToArchiveAndFile
;;
*)
new_action=''
esac
if [[ -n $new_action && $new_action != "$action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$action")
[[ $requires_group = false ]] && awaiting_group=false || awaiting_group=true
action=$new_action
group=''
continue
fi
case $arg in
stable|unstable)
[[ -z $action ]] && action=follow
group=$arg
;;
all|log|tail)
group=tail
;;
disable|false|no|off)
group=false
;;
l|last)
group=last
;;
enable|on|true|yes)
group=true
esac
if [[ -n $action && -n $group ]];then
case $action in
color|colour|colorful|colourful)
case $group in
true|false)
action=''
awaiting_group=false
user_colourful_value=$group
switch_colour=true
UpdateColourful
;;
*)
args_remaining+=("$action")
esac
;;
follow)
case $group in
stable|unstable)
action=''
awaiting_group=false
run_package_actions=false
user_branch_value=$group
switch_branch=true
UpdateBranch
;;
*)
args_remaining+=("$arg")
esac
;;
paste)
case $group in
last)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_last=true
;;
tail)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_tail=true
;;
*)
args_remaining+=("$arg")
esac
;;
terse)
case $group in
true|false)
action=''
awaiting_group=false
user_terse_value=$group
switch_terse=true
UpdateTerse
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$action")
fi
args=(${args_remaining[@]:-})
Func:Exit
}
ParseHelpArgs()
{
Func:Init
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local group=''
local new_action=''
local requires_group=false
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
case $arg in
help)
new_action=help
requires_group=true
;;
*)
new_action=''
esac
if [[ -n $new_action && $new_action != "$action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$action")
[[ $requires_group = false ]] && awaiting_group=false || awaiting_group=true
action=$new_action
group=''
continue
fi
case $arg in
lists)
[[ -z $action ]] && action=help
group=lists
;;
packages|qpkgs)
group=packages
;;
problems)
[[ -z $action ]] && action=help
group=problems
;;
tips)
[[ -z $action ]] && action=help
group=tips
;;
a|abs|abbreviations)
group=abs
;;
action|actions)
[[ -z $action ]] && action=help
group=actions
;;
all)
group=all-actions
;;
actions-all|all-actions)
[[ -z $action ]] && action=help
group=all-actions
;;
group|groups)
[[ -z $action ]] && action=help
group=groups
;;
o|option|options)
[[ -z $action ]] && action=help
group=options
;;
upgrade)
group=upgrades
;;
upgrades|upgrading)
[[ -z $action ]] && action=help
group=upgrades
esac
if [[ -n $action && -n $group ]];then
case $action in
help)
case $group in
abs)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true
;;
actions)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true
;;
all-actions)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true
;;
groups)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true
;;
lists)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true
;;
options)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true
;;
packages)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true
;;
problems)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true
;;
tips)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true
;;
upgrades)
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true
;;
*)
args_remaining+=("$arg")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$action")
fi
for arg in "${args_incomplete[@]:-}";do
case $arg in
help)
run_package_actions=false
useropt_help_basic=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
Func:Exit
}
ParseShowArgs()
{
Func:Init
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local group=''
local new_action=''
local requires_group=false
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
case $arg in
show|view)
new_action=show
requires_group=true
;;
*)
new_action=''
esac
if [[ -n $new_action && $new_action != "$action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$action")
[[ $requires_group = false ]] && awaiting_group=false || awaiting_group=true
action=$new_action
group=''
continue
fi
case $arg in
backups|results)
[[ -z $action ]] && action=show
group=$arg
;;
a|abs|abbreviations)
group=abs
;;
deps)
group=dependencies
;;
d|dependencies)
[[ -z $action ]] && action=show
group=dependencies
;;
l|last)
[[ -z $action ]] && action=show
group=last
;;
log|tail)
[[ -z $action ]] && action=show
group=tail
;;
p|packages|qpkgs)
[[ -z $action ]] && action=show
group=packages
;;
r|repos|repositories)
[[ -z $action ]] && action=show
group=repositories
;;
s|status|statuses)
group=status
;;
esac
if [[ -n $action && -n $group ]];then
case $action in
show)
case $group in
abs)
awaiting_group=false
generate_help_report=true
get_qpkg_states=false
run_package_actions=false
useropt_help_abbreviations=true
;;
backups)
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_backups=true
;;
dependencies)
Packages:Load
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true
;;
last)
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_last=true
;;
packages)
Packages:Load
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_packages=true
;;
repositories)
Packages:Load
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true
;;
results)
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_results=true
;;
status)
Objects:Load
QPKGs.ACstatus.GRall:Set
awaiting_group=false
generate_show_report=true
useropt_show_status=true
;;
tail)
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_tail=true
;;
*)
args_remaining+=("$arg")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$action")
fi
args=(${args_remaining[@]:-})
Func:Exit
}
ParseListArgs()
{
Func:Init
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local group=''
local new_action=''
local requires_group=false
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
case $arg in
list)
new_action=$arg
group=''
requires_group=true
;;
*)
new_action=''
esac
if [[ -n $new_action && $new_action != "$action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$action")
[[ $requires_group = false ]] && awaiting_group=false || awaiting_group=true
action=$new_action
group=''
continue
fi
case $arg in
backedup|installable|installed|missing|results)
group=${arg}
;;
not-backedup)
group=NTbackedup
;;
not-installed)
group=NTinstalled
;;
a|abs|abbreviations)
[[ -z $action ]] && action=list
group=abs
;;
active|started)
group=active
;;
all|entire|everything)
group=all
;;
b|backups)
group=backups
;;
deps|dependent|dependents)
group=dependent
;;
disabled)
group=NTenabled
;;
inactive|not-active|stopped)
group=NTactive
;;
new|updatable|updateable|upgradable)
group=upgradable
;;
non-installable|not-installable)
group=NTinstallable
;;
independent|independents|indeps)
group=independent
;;
version|versions)
group=versions
esac
if [[ -n $action && -n $group ]];then
case $action in
show)
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_backups=true
;;
list)
case $group in
abs)
awaiting_group=false
generate_help_report=true
get_qpkg_states=true
run_package_actions=false
useropt_help_abbreviations=true
;;
active|NTactive)
Objects:Load
QPKGs.AClist.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
awaiting_group=false
generate_list_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
show_title=false
;;
backedup|installed|NTbackedup|NTinstalled)
Objects:Load
QPKGs.AClist.IS${group}:Set
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
dependent|disabled|installable|independent|NTinstallable|upgradable)
Objects:Load
QPKGs.AClist.GR${group}:Set
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
versions)
awaiting_group=false
generate_list_report=true
show_title=false
useropt_show_versions=true
;;
*)
args_remaining+=("$arg")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$action")
fi
args=(${args_remaining[@]:-})
Func:Exit
}
ParseActionArgs()
{
Func:Init
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local group=''
local new_action=''
local real_action=''
local requires_group=false
[[ -n ${args[*]:-} ]] && Packages:Load
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
case $arg in
backup|clean|disable|enable|reassign|rebuild|reinstall|restore|sign)
new_action=$arg
requires_group=true
;;
disable-auto-update)
new_action=disableau
requires_group=true
;;
enable-auto-update)
new_action=enableau
requires_group=true
;;
activate|deactivate|reactivate|restart|start|stop)
new_action=$arg
requires_group=true
;;
add|install)
new_action=install
requires_group=true
;;
rm|remove|uninstall)
new_action=uninstall
requires_group=true
;;
s|status|statuses)
new_action=status
requires_group=true
useropt_show_status=true
;;
update|upgrade)
new_action=upgrade
requires_group=true
;;
*)
new_action=''
esac
if [[ -n $new_action && $new_action != "$action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$action")
[[ $requires_group = false ]] && awaiting_group=false || awaiting_group=true
action=$new_action
group=''
continue
fi
case $action in
activate|start)
real_action=activate
;;
deactivate|stop)
real_action=deactivate
;;
reactivate|restart)
real_action=reactivate
;;
*)
real_action=$action
esac
case $arg in
backedup|installable|installed|missing)
group=$arg
;;
not-backedup)
group=NTbackedup
;;
not-installed)
group=NTinstalled
;;
active|started)
group=active
;;
all|everything)
group=all
;;
deps|dependent|dependents)
group=dependent
;;
disabled)
group=NTenabled
;;
inactive|not-active|stopped)
group=NTactive
;;
new|updatable|updateable|upgradable)
group=upgradable
;;
non-installable|not-installable)
group=NTinstallable
;;
independent|independents|indeps)
group=independent
;;
*)
group=$(QPKG.MatchAbbrv "$arg")
esac
if [[ -n $real_action && -n $group ]];then
case $real_action in
activate|backup|clean|deactivate|disable|enable|reactivate|reinstall|restore|sign|uninstall|upgrade)
case $group in
active|NTactive)
Objects:Load
QPKGs.AC${real_action}.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
awaiting_group=false
generate_action_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
esac
esac
case $group in
all|canbackup|canclean|canrestarttoupdate|dependent|hasdependents|independent|installable|upgradable|NTcanclean|NTinstallable|NTupgradable)
Objects:Load
QPKGs.AC${real_action}.GR${group}:Set
awaiting_group=false
generate_action_report=true
get_qpkg_active_status=false
get_qpkg_states=true
run_package_actions=true
;;
backedup|enabled|installed|missing|NTbackedup|NTenabled|NTinstalled)
Objects:Load
QPKGs.AC${real_action}.IS${group}:Set
awaiting_group=false
generate_action_report=true
get_qpkg_states=true
run_package_actions=true
;;
*)
Objects:Load
QPKGs-AC${real_action}-to:Add "$group"
awaiting_group=false
generate_action_report=true
get_qpkg_states=true
run_package_actions=true
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$action")
fi
for arg in "${args_incomplete[@]:-}";do
case $arg in
status)
Objects:Load
QPKGs.ACstatus.GRall:Set
generate_show_report=true
get_qpkg_states=true
run_package_actions=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
Func:Exit
}
ArgSuggestions:Show()
{
Func:Init
local arg=''
local -a args_remaining=()
if [[ ${#args_incomplete[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args_incomplete[@]}";do
case $arg in
activate|backup|deactivate|restart|reactivate|start|stop|uninstall)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false
;;
color|colour|colorful|colourful|terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
arg_problem=true
useropt_help_basic=false
;;
follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to 'follow' like" 'follow stable'
DisplayAsProjSynIndentExam '' 'follow unstable'
arg_problem=true
useropt_help_basic=false
;;
list)
DisplayAsProjSynExam "please provide a valid source to 'list' like" 'list installable'
arg_problem=true
useropt_help_basic=false
;;
paste)
DisplayAsProjSynExam "please provide a valid source to 'paste' online like" 'paste log'
DisplayAsProjSynIndentExam '' 'paste last'
arg_problem=true
useropt_help_basic=false
;;
show)
DisplayAsProjSynExam "please provide a valid source after 'show' like" 'show packages'
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && echo
ShowAsError "incomplete argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
args_remaining=()
fi
fi
if [[ ${#args[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args[@]}";do
case $arg in
false|off|on|true)
DisplayAsProjSynExam "please provide a valid setting before '$arg' like" "colour $arg"
arg_problem=true
useropt_help_basic=false
;;
all)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before 'all' like" 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed package configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false
;;
dependent)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before 'dependent' like" 'activate dependents'
arg_problem=true
useropt_help_basic=false
;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all packages, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false
;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed package configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false
;;
independent)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before 'independent' like" 'activate independents'
arg_problem=true
useropt_help_basic=false
;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all packages, use' 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all packages, use' 'stop all'
arg_problem=true
useropt_help_basic=false
;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all packages, use' 'force uninstall all'
arg_problem=true
useropt_help_basic=false
;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all packages, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && echo
ShowAsError "unknown argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
useropt_help_basic=false
fi
fi
[[ $arg_problem = true ]] && echo
Func:Exit
}
AllocPackGroupsToAcs()
{
Func:Init
ShowAsProc 'matching QPKG groups to actions'
local action=''
local found=false
local group=''
local prospect=''
for action in "${USER_QPKG_ACTIONS[@]}";do
for group in "${USER_QPKG_IS_GROUPS[@]}";do
found=false
if QPKGs.AC${action}.GR${group}.IsSet;then
case $action in
clean)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-GR${group}:Array);do
QPKG.IsCanClean "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "group 'GR$group' has no positive allocation handler for action '$action'"
esac
;;
install|status)
case $group in
all|dependent|independent)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
;;
*)
DebugAsWarn "group 'GR$group' has no positive allocation handler for action '$action'"
esac
;;
activate|deactivate|disable|disableau|enable|enableau|reactivate|reinstall|stop|uninstall)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-GR${group}:Array);do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "group 'GR$group' has no positive allocation handler for action '$action'"
esac
;;
rebuild)
case $group in
all|dependent|independent)
found=true
for prospect in $(QPKGs-GR${group}:Array);do
QPKGs-GRcanbackup.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
;;
*)
DebugAsWarn "group 'GR$group' has no positive allocation handler for action '$action'"
esac
;;
upgrade)
case $group in
all|dependent|independent|upgradable)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-GRupgradable:Array)"
for prospect in $(QPKGs-GR${group}:Array);do
QPKGs-GRcanrestarttoupdate.Exist "$prospect" && QPKGs-AC${action}-to:Add "$prospect"
done
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACupgrade-to:Array)"
;;
*)
DebugAsWarn "group 'GR$group' has no positive allocation handler for action '$action'"
esac
;;
*)
DebugAsWarn "action '$action' has no positive group allocation handler"
esac
if [[ $found = false ]];then
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GR$group': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any GR packages to '$(Lowercase "$action")'"
fi
fi
done
for group in "${USER_QPKG_ISNT_GROUPS[@]}";do
found=false
if QPKGs.AC${action}.GRNT${group}.IsSet;then
case $action in
*)
DebugAsWarn "action '$action' has no negative group allocation handler"
esac
if [[ $found = false ]];then
QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any GRNT packages to '$(Lowercase "$action")'"
fi
fi
done
done
Func:Exit
}
AllocPackStatesToAcs()
{
Func:Init
ShowAsProc 'matching QPKG states to actions'
local action=''
local check_later=false
local found=false
local state=''
for action in "${USER_QPKG_ACTIONS[@]}";do
for state in "${USER_QPKG_IS_STATES[@]}";do
found=false
check_later=false
if QPKGs.AC${action}.IS${state}.IsSet;then
case $action in
backup|clean|uninstall|upgrade)
case $state in
backedup|cleaned|downloaded|enabled|installed)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
;;
*)
DebugAsWarn "state 'IS$state' has no positive allocation handler for action '$action'"
esac
;;
list)
check_later=true
found=true
;;
*)
DebugAsWarn "action '$action' has no positive state allocation handler"
esac
if [[ $found = false ]];then
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-packages later after 'status' has been determined"
else
ShowAsWarn "unable to find any IS packages to '$(Lowercase "$action")'"
fi
fi
done
for state in "${USER_QPKG_ISNT_STATES[@]}";do
found=false
check_later=false
if QPKGs.AC${action}.ISNT${state}.IsSet;then
case $action in
activate|backup|clean|disableau|enableau|install|uninstall)
case $state in
active|inactive)
check_later=true
found=true
;;
enabled|installed)
found=true
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
;;
*)
DebugAsWarn "state 'ISNT$state' has no negative allocation handler for action '$action'"
esac
;;
list)
check_later=true
found=true
;;
*)
DebugAsWarn "action '$action' has no negative state allocation handler"
esac
if [[ $found = false ]];then
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-packages later after 'status' has been determined"
else
ShowAsWarn "unable to find any ISNT packages to '$(Lowercase "$action")'"
fi
fi
done
done
Func:Exit
}
ResetArchivedLogs()
{
if [[ -n $LOGS_PATH && -d $LOGS_PATH ]];then
ClearPath "$THIS_PACKAGE_PATH" "$LOGS_PATH"
echo 'log reset' > "$sess_active_pathfile"
ShowAsDone 'logs cleared'
fi
return 0
}
ResetCachePath()
{
if [[ -n $CACHE_PATH && -d $CACHE_PATH ]];then
ClearPath "$THIS_PACKAGE_PATH" "$CACHE_PATH"
ShowAsDone 'package cache cleared'
fi
return 0
}
ResetReportsPath()
{
if [[ -n $REPORTS_PATH && -d $REPORTS_PATH ]];then
ClearPath /var/log/sherpa "$REPORTS_PATH"
ShowAsDone 'reports cleared'
fi
return 0
}
Quiz()
{
local prompt=${1:?${FUNCNAME[0]}'()': undefined prompt}
local response=''
ShowAsQuiz "$prompt"
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD igncr
read -rn1 response
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD -igncr
DebugVar response
ShowAsQuizDone "$prompt: $response"
case ${response:0:1} in
y|Y)
return 0
;;
*)
return 1
esac
}
PatchEntwareService()
{
local -r TAB=$'\t'
local -r PREFIX='# the following line was inserted by sherpa: https://git.io/sherpa'
local -r PACKAGE_INIT_PATHFILE=$(QPKG.GetServicePathFile Entware)
local find=''
local insert=''
if $GREP_CMD -q 'opt.orig' "$PACKAGE_INIT_PATHFILE";then
DebugInfo 'patch: do the "/opt shuffle" - already done'
else
find='# sym-link $QPKG_DIR to /opt'
insert='opt_path="/opt";opt_backup_path="/opt.orig"; [[ -d "$opt_path" \&\& ! -L "$opt_path" \&\& ! -e "$opt_backup_path" ]] \&\& mv "$opt_path" "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
find='/bin/ln -sf $QPKG_DIR /opt'
insert='[[ -L "$opt_path" \&\& -d "$opt_backup_path" ]] \&\& cp "$opt_backup_path"/* --target-directory "$opt_path" \&\& rm -r "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${TAB}${PREFIX}\n${TAB}${insert}\n|" "$PACKAGE_INIT_PATHFILE"
DebugAsDone 'patch: do the "opt shuffle"'
fi
return 0
}
UpdateEntwarePackageList()
{
if IsNtSysFileExist $OPKG_CMD;then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${ENTWARE_PACKAGE_LIST_UPTODATE:-false} = false ]] || return
local -i z=0
if ! IsThisFileRecent "$EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES" || [[ ! -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE || $useropt_check = true ]];then
DebugAsProc "updating $(ShowAsPackageName Entware) package list"
RunAndLog "$OPKG_CMD update" "$LOGS_PATH/Entware.$UPDATE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
DebugAsDone "updated $(ShowAsPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(ShowAsPackageName Entware) package list $(ShowAsExitcode "$z")"
fi
else
DebugInfo "$(ShowAsPackageName Entware) package list was updated less-than $FILE_CHANGE_THRESHOLD_MINUTES minutes ago: skipping update"
fi
[[ -f $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE && ! -f $EXTERNAL_PACKAGES_PATHFILE ]] && OpenIpkArchive
readonly ENTWARE_PACKAGE_LIST_UPTODATE=true
return 0
}
IsThisFileRecent()
{
[[ -e ${1:-} && $((($(/bin/date +%s)-$(/usr/bin/stat "$1" -c %Z))/60)) -le ${2:-1440} ]]
}
SaveEntwarePackageList()
{
$PIP_CMD freeze > "$PREV_PIP_LIST"
[[ -e $PREV_PIP_LIST ]] && DebugAsDone "saved current PIP module list to $(ShowAsFileName "$PREV_PIP_LIST")"
$OPKG_CMD list-installed > "$PREV_IPK_LIST"
[[ -e $PREV_IPK_LIST ]] && DebugAsDone "saved current $(ShowAsPackageName Entware) IPK list to $(ShowAsFileName "$PREV_IPK_LIST")"
} 2>/dev/null
LoadEntwarePackageList()
{
local name=''
local separator=''
local version=''
if [[ -e $PREV_IPK_LIST ]];then
while read -r name separator version;do
IPKs-ACinstall-to:Add "$name"
done < "$PREV_IPK_LIST"
fi
}
CalcIpkDepsToInstall()
{
IsSysFileExist $GNU_GREP_CMD || return
Func:Init
local complete=false
local -a dep_acc=()
local element=''
local -i iterations=0
local -r ITERATION_LIMIT=20
local -i pre_exclude_count=0
local pre_exclude_list=''
local req_list=''
local -i requested_count=0
local -a this_list=()
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$($WC_CMD -w <<< "$req_list")
if [[ $requested_count -eq 0 ]];then
DebugAsWarn 'no IPKs requested'
Func:Exit 1;return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
ShowAsProc 'resolving IPK dependencies'
while [[ $iterations -lt $ITERATION_LIMIT ]];do
ShowAsIterativeProgress 'resolving IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique package'
((iterations++))
local ipk_titles=$(printf '^Package: %s$\|' "${this_list[@]}")
ipk_titles=${ipk_titles%??}
this_list=($($GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD -vG '^Section:\|^Version:' | $GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator "$ipk_titles" | $GNU_GREP_CMD -vG "$ipk_titles" | $GNU_GREP_CMD -vG '^Package: ' | $SED_CMD 's|^Depends: ||;s|, |\n|g' | $SORT_CMD | $UNIQ_CMD))
ShowAsIterativeProgress 'resolving IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique package'
if [[ ${#this_list[@]} -eq 0 ]];then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
if [[ $complete = true ]];then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$ITERATION_LIMIT [$ITERATION_LIMIT]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$($WC_CMD -w <<< "$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]];then
ShowAsProc 'excluding IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do
if [[ $element != 'ca-certs' && $element != 'python3-gdbm' ]];then
if [[ $element != 'libjpeg' ]];then
if ! $OPKG_CMD status "$element" | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $OPKG_CMD status 'libjpeg-turbo' | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
Func:Exit
}
CalcIpkDownloadSize()
{
Func:Init
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]];then
ShowAsProc "calculating size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($GNU_GREP_CMD -w '^Package:\|^Size:' "$EXTERNAL_PACKAGES_PATHFILE" | $GNU_GREP_CMD --after-context 1 --no-group-separator ": $($SED_CMD 's/ /$ /g;s/\$ /\$\\\|: /g' <<< "$(IPKs-ACdownload-to:List)")" | $GREP_CMD '^Size:' | $SED_CMD 's|^Size: ||'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$((${size_array[*]:-}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
Func:Exit
}
IPKs:upgrade()
{
[[ $ipks_upgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
Error.IsNt || return
Func:Init
local desc=''
local log_pathfile=$LOGS_PATH/ipks.$UPGRADE_LOG_FILE
local -i total_count=0
local -i z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($OPKG_CMD list-upgradable | cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK module$(Pluralise "$total_count")"
ShowAsProc "upgrading $desc"
_DirSizeMonitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillActiveFork
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultToLog IPK "$desc" upgrade ok "$z"
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultToLog IPK "$desc" upgrade failed "$z"
fi
fi
Func:Exit $z
}
IPKs:install()
{
[[ $ipks_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
Error.IsNt || return
Func:Init
local desc=''
local -i i=0
local log_pathfile=$LOGS_PATH/ipks.$INSTALL_LOG_FILE
local previous=''
local -i total_count=0
local -i z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware || ([[ $useropt_check = true ]] && QPKG.IsInstalled Entware);then
IPKs-ACinstall-to:Add "$ESSENTIAL_IPKS"
if [[ -e $PREV_IPK_LIST ]];then
LoadEntwarePackageList
mv "$PREV_IPK_LIST" "$PREV_IPK_LIST.installing"
fi
fi
if QPKGs.ACinstall.GRall.IsSet;then
for i in "${!QPKG_NAME[@]}";do
[[ $previous = "${QPKG_NAME[$i]}" ]] && continue || previous=${QPKG_NAME[$i]}
IPKs-ACinstall-to:Add "$(QPKG.GetIPKs "${QPKG_NAME[$i]}" "$i")"
done
else
for i in "${!QPKG_NAME[@]}";do
[[ $previous = "${QPKG_NAME[$i]}" ]] && continue || previous=${QPKG_NAME[$i]}
if QPKGs-ACinstall-to.Exist "${QPKG_NAME[$i]}" || QPKGs-ISinstalled.Exist "${QPKG_NAME[$i]}" || QPKGs-ACreinstall-to.Exist "${QPKG_NAME[$i]}" || (QPKGs-ACactivate-to.Exist "${QPKG_NAME[$i]}" && (QPKGs-ACinstall-to.Exist "${QPKG_NAME[$i]}" || QPKGs-ISinstalled.Exist "${QPKG_NAME[$i]}" || QPKGs-ACreinstall-to.Exist "${QPKG_NAME[$i]}"));then
QPKG.IsMinOSVerOk "${QPKG_NAME[$i]}" || continue
QPKG.IsMinRAMOk "${QPKG_NAME[$i]}" || continue
IPKs-ACinstall-to:Add "$(QPKG.GetIPKs "${QPKG_NAME[$i]}" "$i")"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK module$(Pluralise "$total_count")"
ShowAsProc "installing $desc"
_DirSizeMonitor_ "$IPK_DL_PATH" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD install --force-overwrite $(IPKs-ACdownload-to:List) --cache $IPK_CACHE_PATH --tmp-dir $IPK_DL_PATH" "$log_pathfile" log:failure-only
z=$?
KillActiveFork
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultToLog IPK "$desc" install ok "$z"
Keystrokes:Hide
UpdateColourisation
if [[ -e $PREV_IPK_LIST.installing ]];then
rm "$PREV_IPK_LIST.installing"
fi
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultToLog IPK "$desc" install failed "$z"
if [[ -e $PREV_IPK_LIST.installing ]];then
mv "$PREV_IPK_LIST.installing" "$PREV_IPK_LIST"
fi
fi
fi
Func:Exit $z
}
IPKs:downgrade()
{
[[ $ipks_downgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
Error.IsNt || return
Func:Init
local desc=''
local -i fail_count=0
local log_pathfile=''
local name=''
local -i ok_count=0
local package_type=''
local remote_url=''
local -i total_count=0
local url_prefix=''
local url_suffix=''
local -i z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
if [[ $total_count -gt 0 ]];then
package_type='auxiliary IPK module'
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNLOAD_LOG_FILE
ShowAsProc "downloading $desc"
if OS.IsNonStdKernelPageSize;then
url_prefix=http://bin.entware.net
url_suffix=_2.38-1
case $NAS_QPKG_ARCH in
a41)
url_prefix+='/armv7sf-k3.2'
url_suffix+='_armv7-3.2'
esac
url_prefix+=/archive/
url_suffix+=.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "downloading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$IPK_DOWNGRADE_DL_PATH/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "downloading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
total_count=1
ok_count=0
fail_count=0
package_type='auxiliary IPK group'
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$LOGS_PATH/ipks.$DOWNGRADE_LOG_FILE
ShowAsProc "downgrading $desc"
ShowAsPercentProgress "downgrading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
RunAndLog "$OPKG_CMD install --force-downgrade --cache $IPK_CACHE_PATH --tmp-dir $IPK_DOWNGRADE_DL_PATH $IPK_DOWNGRADE_DL_PATH/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultToLog IPK "$desc" downgrade ok "$z"
else
((fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultToLog IPK "$desc" downgrade failed "$z"
fi
ShowAsPercentProgress "downgrading $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
Func:Exit $z
}
PIPs:install()
{
[[ $pips_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
$OPKG_CMD status python3-pip | $GREP_CMD -q "Status:.*installed" || return
Error.IsNt || return
Func:Init
local desc=''
local exec_cmd=''
local -i fail_count=0
local log_pathfile=$LOGS_PATH/pypi.$INSTALL_LOG_FILE
local -i ok_count=0
local package_type='auxiliary PyPI group'
local -i total_count=0
local -i z=0
if [[ $useropt_check = true ]] || IPKs-ACinstall-ok.Exist python3-pip;then
((total_count++))
exec_cmd="$PIP_CMD install --upgrade --no-input $ESSENTIAL_PIPS --cache-dir $PIP_CACHE_PATH 2> >($GREP_CMD -v \"Running pip as the 'root' user\") >&2"
desc='auxiliary PyPI modules'
ShowAsProc "installing $total_count ${package_type}$(Pluralise "$total_count")"
ShowAsPercentProgress "installing $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 0 "$total_count"
RunAndLog "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
DebugAsDone "installed $desc"
SaveActionResultToLog PIP "$desc" install ok "$z"
else
((fail_count++))
SaveActionResultToLog PIP "$desc" install failed "$z"
fi
ShowAsPercentProgress "installing $total_count ${package_type}$(Pluralise "$total_count")" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
Func:Exit $z
}
OpenIpkArchive()
{
if [[ ! -e $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE ]];then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
RunAndLog "/usr/local/sbin/7z e -o$($DIRNAME_CMD "$EXTERNAL_PACKAGES_PATHFILE") $EXTERNAL_PACKAGES_ARCHIVE_PATHFILE" "$CACHE_PATH/ipk.archive.extract" log:failure-only
if [[ ! -e $EXTERNAL_PACKAGES_PATHFILE ]];then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0
}
CloseIpkArchive()
{
rm -f "$EXTERNAL_PACKAGES_PATHFILE"
}
_LaunchOneActionWithManyForks_()
{
local a=${1:-function null}
local b=''
shift
local -a c=("$@")
for b in "${c[@]}";do
while [[ $fork_count -ge $max_forks && ! -e $ACTION_ABORT_PATHFILE ]];do
sleep .2
UpdateForkProgress
done
[[ -e $ACTION_ABORT_PATHFILE ]] && exit
IncForkProgressIndex
MarkThisActionForkAsStarted
$a "$b" &
DebugAsDone "forked $a() for '$b'"
UpdateForkProgress
done
while [[ $fork_count -gt 0 ]];do
sleep .2
UpdateForkProgress
done
}
_DirSizeMonitor_()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} ]] || exit
[[ -d $1 && ${2:-0} -gt 0 ]] || exit
IsSysFileExist $GNU_FIND_CMD || exit
local -i current_bytes=-1
local -i last_bytes=0
local perc_msg=''
local progress_msg=''
local stall_msg=''
local -i stall_seconds=0
local -i stall_seconds_threshold=4
local -i total_bytes=${2:-0}
InitProgress
while [[ $current_bytes -lt $total_bytes ]];do
current_bytes=$($GNU_FIND_CMD "$1" -type f -name '*.ipk' -exec $DU_CMD --bytes --total --apparent-size {} + 2>/dev/null | $GREP_CMD total$ | cut -f1)
[[ -z $current_bytes ]] && current_bytes=0
if [[ $current_bytes -ne $last_bytes ]];then
stall_seconds=0
last_bytes=$current_bytes
else
((stall_seconds++))
fi
perc_msg="$((200*(current_bytes)/(total_bytes)%2+100*(current_bytes)/(total_bytes)))%"
[[ $current_bytes -lt $total_bytes && $perc_msg = '100%' ]] && perc_msg='99%'
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$total_bytes")"))"
if [[ $stall_seconds -ge $stall_seconds_threshold ]];then
stall_msg=' stalled for '
if [[ $stall_seconds -lt 60 ]];then
stall_msg+="$stall_seconds seconds"
else
stall_msg+=$(FormatSecsToHoursMinutesSecs "$stall_seconds")
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg=$(TextBrightRed "$stall_msg")
elif [[ $stall_seconds -ge 45 ]];then
stall_msg=$(TextBrightOrange "$stall_msg")
elif [[ $stall_seconds -ge 20 ]];then
stall_msg=$(TextBrightYellow "$stall_msg")
fi
progress_msg+=$stall_msg
fi
[[ ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
WriteMsgInPlace "$progress_msg"
sleep 1
done
[[ -n $progress_msg ]] && WriteMsgInPlace 'done!'
}
WriteMsgInPlace()
{
local -i a=0
local b=$(tr -s ' ' <<< "${1:-}")
local c=$(StripANSICodes "$b")
if [[ $c != "$prev_clean_msg" ]];then
if [[ ${#c} -lt ${#prev_clean_msg} ]];then
a=$((${#c}-${#prev_clean_msg}))
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"; printf "%${a}s"; printf "%${a}s" | tr ' ' '\b'
else
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"
fi
prev_clean_msg=$c
fi
}
KillActiveFork()
{
if [[ -n ${fork_pid:-} && ${fork_pid:-0} -gt 0 && -d /proc/$fork_pid ]];then
sleep .2
set +m
kill -9 "$fork_pid"
set -m
wait
fi
} &>/dev/null
Reset()
{
ResetCachePath
ResetReportsPath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
exit 0
}
UpdateColourful()
{
local a=''
if [[ $switch_colour = true && -n $user_colourful_value ]];then
for a in true false;do
[[ $a != "$user_colourful_value" ]] && continue
useropt_colourful=$user_colourful_value
if [[ ${1:-} = silent ]];then
SaveSetting Colourful "$useropt_colourful"
else
SaveSetting Colourful "$useropt_colourful" announce
fi
switch_colour=false
return
done
ShowAsAbort "user setting '$user_colourful_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
UpdateBranch()
{
local a=''
if [[ $switch_branch = true && -n $user_branch_value ]];then
for a in unstable stable;do
[[ $a != "$user_branch_value" ]] && continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then
SaveSetting Git_Branch "$useropt_branch"
else
SaveSetting Git_Branch "$useropt_branch" announce
Reset
fi
switch_branch=false
return
done
ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1
fi
}
UpdateTerse()
{
local a=''
if [[ $switch_terse = true && -n $user_terse_value ]];then
for a in true false;do
[[ $a != "$user_terse_value" ]] && continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then
SaveSetting Terse "$useropt_terse"
else
SaveSetting Terse "$useropt_terse" announce
fi
switch_terse=false
return
done
ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
SaveSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined value}")
case $b in
true|false)
b=$(Uppercase "$b")
esac
/sbin/setcfg sherpa "$a" "$b" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]] && ShowAsDone "user setting '$a = $b' has been saved"
}
LoadSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined default value}")
Lowercase "$(/sbin/getcfg sherpa "$a" -d "$b" -f /etc/config/qpkg.conf)"
}
DeleteSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
/sbin/setcfg -e sherpa "$a" -f /etc/config/qpkg.conf
}
User.IsOk()
{
if ! User.IsSU;then
if OS.IsSupportSudo;then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${CHARS_SUDO_PROMPT}sherpa $ARGS_RAW" >&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again"
fi
return 1
fi
return 0
}
User.IsSU()
{
[[ $EUID -eq 0 ]]
}
DebugBinPathVerAndMinVer()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined filename} ]] || return
local a=$(GetThisBinPath "$1")
if [[ -n $a ]];then
DebugUserspace ok "'$1' path" "$a"
else
DebugUserspace warning "'$1' path" 'not present'
fi
if [[ -n ${2:-} && ${2:-undefined} != undefined ]];then
[[ -n ${3:-} && ${3:-undefined} != undefined ]] || return
if [[ ${2//./} -ge ${3//./} ]];then
DebugUserspace ok "'$1' version" "$2"
else
DebugUserspace warning "'$1' version" "$2"
fi
else
DebugUserspace warning "'$1' version" 'undefined'
fi
return 0
}
IsSysFileExist()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined pathfile} ]] || exit
local a=${1%% *}
if ! [[ -f $a || -L $a ]];then
ShowAsAbort "a required NAS system file is missing $(ShowAsFileName "$a")"
return 1
fi
return 0
}
IsNtSysFileExist()
{
! IsSysFileExist "${1:?${FUNCNAME[0]}'()': undefined pathfile}"
}
LenANSIDiff()
{
local original=${1:-}
local stripped=$(StripANSICodes "$original")
echo -n "$((${#original}-${#stripped}))"
return 0
}
CalcMaxStatusReportCols()
{
local col3_width=$((${#CHAR_SPACER}+${#CHARS_BULLET}+PACKAGE_VER_COL_WIDTH))
if QPKGs-GRupgradable.IsAny;then
package_ver_final_col_width=$((PACKAGE_VER_COL_WIDTH+6))
((col3_width+6))
else
package_ver_final_col_width=$PACKAGE_VER_COL_WIDTH
fi
return 0
}
#CalcMaxDepsReportCols()
DisplayAsProjSynExam()
{
printf "\n${CHARS_BULLET}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf "\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}%s\n" '' "sherpa ${2:-}"
}
DisplayAsProjSynIndentExam()
{
if [[ -n $1	]];then
printf "\n%${HELP_DESC_INDENT}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf '\n'
fi
printf "%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_SUDO_PREFIX}%s\n" '' "sherpa ${2:-}"
}
DisplayAsSynExam()
{
printf "\n${CHARS_BULLET}%s:\n%${HELP_SYNTAX_INDENT}s${HELP_SYNTAX_PREFIX}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}"
}
DisplayAsPacksReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}App version:"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}Description:"
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsPacksReportItemLine()
{
local app_ver_msg=$CHARS_BLANK
local description_msg=$CHARS_BLANK
local mode=''
local name=${1:?${FUNCNAME[0]}'()': undefined package name}
local description=$(QPKG.GetDesc "$name")
local notes=$(QPKG.GetNote "$name")
local name_msg=$CHARS_NORMAL
if QPKG.IsMissing "$name";then
mode=highlighted
elif QPKG.IsNtInstalled "$name";then
mode=muted
else
mode=normal
fi
app_ver_msg+=$(QPKG.App.GetVer "$name")
description_msg+="$(Capitalise "$description")."
name_msg+=$name
local notes_msg="${notes}."
case $mode in
muted)
app_ver_msg=$(TextDarkGrey "$app_ver_msg")
description_msg=$(TextDarkGrey "$description_msg")
name_msg=$(TextDarkGrey "$name_msg")
;;
highlighted)
name_msg=$(TextBrightRed "$name_msg")
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_DESCRIPTION_COL_WIDTH+$(LenANSIDiff "$description_msg")))s" "$description_msg"
if [[ -n $notes ]];then
printf "\n%$((${#CHARS_BLANK}+PACKAGE_NAME_COL_WIDTH+PACKAGE_APP_VER_COL_WIDTH+(COLUMN_SPACING*2)))s$(TextBrightOrange "${CHARS_DROPEND}${CHARS_NOTE}")%s" '' "$notes_msg"
fi
fi
printf '\n'
}
DisplayAsStatusReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}QPKG statuses:"
printf "%-$((PACKAGE_STATUS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}QPKG version"
QPKGs-GRupgradable.IsAny && a+=" ($(TextBrightOrange new))"
a+=':'
printf "%-$((${package_ver_final_col_width:=0}+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 4 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}App version:"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 5 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}QPKG installation path:"
printf "%-$((PACKAGE_PATH_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsStatusReportItemLine()
{
local app_ver_msg=$CHARS_BLANK
local mode=''
local name=${1:?${FUNCNAME[0]}'()': undefined package name}
local name_msg=$CHARS_BLANK
local path_msg=$CHARS_BLANK
local status=''
local status_msg=''
local upgrade_ver=''
local ver_msg=$CHARS_BLANK
if QPKG.IsMissing "$name";then
mode=highlighted
elif QPKG.IsNtInstalled "$name";then
mode=muted
else
mode=normal
fi
case $mode in
normal)
if QPKGs-ISenabled.Exist "$name";then
status+=" $(TextBrightGreen enabled)"
else
status+=" $(TextBrightRed disabled)"
fi
if QPKGs-ACstatus-ok.Exist "$name";then
if QPKGs-ISactive.Exist "$name";then
status+=" $(TextBrightGreen active)"
elif QPKGs-ISslow.Exist "$name";then
status+=" $(TextBrightOrange slow)"
elif QPKGs-ISstarting.Exist "$name";then
status+=" $(TextBrightOrange starting)"
elif QPKGs-ISstopping.Exist "$name";then
status+=" $(TextBrightOrange stopping)"
elif QPKGs-ISrestarting.Exist "$name";then
status+=" $(TextBrightOrange restarting)"
elif QPKGs-ISunknown.Exist "$name";then
status+=" $(TextBrightOrange unknown)"
else
status+=" $(TextBrightRed inactive)"
fi
else
status+=" $(TextBrightOrange unknown)"
fi
if [[ -n $status ]];then
status=$(Trim "$status")
status_msg=${status// /, }
fi
status_msg=${CHARS_NORMAL}${status_msg}
QPKGs-GRupgradable.Exist "$name" && upgrade_ver=$(QPKG.Avail.GetVer "$name")
ver_msg+=$(QPKG.Local.GetVer "$name")
if [[ -n $upgrade_ver ]];then
ver_msg+=" ($(TextBrightOrange "$upgrade_ver"))"
name_msg+=$(TextBrightOrange "$name")
else
name_msg+=$name
fi
app_ver_msg+=$(QPKG.App.GetVer "$name")
path_msg+=$(QPKG.GetInstallationPath "$name")
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name";then
status='incompatible arch'
ver_msg=''
app_ver_msg=''
elif ! QPKG.IsMinOSVerOk "$name";then
status="incompatible $(GetQnapOS) version"
ver_msg=''
app_ver_msg=''
elif ! QPKG.IsMinRAMOk "$name";then
status='insufficient RAM'
ver_msg=''
app_ver_msg=''
else
status='not installed'
ver_msg+=$(TextDarkGrey "$(QPKG.Avail.GetVer "$name")")
app_ver_msg+=$(TextDarkGrey "$(QPKG.App.GetVer "$name")")
fi
status_msg=$(TextDarkGrey "${CHARS_NORMAL}${status}")
path_msg=''
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
status_msg=$(TextBrightRedBlink "${CHARS_ALERT}missing")
ver_msg+=$(TextBrightRed "$(QPKG.Local.GetVer "$name")")
app_ver_msg+=$(TextBrightRed "$(QPKG.App.GetVer "$name")")
path_msg=$(TextBrightRedBlink "${CHARS_ALERT}$(QPKG.GetInstallationPath "$name")")
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_STATUS_COL_WIDTH+$(LenANSIDiff "$status_msg")))s" "$status_msg"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((${package_ver_final_col_width:=0}+$(LenANSIDiff "$ver_msg")))s" "$ver_msg"
fi
if [[ $max_cols -ge 4 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_APP_VER_COL_WIDTH+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
fi
if [[ $max_cols -ge 5 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_PATH_COL_WIDTH+$(LenANSIDiff "$path_msg")))s" "$path_msg"
fi
printf '\n'
}
DisplayAsReposReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}install date:"
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}repository:"
printf "%-$((PACKAGE_REPO_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsReposReportItemLine()
{
local assigned_repo_msg=$CHARS_NORMAL
local install_date_msg=$CHARS_BLANK
local mode=''
local name=${1:?${FUNCNAME[0]}'()': undefined package name}
local install_date=$(QPKG.GetInstallDate "$name")
local store_id=$(QPKG.GetStoreID "$name")
local assigned_repo=$(GetRepoURLFromStoreID "$store_id")
local name_msg=$CHARS_BLANK
if QPKG.IsMissing "$name";then
mode=highlighted
elif QPKG.IsNtInstalled "$name";then
mode=muted
else
mode=normal
fi
if [[ $store_id = sherpa ]];then
assigned_repo=sherpa
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
else
assigned_repo_msg+=$assigned_repo
fi
case $mode in
normal)
name_msg+=$name
case $install_date in
sherpa)
install_date_msg+=$(TextBrightGreen "$install_date")
;;
unassigned)
install_date_msg+=$(TextBrightOrange "$install_date")
;;
*)
install_date_msg+=$install_date
esac
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name";then
assigned_repo='incompatible arch'
elif ! QPKG.IsMinOSVerOk "$name";then
assigned_repo="incompatible $(GetQnapOS) version"
elif ! QPKG.IsMinRAMOk "$name";then
assigned_repo='insufficient RAM'
else
assigned_repo='not installed'
fi
install_date_msg+=$(TextDarkGrey "$assigned_repo")
assigned_repo=''
assigned_repo_msg=''
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
install_date_msg+=$install_date
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_INSTALL_DATE_COL_WIDTH+$(LenANSIDiff "$install_date_msg")))s" "$install_date_msg"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_REPO_COL_WIDTH+$(LenANSIDiff "$assigned_repo_msg")))s" "$assigned_repo_msg"
fi
printf '\n'
}
DisplayAsAbsReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}acceptable QPKG name abbreviations and aliases:"
printf "%-$((PACKAGE_ABBS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsAbsReportItemLine()
{
local abs=''
local abs_msg=$CHARS_NORMAL
local mode=''
local name=${1:?${FUNCNAME[0]}'()': undefined package name}
local name_msg=$CHARS_BLANK
if QPKG.IsMissing "$name";then
mode=highlighted
elif QPKG.IsNtInstalled "$name";then
mode=muted
else
mode=normal
fi
abs=$(QPKG.GetAbbrvs "$name")
if [[ -n $abs ]];then
abs=$(Trim "$abs");abs=${abs// /, }
fi
case $mode in
normal)
abs_msg+=$abs
name_msg+=$name
;;
muted)
name_msg+=$(TextDarkGrey "$name")
if ! QPKG.IsArchOK "$name";then
abs_msg+='(incompatible arch)'
elif ! QPKG.IsMinOSVerOk "$name";then
abs_msg+="(incompatible $(GetQnapOS) version)"
elif ! QPKG.IsMinRAMOk "$name";then
abs_msg+='(insufficient RAM)'
else
abs_msg+=$abs
fi
abs_msg=$(TextDarkGrey "$abs_msg")
;;
highlighted)
abs_msg=$(TextBrightRedBlink "${CHARS_ALERT}${abs}")
name_msg+=$(TextBrightRed "$name")
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ABBS_COL_WIDTH+$(LenANSIDiff "$abs_msg")))s" "$abs_msg"
fi
printf '\n'
}
DisplayAsDepsReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}QPKG name:"
printf "%-$((PACKAGE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}dependencies:"
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}installed?"
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 4 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}enabled?"
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 5 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}min RAM:"
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 6 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}min OS:"
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 7 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}max OS:"
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 8 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}supported arch?"
printf "%-$((PACKAGE_ARCH_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsDepsReportItemLine()
{
local dep=''
local mode=''
local name=${1:?${FUNCNAME[0]}'()': undefined package name}
local package_deps_raw=$(QPKG.GetDependencies "$name")
local package_max_os=$(QPKG.GetMaxOSVer "$name")
local package_min_os=$(QPKG.GetMinOSVer "$name")
local package_min_ram=$(QPKG.GetMinRAM "$name")
local name_msg=$CHARS_BLANK
local package_arch_msg=$CHARS_BLANK
local package_deps=''
local package_deps_msg=$CHARS_NORMAL
local package_enabled_msg=$CHARS_BLANK
local package_installed_msg=$CHARS_BLANK
local package_max_os_msg=$CHARS_BLANK
local package_min_os_msg=$CHARS_BLANK
local package_min_ram_msg=$CHARS_BLANK
[[ -z $package_deps_raw ]] && package_deps_raw=none
[[ -n $package_max_os && $package_max_os != none && ${#package_max_os} -eq 3 ]] && package_max_os=${package_max_os:0:1}.${package_max_os:1:1}.${package_max_os:2:1}
[[ -n $package_min_os && $package_min_os != none && ${#package_min_os} -eq 3 ]] && package_min_os=${package_min_os:0:1}.${package_min_os:1:1}.${package_min_os:2:1}
[[ $package_min_ram != none ]] && package_min_ram=$(FormatAsThous "$package_min_ram")kB
if QPKG.IsMissing "$name";then
mode=highlighted
elif QPKG.IsNtInstalled "$name";then
mode=muted
else
mode=normal
fi
case $mode in
normal)
name_msg+=$name
if [[ $package_deps_raw != none ]];then
for dep in $package_deps_raw;do
[[ -n $package_deps ]] && package_deps+=' '
if QPKG.IsInstalled "$dep" && QPKG.IsEnabled "$dep";then
package_deps+=$(TextBrightGreen "$dep")
else
package_deps+=$(TextBrightRed "$dep")
package_deps_msg=$(TextBrightRed "$CHARS_ALERT")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
done
else
package_deps+=$(TextBrightGreen "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /, }
if QPKG.IsInstalled "$name";then
package_installed_msg+=$(TextBrightGreen true)
else
package_installed_msg+=false
fi
if QPKG.IsEnabled "$name";then
package_enabled_msg+=$(TextBrightGreen true)
else
package_enabled_msg=$(TextBrightRed "$CHARS_ALERT")
package_enabled_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMinRAMOk "$name";then
package_min_ram_msg+=$(TextBrightGreen "$package_min_ram")
else
package_min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_ram_msg+=$(TextBrightRed "$package_min_ram")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMinOSVerOk "$name";then
package_min_os_msg+=$(TextBrightGreen "$package_min_os")
else
package_min_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_os_msg+=$(TextBrightRed "$package_min_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsMaxOSVerOk "$name";then
package_max_os_msg+=$(TextBrightGreen "$package_max_os")
else
package_max_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_max_os_msg+=$(TextBrightRed "$package_max_os")
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
if QPKG.IsArchOK "$name";then
package_arch_msg+=$(TextBrightGreen true)
else
package_arch_msg=$(TextBrightRed "$CHARS_ALERT")
package_arch_msg+=$(TextBrightRed false)
name_msg=${CHARS_BLANK}$(TextBrightRed "$name")
fi
;;
muted)
name_msg+=$(TextDarkGrey "$name")
package_deps_msg=$(TextDarkGrey "$CHARS_NORMAL")
if [[ $package_deps_raw != none ]];then
for dep in $package_deps_raw;do
[[ -n $package_deps ]] && package_deps+=' '
package_deps+=$(TextDarkGrey "$dep")
done
else
package_deps+=$(TextDarkGrey "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /$(TextDarkGrey ', ')}
package_installed_msg+=$(TextDarkGrey false)
package_enabled_msg+=$(TextDarkGrey 'N/A')
if QPKG.IsMinRAMOk "$name";then
package_min_ram_msg+=$(TextDarkGrey "$package_min_ram")
else
package_min_ram_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_min_ram_msg+=$(TextBrightOrange "$package_min_ram")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsMinOSVerOk "$name";then
package_min_os_msg+=$(TextDarkGrey "$package_min_os")
else
package_min_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_min_os_msg+=$(TextBrightOrange "$package_min_os")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsMaxOSVerOk "$name";then
package_max_os_msg+=$(TextDarkGrey "$package_max_os")
else
package_max_os_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_max_os_msg+=$(TextBrightOrange "$package_max_os")
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
if QPKG.IsArchOK "$name";then
package_arch_msg+=$(TextDarkGrey true)
else
package_arch_msg=$(TextBrightOrange "$CHARS_ATTENTION")
package_arch_msg+=$(TextBrightOrange false)
name_msg=${CHARS_BLANK}$(TextBrightOrange "$name")
fi
;;
highlighted)
name_msg+=$(TextBrightRed "$name")
if [[ $package_deps_raw != none ]];then
for dep in $package_deps_raw;do
[[ -n $package_deps ]] && package_deps+=' '
if QPKG.IsInstalled "$dep" && QPKG.IsEnabled "$dep";then
package_deps+=$(TextBrightGreen "$dep")
else
package_deps+=$(TextBrightRed "$dep")
fi
done
else
package_deps+=$(TextBrightGreen "$package_deps_raw")
fi
package_deps_msg+=${package_deps// /, }
package_installed_msg=$(TextBrightRedBlink "$CHARS_ALERT")
package_installed_msg+=$(TextBrightRedBlink 'missing')
if QPKG.IsEnabled "$name";then
package_enabled_msg+=$(TextBrightGreen true)
else
package_enabled_msg=$(TextBrightRedBlink "$CHARS_ALERT")
package_enabled_msg+=$(TextBrightRed 'false')
fi
if QPKG.IsMinRAMOk "$name";then
package_min_ram_msg+=$(TextBrightGreen "$package_min_ram")
else
package_min_ram_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_ram_msg+=$(TextBrightRed "$package_min_ram")
fi
if QPKG.IsMinOSVerOk "$name";then
package_min_os_msg+=$(TextBrightGreen "$package_min_os")
else
package_min_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_min_os_msg+=$(TextBrightRed "$package_min_os")
fi
if QPKG.IsMaxOSVerOk "$name";then
package_max_os_msg+=$(TextBrightGreen "$package_max_os")
else
package_max_os_msg=$(TextBrightRed "$CHARS_ALERT")
package_max_os_msg+=$(TextBrightRed "$package_max_os")
fi
if QPKG.IsArchOK "$name";then
package_arch_msg+=$(TextBrightGreen true)
else
package_arch_msg=$(TextBrightRed "$CHARS_ALERT")
package_arch_msg+=$(TextBrightRed false)
fi
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((PACKAGE_NAME_COL_WIDTH+$(LenANSIDiff "$name_msg")))s" "$name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_DEPENDENCIES_COL_WIDTH+$(LenANSIDiff "$package_deps_msg")))s" "$package_deps_msg"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_INSTALLED_COL_WIDTH+$(LenANSIDiff "$package_installed_msg")))s" "$package_installed_msg"
fi
if [[ $max_cols -ge 4 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ENABLED_COL_WIDTH+$(LenANSIDiff "$package_enabled_msg")))s" "$package_enabled_msg"
fi
if [[ $max_cols -ge 5 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MIN_RAM_COL_WIDTH+$(LenANSIDiff "$package_min_ram_msg")))s" "$package_min_ram_msg"
fi
if [[ $max_cols -ge 6 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MIN_OS_COL_WIDTH+$(LenANSIDiff "$package_min_os_msg")))s" "$package_min_os_msg"
fi
if [[ $max_cols -ge 7 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_MAX_OS_COL_WIDTH+$(LenANSIDiff "$package_max_os_msg")))s" "$package_max_os_msg"
fi
if [[ $max_cols -ge 8 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((PACKAGE_ARCH_COL_WIDTH+$(LenANSIDiff "$package_arch_msg")))s" "$package_arch_msg"
fi
printf '\n'
}
DisplayAsBacksReportTitleLine()
{
local a=''
printf '\n'
if [[ $max_cols -ge 1 ]];then
a="${CHARS_BULLET}Backup file:"
printf "%-$((FILE_NAME_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}size in bytes:"
printf "%-$((FILE_BYTES_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
a="${CHARS_BULLET}last backup date:"
printf "%-$((FILE_CHANGE_DATE_COL_WIDTH+2+$(LenANSIDiff "$a")))s" "$a"
fi
printf '\n'
}
DisplayAsBacksReportItemLine()
{
local epoch_time=${1:-0}
local epoch_time_msg=$CHARS_NORMAL
local file_bytes=${3:-0}
local file_bytes_msg=$CHARS_BLANK
local file_name=${2:-}
local file_name_msg=$CHARS_BLANK
local highlight_older_than=${4:-'1 week ago'}
local mode=''
if [[ ${epoch_time%.*} -lt $(/bin/date --date="$highlight_older_than" +%s) ]];then
mode=highlighted
else
mode=normal
fi
case $mode in
normal)
epoch_time_msg+=$(/bin/date -d @"$epoch_time" +%c)
file_bytes_msg+=$file_bytes
file_name_msg+=$file_name
;;
highlighted)
epoch_time_msg+=$(TextBrightRed "$(/bin/date -d @"$epoch_time" +%c)")
file_bytes_msg+=$(TextBrightRed "$file_bytes")
file_name_msg+=$(TextBrightRed "$file_name")
esac
if [[ $max_cols -ge 1 ]];then
printf "%-$((FILE_NAME_COL_WIDTH+$(LenANSIDiff "$file_name_msg")))s" "$file_name_msg"
fi
if [[ $max_cols -ge 2 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%$((FILE_BYTES_COL_WIDTH+$(LenANSIDiff "$file_bytes_msg")))s" "$file_bytes_msg "
fi
if [[ $max_cols -ge 3 ]];then
printf "%$((COLUMN_SPACING))s"
printf "%-$((FILE_CHANGE_DATE_COL_WIDTH+$(LenANSIDiff "$epoch_time_msg")))s" "$epoch_time_msg"
fi
printf '\n'
}
DisplayAsHelpTitle()
{
printf "\n${CHARS_BULLET}%s\n" "$(Capitalise "${1:-}" | tr -s ' ')"
}
DisplayAsHelpTitleHighlighted()
{
printf "\n$(TextBrightOrange "${CHARS_BULLET}%s\n")" "$(Capitalise "${1:-}")"
}
DisplayAsIndentActionResultDurationReason()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
local action=''
local duration=''
case $1 in
disableau)
action='disable auto-update'
;;
enableau)
action='enable auto-update'
;;
*)
action=$1
esac
[[ -n ${3:-} ]] && duration=$(FormatMillisecsToMinutesSecs "$3")
printf "%${ACTION_RESULT_INDENT}s" ''
if [[ -z ${4:-} ]];then
printf "%s %s%s" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")"
else
printf "%s %s%s (%s)" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")" "$4"
fi
printf '\n'
}
EraseThisLine()
{
[[ ${useropt_verbose:=false} = false ]] && printf '\033[2K\r'
} >&2
Display()
{
if [[ -z ${1:-} ]];then
printf '\n'
else
printf '%s\n' "$1"
fi
}
DisplayWait()
{
printf '%s' "${1:-}"
}
Help.Actions:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport actions
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these packages (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'check all application dependencies are installed' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clean local repository files from these packages (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these packages' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these packages. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these packages. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'install these packages' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reactivate these packages (this will upgrade internal applications where-supported)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign packages to $(ShowAsTitleName). Detach packages previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these packages ('install' packages, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these packages' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'digitally "sign" these QPKGs' "sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these packages' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these packages (this will upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all packages can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.ActionsAll:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport 'all actions'
{
Help.Basic:Show
DisplayAsHelpTitle "the 'all' group applies to all installed packages. If $(ShowAsAction) is 'install all' then all available packages will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all installed packages (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all packages (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all installed packages' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all installed packages. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on package activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all installed packages. Packages must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on package activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate packages (this will upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all packages to $(ShowAsTitleName). Detach packages previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all packages where backup files exist ('install' packages and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all installed packages' 'reinstall all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'digitally "sign" all packages' 'sign all'
DisplayAsProjSynIndentExam 'uninstall everything!' 'force uninstall all'
DisplayAsProjSynIndentExam 'upgrade all installed packages (and internal applications where-supported)' 'upgrade all'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.BackupLocation:Show()
{
DisplayAsSynExam 'the backup location can be accessed by running' "cd $QPKG_BU_PATH"
return 0
}
Help.Basic:Show()
{
DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0
}
Help.Basic.Examples:Show()
{
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show packages'
DisplayAsProjSynIndentExam '' p
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')"
Display
return 0
}
Help.Groups:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport groups
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only independent packages (these do not depend on other QPKGs)' "$(ShowAsAction) independent"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) independents"
DisplayAsProjSynIndentExam 'select only dependent packages (these require another QPKG to be installed and active)' "$(ShowAsAction) dependent"
DisplayAsProjSynIndentExam 'select only active packages' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only inactive packages' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installed packages' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only packages that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only packages that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only packages that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only packages that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing packages (these are partly installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Issue:Show()
{
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://forum.qnap.com/viewtopic.php?f=320&t=132373')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange 'log for analysis!')"
Display
return 0
}
Help.Lists:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport lists
{
Help.Basic:Show
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available packages' 'list all'
DisplayAsProjSynIndentExam 'list package backup files' 'list backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'list only packages that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed packages' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only packages that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable packages' 'list upgradable'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Report.Results:Show()
{
local action=''
local -i datetime=0
local -i duration=0
local found=false
local package_name=''
local package_type=''
local plural='these actions'
local reason=''
local result=''
local singular='this action'
{
if [[ -e $SESS_ACTION_RESULTS_PATHFILE ]];then
local IFS='|'
while read -r datetime action package_name result duration reason package_type;do
if [[ $display_last_action_datetime = true ]];then
DisplayAsHelpTitle "the following package actions were run: $(/bin/date -d @"$datetime")"
display_last_action_datetime=false
fi
if [[ $result = "$1" ]] || [[ $1 = skipped && ($result = 'skipped-ok' || $result = 'skipped-error' || $result = 'skipped-abort') ]];then
[[ $action != status ]] || continue
case $result in
ok)
[[ $found = false ]] && DisplayAsHelpTitle "$plural completed $(TextBrightGreen OK):"
;;
skipped*)
[[ $found = false ]] && DisplayAsHelpTitle "$plural were $(TextBrightOrange skipped) (and why):"
;;
failed)
[[ $found = false ]] && DisplayAsHelpTitle "$plural $(TextBrightRed failed) (and why):"
esac
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason"
found=true
fi
done < "$SESS_ACTION_RESULTS_PATHFILE"
fi
if [[ $found = false ]];then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK)."
;;
skipped)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped)."
;;
failed)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
} > "$REPORT_OUTPUT_PATHFILE"
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
$CAT_CMD "$REPORT_OUTPUT_PATHFILE"
fi
return 0
}
Help.Options:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport options
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show live debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' v
DisplayAsProjSynIndentExam 'record debugging information to file-only' "$(ShowAsAction) $(ShowAsPackages) debug"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Packages:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport packages
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for packages will go here:'
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Problems:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport problems
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'show package statuses' 'show status'
DisplayAsProjSynIndentExam '' s
DisplayAsProjSynIndentExam 'show live debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' v
DisplayAsProjSynIndentExam 'record debugging information to file-only' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam 'ensure all dependencies exist for installed packages' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clear local repository files from these packages' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'reactivate all installed packages (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'enable then activate these packages' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'stop then disable these packages (disabling will prevent them starting on reboot)' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")"
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Upgrades:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport upgrades
{
Help.Basic:Show
DisplayAsHelpTitle 'usage examples for upgrading your packages:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable packages' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable packages' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'show package statuses' 'show status'
DisplayAsProjSynIndentExam '' s
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Help.Tips:Show()
{
DisableDebugToArchiveAndFile
DisplayProcReport tips
{
Help.Basic:Show
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) packages" 'install all'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all installed packages (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only packages that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive packages' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
Help.BackupLocation:Show
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
return 0
}
Log.Last:View()
{
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
EraseThisLine
if [[ -e $SESS_LAST_PATHFILE ]];then
DisplayFileInViewport "$SESS_LAST_PATHFILE" linenumbers
Display
else
ShowAsError 'no last session log to display'
fi
return 0
}
Log.Tail:View()
{
DisableDebugToArchiveAndFile
ExtractTailFromLog
EraseThisLine
if [[ -e $SESS_TAIL_PATHFILE ]];then
DisplayFileInViewport "$SESS_TAIL_PATHFILE" linenumbers
Display
else
ShowAsError 'no session log tail to display'
fi
return 0
}
DisplayFileInViewport()
{
local filename=${1:-}
local jumptoend=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local showlinenumbers=false
local wraplines=false
if [[ ! -e $filename ]];then
echo "filename '$filename' not found"
return 1
fi
case 'linenumbers' in
${2:-}|${3:-}|${4:-})
showlinenumbers=true
esac
case 'jumptoend' in
${2:-}|${3:-}|${4:-})
jumptoend=true
esac
case 'wrap' in
${2:-}|${3:-}|${4:-})
wraplines=true
esac
if [[ $useropt_verbose = true ]];then
if [[ -e $CAT_CMD ]];then
$CAT_CMD "$filename"
return
else
echo "$(<$1)"
return
fi
fi
if [[ $($WC_CMD -l < "$filename") -ge $SESS_ROWS ]];then
if [[ -e $GNU_LESS_CMD ]];then
options=' --quit-on-intr --tilde --mouse --RAW-CONTROL-CHARS --shift 4 --redraw-on-quit --quit-if-one-screen'
[[ $wraplines = false ]] && options+=' --chop-long-lines'
[[ $showlinenumbers = true ]] && options+=' --LINE-NUMBERS'
[[ $jumptoend = true ]] && options+=' +G'
LESSSECURE=1 ${GNU_LESS_CMD}${options} --prompt "$prompt" "$filename"
return
fi
if [[ -e $LESS_CMD ]];then
options=' -~'
[[ $wraplines = false ]] && options+='S'
[[ $showlinenumbers = true ]] && options+='N'
${LESS_CMD}${options} "$filename"
return
fi
fi
if [[ -e $CAT_CMD ]];then
[[ $showlinenumbers = true ]] && options+=' --number'
${CAT_CMD}${options} "$filename"
return
elif [[ -e $MORE_CMD ]];then
$MORE_CMD "$filename"
return
fi
echo "$(<$1)"
}
Log.Last:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $SESS_LAST_PATHFILE ]];then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "uploading $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$SESS_LAST_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_zero_qpkgs=false
return 1
fi
else
ShowAsError 'no last session log found'
fi
return 0
}
Log.Tail:Paste()
{
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]];then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$LOG_TAIL_LINES") lines in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "uploading $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$SESS_TAIL_PATHFILE" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_zero_qpkgs=false
return 1
fi
else
ShowAsError 'no session log tail found'
fi
return 0
}
GetLogSessStartLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*started:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | $HEAD_CMD -n1 | cut -d':' -f1)-1))
[[ $linenum -lt 1 ]] && linenum=1
echo -n "$linenum"
}
GetLogSessFinishLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*finished:' "$SESS_TAIL_PATHFILE" | $TAIL_CMD -n${1:-1} | cut -d':' -f1)+2))
[[ $linenum -eq 2 ]] && linenum=3
echo -n "$linenum"
}
ArchiveActiveSessLog()
{
[[ -n ${sess_active_pathfile:-} && -e $sess_active_pathfile ]] && $CAT_CMD "$sess_active_pathfile" >> "$SESS_ARCHIVE_PATHFILE"
}
ArchivePriorSessLogs()
{
local f=''
for f in "$THIS_PACKAGE_PATH"/session.*.active.log;do
if [[ -f $f && $f != "$sess_active_pathfile" ]];then
$CAT_CMD "$f" >> "$SESS_ARCHIVE_PATHFILE"
rm -f "$f"
fi
done
}
ResetActiveSessLog()
{
rm -f "$sess_active_pathfile"
}
ExtractPrevSessFromTail()
{
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
local -i start_line=0
ExtractTailFromLog
if [[ -e $SESS_TAIL_PATHFILE ]];then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]];do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]] && break
done
$SED_CMD "$start_line,$end_line!d" "$SESS_TAIL_PATHFILE" > "$SESS_LAST_PATHFILE"
else
rm -f "$SESS_LAST_PATHFILE"
fi
return 0
}
ExtractTailFromLog()
{
if [[ -e $SESS_ARCHIVE_PATHFILE ]];then
$TAIL_CMD -n${LOG_TAIL_LINES} "$SESS_ARCHIVE_PATHFILE" > "$SESS_TAIL_PATHFILE"
else
rm -f "$SESS_TAIL_PATHFILE"
fi
return 0
}
Report.Versions:Show()
{
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: ${THIS_PACKAGE_VER:-undefined}"
Display "manager: ${THIS_SCRIPT_VER:-undefined}"
Display "loader: ${LOADER_SCRIPT_VER:-undefined}"
Display "objects: ${OBJECTS_VER:-undefined}"
Display "packages: ${PACKAGES_VER:-undefined}"
return 0
}
InitForkCounts()
{
MakePath "$ACTION_FORKS_COUNT" 'action forks'
proc_counts_path=$($MKTEMP_CMD -d "$ACTION_FORKS_COUNT"/"${FUNCNAME[1]}"_XXXXXX)
[[ -n ${proc_counts_path:?undefined proc counts path} ]] || return
EraseForkCountPaths
proc_fork_count_path=$proc_counts_path/fork.count
proc_ok_count_path=$proc_counts_path/ok.count
proc_skip_count_path=$proc_counts_path/skip.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_fail_count_path=$proc_counts_path/fail.count
mkdir -p "$proc_fork_count_path"
mkdir -p "$proc_ok_count_path"
mkdir -p "$proc_skip_count_path"
mkdir -p "$proc_skip_ok_count_path"
mkdir -p "$proc_skip_error_count_path"
mkdir -p "$proc_skip_abort_count_path"
mkdir -p "$proc_fail_count_path"
InitProgress
}
IncForkProgressIndex()
{
((progress_index++))
local a=$(printf '%02d' "$progress_index")
proc_fork_pathfile=$proc_fork_count_path/$a
proc_ok_pathfile=$proc_ok_count_path/$a
proc_skip_pathfile=$proc_skip_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_fail_pathfile=$proc_fail_count_path/$a
}
RefreshForkCounts()
{
fork_count=$(ls -A -1 "$proc_fork_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
ok_count=$(ls -A -1 "$proc_ok_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_count=$(ls -A -1 "$proc_skip_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_ok_count=$(ls -A -1 "$proc_skip_ok_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_error_count=$(ls -A -1 "$proc_skip_error_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_abort_count=$(ls -A -1 "$proc_skip_abort_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
fail_count=$(ls -A -1 "$proc_fail_count_path" 2>/dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
} &>/dev/null
EraseForkCountPaths()
{
ClearPath /var/run/sherpa/actions/forks "$proc_counts_path"
[[ -e $ACTION_ABORT_PATHFILE ]] && rm -f "$ACTION_ABORT_PATHFILE"
} &>/dev/null
InitProgress()
{
progress_index=0
prev_clean_msg=''
RefreshForkCounts
}
UpdateForkProgress()
{
local a=''
local b=''
RefreshForkCounts
[[ $useropt_verbose = false && ! -e $DISPLAY_INHIBIT_PATHFILE ]] || return
a=$((skip_count+skip_ok_count+skip_error_count+skip_abort_count))
b=$(PercFrac "$ok_count" "$a" "$fail_count" "$total_count")
if [[ $ok_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightGreen "$ok_count") OK"
fi
if [[ $a -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightOrange "$a") skipped"
fi
if [[ $fail_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightRed "$fail_count") failed"
fi
if [[ $fork_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightYellow "$fork_count") in-progress"
fi
[[ -n $b && ! -e $DISPLAY_INHIBIT_PATHFILE ]] && ShowAsProc "${fork_progress_prefix:-}" "$b"
return 0
} >&2
QPKGs.Missing:Show()
{
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b=' is'
c='it'
else
b='s are'
c='them'
fi
ShowAsNote "the $a QPKG${b} missing or broken. Please reinstall $c"
return 1
}
QPKGs.NewVers:Show()
{
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-GRupgradable:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-GRupgradable:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b='a '
c='version is'
else
c="version$(Pluralise "${#packages[@]}") are"
fi
ShowAsNote "${b}new QPKG $c available for $a"
return 1
}
QPKGs.Conflicts:Check()
{
[[ $run_package_actions = false ]] || return 0
local a=''
if [[ -n ${BASE_QPKG_CONFLICTS_WITH:-} ]];then
for a in "${BASE_QPKG_CONFLICTS_WITH[@]}";do
if QPKG.IsEnabled "$a";then
ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
return 1
fi
done
fi
return 0
}
QPKGs.Warnings:Check()
{
local a=''
if [[ -n ${BASE_QPKG_WARNINGS:-} ]];then
for a in "${BASE_QPKG_WARNINGS[@]}";do
if QPKG.IsEnabled "$a";then
ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
return 1
fi
done
fi
return 0
}
PIPs.Actions:List()
{
[[ $useropt_debug = true ]] || return
Func:Init
local a=''
DebugInfoMinSepr
for a in "${PIP_ACTIONS[@]}";do
PIPs-AC${a}-ok.IsAny && DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny && DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) "
done
DebugInfoMinSepr
Func:Exit
}
IPKs.Actions:List()
{
[[ $useropt_debug = true ]] || return
Func:Init
local a=''
local border_shown=false
for a in "${IPK_ACTIONS[@]}";do
if IPKs-AC${a}-ok.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) "
fi
if IPKs-AC${a}-er.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) "
fi
done
[[ $border_shown = true ]] && DebugInfoMinSepr
Func:Exit
}
QPKGs.Actions:List()
{
[[ $useropt_debug = true ]] || return
Func:Init
local a=''
local b=''
local border_shown=false
for a in "${QPKG_ACTIONS[@]}";do
for b in ok er sk so se sa;do
if QPKGs-AC${a}-${b}.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
case $b in
ok)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
sk|so|se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]] && DebugInfoMinSepr
Func:Exit
}
#QPKGs.Actions:ListAll()
QPKGs.States:List()
{
[[ $useropt_debug = true ]] || return
Func:Init
local a=''
QPKGs.States:Build
DebugInfoMinSepr
for a in "${QPKG_IS_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}";do
[[ $a = installed ]] && continue
if [[ $a = unknown ]];then
QPKGs-IS${a}.IsAny && DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
else
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
fi
done
for a in "${QPKG_ISNT_STATES[@]}" "${QPKG_SERVICE_RESULTS[@]}";do
[[ $a = installed ]] && continue
if [[ $a = ok ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
else
QPKGs-ISNT${a}.IsAny && DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
fi
done
for a in "${QPKG_STATES_TRANSIENT[@]}";do
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
done
DebugInfoMinSepr
Func:Exit
}
QPKGs.IndependentDependent:Build()
{
local a=''
for a in "${QPKG_NAME[@]}";do
if QPKG.IsDependent "$a";then
QPKGs-GRdependent:Add "$a"
else
QPKGs-GRindependent:Add "$a"
fi
done
return 0
}
QPKGs.States:Build()
{
Func:Init
local a=''
local b=''
local c=''
local f=''
if [[ ${qpkgs_states_built:=false} = true ]];then
DebugAsDone "don't build states: they're already built"
Func:Exit;return
fi
Packages:Load
QPKGs.States:Init
OS.IsStarting && ShowAsWarn "$(GetQnapOS) is starting all enabled QPKGs $CHARS_ELLIPSIS check again in a few minutes"
OS.IsStopping && ShowAsWarn "$(GetQnapOS) is shutting-down and all QPKGs are stopping"
if OS.IsLoadAverageInsane;then
ShowAsWarn "the NAS currently has an exceptionally-high system-load, recommend aborting and trying again later"
elif OS.IsLoadAverageHigh;then
ShowAsWarn "the NAS currently has an unusually-high system-load, so this will take a while"
elif OS.IsLoadAverageElevated;then
ShowAsNote "the NAS currently has an elevated system-load, this will take a little longer than usual"
fi
ShowAsProc 'QPKG states'
MakePath "$QPKG_STATES_PATH" states || return
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsNtInstalled "$a";then
if QPKG.IsInstallable "$a";then
echo installable
else
echo notinstallable
fi >> "$QPKG_STATES_PATH/$a"
fi
done &
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsUpgradable "$a";then
echo upgradable
else
echo notupgradable
fi >> "$QPKG_STATES_PATH/$a"
done &
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsCanBackup "$a";then
echo backupable
if QPKG.IsBackupExist "$a";then
echo backedup
else
echo notbackedup
fi >> "$QPKG_STATES_PATH/$a"
else
echo notbackupable
fi >> "$QPKG_STATES_PATH/$a"
done &
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsMissing "$a";then
echo missing
else
echo notmissing
fi >> "$QPKG_STATES_PATH/$a"
done &
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsEnabled "$a";then
echo enabled
else
echo notenabled
fi >> "$QPKG_STATES_PATH/$a"
done &
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
if QPKG.IsInstalled "$a";then
echo installed
else
echo notinstalled
fi >> "$QPKG_STATES_PATH/$a"
done &
wait 2>/dev/null
for a in $(QPKGs-GRall:Array);do
[[ $a = "$b" ]] && continue || b=$a
f=/var/run/$a.last.operation
if [[ -e $f ]];then
case $(<$f) in
start)
QPKGs-ISstarting:Add "$a"
;;
restart)
QPKGs-ISrestarting:Add "$a"
;;
stop)
QPKGs-ISstopping:Add "$a"
;;
failed)
QPKGs-ISNTok:Add "$a"
;;
ok)
QPKGs-ISok:Add "$a"
esac
fi
f="$QPKG_STATES_PATH/$a"
[[ -e $f ]] || continue
for c in $(<$f);do
case $c in
backedup)
QPKGs-ISbackedup:Add "$a"
;;
notbackedup)
QPKGs-ISNTbackedup:Add "$a"
;;
backupable)
:
;;
notbackupable)
:
;;
enabled)
QPKGs-ISenabled:Add "$a"
;;
notenabled)
QPKGs-ISNTenabled:Add "$a"
;;
installable)
QPKGs-GRinstallable:Add "$a"
;;
notinstallable)
QPKGs-GRNTinstallable:Add "$a"
;;
installed)
QPKGs-ISinstalled:Add "$a"
;;
notinstalled)
QPKGs-ISNTinstalled:Add "$a"
;;
missing)
QPKGs-ISmissing:Add "$a"
QPKGs-ISok:Remove "$a"
QPKGs-ISNTok:Add "$a"
;;
notmissing)
QPKGs-ISNTmissing:Add "$a"
;;
upgradable)
QPKGs-GRupgradable:Add "$a"
;;
notupgradable)
QPKGs-GRNTupgradable:Add "$a"
esac
done
done
qpkgs_states_built=true
QPKGs.Missing:Show
QPKGs.NewVers:Show
Func:Exit
}
QPKGs.States:Init()
{
Objects:Load || return
Func:Init
local a=''
DebugAsProc 'initialising state lists'
for a in "${USER_QPKG_IS_STATES[@]:-}" "${QPKG_STATES_TRANSIENT[@]:-}";do
[[ $a = active ]] && continue
QPKGs-IS${a}:Init
done
for a in "${USER_QPKG_ISNT_STATES[@]:-}";do
[[ $a = active ]] && continue
QPKGs-ISNT${a}:Init
done
ClearPath /var/run/sherpa/packages "$QPKG_STATES_PATH"
DebugAsDone 'initialised state lists'
qpkgs_states_built=false
Func:Exit
}
QPKGs.IsCanBackup:Build()
{
Func:Init
local a=''
for a in $(QPKGs-GRall:Array);do
QPKG.IsCanBackup "$a" && QPKGs-GRcanbackup:Add "$a"
done
Func:Exit
}
QPKGs.IsCanRestartToUpdate:Build()
{
Func:Init
local a=''
for a in $(QPKGs-GRall:Array);do
QPKG.IsCanRestartToUpdate "$a" && QPKGs-GRcanrestarttoupdate:Add "$a"
done
Func:Exit
}
QPKGs.IsCanClean:Build()
{
Func:Init
local a=''
for a in $(QPKGs-GRall:Array);do
QPKG.IsCanClean "$a" && QPKGs-GRcanclean:Add "$a"
done
Func:Exit
}
QPKGs.IsTimeoutsIncreased()
{
[[ -e /usr/local/sbin/qpkg_service.orig ]]
}
Help.Abbreviations:Show()
{
Func:Init
local a=''
local b=''
max_cols=2
local -i m=0
local -i n=0
Packages:Load
local -i t=$(QPKGs-GRall:Count)
DisableDebugToArchiveAndFile
DisplayProcReport abbreviations
ResetReportsPath &>/dev/null
{
Help.Basic:Show
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages)."
DisplayAsAbsReportTitleLine
} >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-GRall:Array);do
((n++))
DisplayAsAbsReportItemLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && b+="$(<$f)\n"
done
[[ -n $b ]] && echo -en "$b" >>"$REPORT_OUTPUT_PATHFILE"
{
DisplayAsProjSynExam "example: to install $(ShowAsPackageName SABnzbd), $(ShowAsPackageName Mylar3) and $(ShowAsPackageName nzbToMedia) all-at-once" 'install sab my nzb2'
} >> "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
Display
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Backups:Show()
{
Func:Init
local epoch_time=0
local file_bytes=0
local file_date=''
local file_name=''
local file_time=''
local highlight_older_than='2 weeks ago'
max_cols=3
DisableDebugToArchiveAndFile
DisplayProcReport backups
{
DisplayAsHelpTitle "the location for $(ShowAsTitleName) backups is: $QPKG_BU_PATH"
DisplayAsHelpTitle "backups are listed oldest-first, and those shown in $(TextBrightRed '! red') were last updated more-than $highlight_older_than."
DisplayAsBacksReportTitleLine
if [[ -e $GNU_FIND_CMD ]];then
while read -r epoch_time file_name file_bytes;do
[[ -z $epoch_time || -z $file_name ]] && break
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_older_than"
done <<< "$($GNU_FIND_CMD "$QPKG_BU_PATH"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2>/dev/null | $SORT_CMD)"
else
while read -r file_date file_time file_name file_bytes;do
[[ -z $file_date || -z $file_name ]] && break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$($BASENAME_CMD "$file_name")
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_older_than"
done <<< "$(cd "$QPKG_BU_PATH" && ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2>/dev/null | $AWK_CMD '{print $6" "$7" "$8" "$5}')"
fi
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
Func:Exit
}
Report.Dependencies:Show()
{
Func:Init
local a=''
local b=''
max_cols=8
local -i m=0
local -i n=0
local -i t=$(QPKGs-GRall:Count)
DisableDebugToArchiveAndFile
DisplayProcReport dependency
ResetReportsPath &>/dev/null
{
DisplayAsHelpTitle "package dependencies are automatically installed/started/stopped/restarted as-required."
DisplayAsHelpTitle "requirements shown in \"$(TextBrightOrange '* orange')\" prevent the package being installed."
DisplayAsHelpTitle "those shown in \"$(TextBrightRed '! red')\" are preventing the package from working correctly."
DisplayAsDepsReportTitleLine
} >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-GRall:Array);do
((n++))
DisplayAsDepsReportItemLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && b+="$(<$f)\n"
done
[[ -n $b ]] && echo -en "$b" >>"$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Packages:Show()
{
Func:Init
local a=''
max_cols=3
DisableDebugToArchiveAndFile
DisplayProcReport package
{
Help.Basic:Show
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once."
DisplayAsPacksReportTitleLine
for a in $(QPKGs-GRall:Array);do
DisplayAsPacksReportItemLine "$a"
done
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
} > "$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
Func:Exit
}
Report.Repos:Show()
{
Func:Init
local a=''
local b=''
max_cols=3
local -i m=0
local -i n=0
local -i t=$(QPKGs-GRall:Count)
DisableDebugToArchiveAndFile
DisplayProcReport repository
ResetReportsPath &>/dev/null
DisplayAsReposReportTitleLine >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-GRall:Array);do
((n++))
DisplayAsReposReportItemLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && b+="$(<$f)\n"
done
[[ -n $b ]] && echo -en "$b" >>"$REPORT_OUTPUT_PATHFILE"
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
Report.Statuses:Show()
{
Func:Init
local a=''
local b=''
local f=''
max_cols=5
local -i m=0
local -i n=0
local -i t=$(QPKGs-GRall:Count)
DisableDebugToArchiveAndFile
DisplayProcReport status
ResetReportsPath &>/dev/null
CalcMaxStatusReportCols
DisplayAsStatusReportTitleLine >"$REPORT_OUTPUT_PATHFILE"
for a in $(QPKGs-GRall:Array);do
((n++))
DisplayAsStatusReportItemLine "$a" > "$REPORTS_PATH/$n" &
done
m=$n
wait 2>/dev/null
for ((n=1;n<=m; n++)); do
f="$REPORTS_PATH/$n"
[[ -e $f ]] && b+="$(<$f)\n"
done
[[ -n $b ]] && echo -en "$b" >>"$REPORT_OUTPUT_PATHFILE"
if QPKGs-ISslow.IsAny;then
{
DisplayAsHelpTitle "statuses shown as '$(TextBrightOrange slow)' are usually because the application has been page-swapped to disk and must be reloaded into RAM to respond to a status request. Requesting the QPKG status again shortly afterward should return a useful status result."
} >>"$REPORT_OUTPUT_PATHFILE"
fi
EraseThisLine
if [[ -e $REPORT_OUTPUT_PATHFILE ]];then
DisplayFileInViewport "$REPORT_OUTPUT_PATHFILE"
else
ShowAsError 'no information to display'
fi
QPKGs.States:List
Func:Exit
}
QPKGs.IsBackedUp:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISbackedup:Array);do
Display "$a"
done
return 0
}
QPKGs.IsNtBackedUp:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISNTbackedup:Array);do
Display "$a"
done
return 0
}
QPKGs.IsInstalled:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISinstalled:Array);do
Display "$a"
done
return 0
}
QPKGs.IsNtInstalled:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISNTinstalled:Array);do
Display "$a"
done
return 0
}
#QPKGs.GrAll:Show()
QPKGs.GrInstallable:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-GRinstallable:Array);do
Display "$a"
done
return 0
}
QPKGs.GrNtInstallable:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-GRNTinstallable:Array);do
Display "$a"
done
return 0
}
QPKGs.IsActive:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISactive:Array);do
Display "$a"
done
return 0
}
QPKGs.IsNtActive:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-ISNTactive:Array);do
Display "$a"
done
return 0
}
QPKGs.GrUpgradable:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-GRupgradable:Array);do
Display "$a"
done
return 0
}
QPKGs.GrIndependent:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-GRindependent:Array);do
Display "$a"
done
return 0
}
QPKGs.GrDependent:Show()
{
local a=''
DisableDebugToArchiveAndFile
EraseThisLine
for a in $(QPKGs-GRdependent:Array);do
Display "$a"
done
return 0
}
SendParentChangeEnv()
{
WriteToActionMsgPipe env "$1" '' ''
}
SendPackageStateChange()
{
WriteToActionMsgPipe change "$1" package "$PACKAGE_NAME"
}
SendActionStatus()
{
WriteToActionMsgPipe status "$1" package "$PACKAGE_NAME"
}
WriteToActionMsgPipe()
{
[[ $action_msg_pipe_fd != none && -e /proc/$$/fd/$action_msg_pipe_fd ]] && echo "$1|$2|$3|$4" >&$action_msg_pipe_fd
return 0
}
ReadFromActionMsgPipe()
{
local _msg1_key
local _msg1_value
local _msg2_key
local _msg2_value
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value <&$action_msg_pipe_fd
eval "$1='$_msg1_key' $2='$_msg1_value' $3='$_msg2_key' $4='$_msg2_value'"
return 0
}
FindNextFD()
{
local -i fd=-1
for fd in {10..100};do
if [[ ! -e /proc/$$/fd/$fd ]];then
echo -n "$fd"
return 0
fi
done
return 1
}
MarkThisActionForkAsStarted()
{
[[ -n $proc_fork_pathfile ]] && $TOUCH_CMD "$proc_fork_pathfile"
}
MarkThisActionForkAsOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_ok_pathfile"
SendActionStatus ok
}
MarkThisActionForkAsSkippedOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_ok_pathfile"
SendActionStatus so
}
MarkThisActionForkAsSkipped()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_pathfile"
SendActionStatus sk
}
MarkThisActionForkAsSkippedError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_error_pathfile"
SendActionStatus se
}
MarkThisActionForkAsSkippedAbort()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_abort_pathfile"
SendActionStatus sa
}
MarkThisActionForkAsFailed()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_fail_pathfile"
SendActionStatus er
}
NoteIpkAcAsOk()
{
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-ok:Add "$1"
return 0
}
NoteIpkAcAsEr()
{
local a="failing request to $2 $(ShowAsPackageName "$1")"
[[ -n ${3:-} ]] && a+=" as $3"
DebugAsError "$a" >&2
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-er:Add "$1"
return 0
}
ModPathToEntware()
{
local a=''
local b=/opt/bin:/opt/sbin
if QPKGs-ISenabled.Exist Entware;then
! [[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=$b:${a%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=${a%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0
}
GetCPUInfo()
{
if $GREP_CMD -q '^model name' /proc/cpuinfo;then
$GREP_CMD '^model name' /proc/cpuinfo | $HEAD_CMD -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
elif $GREP_CMD -q '^Processor name' /proc/cpuinfo;then
$GREP_CMD '^Processor name' /proc/cpuinfo | $HEAD_CMD -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
else
printf unknown
return 1
fi
return 0
}
GetArch()
{
$UNAME_CMD -m
}
GetKernelVersion()
{
$UNAME_CMD -r
}
GetKernelPageSize()
{
$GREP_CMD KernelPageSize /proc/1/smaps | $HEAD_CMD -n1 | cut -f2 -d':' | tr -d ' '
}
GetPlatform()
{
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf
}
GetDefVol()
{
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info
}
GetPython3Ver()
{
GetPythonVer "${1:-python3}"
}
GetPythonVer()
{
GetThisBinPath ${1:-python} &>/dev/null && ${1:-python} -V 2>&1 | $SED_CMD 's|^Python ||'
}
GetPerlVer()
{
GetThisBinPath ${1:-perl} &>/dev/null && ${1:-perl} -e 'print "$^V\n"' 2>/dev/null | $SED_CMD 's|v||'
}
GetThisBinPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined binary} ]] && command -v "$1" 2>&1
}
GetRepoURLFromStoreID()
{
[[ -n ${1:-} ]] || return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf
}
GetUptime()
{
local n=$(</proc/uptime)
FormatSecsToHoursMinutesSecs "${n%%.*}"
}
GetTimeInShell()
{
local n=0
if [[ -n ${LOADER_SCRIPT_PPID:-} ]];then
n=$($PS_CMD -o pid,etime | $GREP_CMD $LOADER_SCRIPT_PPID | $HEAD_CMD -n1)
fi
FormatLongMinutesSecs "${n:6}"
}
GetSysLoadAverages()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print "1m:"$1", 5m:"$2", 15m:"$3}'
}
GetSysLoad1MinAverage()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print $1}'
}
GetCPUCores()
{
local n=$($GREP_CMD -c '^processor' /proc/cpuinfo)
[[ $n -eq 0 ]] && n=$($GREP_CMD -c '^Processor' /proc/cpuinfo)
echo -n "$n"
}
GetInstalledRAM()
{
$GREP_CMD MemTotal /proc/meminfo | $SED_CMD 's|.*: ||;s|kB||;s| ||g'
}
GetFirmwareVer()
{
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf
}
GetFirmwareBuild()
{
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf
}
GetFirmwareDate()
{
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf
}
GetQnapOS()
{
if $GREP_CMD -q zfs /proc/filesystems;then
printf 'QuTS hero'
else
printf QTS
fi
}
GetQpkgArch()
{
case $NAS_ARCH in
x86_64)
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]] && printf i64 || printf i86
;;
i686|x86)
printf i86
;;
armv5tel)
printf a19
;;
armv7l)
case $NAS_PLATFORM in
ARM_MS)
printf a31
;;
ARM_AL)
printf a41
;;
*)
printf none
esac
;;
aarch64)
printf a64
;;
*)
printf none
esac
}
GetEntwareType()
{
if QPKG.IsInstalled Entware;then
if [[ -e /opt/etc/passwd ]];then
if [[ -L /opt/etc/passwd ]];then
printf std
else
printf alt
fi
else
printf none
fi
else
printf 'not-installed'
fi
} 2>/dev/null
GetSudoUID()
{
echo -n "${SUDO_UID:-undefined}"
}
GetUpState()
{
if OS.IsStarting;then
printf 'starting-up'
elif OS.IsStopping;then
printf 'shutting-down'
else
printf stable
fi
}
OS.IsOk()
{
if ! OS.IsQNAP;then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0
}
OS.IsQNAP()
{
[[ -e /etc/init.d/functions ]]
}
OS.IsCompatibleWithSigned()
{
[[ $NAS_FIRMWARE_DATE -lt 20201015 || $NAS_FIRMWARE_DATE -gt 20201020 ]]
}
OS.IsSupported()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 400 ]]
}
OS.IsSupportSecureDownload()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 500 ]]
}
OS.IsSupportQpkgTimeout()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 430 ]]
}
OS.IsSupportSignedPackages()
{
[[ ${NAS_FIRMWARE_VER//.} -ge 435 ]]
}
OS.IsSupportSudo()
{
[[ -e /usr/bin/sudo ]]
}
OS.IsAllowUnsignedPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert) = TRUE ]]
}
OS.IsStarting()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcS' | $GREP_CMD -v grep
} &>/dev/null
OS.IsStopping()
{
$PS_CMD | $GREP_CMD -F '/bin/sh /etc/init.d/rcK' | $GREP_CMD -v grep
} &>/dev/null
OS.IsStdKernelPageSize()
{
[[ ${KERNEL_PAGE_SIZE:=$(GetKernelPageSize)} = 4kB ]]
}
OS.IsNonStdKernelPageSize()
{
! OS.IsStdKernelPageSize
}
OS.IsLoadAverageElevated()
{
local a=$(GetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*2*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OS.IsLoadAverageHigh()
{
local a=$(GetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*4*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OS.IsLoadAverageInsane()
{
local a=$(GetSysLoad1MinAverage);a=${a/./}
local b=$((CPU_CORES*8*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
Error:Set()
{
run_package_actions=false
Error.IsSet && return
_script_error_flag_=true
DebugVar _script_error_flag_
}
Error.IsSet()
{
[[ ${_script_error_flag_:=false} = true ]]
}
Error.IsNt()
{
[[ ${_script_error_flag_:=false} != true ]]
}
ShowZeroQpkgs()
{
[[ ${packages_loaded:=false} = true ]] || return
local a=''
local b=''
for a in "${USER_QPKG_IS_STATES[@]:-}";do
for b in "${USER_QPKG_ACTIONS[@]:-}";do
[[ $b = list ]] && continue
QPKGs.AC${b}.IS${a}.IsSet && QPKGs-AC${b}-ok.IsNone && ShowAsWarn "no QPKGs were able to $(Lowercase "$b")"
done
done
return 0
}
LockFile:Claim()
{
local a=''
readonly LOCK_PATHFILE=/var/run/sherpa.lock
for a in sherpa-manager.sh sherpa-manager.source;do
if [[ -e $LOCK_PATHFILE && -d /proc/$(<"$LOCK_PATHFILE") && $(</proc/"$(<"$LOCK_PATHFILE")"/cmdline) =~ $a ]];then
ShowAsAbort "another sherpa instance was found (PID:$(<"$LOCK_PATHFILE")), can't continue"
return 1
fi
done
echo "$$" > "$LOCK_PATHFILE"
return 0
}
LockFile:Release()
{
rm -f "$LOCK_PATHFILE"
}
Verbose:Enable()
{
useropt_verbose=true
DebugVar useropt_verbose
Keystrokes:Show
Cursor:Show
}
EnableDebugToArchiveAndFile()
{
useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward
}
DisableDebugToArchiveAndFile()
{
archive_debug_afterward=false
useropt_debug=false
}
SaveActionResultToLog()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
local -r PACKAGE_TYPE=${1:?${FUNCNAME[0]}'()': undefined package type}
local -r PACKAGE_NAME=${2:?${FUNCNAME[0]}'()': undefined package name}
local -r ACTION=${3:?${FUNCNAME[0]}'()': undefined action}
local -r CLEAN_ACTION=${ACTION//\"/}
local -r RESULT=${4:?${FUNCNAME[0]}'()': undefined result}
local -r REASON=${5:-}
local -r DURATION=$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")
local -r ACTION_TIMES_PATHFILE=$ACTION_TIMES_PATH/$CLEAN_ACTION.milliseconds
if [[ $2 = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
echo "$(/bin/date +%s)|$ACTION|$PACKAGE_NAME|$RESULT|$DURATION|$REASON|$PACKAGE_TYPE" >> "$SESS_ACTION_RESULTS_PATHFILE"
if [[ -e $ACTION_TIMES_PATHFILE ]] && $GREP_CMD -q "^$PACKAGE_NAME|" < "$ACTION_TIMES_PATHFILE";then
$SED_CMD -i "/^$PACKAGE_NAME|/d" "$ACTION_TIMES_PATHFILE"
fi
echo "$PACKAGE_NAME|$DURATION" >> "$ACTION_TIMES_PATHFILE"
case $4 in
ok|skipped-ok)
DebugAsInfo "$REASON"
;;
skipped)
DebugAsWarn "$REASON"
;;
failed|skipped-error|skipped-abort)
DebugAsError "$REASON"
esac
return 0
}
_QPKG:reassign_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif [[ $(QPKG.GetStoreID "$PACKAGE_NAME") = sherpa ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign skipped 'QPKG is already assigned to sherpa'
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "reassigning $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/setcfg -e $PACKAGE_NAME store -f /etc/config/qpkg.conf" "$LOGS_PATH/$PACKAGE_NAME.$REASSIGN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reassign failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:download_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -r REMOTE_HASH=$(QPKG.GetHash "$PACKAGE_NAME")
local -r REMOTE_URL=$(QPKG.GetURL "$PACKAGE_NAME")
local -r REMOTE_FILENAME=$($BASENAME_CMD "$REMOTE_URL")
local -r LOCAL_PATHFILE=$QPKG_DL_PATH/$REMOTE_FILENAME
local -r LOCAL_FILENAME=$($BASENAME_CMD "$LOCAL_PATHFILE")
local -r LOG_PATHFILE=$LOGS_PATH/$LOCAL_FILENAME.$DOWNLOAD_LOG_FILE
local -i z=0
if [[ -z $REMOTE_URL || -z $REMOTE_HASH ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" download skipped 'NAS arch is incompatible'
MarkThisActionForkAsSkipped
z=1
elif [[ -f $LOCAL_PATHFILE ]];then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" download skipped-ok "existing file $(ShowAsFileName "$LOCAL_FILENAME") checksum correct"
MarkThisActionForkAsSkippedOk
z=2
else
DebugInfo "deleting $(ShowAsFileName "$LOCAL_FILENAME") as checksum is incorrect"
rm -f "$LOCAL_PATHFILE"
fi
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
if [[ ! -f $LOCAL_PATHFILE ]];then
DebugAsProc "downloading $(ShowAsFileName "$REMOTE_FILENAME")"
rm -f "$LOG_PATHFILE"
RunAndLog "$CURL_CMD --location --output $LOCAL_PATHFILE $REMOTE_URL" "$LOG_PATHFILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
if FileMatchesMD5 "$LOCAL_PATHFILE" "$REMOTE_HASH";then
[[ $(Lowercase "${LOCAL_PATHFILE##*.}") = zip ]] && $UNZIP_CMD -nq "$LOCAL_PATHFILE" -d "$QPKG_DL_PATH"
SaveActionResultToLog QPKG "$PACKAGE_NAME" download ok
SendPackageStateChange ISdownloaded
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" download failed "cache file $(ShowAsFileName "$LOCAL_FILENAME") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkThisActionForkAsFailed
z=1
fi
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" download failed "$z"
MarkThisActionForkAsFailed
z=1
fi
fi
FuncFork:Exit $z
}
_QPKG:install_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'QPKG is already installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsArchOK "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'NAS arch is incompatible'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsMinOSVerOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped "$(GetQnapOS) version is incompatible"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsMinRAMOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped 'NAS has insufficient RAM'
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" install skipped-error 'no local file found for processing: please report this issue'
MarkThisActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
if [[ $PACKAGE_NAME = Entware ]] && ! QPKGs-ISinstalled.Exist Entware && QPKGs-ACinstall-to.Exist Entware;then
local -r OPT_PATH=/opt
local -r OPT_BU_PATH=/opt.orig
if [[ -d $OPT_PATH && ! -L $OPT_PATH && ! -e $OPT_BU_PATH ]];then
DebugAsProc 'backup original /opt'
mv "$OPT_PATH" "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
local target_path=''
DebugAsProc "installing $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
[[ ${QPKGs_were_installed_name[*]:-} = *"$PACKAGE_NAME"* ]] && target_path="QINSTALL_PATH=$(QPKG.GetOriginalPath "$PACKAGE_NAME") "
RunAndLog "${a}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$INSTALL_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
QPKG.ServiceStatus:Log
SendPackageStateChange ISinstalled
if QPKG.IsEnabled "$PACKAGE_NAME";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$PACKAGE_NAME" install ok "version $(QPKG.Local.GetVer "$PACKAGE_NAME")"
if [[ $PACKAGE_NAME = Entware ]];then
SendParentChangeEnv ModPathToEntware
PatchEntwareService
if [[ -L ${OPT_PATH:-} && -d ${OPT_BU_PATH:-} ]];then
DebugAsProc 'restoring original /opt'
mv "$OPT_BU_PATH"/* "$OPT_PATH" && ClearPath / "$OPT_BU_PATH"
DebugAsDone complete
fi
fi
SendParentChangeEnv "QPKGs-ACsign-to:Add $PACKAGE_NAME"
MarkThisActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" install failed "$z"
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:reinstall_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped "QPKG is not installed, please use 'install' instead."
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall skipped-error 'no local file found for processing, please report this issue.'
MarkThisActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local target_path=''
DebugAsProc "reinstalling $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
QPKG.IsInstalled "$PACKAGE_NAME" && target_path="QINSTALL_PATH=$($DIRNAME_CMD "$(QPKG.GetInstallationPath $PACKAGE_NAME)") "
RunAndLog "${a}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$REINSTALL_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
QPKG.ServiceStatus:Log
if QPKG.IsEnabled "$PACKAGE_NAME";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall ok "version $current_ver"
MarkThisActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reinstall failed "$z"
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:rebuild_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if ! QPKG.IsCanBackup;then
SaveActionResultToLog QPKG "$PACKAGE_NAME" meta-rebuild skipped 'QPKG does not support rebuild'
MarkThisActionForkAsSkipped
z=1
elif QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" meta-rebuild skipped "QPKG is already installed, please use 'restore' instead"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsBackupExist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" meta-rebuild skipped 'QPKG backup does not exist'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" meta-rebuild skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "meta-rebuilding $(ShowAsPackageName "$PACKAGE_NAME")"
SaveActionResultToLog QPKG "$PACKAGE_NAME" meta-rebuild ok
MarkThisActionForkAsOk
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:upgrade_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKGs-GRupgradable.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped 'no new QPKG is available'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local local_pathfile=$(QPKG.GetPathFilename "$PACKAGE_NAME")
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade skipped-error 'no local file found for processing, please report this issue'
MarkThisActionForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local prev_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
local target_path=''
DebugAsProc "upgrading $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
QPKG.IsInstalled "$PACKAGE_NAME" && target_path="QINSTALL_PATH=$($DIRNAME_CMD "$(QPKG.GetInstallationPath "$PACKAGE_NAME")") "
RunAndLog "${a}${target_path}${SH_CMD} $local_pathfile" "$LOGS_PATH/$($BASENAME_CMD "$local_pathfile").$UPGRADE_LOG_FILE" log:failure-only 10
z=$?
[[ $PACKAGE_NAME = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
QPKG.ServiceStatus:Log
SendPackageStateChange GRNTupgradable
if QPKG.IsEnabled "$PACKAGE_NAME";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QPKG.Local.GetVer "$PACKAGE_NAME")
if [[ $current_ver = "$prev_ver" ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade ok "version $current_ver"
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade ok "upgraded from version $prev_ver to version $current_ver"
fi
MarkThisActionForkAsOk
z=0
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" upgrade failed "$z"
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:uninstall_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif [[ $PACKAGE_NAME = sherpa ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped "it's needed here! 😉"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
local -r QPKG_UNINSTALLER_PATHFILE=$(QPKG.GetInstallationPath "$PACKAGE_NAME")/.uninstall.sh
[[ $PACKAGE_NAME = Entware ]] && SaveEntwarePackageList
if [[ -e $QPKG_UNINSTALLER_PATHFILE ]];then
DebugAsProc "uninstalling $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}${SH_CMD} $QPKG_UNINSTALLER_PATHFILE" "$LOGS_PATH/$PACKAGE_NAME.$UNINSTALL_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
[[ -e /sbin/qpkg_cli ]] && ! QPKGs-ACinstall-to.Exist "$PACKAGE_NAME" && /sbin/qpkg_cli --remove "$PACKAGE_NAME" &>/dev/null
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall ok
/sbin/rmcfg "$PACKAGE_NAME" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $PACKAGE_NAME = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISNTinstalled
SendPackageStateChange ISNTactive
SendPackageStateChange ISNTenabled
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall failed "$z"
MarkThisActionForkAsFailed
z=1
fi
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" uninstall failed '.uninstall.sh script is missing'
MarkThisActionForkAsFailed
fi
FuncFork:Exit $z
}
_QPKG:activate_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped "QPKG is not enabled, please 'enable' it first"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$ACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_START_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "activating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate skipped-error 'QPKG service script file undefined'
MarkThisActionForkAsSkippedError
FuncFork:Exit 4
elif [[ $useropt_debug = true ]];then
a='DEBUG_QPKG=true '
RunAndLog "${a}${service_pathfile} start" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} start $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile start" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate ok
if [[ $PACKAGE_NAME = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISactive
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" activate failed "$z"
SendPackageStateChange ISNTactive
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:reactivate_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped "QPKG is not enabled, please 'enable' it first"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$REACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_RESTART_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "reactivating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate skipped-error 'QPKG service script file undefined'
MarkThisActionForkAsSkippedError
FuncFork:Exit 4
elif [[ $useropt_debug = true ]];then
a='DEBUG_QPKG=true '
RunAndLog "${a}${service_pathfile} restart" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} restart $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile restart" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" reactivate failed "$z"
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:deactivate_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif [[ $PACKAGE_NAME = sherpa ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped "it's needed here! 😉"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$DEACTIVATE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_STOP_TIMEOUT_SECONDS"
local service_pathfile=$(QPKG.GetServicePathFile "$PACKAGE_NAME")
DebugAsProc "deactivating $(ShowAsPackageName "$PACKAGE_NAME")"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate skipped-error 'QPKG service script file undefined'
MarkThisActionForkAsSkippedError
FuncFork:Exit 4
elif [[ $useropt_debug = true ]];then
a='DEBUG_QPKG=true '
RunAndLog "${a}${service_pathfile} stop" "$LOG_PATHFILE" log:failure-only
z=$?
elif QPKG.IsCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} stop $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.LastResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile stop" "$LOG_PATHFILE" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate ok
if [[ $PACKAGE_NAME = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateColourisation
fi
SendPackageStateChange ISNTactive
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" deactivate failed "$z"
MarkThisActionForkAsFailed
z=1
fi
QPKG.AppCenterNotifier:Clear
FuncFork:Exit $z
}
_QPKG:enable_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif QPKGs-ISenabled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped 'QPKG is already enabled'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$ENABLE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_ENABLE_TIMEOUT_SECONDS"
DebugAsProc "enabling $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/qpkg_service${timeout} enable $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
QPKG.IsEnabled "$PACKAGE_NAME" && SendPackageStateChange ISenabled
QPKG.AppCenterNotifier:Clear
SaveActionResultToLog QPKG "$PACKAGE_NAME" enable ok
MarkThisActionForkAsOk
FuncFork:Exit $z
}
_QPKG:disable_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped 'QPKG is already disabled'
MarkThisActionForkAsSkipped
z=1
elif [[ $PACKAGE_NAME = sherpa ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped "it's needed here! 😉"
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
QPKG.ServiceStatus:Clear
local -r LOG_PATHFILE=$LOGS_PATH/$PACKAGE_NAME.$DISABLE_LOG_FILE
local timeout=''
OS.IsSupportQpkgTimeout && timeout=" -t $QPKG_DISABLE_TIMEOUT_SECONDS"
DebugAsProc "disabling $(ShowAsPackageName "$PACKAGE_NAME")"
RunAndLog "/sbin/qpkg_service${timeout} disable $PACKAGE_NAME" "$LOG_PATHFILE" log:failure-only
! QPKG.IsEnabled "$PACKAGE_NAME" && SendPackageStateChange ISNTenabled
QPKG.AppCenterNotifier:Clear
SaveActionResultToLog QPKG "$PACKAGE_NAME" disable ok
MarkThisActionForkAsOk
FuncFork:Exit $z
}
_QPKG:enableau_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enableau skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsCanRestartToUpdate "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enableau skipped 'QPKG does not support auto-updating'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" enableau skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "enabling auto-update $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}$(QPKG.GetServicePathFile) enable-auto-update" "$LOGS_PATH/$PACKAGE_NAME.$ENABLEAU_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" enableau ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" enableau failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:disableau_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disableau skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsCanRestartToUpdate "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disableau skipped 'QPKG does not support auto-updating'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" disableau skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "disabling auto-update $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}$(QPKG.GetServicePathFile) disable-auto-update" "$LOGS_PATH/$PACKAGE_NAME.$DISABLEAU_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" disableau ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" disableau failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:backup_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsCanBackup;then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped 'QPKG does not support backup'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "backing-up $(ShowAsPackageName "$PACKAGE_NAME") configuration"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}$(QPKG.GetServicePathFile) backup" "$LOGS_PATH/$PACKAGE_NAME.$BACKUP_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup ok
SendPackageStateChange ISbackedup
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" backup failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:restore_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsCanBackup;then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped 'QPKG does not support restore'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsBackupExist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped 'QPKG backup does not exist'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "restoring $(ShowAsPackageName "$PACKAGE_NAME") configuration"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}$(QPKG.GetServicePathFile) restore" "$LOGS_PATH/$PACKAGE_NAME.$RESTORE_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore ok
SendPackageStateChange ISrestored
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" restore failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:clean_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsCanClean;then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped 'QPKG does not support cleaning'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "cleaning $(ShowAsPackageName "$PACKAGE_NAME")"
[[ $useropt_debug = true ]] && a='DEBUG_QPKG=true '
RunAndLog "${a}$(QPKG.GetServicePathFile) clean" "$LOGS_PATH/$PACKAGE_NAME.$CLEAN_LOG_FILE" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
QPKG.ServiceStatus:Log
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean ok
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" clean failed "$z"
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:sign_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
local b=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if [[ -e $ACTION_ABORT_PATHFILE ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped-abort 'abort requested, unable to continue'
MarkThisActionForkAsSkippedAbort
z=3
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugVar SQLITE_CMD
if ! QPKGs-ISinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
elif ! OS.IsSupportSignedPackages;then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped 'not required: firmware < 4.3.5'
MarkThisActionForkAsSkipped
z=1
elif ! QPKG.IsRepoOk "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped "QPKG is assigned to another repository, please 'reassign' it first"
MarkThisActionForkAsSkipped
z=1
elif [[ ! -e $SQLITE_CMD ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped-abort 'sqlite3 unavailable'
MarkThisActionForkAsSkippedAbort
z=3
elif [[ ! -e $CERT_DB_PATHFILE ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped-abort "$(GetQnapOS) certificate database not found"
MarkThisActionForkAsSkippedAbort
z=3
else
a="SELECT 1 FROM Certificate WHERE QpkgName = '$PACKAGE_NAME' LIMIT 1;"
b=$($SQLITE_CMD "$CERT_DB_PATHFILE" "$a")
if [[ $b = 1 ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' skipped-ok 'QPKG is already signed'
MarkThisActionForkAsSkippedOk
z=2
fi
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "\"signing\" $(ShowAsPackageName "$PACKAGE_NAME")"
a="INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$PACKAGE_NAME','$QPKG_CERTIFICATE','$QPKG_SIGNATURE');"
for ((retries=0;retries<10; retries++)); do
$SQLITE_CMD "$CERT_DB_PATHFILE" "$a"
z=$?
case $z in
5)
sleep 0.5
;;
*)
break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' ok
SendPackageStateChange ISsigned
MarkThisActionForkAsOk
else
SaveActionResultToLog QPKG "$PACKAGE_NAME" '"sign"' failed "($z) but don't know why. Please report this as a bug"
SendParentChangeEnv 'show_suggest_raise_issue=true'
MarkThisActionForkAsFailed
z=1
fi
FuncFork:Exit $z
}
_QPKG:status_()
{
[[ $useropt_verbose != true ]] && exec &>/dev/null
FuncFork:Init
local a=''
local b=''
PACKAGE_NAME=${1:?${FUNCNAME[0]}'()': undefined package name}
local -i z=0
if QPKGs-ISNTinstalled.Exist "$PACKAGE_NAME";then
SaveActionResultToLog QPKG "$PACKAGE_NAME" status skipped 'QPKG is not installed'
MarkThisActionForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncFork:Exit $z
DebugAsProc "statusing $(ShowAsPackageName "$PACKAGE_NAME")"
a=$(QPKG.GetActiveTest "$PACKAGE_NAME")
if [[ $a = builtin ]];then
[[ $useropt_debug = true ]] && b='DEBUG_QPKG=true '
if [[ -e $GNU_TIMEOUT_CMD ]];then
$GNU_TIMEOUT_CMD "$QPKG_STATUS_CHECK_TIMEOUT_SECONDS" /bin/bash -c "${b}$(QPKG.GetServicePathFile) status"
z=$?
else
RunAndLog "${b}$(QPKG.GetServicePathFile) status" "$LOGS_PATH/$PACKAGE_NAME.$STATUS_LOG_FILE" log:failure-only
z=$?
fi
elif [[ $a != none ]];then
eval "$a" &>/dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive
;;
124)
SendPackageStateChange ISslow
;;
130)
SendPackageStateChange ISunknown
;;
*)
SendPackageStateChange ISNTactive
esac
SaveActionResultToLog QPKG "$PACKAGE_NAME" status ok
MarkThisActionForkAsOk
FuncFork:Exit
}
QPKG.AppCenterNotifier:Clear()
{
[[ -e /sbin/qpkg_cli ]] && /sbin/qpkg_cli --cancel "$PACKAGE_NAME"
QPKG.IsNtInstalled "$PACKAGE_NAME" && return 0
/sbin/setcfg "$PACKAGE_NAME" Status complete -f /etc/config/qpkg.conf
return 0
} &>/dev/null
QPKG.ServiceStatus:Clear()
{
rm -f /var/run/"$PACKAGE_NAME".last.operation
}
QPKG.LastResultWasOk()
{
[[ $(QPKG.GetServiceStatus "$PACKAGE_NAME") = ok ]]
}
QPKG.ServiceStatus:Log()
{
if ! local a=$(QPKG.GetServiceStatus "$PACKAGE_NAME");then
DebugAsWarn "unable to get status of $(ShowAsPackageName "$PACKAGE_NAME") service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $a in
start|stop|restart)
DebugInfo "$(ShowAsPackageName "$PACKAGE_NAME") service is $a"
;;
ok)
DebugInfo "$(ShowAsPackageName "$PACKAGE_NAME") service action completed OK"
;;
failed)
if [[ -e /var/log/$PACKAGE_NAME.log ]];then
DebugAsError "$(ShowAsPackageName "$PACKAGE_NAME") service action failed. Check $(ShowAsFileName "/var/log/$PACKAGE_NAME.log") for more information"
AddExtLogToSessLog /var/log/$PACKAGE_NAME.log
else
DebugAsError "$(ShowAsPackageName "$PACKAGE_NAME") service action failed"
fi
;;
*)
DebugAsWarn "$(ShowAsPackageName "$PACKAGE_NAME") service status is unrecognised or unsupported"
esac
return 0
}
QPKG.GetInstallationPath()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Install_Path -d undefined -f /etc/config/qpkg.conf
}
QPKG.GetServicePathFile()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Shell -d undefined -f /etc/config/qpkg.conf
}
QPKG.App.GetVer()
{
local a=''
local -i i=-1
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] && i=$2 || i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
a=${QPKG_APP_VERSION[$i]}
[[ $a = default ]] && a=${QPKG_APP_VERSION[$(QPKG.GetDefaultArchIndex "$1")]}
[[ $a = version ]] && a=${QPKG_VERSION[$(QPKG.GetDefaultArchIndex "$1")]}
echo -n "$a"
return 0
}
QPKG.Avail.GetVer()
{
local a=''
local b=''
local -i i=0
for i in "${!QPKG_NAME[@]}";do
a=${QPKG_NAME[$i]}
[[ $a = "$b" ]] && continue || b=$a
if [[ ${1:-${PACKAGE_NAME:-sherpa}} = "$a" ]];then
echo -n "${QPKG_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.Local.GetVer()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" Version -d undefined -f /etc/config/qpkg.conf
}
QPKG.GetStoreID()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" store -d sherpa -f /etc/config/qpkg.conf
}
QPKG.IsRepoOk()
{
local a=$(QPKG.GetStoreID "${1:-${PACKAGE_NAME:-sherpa}}")
[[ -z $a || $a = sherpa ]]
}
QPKG.GetInstallDate()
{
/sbin/getcfg "${1:-${PACKAGE_NAME:-sherpa}}" date -d undefined -f /etc/config/qpkg.conf
}
QPKG.IsBackupExist()
{
[[ -e $QPKG_BU_PATH/${1:?${FUNCNAME[0]}'()': undefined package name}.config.tar.gz ]]
}
QPKG.IsDependent()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
a=${QPKG_DEPENDS_ON[$i]}
[[ $a = default ]] && a=${QPKG_DEPENDS_ON[$(QPKG.GetDefaultArchIndex "${QPKG_NAME[$i]}")]}
[[ $a = none ]] && break
[[ -n $a ]] && return
fi
done
return 1
}
QPKG.IsUpgradable()
{
local a=${1:-$PACKAGE_NAME}
QPKG.IsInstalled "$a" && QPKG.IsRepoOk "$a" && [[ $(QPKG.Local.GetVer "$a") != "$(QPKG.Avail.GetVer "$a")" ]] && QPKG.IsArchOK "$a" && QPKG.IsMinOSVerOk "$a" && QPKG.IsMinRAMOk "$a"
}
QPKG.IsInstallable()
{
local a=${1:-$PACKAGE_NAME}
! QPKG.IsInstalled "$a" && QPKG.IsRepoOk "$a" && QPKG.IsArchOK "$a" && QPKG.IsMinOSVerOk "$a" && QPKG.IsMinRAMOk "$a"
}
QPKG.GetOriginalPath()
{
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]];then
for i in "${!QPKGs_were_installed_name[@]}";do
if [[ ${QPKGs_were_installed_name[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKGs_were_installed_path[$i]}"
return 0
fi
done
fi
return 1
}
QPKG.MatchAbbrv()
{
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!QPKG_NAME[@]}";do
ar=(${QPKG_ABBRVS[$i]})
for j in "${!ar[@]}";do
if [[ ${ar[$j]} = "$1" ]];then
echo -n "${QPKG_NAME[$i]}"
z=0
break 2
fi
done
done
return $z
}
QPKG.GetPathFilename()
{
local a=$(QPKG.GetURL "${1:?${FUNCNAME[0]}'()': undefined package name}")
[[ -n $a ]] || return
[[ $(Lowercase "${a##*.}") != qpkg ]] && a=${a%.*}.qpkg
echo -n "$QPKG_DL_PATH/$($BASENAME_CMD "$a")"
return 0
}
QPKG.GetHash()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]] && [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]];then
echo -n "${QPKG_HASH[$i]}"
return 0
fi
done
return 1
}
QPKG.GetURL()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]] && [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]];then
echo -n "${QPKG_URL[$i]}"
return 0
fi
done
return 1
}
QPKG.IsArchOK()
{
local a=$(QPKG.GetURL "${1:-$PACKAGE_NAME}")
[[ -n $a && $a != none ]]
}
QPKG.GetMinRAM()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_MIN_RAM_KB[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMinRAMOk()
{
local a=$(QPKG.GetMinRAM "${1:?${FUNCNAME[0]}'()': undefined package name}")
[[ -n $a ]] && [[ $a = none || $NAS_RAM_KB -ge $a ]]
}
QPKG.GetMinOSVer()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_MIN_OS_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMinOSVerOk()
{
local a=$(QPKG.GetMinOSVer "${1:?${FUNCNAME[0]}'()': undefined package name}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -ge $a ]]
}
QPKG.GetMaxOSVer()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_MAX_OS_VERSION[$i]}"
return 0
fi
done
return 1
}
QPKG.IsMaxOSVerOk()
{
local a=$(QPKG.GetMaxOSVer "${1:?${FUNCNAME[0]}'()': undefined package name}")
[[ -n $a ]] && [[ $a = none || ${NAS_FIRMWARE_VER//.} -le $a ]]
}
QPKG.GetAuthor()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_AUTHOR[$i]}"
return 0
fi
done
return 1
}
#QPKG.GetAuthorEmail()
#QPKG.GetAppAuthor()
#QPKG.GetAppAuthorEmail()
QPKG.GetDesc()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_DESC[$i]}"
return 0
fi
done
return 1
}
QPKG.GetNote()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
a=${QPKG_NOTE[$i]}
[[ $a != none ]] && echo -n "$a"
return 0
fi
done
return 1
}
QPKG.GetAbbrvs()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "${QPKG_ABBRVS[$i]}"
return 0
fi
done
return 1
}
QPKG.GetArchIndex()
{
local -i i=-1
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
if [[ ${QPKG_ARCH[$i]} = all || ${QPKG_ARCH[$i]} = "$NAS_QPKG_ARCH" ]];then
echo -n "$i"
return
fi
fi
done
echo -n "$i"
return 1
}
QPKG.GetDefaultArchIndex()
{
local -i i=-1
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
echo -n "$i"
return
fi
done
echo -n "$i"
return 1
}
QPKG.GetDependencies()
{
local alt=''
local first=''
local found=false
local g=''
local -i i=-1
local oldIFS=$IFS
local out=''
local x=''
i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
g=${QPKG_DEPENDS_ON[$i]}
[[ $g = none ]] && return 1
[[ $g = default ]] && g=${QPKG_DEPENDS_ON[$(QPKG.GetDefaultArchIndex "$1")]}
if [[ $g != *'|'* ]];then
echo -n "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=" $x"
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first && -n $alt ]] && first=$alt
if QPKG.IsArchOK "$alt";then
out+=" $alt"
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]] && IFS=$oldIFS
if [[ $found = false ]];then
out+=" $first"
first=''
fi
done
echo -n "$out"
return 0
}
QPKG.GetIPKs()
{
local a=''
local -i i=-1
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] && i=$2 || i=$(QPKG.GetArchIndex "$1")
[[ $i -ge 0 ]] || return
a=${QPKG_REQUIRES_IPKS[$i]}
[[ $a = default ]] && a=${QPKG_REQUIRES_IPKS[$(QPKG.GetDefaultArchIndex "$1")]}
[[ $a = none ]] && return 1
echo -n "$a"
return 0
}
QPKG.GetDependents()
{
local -a ar=()
local -i i=-1
local re=\\b${1:-}\\b
if QPKGs-GRindependent.Exist "$1";then
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_DEPENDS_ON[$i]} =~ $re ]];then
[[ ${ar[*]:-} != "${QPKG_NAME[$i]}" ]] && ar+=(${QPKG_NAME[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]];then
echo -n "${ar[@]}"
return 0
fi
return 1
}
QPKG.IsCanBackup()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]];then
if ${QPKG_CAN_BACKUP[$i]};then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanRestartToUpdate()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
if ${QPKG_CAN_RESTART_TO_UPDATE[$i]};then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanClean()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]];then
if ${QPKG_CAN_CLEAN[$i]};then
return 0
else
break
fi
fi
done
return 1
}
QPKG.IsCanLog()
{
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:-$PACKAGE_NAME}" ]];then
if ${QPKG_CAN_LOG_SERVICE_OPERATIONS[$i]};then
return 0
else
break
fi
fi
done
return 1
}
QPKG.GetActiveTest()
{
local a=''
local -i i=0
for i in "${!QPKG_NAME[@]}";do
if [[ ${QPKG_NAME[$i]} = "${1:?${FUNCNAME[0]}'()': undefined package name}" ]];then
a=${QPKG_TEST_FOR_ACTIVE[$i]}
[[ -n $a ]] || break
echo -n "$a"
return 0
fi
done
return 1
}
QPKG.IsInstalled()
{
$GREP_CMD -q "^\[${1:?${FUNCNAME[0]}'()': undefined package name}\]" /etc/config/qpkg.conf
}
QPKG.IsNtInstalled()
{
! QPKG.IsInstalled "${1:?${FUNCNAME[0]}'()': undefined package name}"
}
QPKG.IsMissing()
{
local a=$(QPKG.GetInstallationPath "${1:?${FUNCNAME[0]}'()': undefined package name}")
[[ $a != undefined && ! -d $a ]]
}
QPKG.IsEnabled()
{
[[ $(/sbin/getcfg "${1:?${FUNCNAME[0]}'()': undefined package name}" Enable -u -f /etc/config/qpkg.conf) = TRUE ]]
}
QPKG.GetServiceStatus()
{
local a=${1:?${FUNCNAME[0]}'()': undefined package name}
[[ -e /var/run/$a.last.operation ]] && echo "$(</var/run/"$a".last.operation)"
}
QPKG.Signing:Load()
{
QPKG_CERTIFICATE=''
QPKG_SIGNATURE=''
read -r -d '' QPKG_CERTIFICATE << EOB
-----BEGIN CERTIFICATE-----
MIIDwzCCAqugAwIBAgIFALhDVuwwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYT
AlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwE
UU5BUDEMMAoGA1UECwwDTkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcN
AQkBFhFzZWN1cml0eUBxbmFwLmNvbTAeFw0yMjAzMTgwNzM5MTRaFw0yNTAzMTcw
NzM5MTRaMIGGMQswCQYDVQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQH
DAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsMA05BUzEWMBQGA1UEAwwN
TGljZW5zZUNlbnRlcjEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20w
ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC/bAgbZryVvBXfpBHNUKQV
sAkAfvDXjKnxa7lKHrRIcFcOnf+voUZcP1Ly9qWb782gB2eUHsUS1Xqj4CF/dUJf
FEnOBrQUo9+Q9B3x4oTRpMdky7acP4dxAbt4T92swgaReQXAewy9s9//a52HIBca
1dAA4JPwplqiZ/oh18GDCKxh84Iu9Gcu2J5e+VXEI/KUxCwKUd22aDTpv128MSoq
dYexCerCJtQbgM3cwkkMiDnFpjrsta5iFpyrNKdLoBJ7YbY3d5Onkqy4DjE8hwR7
0j7Qd+3xbMqv3FOCKeLLLn6N03IXHKP/big/MdXKY1dJQVA3/ks/knPH8mhcOM0d
AgMBAAGjPDA6MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFw
LmNvbS9jcmwvcXRzX3YxLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAWlT1GDH6v8G3
laIAs2/RdxhPgtKX4aL+fnTEFNF5V2yH0G4luyq5tHQw+VCHtDM6Z3GXWhciKPAR
upbRcHq744JCFaUb6i8z1w1KVJDaQ38EVE5+JtpoPMrrnb+hKB/gGmi4PoMSpnvX
VCxLbCbBnwi19o6t/MnPbz0shvUB2NDngnal6lYQFw/F8Sr6cSjV6GAY4TOZotdu
+gunwqQtYUycEVfNyiWVk/flgED8R8oxTPl9ZoDGen+OgjkZrvgynKnqPLHyxZSd
hYSoWyWcZWkMCQ+69kOgJVvrRa7z9F9y30uAHXIUrsLV2d/dImVjApMHbZ60iALG
AVIlas0e4g==
-----END CERTIFICATE-----
EOB
read -r -d '' QPKG_SIGNATURE << EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename="smime.p7m"
Content-Type: application/pkcs7-mime;smime-type=signed-data; name="smime.p7m"
Content-Transfer-Encoding: base64

MIIGtAYJKoZIhvcNAQcCoIIGpTCCBqECAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFAkoseBaFir08zCz63r2YA82DXzxoIIDxzCCA8MwggKroAMCAQIC
BQC4Q1bsMA0GCSqGSIb3DQEBCwUAMIGAMQswCQYDVQQGEwJUVzEPMA0GA1UECAwG
VGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsM
A05BUzEQMA4GA1UEAwwHUU5BUF9DQTEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlA
cW5hcC5jb20wHhcNMjIwMzE4MDczOTE0WhcNMjUwMzE3MDczOTE0WjCBhjELMAkG
A1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYD
VQQKDARRTkFQMQwwCgYDVQQLDANOQVMxFjAUBgNVBAMMDUxpY2Vuc2VDZW50ZXIx
IDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tMIIBIjANBgkqhkiG9w0B
AQEFAAOCAQ8AMIIBCgKCAQEAv2wIG2a8lbwV36QRzVCkFbAJAH7w14yp8Wu5Sh60
SHBXDp3/r6FGXD9S8valm+/NoAdnlB7FEtV6o+Ahf3VCXxRJzga0FKPfkPQd8eKE
0aTHZMu2nD+HcQG7eE/drMIGkXkFwHsMvbPf/2udhyAXGtXQAOCT8KZaomf6IdfB
gwisYfOCLvRnLtieXvlVxCPylMQsClHdtmg06b9dvDEqKnWHsQnqwibUG4DN3MJJ
DIg5xaY67LWuYhacqzSnS6ASe2G2N3eTp5KsuA4xPIcEe9I+0Hft8WzKr9xTgini
yy5+jdNyFxyj/24oPzHVymNXSUFQN/5LP5Jzx/JoXDjNHQIDAQABozwwOjA4BgNV
HR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5hcC5jb20vY3JsL3F0c192
MS5jcmwwDQYJKoZIhvcNAQELBQADggEBAFpU9Rgx+r/Bt5WiALNv0XcYT4LSl+Gi
/n50xBTReVdsh9BuJbsqubR0MPlQh7QzOmdxl1oXIijwEbqW0XB6u+OCQhWlG+ov
M9cNSlSQ2kN/BFROfibaaDzK652/oSgf4BpouD6DEqZ711QsS2wmwZ8ItfaOrfzJ
z289LIb1AdjQ54J2pepWEBcPxfEq+nEo1ehgGOEzmaLXbvoLp8KkLWFMnBFXzcol
lZP35YBA/EfKMUz5fWaAxnp/joI5Ga74Mpyp6jyx8sWUnYWEqFslnGVpDAkPuvZD
oCVb60Wu8/Rfct9LgB1yFK7C1dnf3SJlYwKTB22etIgCxgFSJWrNHuIxggKbMIIC
lwIBATCBijCBgDELMAkGA1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UE
BwwGVGFpcGVpMQ0wCwYDVQQKDARRTkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMM
B1FOQVBfQ0ExIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tAgUAuENW
7DALBglghkgBZQMEAgGggeQwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
hkiG9w0BCQUxDxcNMjIxMjAyMDMwOTE3WjAvBgkqhkiG9w0BCQQxIgQgvtdZSm+m
c7QevdJma9Em5ycFr3I7Wo4aG40Vcx/mT5IweQYJKoZIhvcNAQkPMWwwajALBglg
hkgBZQMEASowCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBAjAKBggqhkiG9w0DBzAO
BggqhkiG9w0DAgICAIAwDQYIKoZIhvcNAwICAUAwBwYFKw4DAgcwDQYIKoZIhvcN
AwICASgwDQYJKoZIhvcNAQEBBQAEggEAuInAOUj+ebOkTqlqg3cf7v2FdKeCvZZn
cunx1xRnHJRVAAvcH/UZ3t7RF6MV5NmEQdVN79NBZl0KU1x7K3zyvcXnkacNuHnI
t+6neKKKkxJmB4hh4ljeYtx9a1RBgwH+PiYyH8+58S7+MF3MVhSH8jEiomgSbvsK
BroOCFQDoYWk14K/VIXW1scmvpNvFNBWwm19pYwi977rF+lPWzMHx/0jVXspFSEd
U48h9xKvPg6CsIlyfuKetHBjZZI6iSCvh2FZOWsD1/W2oGYkkY9Hdff24B34/res
cKXk/K9/JFAONWBbXUpxtzpBCeVJlZS1wQgu4Q+Fr6imaBXJkiyiNg==
EOB
readonly QPKG_CERTIFICATE
readonly QPKG_SIGNATURE
}
MakePath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} && -n ${2:?${FUNCNAME[0]}'()': undefined reason} ]] || return
if [[ $1 != undefined ]] && ! mkdir -p "$1";then
ShowAsError "unable to create $2 path $(ShowAsFileName "$1") $(ShowAsExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0
}
ClearPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined parent path} && -n ${2:?${FUNCNAME[0]}'()': undefined target path} ]] || return
local parent=${1:-undefined}
local target=$($BASENAME_CMD "${2:-undefined}")
[[ -n $parent && $parent != undefined && -n $target && $target != undefined && -d $parent/$target ]] && rm -rf "${parent:?}/${target:?}"/*
}
RunAndLog()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined commandstring} && -n ${2:?${FUNCNAME[0]}'()': undefined pathfile} ]] || return
Func:Init
MakePath "$RUN_LOGS_PATH" 'runtime logs'
local -r LOG_PATHFILE=$($MKTEMP_CMD "$RUN_LOGS_PATH"/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
ShowAsCommand "$1" > "$2"
DebugAsProc "exec: '$1'"
if [[ $useropt_verbose = true ]];then
eval "$1 > >($TEE_CMD $LOG_PATHFILE) 2>&1"
z=$?
else
(eval "$1" > "$LOG_PATHFILE" 2>&1)
z=$?
fi
if [[ -e $LOG_PATHFILE ]];then
ShowAsResultAndStdout "$z" "$(<"$LOG_PATHFILE")" >> "$2"
rm -f "$LOG_PATHFILE"
else
ShowAsResultAndStdout "$z" '<null>' >> "$2"
fi
case $z in
0|"${4:-}")
[[ ${3:-} != log:failure-only || $useropt_debug = true ]] && AddExtLogToSessLog "$2"
DebugAsDone 'exec: complete'
[[ $useropt_debug = false ]] && rm -f "$2"
;;
*)
AddExtLogToSessLog "$2"
DebugAsError 'exec: complete, but with errors'
esac
Func:Exit $z
}
DeDupeWords()
{
[[ -n ${1:-} ]] || return
tr ' ' '\n' <<< "$1" | $SORT_CMD | $UNIQ_CMD | tr '\n' ' ' | $SED_CMD 's|^[[:blank:]]*||;s|[[:blank:]]*$||'
}
FileMatchesMD5()
{
[[ $($MD5SUM_CMD "${1:?${FUNCNAME[0]}'()': undefined pathfile}" | cut -f1 -d' ') = "${2:?${FUNCNAME[0]}'()': undefined checksum}" ]]
}
Pluralise()
{
[[ ${1:-0} -ne 1 ]] && printf s
}
Capitalise()
{
[[ -n ${1:-} ]] || return
if [[ $1 == sherpa* ]];then
echo -n "$1"
else
echo -n "$(Uppercase ${1:0:1})${1:1}"
fi
}
Uppercase()
{
tr 'a-z' 'A-Z' <<< "${1:-}"
}
Lowercase()
{
tr 'A-Z' 'a-z' <<< "${1:-}"
}
LTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob;printf '%s' "${1##+(' ')}")
}
RTrim()
{
[[ -n ${1:-} ]] || return
(shopt -s extglob;printf '%s' "${1%%+(' ')}")
}
Trim()
{
[[ -n ${1:-} ]] || return
RTrim "$(LTrim "$1")"
}
FormatAsThous()
{
local a=$($SED_CMD 's/[^0-9]*//g' <<< "${1:-}")
local b=''
local c=''
while [[ ${#a} -gt 0 ]];do
b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then
c=$b
else
c=$b,$c
fi
if [[ ${#b} -eq 3 ]];then
a=${a%???}
else
break
fi
done
echo -n "$c"
return 0
}
FormatAsIsoBytes()
{
$AWK_CMD 'BEGIN{ u[0]="B";u[1]="kB"; u[2]="MB"; u[3]="GB"} { n = $1; i = 0; while(n > 1000) { i+=1; n= int((n/1000)+0.5) } print n u[i] } ' <<< "$1"
}
Title:Show()
{
[[ $show_title = true && $title_shown = false && $useropt_verbose = false ]] || return
EraseThisLine
if [[ -z ${ARGS_RAW[*]:-} ]];then
Display "$(ShowTitleArt)"
else
Display "$(ShowAsTitleName) $(ShowAsVersion)"
fi
title_shown=true
}
ShowAsTitleName()
{
TextBrightWhite sherpa
}
ShowTitleArt()
{
Display "$(TextBrightOrange '     _')"
Display "$(TextBrightOrange ' ___| |__   ___ _ __ _ __   __ _')"
Display "$(TextBrightOrange "/ __| '_ \ / _ \ '__| '_ \ / _\` |")  $(ShowAsDescription)"
Display "$(TextBrightOrange '\__ \ | | |  __/ |  | |_) | (_| |')  $(ShowAsCopyrightBasic)"
Display "$(TextBrightOrange '|___/_| |_|\___|_|  | .__/ \__,_|')  $(ShowAsVersion)"
Display "$(TextBrightOrange '                    |_|')"
}
ShowAsDescription()
{
printf '%s' 'A mini-package-manager for QNAP® NAS'
}
ShowAsCopyrightBasic()
{
printf '%s' 'Copyright (C) 2017-2024 OneCD'
}
ShowAsVersion()
{
printf '%s' "v$THIS_SCRIPT_VER"
}
#ShowAsEmail()
ShowAsAction()
{
TextBrightYellow '[action]'
}
ShowAsPackages()
{
TextBrightOrange '[packages]'
}
ShowAsPackageGroup()
{
TextBrightOrange '[package group]'
}
ShowAsOptions()
{
TextBrightRed '[options]'
}
ShowAsPackageName()
{
printf '%s' "${1:?${FUNCNAME[0]}'()': undefined package name}"
}
ShowAsFileName()
{
printf '%s' "'${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsURL()
{
TextUnderlinedCyan "${1:?${FUNCNAME[0]}'()': undefined URL}"
}
ShowAsExitcode()
{
printf '%s' "[${1:?${FUNCNAME[0]}'()': undefined exitcode}]"
}
ShowAsLogFilename()
{
printf '%s' "${CHARS_RESULTS}log file: '${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsCommand()
{
echo "${CHARS_RESULTS}command: '${1:?${FUNCNAME[0]}'()': undefined commandstring}'"
}
ShowAsResultAndStdout()
{
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] || return
local a=$CHARS_RESULTS
[[ ${1:-0} -ne 0 ]] && a=$CHARS_ALERT
echo "${a}result_code: $(ShowAsExitcode "$1") ***** stdout/stderr begins below *****"
echo "$2"
echo "${a}***** stdout/stderr is complete *****"
}
DisplayProcReport()
{
[[ ${report_title_shown:=false} = false ]] || return
local a=''
[[ -n ${1:-} ]] && a="$1 "
ShowAsProc "${a}report"
report_title_shown=true
}
DebugInfoMajSepr()
{
DebugInfo "$(eval printf '%0.s=' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugInfoMinSepr()
{
DebugInfo "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugExtLogMinSepr()
{
DebugAsLog "$(eval printf '%0.s-' "{1..$DEBUG_LOG_DATAWIDTH}")"
}
DebugScript()
{
DebugDetectTabld SCRIPT "${1:-}" "${2:-}"
}
DebugHardware()
{
case ${1:-} in
warning)
DebugWarningTabld HARDWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld HARDWARE "${2:-}" "${3:-}"
esac
}
DebugFirmware()
{
case ${1:-} in
warning)
DebugWarningTabld FIRMWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld FIRMWARE "${2:-}" "${3:-}"
esac
}
DebugUserspace()
{
case ${1:-} in
warning)
DebugWarningTabld USERSPACE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld USERSPACE "${2:-}" "${3:-}"
esac
}
DebugIpk()
{
case ${1:-} in
error)
DebugErrorTabld IPK "${2:-}" "${3:-}"
;;
*)
DebugInfoTabld IPK "${2:-}" "${3:-}"
esac
}
DebugQpkg()
{
case ${1:-} in
error)
DebugErrorTabld QPKG "${2:-}" "${3:-}"
;;
warning)
DebugWarningTabld QPKG "${2:-}" "${3:-}"
;;
info)
DebugInfoTabld QPKG "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld QPKG "${2:-}" "${3:-}"
esac
}
DebugDetectTabld()
{
if [[ -z ${3:-} ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsDetect "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugInfoTabld()
{
if [[ -z ${3:-} ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsInfo "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugWarningTabld()
{
if [[ -z ${3:-} ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsWarn "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugErrorTabld()
{
if [[ -z ${3:-} ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsError "$(printf "%${DEBUG_LOG_FIRST_COL_WIDTH}s: %${DEBUG_LOG_SECOND_COL_WIDTH}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugVar()
{
DebugAsVar "\$$1 : '${!1:-undefined}'"
}
DebugInfo()
{
[[ -n ${1:-} ]] || return
if [[ ${2:-} = ' ' || ${2:-} = "'' " ]];then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi
}
Func:Init()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(/bin/date +%s%N)"
DebugAsFuncEn
}
Func:Exit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ShowAsDuration "$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")")"
return ${1:-0}
}
FuncFork:Init()
{
original_sess_active_pathfile=$sess_active_pathfile
MakePath "$ACTION_LOGS_PATH" 'action logs'
sess_active_pathfile=$($MKTEMP_CMD "$ACTION_LOGS_PATH"/"${FUNCNAME[1]}"_XXXXXX)
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(/bin/date +%s%N)"
DebugAsFuncEn
}
FuncFork:Exit()
{
local -r VAR_NAME=${FUNCNAME[1]}_STARTSECONDS
local var_safe_name=${VAR_NAME//[.-]/_}
var_safe_name=${var_safe_name//:/_}
SendActionStatus ex
DebugAsFuncEx "${1:-0}" "$(ShowAsDuration "$(CalcMilliDifference "${!var_safe_name}" "$(/bin/date +%s%N)")")"
if [[ -n $sess_active_pathfile && -e $sess_active_pathfile ]];then
if [[ -s $sess_active_pathfile ]];then
$CAT_CMD "$sess_active_pathfile" >> "$original_sess_active_pathfile"
fi
rm -f "$sess_active_pathfile"
fi
sess_active_pathfile=$original_sess_active_pathfile
original_sess_active_pathfile=''
exit ${1:-0}
}
CalcMilliDifference()
{
echo -n "$((($2-$1)/1000000))"
}
ShowAsDuration()
{
if [[ ${1:-0} -lt 30000 ]];then
echo -n "$(FormatAsThous "${1:-0}")ms"
else
FormatSecsToHoursMinutesSecs "$(($1/1000))"
fi
}
DebugAsFuncEn()
{
DebugThis "(>>) ${FUNCNAME[2]}()"
}
DebugAsFuncEx()
{
DebugThis "(<<) ${FUNCNAME[2]}|${1:-0}|${2:-}"
}
DebugAsProc()
{
[[ -n $1 ]] && DebugThis "(--) $1"
}
DebugAsDone()
{
[[ -n $1 ]] && DebugThis "(==) $1"
}
DebugAsDetect()
{
[[ -n $1 ]] && DebugThis "(**) $1"
}
DebugAsInfo()
{
[[ -n $1 ]] && DebugThis "(II) $1"
}
DebugAsWarn()
{
[[ -n $1 ]] && DebugThis "(WW) $1"
}
DebugAsError()
{
[[ -n $1 ]] && DebugThis "(EE) $1"
}
DebugAsLog()
{
[[ -n $1 ]] && DebugThis "(LL) $1"
}
DebugAsVar()
{
[[ -n $1 ]] && DebugThis "(vv) $1"
}
DebugThis()
{
[[ -n ${1:-} ]] || return
[[ ${useropt_verbose:-false} = true ]] && ShowAsDebug "$1"
WriteToLog dbug "$1"
}
AddExtLogToSessLog()
{
local a=''
local b=false
if [[ $useropt_verbose = true ]];then
b=true
useropt_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(ShowAsLogFilename "${1:?${FUNCNAME[0]}'()': undefined pathfile}")"
while read -r a;do
DebugAsLog "$a"
done < "$1"
DebugExtLogMinSepr
useropt_verbose=$b
}
ShowAsProcLong()
{
ShowAsProc "${1:-} (might take a while)" "${2:-}"
} >&2
ShowAsProc()
{
local a=''
local b=''
[[ -n ${1:-} ]] && a=$1 || return
[[ -n ${2:-} ]] && b=${2:-}
if [[ ${useropt_verbose:=false} = false && ${useropt_terse:=true} = true ]] || [[ ${useropt_verbose:=false} = false && -n ${2:-} ]];then
OpStepClearWait "$(TextBrightYellow proc)" "$a $CHARS_ELLIPSIS $b"
else
OpStepClear "$(TextBrightYellow proc)" "$a $CHARS_ELLIPSIS $b"
fi
WriteToLog proc "${a}${b}"
} >&2
ShowAsDebug()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBlackOnCyan dbug)" "$1"
}
ShowAsNote()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightYellow note)" "$a"
WriteToLog note "$a"
} >&2
ShowAsDone()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightGreen 'done')" "$a"
WriteToLog 'done' "$a"
} >&2
ShowAsWarn()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightOrange warn)" "$a"
WriteToLog warn "$a"
} >&2
ShowAsAbort()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed bort)" "$a"
WriteToLog bort "$a"
Error:Set
} >&2
ShowAsFail()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed fail)" "$a"
WriteToLog fail "$a"
} >&2
ShowAsError()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed derp)" "$a"
WriteToLog derp "$a"
Error:Set
} >&2
ShowAsQuiz()
{
[[ -n ${1:-} ]] || return
OpStepClearWait "$(TextBrightOrangeBlink quiz)" "$1:"
WriteToLog quiz "$1:"
}
ShowAsQuizDone()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBrightOrange quiz)" "$1"
}
AddPeriod()
{
[[ -n ${1:-} ]] || return
[[ ${1: -1} != ':' && ${1: -1} != '?' && ${1: -1} != '.' ]] && printf '%s' "${1}." || printf '%s' "$1"
}
ShowAsPercentProgress()
{
local -r a=${1:-}
local -i b=${3:-0}
local -i c=${4:-0}
local -i d=${5:-0}
local -i e=${6:-0}
local -r f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then
ShowAsProc "$a" "$f"
else
ShowAsProcLong "$a" "$f"
fi
[[ $((b+c+d)) -ge $e ]] && sleep 0.5
return 0
} >&2
PercFrac()
{
local -i a=$((${1:-0}+${2:-0}+${3:-0}))
local -i b=${4:-0}
local c=''
[[ $b -gt 0 ]] || return
if [[ $a -gt $b ]];then
a=$b
c='100%'
else
c="$((200*(a+1)/(b+1)%2+100*(a+1)/(b+1)))%"
fi
echo -n "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0
} 2>/dev/null
ShowAsIterativeProgress()
{
local -r a=${1:?${FUNCNAME[0]}'()': undefined action}
local -i b=${2:-0}
local -r c=${3:?${FUNCNAME[0]}'()': undefined suffix1}
local -i d=${4:-0}
local -r e=${5:?${FUNCNAME[0]}'()': undefined suffix2}
local f=''
f="$(TextBrightWhite "$b") ${c}$(Pluralise "$b"): $(TextBrightWhite "$d") ${e}$(Pluralise "$d")"
if [[ ${6:-short} != long ]];then
ShowAsProc "$a" "$f"
else
ShowAsProcLong "$a" "$f"
fi
return 0
}
ShowAsActionLogDetail()
{
if [[ ${2:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
case ${4:-} in
failed)
if [[ -n "${6:-}" ]];then
case $3 in
download|reassign|sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2" "$5" "$6"
;;
*)
if QPKG.IsCanLog "$2";then
DisplayAsIndentActionResultDurationReason "$3" "$2" "$5" "For more information: /etc/init.d/$($BASENAME_CMD "$(QPKG.GetServicePathFile "$2")") log"
else
DisplayAsIndentActionResultDurationReason "$3" "$2" "$5" "$6"
fi
esac
else
DisplayAsIndentActionResultDurationReason "$3" "$2" "$5" 'no reason was provided by the service script'
fi
;;
skipped*)
if [[ -n "${6:-}" ]];then
DisplayAsIndentActionResultDurationReason "$3" "$2" '' "$6"
else
DisplayAsIndentActionResultDurationReason "$3" "$2" '' "no reason provided"
fi
;;
*)
DisplayAsIndentActionResultDurationReason "$3" "$2" "$5"
esac
}
OpStepClearWait()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
OpStepClear()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
WriteToLog()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
[[ ${useropt_debug:=false} = true && -n $sess_active_pathfile ]] && printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")" >> "$sess_active_pathfile"
}
TextBrightGreen()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightYellow()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrange()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightOrangeBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRed()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightRedBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
#TextCyan()
TextDarkGrey()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
#TextUnderlined()
TextUnderlinedCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBlackOnCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
TextBrightWhite()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2>/dev/null
StripANSICodes()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd ]];then
/opt/bin/sed -r 's/\x1b\[[0-9;]*m//g' <<< "${1:-}"
else
printf '%s' "${1:-}"
fi
} 2>/dev/null
UpdateColourisation()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd && $(LoadSetting Colourful "$colourful_default") = true ]];then
useropt_colourful=true
SendParentChangeEnv 'useropt_colourful=true'
else
useropt_colourful=false
SendParentChangeEnv 'useropt_colourful=false'
fi
}
Cursor:Hide()
{
[[ $useropt_verbose = false ]] && printf '\033[?25l'
}
Cursor:Show()
{
printf '\033[?25h'
}
Keystrokes:Hide()
{
[[ $useropt_verbose = false && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD '-echo'
}
Keystrokes:Show()
{
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD 'echo'
}
FormatMillisecsToMinutesSecs()
{
local seconds=$((${1:-0}/1000))
((m=(seconds%3600)/60))
((s=seconds%60))
[[ $s -eq 0 ]] && s=1
if [[ $m -eq 0 ]];then
if [[ $s -eq 1 ]];then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
else
printf '%dm:%02ds' "$m" "$s"
fi
} 2>/dev/null
FormatSecsToHoursMinutesSecs()
{
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
printf '%01dh:%02dm:%02ds\n' "$h" "$m" "$s"
} 2>/dev/null
FormatLongMinutesSecs()
{
local m=${1%%:*}
local s=${1#*:}
m=${m##* }
s=${s##* }
printf '%01dm:%02ds\n' "$((10#$m))" "$((10#$s))"
} 2>/dev/null
sleep()
{
local n=${1:-}
[[ ${n//.} -eq 0 ]] && n=1
if [[ -e $GNU_SLEEP_CMD && -L /opt/etc/passwd ]];then
$GNU_SLEEP_CMD "$n"
elif [[ $DECIMAL_SLEEP_SECONDS_SUPPORTED = false ]];then
$SLEEP_CMD "$((${n%.*}+1))"
else
$SLEEP_CMD "$n"
fi
return 0
} 2>/dev/null
Objects:Load()
{
[[ ${objects_loaded:=false} = false ]] || return 0
Func:Init
Lists:Load
if [[ ! -e $PWD/dont-refresh-objects ]];then
if [[ ! -e $OBJECTS_PATHFILE ]] || ! IsThisFileRecent "$OBJECTS_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES";then
ShowAsProc 'downloading objects'
if $CURL_CMD --silent --fail "$OBJECTS_ARCHIVE_URL" > "$OBJECTS_ARCHIVE_PATHFILE";then
$TAR_CMD --extract --gzip --no-same-owner --file="$OBJECTS_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
fi
fi
if [[ ! -e $OBJECTS_PATHFILE ]];then
ShowAsAbort 'objects missing'
Func:Exit 1;exit
fi
ShowAsProc 'loading objects'
. "$OBJECTS_PATHFILE"
objects_loaded=true
readonly OBJECTS_VER
DebugVar OBJECTS_VER
Func:Exit
}
Packages:Load()
{
[[ ${packages_loaded:=false} = false ]] || return 0
Func:Init
Objects:Load
if [[ ! -e $PWD/dont-refresh-packages ]];then
if [[ ! -e $PACKAGES_PATHFILE ]] || ! IsThisFileRecent "$PACKAGES_PATHFILE" "$FILE_CHANGE_THRESHOLD_MINUTES";then
ShowAsProc 'downloading QPKG list'
if $CURL_CMD --silent --fail "$PACKAGES_ARCHIVE_URL" > "$PACKAGES_ARCHIVE_PATHFILE";then
$TAR_CMD --extract --gzip --no-same-owner --file="$PACKAGES_ARCHIVE_PATHFILE" --directory="$CACHE_PATH"
fi
fi
fi
if [[ ! -e $PACKAGES_PATHFILE ]];then
ShowAsAbort 'QPKG list missing'
Func:Exit 1;exit
fi
ShowAsProc 'loading QPKG list'
. "$PACKAGES_PATHFILE"
packages_loaded=true
readonly BASE_QPKG_CONFLICTS_WITH
readonly BASE_QPKG_WARNINGS
readonly ESSENTIAL_IPKS
readonly ESSENTIAL_PIPS
readonly MIN_PERL_VER
readonly MIN_PYTHON_VER
readonly PACKAGES_VER
readonly QPKG_ABBRVS
readonly QPKG_APP_AUTHOR
readonly QPKG_APP_AUTHOR_EMAIL
readonly QPKG_APP_VERSION
readonly QPKG_ARCH
readonly QPKG_AUTHOR
readonly QPKG_AUTHOR_EMAIL
readonly QPKG_CAN_BACKUP
readonly QPKG_CAN_CLEAN
readonly QPKG_CAN_LOG_SERVICE_OPERATIONS
readonly QPKG_CAN_RESTART_TO_UPDATE
readonly QPKG_CONFLICTS_WITH
readonly QPKG_DEPENDS_ON
readonly QPKG_DESC
readonly QPKG_HASH
readonly QPKG_MAX_OS_VERSION
readonly QPKG_MIN_OS_VERSION
readonly QPKG_MIN_RAM_KB
readonly QPKG_NAME
readonly QPKG_NOTE
readonly QPKG_REQUIRES_IPKS
readonly QPKG_TEST_FOR_ACTIVE
readonly QPKG_URL
readonly QPKG_VERSION
DebugVar PACKAGES_VER
QPKGs-GRall:Add "${QPKG_NAME[*]}"
QPKGs.IndependentDependent:Build
Func:Exit
}
Traps:Set()
{
trap RunOnEXIT EXIT
trap RunOnSIGINT INT
}
RunOnSIGINT()
{
$TOUCH_CMD "$DISPLAY_INHIBIT_PATHFILE"
EraseThisLine
ShowAsAbort 'caught SIGINT'
KillActiveFork
CloseActionMsgPipe
exit
}
RunOnEXIT()
{
trap - INT
Keystrokes:Show
Cursor:Show
LockFile:Release
}
Init || exit
Actions:Proc
Results:Show
Error.IsNt
