#!/usr/bin/env bash
#* Please don't edit this file directly, it was built/modified programmatically with the 'build-manager.sh' script. (source: 'sherpa-manager.source')
#* sherpa-manager.sh
#* copyright (C) 2017-2024 OneCD.
#* Contact:
#*   one.cd.only@gmail.com
#* Description:
#*   This is the management script for the sherpa mini-package-manager.
#*   It's automatically downloaded via the `sherpa-loader.sh` script in the `sherpa` QPKG no-more than once-per-hour.
#* Project:
#*	 https://git.io/sherpa
#* Forum:
#*	 https://forum.qnap.com/viewtopic.php?t=132373
#* Tested on:
#*	 GNU bash, version 3.2.57(2)-release (i686-pc-linux-gnu)
#*	 GNU bash, version 3.2.57(1)-release (aarch64-QNAP-linux-gnu)
#*	   Copyright (C) 2007 Free Software Foundation, Inc.
#*   ... and periodically on:
#*	 GNU bash, version 5.0.17(1)-release (aarch64-openwrt-linux-gnu)
#*	   Copyright (C) 2019 Free Software Foundation, Inc.
#* License:
#*   This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#*	 This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#*	 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
set -o nounset -o pipefail
shopt -s extglob
[[ $- != *m* ]] || set +m
ln -fns /proc/self/fd /dev/fd
readonly r_args_raw=$*
Init()
{
OsIsOk || return
UserIsOk || return
LoadConsts
LoadVars
UpdateCapabilities
LoadCMDs
CMDsIsOk || return
HideKeystrokes
HideCursor
LoadEnv || return
ClaimLockfile || return
CreatePaths || return
PrepareArgs
ParseManagementArgs || return
ParseHelpArgs || return
ArchivePriorSessLogs
DebugLogInit
ParseShowArgs || return
ParseListArgs || return
ParseActionArgs || return
ShowTitle
ShowArgSuggestions
CheckQPKGsConflicts || return
CheckQPKGsWarnings
DebugLogEnv
CheckTasks
CheckEnv
QPKGsAssignToActions
return 0
}
ShowResults()
{
FuncInit
local a=''
if [[ $generate_show_report = true ]];then
if [[ $useropt_show_log_last = true ]];then
ReleaseLockfile
ViewLogLast
elif [[ $useropt_show_log_tail = true ]];then
ReleaseLockfile
ViewLogTail
elif [[ $useropt_show_backups = true ]];then
ReleaseLockfile
ShowReportBackups
elif [[ $useropt_show_versions = true ]];then
ReleaseLockfile
ShowReportVersions
elif [[ $useropt_show_dependencies = true ]];then
ShowReportDependencies
elif [[ $useropt_show_features = true ]];then
ShowReportFeatures
elif [[ $useropt_show_packages = true ]];then
ShowReportPackages
elif [[ $useropt_show_repos = true ]];then
ShowReportRepos
elif [[ $useropt_show_status = true ]];then
ShowReportStatuses
fi
fi
if [[ $generate_list_report = true ]];then
if [[ ${packages_loaded:=false} = true ]];then
for a in "${r_qpkg_is_states[@]}";do
case $a in
downloaded|signed)
:
;;
*)
if QPKGs.AClist.IS${a}.IsSet;then
ShowQPKGsIS${a}
break
elif QPKGs.AClist.ISNT${a}.IsSet;then
ShowQPKGsISNT${a}
break
fi
esac
done
fi
fi
if [[ $useropt_paste_log_last = true ]];then
PasteLogLast
elif [[ $useropt_paste_log_tail = true ]];then
PasteLogTail
fi
if [[ $useropt_help_basic = true ]];then
ShowHelpBasic
ShowHelpBasicExamples
fi
if [[ $generate_help_report = true ]];then
ReleaseLockfile
if [[ $useropt_help_tips = true ]];then
ShowHelpTips
elif [[ $useropt_help_abbreviations = true ]];then
HelpAbbreviations
elif [[ $useropt_help_actions = true ]];then
ShowHelpActions
elif [[ $useropt_help_actions_all = true ]];then
ShowHelpActionsAll
elif [[ $useropt_help_lists = true ]];then
ShowHelpLists
elif [[ $useropt_help_options = true ]];then
ShowHelpOptions
elif [[ $useropt_help_packages = true ]];then
ShowHelpPackages
elif [[ $useropt_help_show = true ]];then
ShowHelpShow
elif [[ $useropt_help_problems = true ]];then
ShowHelpProblems
elif [[ $useropt_help_upgrades = true ]];then
ShowHelpUpgrades
elif [[ $useropt_help_groups = true ]];then
ShowHelpGroups
fi
fi
if [[ $generate_action_results_report = true || $generate_show_report = true ]];then
ShowReportAllActionResults
fi
[[ $show_backuploc = true ]] && ShowHelpBackupLocation
[[ $show_suggest_raise_issue = true ]] && ShowHelpIssue
DebugInfoMinSepr
DebugScript finished "$(ConvertNowToFullDate)"
DebugScript 'elapsed time' "$(ConvertSecondsToDuration "$(($(ConvertNowToSeconds)-r_script_startseconds))")"
DebugInfoMajSepr
[[ $title_shown = true ]] && Display
FuncExit
[[ $archive_debug_afterward = true ]] && ArchiveActiveSessLog
ResetActiveSessLog
}
DebugLogInit()
{
DebugInfoMajSepr
DebugScript started "$(ConvertSecondsToFullDate "$r_script_startseconds")"
DebugScript PID "$$"
DebugInfoMinSepr
DebugInfo 'Markers: (**) detected, (II) information, (WW) warning, (EE) error, (LL) log file, (--) processing,'
DebugInfo '(==) done, (>>) f entry, (<<) f exit, (aa) array name & values, (vv) variable name & value,'
DebugInfo '($1) positional argument value'
DebugInfoMinSepr
DebugVar r_this_package_ver
DebugVar r_this_script_ver
DebugVar LOADER_SCRIPT_VERSION
}
LoadConsts()
{
readonly r_qpkg_disable_timeout_seconds=10
readonly r_qpkg_enable_timeout_seconds=10
readonly r_qpkg_restart_timeout_seconds=1800
readonly r_qpkg_start_timeout_seconds=1500
readonly r_qpkg_status_check_timeout_seconds=15
readonly r_qpkg_stop_timeout_seconds=300
readonly r_report_qpkg_abbreviations_column_width=84
readonly r_report_qpkg_action_column_width=27
readonly r_report_qpkg_active_test_builtin_column_width=11
readonly r_report_qpkg_appl_version_column_width=22
readonly r_report_qpkg_arch_column_width=15
readonly r_report_qpkg_author_column_width=40
readonly r_report_qpkg_auto_update_column_width=10
readonly r_report_qpkg_dependencies_column_width=29
readonly r_report_qpkg_description_column_width=10
readonly r_report_qpkg_install_date_column_width=20
readonly r_report_qpkg_is_compatible_column_width=9
readonly r_report_qpkg_is_enabled_column_width=10
readonly r_report_qpkg_is_installed_column_width=12
readonly r_report_qpkg_is_managed_column_width=10
readonly r_report_qpkg_max_os_version_column_width=10
readonly r_report_qpkg_min_os_version_column_width=10
readonly r_report_qpkg_min_ram_column_width=14
readonly r_report_qpkg_name_column_width=21
readonly r_report_qpkg_path_column_width=48
readonly r_report_qpkg_repo_column_width=40
readonly r_report_qpkg_status_column_width=23
readonly r_report_qpkg_supports_backup_column_width=10
readonly r_report_qpkg_supports_clean_column_width=11
readonly r_report_qpkg_supports_start_to_update_column_width=11
readonly r_report_qpkg_tier_column_width=8
readonly r_report_qpkg_version_column_width=15
readonly r_report_lazy_column_width=28
readonly r_debug_log_full_width=101
readonly r_debug_log_first_column_width=9
readonly r_debug_log_second_column_width=22
readonly r_debug_log_third_column_width=$((r_debug_log_full_width-r_debug_log_first_column_width-r_debug_log_second_column_width-4))
readonly r_help_desc_indent=3
readonly r_help_syntax_indent=6
readonly r_report_action_result_indent=6
readonly r_report_column_spacing=2
readonly r_report_file_bytes_column_width=16
readonly r_report_file_change_date_column_width=60
readonly r_report_file_name_column_width=$((r_report_qpkg_name_column_width+14))
readonly r_report_footer_name_column_width=14
readonly r_chars_alert='! '
readonly r_chars_attention='* '
readonly r_chars_blank='  '
readonly r_chars_bullet='• '
readonly r_chars_dropend='└─ '
readonly r_chars_ellipsis='...'
readonly r_chars_normal='- '
readonly r_chars_note='* '
readonly r_chars_regular_prompt='$ '
readonly r_chars_sudo_prompt="${r_chars_regular_prompt}sudo "
readonly r_chars_results='= '
readonly r_chars_super_prompt='# '
if OsIsSupportSudo;then
if [[ $(UserGetSudoUID) = undefined ]];then
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
else
readonly r_help_syntax_prefix=$r_chars_regular_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_sudo_prompt
fi
else
readonly r_help_syntax_prefix=$r_chars_super_prompt
readonly r_help_syntax_sudo_prefix=$r_chars_super_prompt
fi
readonly r_file_change_threshold_minutes=60
readonly r_log_tail_lines=5000
}
LoadVars()
{
action_msg_pipe_fd=none
archive_debug_afterward=false
backup_stdin_fd=none
branch_default=stable
fork_pid=''
generate_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
highlight_backups_older_than='2 weeks ago'
ipks_downgrade=false
ipks_install=false
ipks_upgrade=false
pips_install=false
proc_counts_path=''
qpkg_timeouts_increased=false
report_footer_default=true
run_package_actions=false
show_action_results_failed=false
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_zero=false
show_backuploc=false
show_suggest_raise_issue=false
show_title=true
switch_branch=false
switch_colour=false
switch_report_footer=false
switch_terse=false
terse_default=true
title_shown=false
user_branch_value=''
user_colourful_value=''
user_report_footer_value=''
user_terse_value=''
if [[ -t 0 ]];then
colourful_default=true
useropt_colourful=$(LoadSetting Colourful "$colourful_default")
else
colourful_default=false
useropt_colourful=false
fi
useropt_branch=$(LoadSetting Git_Branch "$branch_default")
useropt_check=false
useropt_debug=false
useropt_help_abbreviations=false
useropt_help_actions=false
useropt_help_actions_all=false
useropt_help_basic=false
useropt_help_groups=false
useropt_help_lists=false
useropt_help_options=false
useropt_help_packages=false
useropt_help_problems=false
useropt_help_show=false
useropt_help_tips=false
useropt_help_upgrades=false
useropt_paste_log_last=false
useropt_paste_log_tail=false
useropt_report_footer=$(LoadSetting ReportFooter "$report_footer_default")
useropt_show_backups=false
useropt_show_dependencies=false
useropt_show_features=false
useropt_show_log_last=false
useropt_show_log_tail=false
useropt_show_packages=false
useropt_show_repos=false
useropt_show_all_results=false
useropt_show_status=false
useropt_show_versions=false
useropt_terse=$(LoadSetting Terse "$terse_default")
useropt_verbose=false
}
LoadCMDs()
{
readonly GNU_AWK_CMD=/opt/bin/awk
readonly GNU_FIND_CMD=/opt/bin/find
readonly GNU_GREP_CMD=/opt/bin/grep
readonly GNU_LESS_CMD=/opt/bin/less
readonly GNU_SED_CMD=/opt/bin/sed
readonly GNU_SLEEP_CMD=/opt/bin/sleep
readonly GNU_SORT_CMD=/opt/bin/sort
readonly GNU_STTY_CMD=/opt/bin/stty
readonly GNU_TIMEOUT_CMD=/opt/bin/timeout
readonly OPKG_CMD=/opt/bin/opkg
readonly PERL_CMD=/opt/bin/perl
readonly PYTHON_CMD=/opt/bin/python
readonly PYTHON3_CMD=/opt/bin/python3
readonly PIP_CMD="$PYTHON3_CMD -m pip"
readonly AWK_CMD=/bin/awk
readonly BASENAME_CMD=/usr/bin/basename
readonly CAT_CMD=/bin/cat
CURL_CMD=/sbin/curl
readonly DF_CMD=/bin/df
readonly DIRNAME_CMD=/usr/bin/dirname
readonly DU_CMD=/usr/bin/du
readonly GREP_CMD=/bin/grep
readonly LESS_CMD=/bin/less
readonly MD5SUM_CMD=/bin/md5sum
readonly MKNOD_CMD=/bin/mknod
readonly MKTEMP_CMD=/bin/mktemp
readonly MORE_CMD=/bin/more
readonly PS_CMD=/bin/ps
readonly READLINK_CMD=/usr/bin/readlink
readonly SCREEN_CMD=/usr/sbin/screen
readonly SED_CMD=/bin/sed
readonly SH_CMD=/bin/sh
readonly SLEEP_CMD=/bin/sleep
readonly SORT_CMD=/usr/bin/sort
readonly TAIL_CMD=/usr/bin/tail
readonly TAR_CMD=/bin/tar
readonly TEE_CMD=/usr/bin/tee
readonly UNAME_CMD=/bin/uname
readonly UNIQ_CMD=/bin/uniq
readonly UNZIP_CMD=/usr/bin/unzip
readonly UPTIME_CMD=/usr/bin/uptime
readonly WC_CMD=/usr/bin/wc
}
CMDsIsOk()
{
IsSysFileExist $AWK_CMD || return
IsSysFileExist $BASENAME_CMD || return
IsSysFileExist $CAT_CMD || return
IsSysFileExist $CURL_CMD || return
IsSysFileExist $DF_CMD || return
IsSysFileExist $DIRNAME_CMD || return
IsSysFileExist $DU_CMD || return
IsSysFileExist $GREP_CMD || return
IsSysFileExist $MD5SUM_CMD || return
IsSysFileExist $MKNOD_CMD || return
IsSysFileExist $MKTEMP_CMD || return
IsSysFileExist $PS_CMD || return
IsSysFileExist $READLINK_CMD || return
IsSysFileExist $SCREEN_CMD || return
IsSysFileExist $SH_CMD || return
IsSysFileExist $TAIL_CMD || return
IsSysFileExist $TAR_CMD || return
IsSysFileExist $TEE_CMD || return
IsSysFileExist $UNAME_CMD || return
IsSysFileExist $UNIQ_CMD || return
IsSysFileExist $UNZIP_CMD || return
IsSysFileExist $UPTIME_CMD || return
[[ ! -e $SORT_CMD ]] && ln -s /bin/busybox "$SORT_CMD"
LocateSQLiteBinary
return 0
}
LocateSQLiteBinary()
{
local a=''
sqlite_pathfile=''
sqlite_cmd=''
if [[ -z ${sqlite_cmd:-} ]] && QpkgIsInstalled Entware;then
sqlite_pathfile=/opt/bin/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]] && QpkgIsInstalled HybridBackup;then
sqlite_pathfile=$(QpkgGetInstalledPath HybridBackup)/CloudConnector3/bin/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]] && QpkgIsInstalled ArchiwareP5;then
sqlite_pathfile=$(QpkgGetInstalledPath ArchiwareP5)/binaries/Linux/unknown/64/sqlite3
[[ -e $sqlite_pathfile ]] && sqlite_cmd=$sqlite_pathfile
fi
if [[ -z $sqlite_cmd ]];then
for a in container-station HD_Station;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstalledPath "$a")/usr/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in CacheMount qmiixagent QPython312 QPython311 QPython39;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstalledPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd=$sqlite_pathfile
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
for a in img2pdf Qsirch OCR_Converter;do
if QpkgIsInstalled "$a";then
sqlite_pathfile=$(QpkgGetInstalledPath "$a")/bin/sqlite3
[[ -e $sqlite_pathfile ]] || continue
sqlite_cmd="LD_LIBRARY_PATH=$(QpkgGetInstalledPath "$a")/lib $sqlite_pathfile"
break
fi
done
fi
if [[ -z $sqlite_cmd ]];then
sqlite_pathfile=/opt/bin/sqlite3
sqlite_cmd=$sqlite_pathfile
fi
}
LoadEnv()
{
ShowAsProc env
qpkg_name=sherpa
readonly r_cert_db_pathfile=/etc/config/nas_sign_qpkg.db
readonly r_cpu_cores=$(HardwareGetCPUCores)
readonly r_concurrency=$r_cpu_cores
readonly r_entware_version=$(QpkgGetEntwareType)
readonly r_kernel_page_size=$(OsGetKernelPageSize)
readonly r_nas_arch=$(OsGetArch)
readonly r_nas_firmware_build=$(OsGetFirmwareBuild)
readonly r_nas_firmware_date=$(OsGetFirmwareDate)
readonly r_nas_firmware_version=$(OsGetFirmwareVer)
readonly r_nas_platform=$(HardwareGetPlatform)
readonly r_nas_qpkg_arch=$(QpkgGetArch)
readonly r_nas_ram_kb=$(HardwareGetInstalledRAM)
readonly r_nas_upstate=$(OsGetUpState)
readonly r_this_package_ver=$(QpkgGetInstalledVer)
OsIsSupportSecureDownload || CURL_CMD+=' --insecure'
readonly CURL_CMD
args=()
args_incomplete=()
qpkg_default_index=0
qpkg_index=0
useropt_branch=$(UserGetGitBranch)
readonly r_objects_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa'/$useropt_branch/objects.tar.gz
readonly r_packages_archive_url='https://raw.githubusercontent.com/OneCDOnly/sherpa.packages'/$useropt_branch/packages.tar.gz
readonly r_this_script_ver='240909'-$useropt_branch
readonly r_qpkg_bu_path=$(UserGetDefVol)/.qpkg_config_backup
readonly r_this_package_path=$(QpkgGetInstalledPath)
if [[ -z $r_this_package_path || $r_this_package_path = undefined || ! -d $r_this_package_path ]];then
ShowAsError "$(ShowAsTitleName) installation path not found. Please reinstall the $(ShowAsTitleName) QPKG"
return 1
fi
readonly r_cache_path=$r_this_package_path/cache
readonly r_action_times_path=$r_cache_path/action.times
readonly r_async_procs_path=$r_cache_path/proc
readonly r_dependent_qpkgs_list_pathfile=$r_cache_path/dependents
readonly r_display_inhibit_pathfile=$r_cache_path/display.inhibit
readonly r_independent_qpkgs_list_pathfile=$r_cache_path/independents
readonly r_ipk_cache_path=$r_cache_path/IPKs
readonly r_ipk_downgrade_path=$r_ipk_cache_path/downgrade
readonly r_ipk_download_path=$r_ipk_cache_path/downloads
readonly r_prev_ipk_list_pathfile=$r_ipk_cache_path/ipk.list.save
readonly r_objects_archive_pathfile=$r_cache_path/objects.tar.gz
readonly r_objects_pathfile=$r_cache_path/objects
readonly r_packages_archive_pathfile=$r_cache_path/packages.tar.gz
readonly r_packages_pathfile=$r_cache_path/packages
readonly r_pip_cache_path=$r_cache_path/PIPs
readonly r_prev_pip_list_pathfile=$r_pip_cache_path/pip.list.save
readonly r_qpkg_cache_path=$r_cache_path/QPKGs
readonly r_qpkg_download_path=$r_qpkg_cache_path/downloads
readonly r_logs_path=$r_this_package_path/logs
readonly r_oom_log_pathfile=$r_logs_path/oom.log
readonly r_ram_freeused_pathfile=$r_logs_path/ram.freeused
readonly r_ramfs_freespace_pathfile=$r_logs_path/ramfs.freespace
readonly r_screen_sessions_pathfile=$r_logs_path/screen.sessions
readonly r_session_action_results_pathfile=$r_logs_path/session.action.results.log
readonly r_session_archive_pathfile=$r_logs_path/session.archive.log
readonly r_session_last_pathfile=$r_logs_path/session.last.log
readonly r_session_tail_pathfile=$r_logs_path/session.tail.log
sess_active_pathfile=$r_this_package_path/session.$$.active.log
readonly r_action_forks_count=/var/run/sherpa/actions/forks
readonly r_action_logs_path=/var/log/sherpa/actions/logs
readonly r_qpkg_states_path=/var/run/sherpa/packages/states
readonly r_action_abort_pathfile=$r_qpkg_states_path/abort.action
readonly r_action_msg_pipe=$r_qpkg_states_path/action.messages.pipe
readonly r_report_columns_path=/var/run/sherpa/report/columns
readonly r_report_flags_path=/var/run/sherpa/report/flags
readonly r_reports_path=/var/log/sherpa/reports
readonly r_report_output_pathfile=$r_reports_path/report.ansi
readonly r_run_logs_path=/var/run/sherpa/run.logs
readonly r_external_packages_archive_pathfile=/opt/var/opkg-lists/entware
readonly r_external_packages_pathfile=$r_cache_path/Packages
[[ -e $PYTHON3_CMD && ! -L $PYTHON_CMD ]] && ln -s "$PYTHON3_CMD" "$PYTHON_CMD"
rm -f "$r_report_output_pathfile" "$r_ramfs_freespace_pathfile" "$r_display_inhibit_pathfile" 2> /dev/null
if [[ -e $GNU_STTY_CMD && -t 0 ]];then
local terminal_dimensions=$($GNU_STTY_CMD size)
readonly r_sess_rows=${terminal_dimensions% *}
readonly r_sess_columns=${terminal_dimensions#* }
else
readonly r_sess_rows=40
readonly r_sess_columns=156
fi
}
LoadLists()
{
[[ ${lists_loaded:=false} = false ]] || return 0
r_package_tiers=(independent auxiliary dependent)
r_qpkg_is_states=(active backedup downloaded enabled installable installed missing signed upgradable)
r_qpkg_isnt_states=(active backedup downloaded enabled installable installed missing signed upgradable)
r_qpkg_is_groups=(all canbackup canclean canrestarttoupdate dependent hasdependents independent)
r_qpkg_isnt_groups=(canclean)
r_qpkg_states_transient=(restarting slow starting stopping unknown)
r_qpkg_service_results=(failed ok)
r_qpkg_actions=(status list rebuild reassign download backup deactivate disable uninstall upgrade reinstall install enableau disableau sign restore clean enable activate reactivate)
r_ipk_actions=(downgrade download uninstall upgrade install)
r_pip_actions=(uninstall upgrade install)
r_user_qpkg_actions=(activate backup clean deactivate disable disableau enable enableau install list reactivate reassign rebuild reinstall restore sign status uninstall upgrade)
readonly r_package_tiers
readonly r_qpkg_is_states
readonly r_qpkg_isnt_states
readonly r_qpkg_is_groups
readonly r_qpkg_isnt_groups
readonly r_qpkg_states_transient
readonly r_qpkg_service_results
readonly r_qpkg_actions
readonly r_ipk_actions
readonly r_pip_actions
readonly r_user_qpkg_actions
local action=''
for action in "${r_qpkg_actions[@]}" check debug downgrade update;do
readonly r_"$(Lowercase "$action")"_log_file=$action.log
done
lists_loaded=true
}
CreatePaths()
{
ClearPath "$r_cache_path" "$r_async_procs_path"
ClearPath "$r_cache_path" "$r_ipk_cache_path"
ClearPath "$r_cache_path" "$r_ipk_download_path"
ClearPath "$r_cache_path" "$r_pip_cache_path"
ClearPath /var/run/sherpa/report "$r_report_columns_path"
ClearPath /var/run/sherpa/report "$r_report_flags_path"
MakePath "$r_action_times_path" 'action times' || return
MakePath "$r_async_procs_path" 'asynchronous process tracking' || return
MakePath "$r_cache_path" cache || return
MakePath "$r_ipk_cache_path" 'IPK cache' || return
MakePath "$r_ipk_download_path" 'IPK download' || return
MakePath "$r_ipk_downgrade_path" 'IPK downgrade' || return
MakePath "$r_logs_path" logs || return
MakePath "$r_pip_cache_path" 'PIP cache' || return
MakePath "$r_report_columns_path" 'report columns' || return
MakePath "$r_report_flags_path" 'report flags' || return
MakePath "$r_reports_path" reports || return
MakePath "$r_qpkg_bu_path" 'QPKG backup' || return
MakePath "$r_qpkg_download_path" 'QPKG download' || return
}
DebugLogEnv()
{
[[ $run_package_actions = true ]] || return 0
[[ $useropt_debug = true ]] || return 0
FuncInit
ShowAsProc 'log env'
DebugInfoMinSepr
DebugHardware ok model "$(get_display_name)"
DebugHardware ok CPU "$(HardwareGetCPUInfo)"
DebugHardware ok 'CPU cores' "$r_cpu_cores"
DebugHardware ok 'CPU architecture' "$r_nas_arch"
DebugHardware ok RAM "$(FormatAsThous "$r_nas_ram_kb")kiB"
DebugFirmware ok OS "$(OsGetQnapOS)"
if OsIsSupported;then
DebugFirmware ok version "$r_nas_firmware_version.$r_nas_firmware_build"
else
DebugFirmware warning version "$r_nas_firmware_version"
fi
if OsIsCompatibleWithSigned;then
DebugFirmware ok 'build date' "$r_nas_firmware_date"
else
DebugFirmware warning 'build date' "$r_nas_firmware_date"
fi
DebugFirmware ok 'kernel version' "$(OsGetKernelVersion)"
if OsIsStdKernelPageSize;then
DebugFirmware ok 'kernel page size' "${r_kernel_page_size}B"
else
DebugFirmware warning 'kernel page size' "${r_kernel_page_size}B"
fi
DebugFirmware ok platform "$r_nas_platform"
case $r_nas_upstate in
starting-up|shutting-down)
DebugFirmware warning 'OS state' "$r_nas_upstate"
;;
*)
DebugFirmware ok 'OS state' "$r_nas_upstate"
esac
DebugFirmware ok 'OS uptime' "$(OsGetUptime)"
if OsIsLoadAverageElevated;then
DebugFirmware warning 'system load' "$(OsGetSysLoadAverages)"
else
DebugFirmware ok 'system load' "$(OsGetSysLoadAverages)"
fi
DebugUserspace ok 'GLIBC' "$(/sbin/ldd --version | head -n1 | cut -d' ' -f4) $(/sbin/ldd --version | /bin/grep Copyright | /bin/sed 's|\$||')"
DebugUserspace ok 'bash' "$(bash --version | head -n1)"
DebugUserspace ok 'shell options' "$-"
DebugUserspace ok 'time in shell' "$(UserGetTimeInShell)"
if OsIsSupportSudo;then
DebugUserspace ok '$SUDO_UID' "$(UserGetSudoUID)"
else
DebugUserspace ok '$SUDO_UID' N/A
fi
DebugUserspace ok '$EUID' "$EUID"
DebugUserspace ok 'default volume' "$(UserGetDefVol)"
DebugUserspace ok '/opt' "$($READLINK_CMD /opt 2> /dev/null || printf 'not present')"
local public_share=$(/sbin/getcfg SHARE_DEF defPublic -d Qpublic -f /etc/config/def_share.info)
if [[ -L /share/$public_share ]];then
DebugUserspace ok "'$public_share' share" "/share/$public_share"
else
DebugUserspace warning "'$public_share' share" 'not present'
fi
if [[ ${#PATH} -le $r_debug_log_third_column_width ]];then
DebugUserspace ok '$PATH' "$PATH"
else
DebugUserspace ok '$PATH (LHS-only)' "${PATH:0:$((r_debug_log_third_column_width-${#r_chars_ellipsis}))}${r_chars_ellipsis}"
fi
DebugScript 'git branch' "$useropt_branch"
DebugScript 'logs path' "$r_logs_path"
DebugScript 'action concurrency' "$r_concurrency"
if OsIsSupportUnofficialPackages;then
if OsIsAllowUnofficialPackages;then
DebugQpkg detect 'allow unofficial' yes
else
DebugQpkg warning 'allow unofficial' no
fi
else
DebugQpkg detect 'allow unofficial' N/A
fi
if OsIsSupportSignedPackages;then
if OsIsAllowUnsignedPackages;then
DebugQpkg detect 'allow unsigned' yes
else
DebugQpkg detect 'allow unsigned' no
fi
else
DebugQpkg detect 'allow unsigned' N/A
fi
DebugQpkg detect architecture "$r_nas_qpkg_arch"
DebugQpkg detect "$(ShowAsPackageName Entware) type" "$r_entware_version"
DebugQpkg detect "$(ShowAsPackageName Entware) install date" "$(QpkgGetInstalledDate Entware)"
if QpkgIsInstalled SortMyQPKGs;then
DebugQpkg detect "$(ShowAsPackageName SortMyQPKGs)" installed
else
DebugQpkg warning "$(ShowAsPackageName SortMyQPKGs)" 'not installed'
fi
if OsIsSupportQpkgTimeout;then
if QpkgIsInstalled IncreaseTimeouts;then
if QPKGs.IsTimeoutsIncreased;then
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" active
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" inactive
fi
else
DebugQpkg warning "$(ShowAsPackageName IncreaseTimeouts)" 'not installed'
fi
else
DebugQpkg detect "$(ShowAsPackageName IncreaseTimeouts)" N/A
fi
DebugInfoMinSepr
RunAndLog "$DF_CMD -h | $GREP_CMD '^Filesystem\|^none\|^tmpfs\|ram'" "$r_ramfs_freespace_pathfile"
DebugInfoMinSepr
RunAndLog "$SCREEN_CMD -ls" "$r_screen_sessions_pathfile" '' 1
DebugInfoMinSepr
RunAndLog '/usr/bin/free' "$r_ram_freeused_pathfile" '' 1
DebugInfoMinSepr
RunAndLog "$GREP_CMD -i 'out of memory\|oom-killer' /mnt/HDA_ROOT/.logs/kmsg" "$r_oom_log_pathfile" '' 1
DebugInfoMinSepr
FuncExit
}
CheckTasks()
{
if [[ $arg_problem = true || $useropt_help_basic = true ]];then
generate_action_results_report=false
generate_help_report=false
generate_list_report=false
generate_show_report=false
get_qpkg_active_status=false
get_qpkg_states=false
run_package_actions=false
fi
[[ $get_qpkg_states = true ]] || return 0
FuncInit
local action=''
local build_states=false
local group=''
local state=''
if [[ $useropt_check = true || $useropt_show_status = true ]];then
build_states=true
elif [[ $useropt_show_dependencies = true || $useropt_show_features = true || $useropt_show_packages = true || $useropt_show_repos = true ]];then
build_states=true
elif [[ $useropt_help_actions = true || $useropt_help_actions_all = true || $useropt_help_groups = true || $useropt_help_lists = true || $useropt_help_options = true || $useropt_help_packages = true || $useropt_help_problems = true || $useropt_help_tips = true || $useropt_help_upgrades = true || $useropt_show_all_results = true ]];then
:
else
LoadPackages
for action in "${r_user_qpkg_actions[@]}";do
if QPKGs-AC${action}-to.IsAny;then
build_states=true
break
fi
for group in "${r_qpkg_is_groups[@]}";do
if QPKGs.AC${action}.GR${group}.IsSet;then
build_states=true
break 2
fi
done
for group in "${r_qpkg_isnt_groups[@]}";do
if QPKGs.AC${action}.GRNT${group}.IsSet;then
build_states=true
break 2
fi
done
for state in "${r_qpkg_is_states[@]}";do
if QPKGs.AC${action}.IS${state}.IsSet;then
build_states=true
break 2
fi
done
for state in "${r_qpkg_isnt_states[@]}";do
if QPKGs.AC${action}.ISNT${state}.IsSet;then
build_states=true
break 2
fi
done
done
fi
if [[ $build_states = true ]];then
BuildQPKGsStates
else
get_qpkg_states=false
run_package_actions=false
fi
FuncExit
}
CheckEnv()
{
[[ $run_package_actions = true ]] || return 0
FuncInit
ShowAsProc 'check env'
local installed_ver=''
local target_packages=''
if [[ $($GREP_CMD -i 'out of memory\|oom-killer' /mnt/HDA_ROOT/.logs/kmsg | $WC_CMD -l) -gt 0 ]];then
ShowAsWarn "the $(TextBrightRed 'Out-Of-Memory killer') has been triggered ... check for $(TextBrightRed inactive) QPKGs"
fi
if QpkgIsInstalled Entware;then
if [[ $r_entware_version != none ]];then
_UpdateEntwarePackageList_ &
else
DebugAsWarn "$(ShowAsPackageName Entware) appears to be installed but is inactive. Please consider starting the $(ShowAsPackageName Entware) QPKG."
fi
if [[ $useropt_check = true ]] || QPKGs-ACupgrade-to.Exist Entware;then
ipks_install=true
ipks_upgrade=true
pips_install=true
if Python3IsOutdated;then
ShowAsNote "the $(TextBrightOrange Python) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'python*'
fi
if PerlIsOutdated;then
ShowAsNote "the $(TextBrightOrange Perl) environment will be auto-upgraded"
IPKs-ACuninstall-to:Add 'perl*'
fi
fi
case $r_nas_qpkg_arch in
a41)
if OsIsNonStdKernelPageSize;then
target_packages='ar binutils libbfd libctf libopcodes objdump'
installed_version=$($OPKG_CMD list-installed | $GREP_CMD "^${target_packages%% *} *" | head -n1 | cut -d' ' -f3 | cut -d'-' -f1)
if [[ ${installed_version//.} -gt 238 ]];then
ipks_downgrade=true
ShowAsNote "various IPKs will be downgraded to suit ${r_kernel_page_size}B kernel page size"
IPKs-ACdowngrade-to:Add "$target_packages"
else
IPKs-ACdowngrade-sk:Add "$target_packages"
fi
fi
esac
fi
BuildQPKGsIsCanBackup
BuildQPKGsIsCanRestartToUpdate
BuildQPKGsIsCanClean
AllocPackGroupsToAcs
AllocPackStatesToAcs
if QPKGs-ISupgradable.Exist sherpa;then
ShowAsNote "the $(TextBrightOrange sherpa) QPKG will be auto-upgraded"
QPKGs-ACupgrade-to:Add sherpa
fi
wait 2> /dev/null
FuncExit
}
QPKGsAssignToActions()
{
[[ $run_package_actions = true ]] || return 0
FuncInit
ShowAsProc 'QPKG assignment'
local action=''
local prospect=''
if QpkgIsInstalled Entware;then
local entware_install_date=$(QpkgGetInstalledDate Entware)
if [[ $entware_install_date = undefined || ${entware_install_date//[!0-9]/} -le 20240809 ]] && [[ $r_nas_arch != armv5tel ]];then
ShowAsNote "the $(TextBrightOrange Entware) QPKG will be auto-reinstalled (Entware packages were updated early in August 2024)"
QPKGs-ACreinstall-to:Add Entware
fi
fi
if QPKGs-ACrebuild-to.IsAny;then
for qpkg_name in $(QPKGs-ACrebuild-to:Array);do
QpkgSetIndex
if QPKGs-ISNTinstalled.Exist "$qpkg_name" && QpkgIsBackupExist;then
QPKGs-ACinstall-to:Add "$qpkg_name"
QPKGs-ACrestore-to:Add "$qpkg_name"
fi
done
fi
for qpkg_name in $(QPKGs-ACinstall-to:Array) $(QPKGs-ACreinstall-to:Array);do
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependencies);do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
done
for qpkg_name in $(QPKGs-ISinstalled:Array);do
if [[ $useropt_check = true ]] || QPKGs-ACactivate-to.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependencies);do
QPKGs-ISNTinstalled.Exist "$prospect" && QPKGs-ACinstall-to:Add "$prospect"
done
fi
done
for action in reinstall reactivate upgrade;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependents);do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
done
for action in deactivate uninstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependents);do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACdeactivate-to:Add "$prospect"
done
fi
done
done
if QPKGs-ACreinstall-to.Exist Entware;then
QPKGs-ACreinstall-to:Remove Entware
QPKGs-ACuninstall-to:Add Entware
QPKGs-ACinstall-to:Add Entware
fi
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-GRindependent.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACinstall-to.Exist "$qpkg_name";then
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependents);do
if QPKGs-ISenabled.Exist "$prospect";then
QPKGs-ACdeactivate-to:Add "$prospect"
! QPKGs-ACuninstall-to.Exist "$prospect" && ! QPKGs-ACinstall-to.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
fi
done
fi
done
for action in backup restore upgrade reinstall;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
if QPKGs-ISenabled.Exist "$qpkg_name";then
QPKGs-ACdeactivate-to:Add "$qpkg_name"
! QPKGs-ACuninstall-to.Exist "$qpkg_name" && ! QPKGs-ACinstall-to.Exist "$qpkg_name" && QPKGs-ACactivate-to:Add "$qpkg_name"
fi
done
done
for action in reinstall install activate reactivate;do
for qpkg_name in $(QPKGs-AC${action}-to:Array);do
QpkgSetIndex
for prospect in $(QpkgGetDatabaseDependencies);do
QPKGs-ISinstalled.Exist "$prospect" && QPKGs-ACactivate-to:Add "$prospect"
done
done
done
if QPKGs.ACuninstall.GRall.IsSet;then
QPKGs-ACreactivate-to:Init
QPKGs-ACdisable-to:Init
else
QPKGs-ACreactivate-to:Remove "$(QPKGs-ACuninstall-to:Array)"
QPKGs-ACdisable-to:Remove "$(QPKGs-ACuninstall-to:Array)"
fi
QPKGs-ACactivate-to:Remove "$(QPKGs-ACreactivate-to:Array)"
QPKGs_were_installed_name=()
QPKGs_were_installed_path=()
if QPKGs-ACuninstall-to.IsAny;then
for qpkg_name in $(QPKGs-ACuninstall-to:Array);do
if QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACinstall-to.Exist "$qpkg_name";then
QPKGs_were_installed_name+=("$qpkg_name")
QpkgSetIndex
QPKGs_were_installed_path+=("$($DIRNAME_CMD "$(QpkgGetInstalledPath)")")
fi
QPKGs-ACdeactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdownload-to:Add "$(QPKGs-ACinstall-to:Array)"
for qpkg_name in $(QPKGs-ACreinstall-to:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && QPKGs-ACdownload-to:Add "$qpkg_name"
done
for qpkg_name in $(QPKGs-ACupgrade-to:Array);do
QPKGs-ISupgradable.Exist "$qpkg_name" && QPKGs-ACdownload-to:Add "$qpkg_name"
done
if [[ $useropt_check = true ]];then
OsIsSupportSignedPackages && QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
for qpkg_name in $(QPKGs-GRdependent:Array);do
QPKGs-ISenabled.Exist "$qpkg_name" && QPKGs-ACreactivate-to:Add "$qpkg_name"
done
fi
QPKGs-ACdeactivate-to:Remove sherpa
QPKGs-ACuninstall-to:Remove sherpa
if QPKGs-ACsign-to.IsAny || QPKGs-ACinstall-to.IsAny;then
LoadQpkgSigning
fi
FuncExit
}
ProcActions()
{
[[ $run_package_actions = true ]] || return
FuncInit
ShowAsProc 'package actions'
local tier=''
local action=''
local state=''
local -i tier_index=0
rm -f "$r_session_action_results_pathfile" 2> /dev/null
ProcAction status all QPKG '"live" status' '"live" statused'
if [[ $useropt_show_status = false ]];then
ShowAsProc 'assign QPKGs by state'
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
QPKGs.AC${action}.IS${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
done
for state in "${r_qpkg_isnt_states[@]}";do
QPKGs.AC${action}.ISNT${state}.IsSet && QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
done
done
fi
ProcAction rebuild all QPKG meta-rebuild meta-rebuilt
ProcAction reassign all QPKG reassign reassigned
ProcAction download all QPKG download downloaded
if QPKGs-ACdownload-er.IsNone && QPKGs-ACdownload-se.IsNone && QPKGs-ACdownload-sa.IsNone;then
for ((tier_index=${#r_package_tiers[@]}-1;tier_index>=0; tier_index--)); do
tier=${r_package_tiers[$tier_index]}
case $tier in
?(in)dependent)
ProcAction deactivate $tier QPKG deactivate deactivated
ProcAction disableau $tier QPKG 'disable auto-update' 'disabled auto-update'
ProcAction backup $tier QPKG backup backed-up
ProcAction disable $tier QPKG disable disabled
ProcAction uninstall $tier QPKG uninstall uninstalled
;;
auxiliary)
if QPKGs-ISenabled.Exist Entware;then
ModPathToEntware
PIPs:uninstall
IPKs:uninstall
fi
esac
done
for tier in "${r_package_tiers[@]}";do
case $tier in
?(in)dependent)
ProcAction upgrade $tier QPKG upgrade upgraded
ProcAction reinstall $tier QPKG reinstall reinstalled
ProcAction install $tier QPKG install installed
ProcAction restore $tier QPKG restore restored
ProcAction enableau $tier QPKG 'enable auto-update' 'enabled auto-update'
ProcAction clean $tier QPKG clean cleaned
[[ $tier = dependent ]] && ProcAction sign dependent QPKG '"sign"' '"signed"'
ProcAction enable $tier QPKG enable enabled
ProcAction reactivate $tier QPKG reactivate reactivated
ProcAction activate $tier QPKG activate activated
;;
auxiliary)
for action in status install reinstall upgrade activate;do
if (QPKGs-ACinstall-ok.Exist Entware) || QPKGs-AC${action}-to.IsAny && QPKGs-ISenabled.Exist Entware;then
ipks_downgrade=true
ipks_install=true
ipks_upgrade=true
pips_install=true
break
fi
done
if QPKGs-ISenabled.Exist Entware;then
ModPathToEntware
IPKs:upgrade
IPKs:install
IPKs:downgrade
PIPs:upgrade
PIPs:install
fi
QPKGs-ACinstall-ok.Exist Entware && [[ $sqlite_pathfile = /opt/bin/sqlite3 && -e $sqlite_pathfile ]] && OsIsSupportSignedPackages && QPKGs-ACsign-to:Add "$(QPKGs-ISinstalled:Array)"
ProcAction sign independent QPKG '"sign"' '"signed"'
esac
done
fi
if [[ $useropt_debug = true ]];then
ListQPKGsActions
ListIPKsActions
ListPIPsActions
fi
if [[ $title_shown = true ]];then
if ErrorIsNt;then
ShowAsDone 'actions complete'
else
ShowAsFail 'actions complete with errors'
fi
fi
FuncExit
}
ProcAction()
{
FuncInit
local -r r_action=${1:?${FUNCNAME[0]}'()': undefined action}
local -r r_action_past_msg=${5:?${FUNCNAME[0]}'()': undefined action past}
local -r r_action_present_msg=${4:?${FUNCNAME[0]}'()': undefined action present}
local group=''
local msg1_key=''
local msg1_value=''
local msg2_key=''
local msg2_value=''
local original_colourful=$useropt_colourful
local package=''
local -i package_index=0
local -r r_package_type=${3:?${FUNCNAME[0]}'()': undefined package type}
local re=''
local state=''
local -a target_packages=()
local -r r_tier=${2:?${FUNCNAME[0]}'()': undefined tier}
total_count=0
DebugVar r_action
DebugVar r_tier
DebugVar r_package_type
case $r_package_type in
QPKG)
target_object_name=AC${r_action}-to
if [[ $r_tier = all ]];then
target_packages=($(${r_package_type}s-$target_object_name:Array))
else
for package in $(${r_package_type}s-$target_object_name:Array);do
${r_package_type}s-GR${r_tier}.Exist "$package" && target_packages+=("$package")
done
fi
total_count=${#target_packages[@]}
DebugVar total_count
if [[ $total_count -eq 0 ]];then
DebugInfo 'nothing to process'
FuncExit;return
fi
if [[ $total_count -eq 1 ]];then
fork_progress_prefix="$r_action_present_msg $(TextBrightOrange "${target_packages[0]}") $r_package_type"
else
fork_progress_prefix="$r_action_present_msg $([[ $r_tier != all ]] && echo "$r_tier ")$(Uppercase "$r_package_type")$(Pluralise "$total_count")"
fi
SetMaxForks "$r_action"
InitForkCounts
OpenActionMsgPipe
re=\\bEntware\\b
if [[ $r_action = uninstall && ${target_packages[*]} =~ $re ]];then
ShowKeystrokes
fi
pidfile=$($MKTEMP_CMD "$r_async_procs_path"/bgproc_XXXXXX)
_ExecOneActionWithManyForks_ "_${r_package_type}:${r_action}_" "${target_packages[@]}" &
echo "$!" > "$pidfile"
while [[ ${#target_packages[@]} -gt 0 && ! -e $r_action_abort_pathfile ]];do
ReadFromActionMsgPipe msg1_key msg1_value msg2_key msg2_value
case $msg1_key in
env)
eval "$msg1_value"
;;
change)
while true;do
for state in "${r_qpkg_is_states[@]}" "${r_qpkg_states_transient[@]}";do
case $msg1_value in
"IS${state}")
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Add "$msg2_value"
break 2
esac
done
for state in "${r_qpkg_isnt_states[@]}" "${r_qpkg_states_transient[@]}";do
case $msg1_value in
"ISNT${state}")
[[ $(type -t QPKGs-IS${state}:Init) = function ]] && QPKGs-IS${state}:Remove "$msg2_value"
[[ $(type -t QPKGs-ISNT${state}:Init) = function ]] && QPKGs-ISNT${state}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_is_groups[@]}";do
case $msg1_value in
"GR${group}")
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Add "$msg2_value"
break 2
esac
done
for group in "${r_qpkg_isnt_groups[@]}";do
case $msg1_value in
"GRNT${group}")
[[ $(type -t QPKGs-GR${group}:Init) = function ]] && QPKGs-GR${group}:Remove "$msg2_value"
[[ $(type -t QPKGs-GRNT${group}:Init) = function ]] && QPKGs-GRNT${group}:Add "$msg2_value"
break 2
esac
done
DebugAsWarn "unidentified change request in message queue: '$msg1_value'"
break
done
;;
status)
case $msg1_value in
ok)
[[ $r_action != status ]] && ((ok_count++))
;;
so)
((skip_ok_count++))
;;
sk)
((skip_count++))
;;
se)
((skip_error_count++))
;;
sa)
((skip_abort_count++))
/bin/touch "$r_action_abort_pathfile"
;;
er)
((fail_count++))
esac
case $msg1_value in
ok|so|sk|se|sa|er)
[[ $(type -t QPKGs-AC${r_action}-to:Init) = function ]] && QPKGs-AC${r_action}-to:Remove "$msg2_value"
[[ $(type -t QPKGs-AC${r_action}-${msg1_value}:Init) = function ]] && QPKGs-AC${r_action}-${msg1_value}:Add "$msg2_value"
[[ $(type -t QPKGs-AC${r_action}-dn:Init) = function ]] && QPKGs-AC${r_action}-dn:Add "$msg2_value"
;;
ex)
for package_index in "${!target_packages[@]}";do
if [[ ${target_packages[package_index]} = "$msg2_value" ]];then
unset 'target_packages[package_index]'
break
fi
done
;;
*)
DebugAsWarn "unidentified status in message queue: '$msg1_value'"
esac
;;
*)
DebugAsWarn "unidentified key in message queue: '$msg1_key'"
esac
[[ -e $r_action_abort_pathfile ]] && break
done
[[ $fail_count -gt 0 ]] && show_action_results_failed=true
[[ $ok_count -gt 0 ]] && show_action_results_ok=true
[[ $skip_count -gt 0 || $skip_ok_count -gt 0 || $skip_error_count -gt 0 || $skip_abort_count -gt 0 ]] && show_action_results_skipped=true
[[ ${#target_packages[@]} -gt 0 ]] && KillPID "$(<$pidfile)"
wait 2> /dev/null
CloseActionMsgPipe
[[ ${useropt_terse:=true} = false && $useropt_verbose = false ]] && echo
;;
IPK|PIP)
if [[ $ipks_downgrade = true || $ipks_install = true || $ipks_upgrade = true || $pips_install = true ]];then
InitForkCounts
${r_package_type}s:${r_action}
fi
esac
EraseForkCountPaths
FuncExit
ErrorIsNt
}
OpenActionMsgPipe()
{
[[ -p $r_action_msg_pipe ]] && rm -f "$r_action_msg_pipe" 2> /dev/null
[[ ! -p $r_action_msg_pipe ]] && mknod "$r_action_msg_pipe" p
backup_stdin_fd=$(FindNextFD)
DebugVar backup_stdin_fd
eval "exec $backup_stdin_fd>&0"
action_msg_pipe_fd=$(FindNextFD)
DebugVar action_msg_pipe_fd
[[ $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd<>$r_action_msg_pipe"
}
CloseActionMsgPipe()
{
if [[ -n ${backup_stdin_fd:-} ]];then
[[ $backup_stdin_fd != none ]] && eval "exec 0>&$backup_stdin_fd"
[[ $backup_stdin_fd != none ]] && eval "exec $backup_stdin_fd>&-"
fi
[[ -n ${action_msg_pipe_fd:-} && $action_msg_pipe_fd != none ]] && eval "exec $action_msg_pipe_fd>&-"
[[ -n ${r_action_msg_pipe:-} && -p $r_action_msg_pipe ]] && rm -f "$r_action_msg_pipe" 2> /dev/null
}
SetMaxForks()
{
max_forks=$r_concurrency
local reason=''
if [[ $useropt_verbose = true ]];then
max_forks=1
reason='verbose mode is active'
elif [[ $useropt_debug = true ]];then
max_forks=1
reason='debug mode is active'
else
case ${1:-} in
?(re)install|upgrade)
max_forks=1
reason="'$1'"
;;
clean)
max_forks=$(((max_forks+1)/2))
reason="'$1'"
;;
backup|deactivate|download|uninstall)
max_forks=4
reason="'$1'"
;;
@(dis|en)able?(au)|rebuild|sign|status)
max_forks=8
reason="'$1'"
esac
[[ -n $reason ]] && reason+=' action was requested'
fi
[[ -n $reason ]] && DebugInfo "limiting \$max_forks to $max_forks because $reason"
DebugVar max_forks
}
PrepareArgs()
{
ShowAsProc args
local a=$(Lowercase "${r_args_raw//,/ }")
args=(${a/--/})
arg_problem=false
[[ -z $r_args_raw ]] && useropt_help_basic=true
}
ParseManagementArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
check)
generate_show_report=true
get_qpkg_states=true
requires_group=false
run_package_actions=true
user_action=$arg
useropt_check=true
;;
colo?(u)r?(ful)|follow|paste|report-footer|terse)
requires_group=true
user_action=$arg
;;
debug|verbose)
requires_group=false
user_action=$arg
EnableVerbose
EnableDebugToArchiveAndFile
;;
reset)
DeleteSetting Colourful
DeleteSetting Git_Branch
DeleteSetting Terse
Reset
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
if [[ -n $action && -n $group ]];then
case $action in
colo?(u)r?(ful))
case $group in
true|false)
action=''
awaiting_group=false
switch_colour=true
user_colourful_value=$group
UpdateColourful
;;
*)
args_remaining+=("$action")
esac
;;
follow)
case $group in
?(un)stable)
action=''
awaiting_group=false
run_package_actions=false
switch_branch=true
user_branch_value=$group
UpdateBranch
;;
*)
args_remaining+=("$action")
esac
;;
paste)
case $group in
last)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_last=true
;;
tail)
action=''
awaiting_group=false
run_package_actions=false
useropt_paste_log_tail=true
;;
*)
args_remaining+=("$action")
esac
;;
report-footer)
case $group in
true|false)
action=''
awaiting_group=false
switch_report_footer=true
user_report_footer_value=$group
UpdateReportFooter
;;
*)
args_remaining+=("$action")
esac
;;
terse)
case $group in
true|false)
action=''
awaiting_group=false
switch_terse=true
user_terse_value=$group
UpdateTerse
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseHelpArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
help)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs|actions|all|all-actions|groups|lists|options|packages|problems|show|tips|upgrades)
[[ -z $action ]] && action=help
esac
if [[ -n $action && -n $group ]];then
case $action in
help)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_abbreviations=true
;;
actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions=true
;;
all|all-actions)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_actions_all=true
;;
groups)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_groups=true
;;
lists)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_lists=true
;;
options)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_options=true
;;
packages)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_packages=true
;;
problems)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_problems=true
;;
show)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_show=true
;;
tips)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_tips=true
;;
upgrades)
action=''
awaiting_group=false
generate_help_report=true
run_package_actions=false
useropt_help_upgrades=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
case $arg in
help)
run_package_actions=false
useropt_help_basic=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit
}
ParseShowArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
show)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs|backups|dependent|features|last|packages|repositories|results|status|tail)
[[ -z $action ]] && action=show
esac
if [[ -n $action && -n $group ]];then
case $action in
show)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_states=false
run_package_actions=false
useropt_help_abbreviations=true
;;
backups)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_backups=true
;;
dependent)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_dependencies=true
;;
features)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_features=true
;;
last)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_last=true
;;
packages)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_packages=true
;;
repositories)
LoadPackages
action=''
awaiting_group=false
generate_show_report=true
run_package_actions=false
useropt_show_repos=true
;;
results)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_all_results=true
;;
status)
LoadObjects
QPKGs.ACstatus.GRall:Set
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=true
run_package_actions=true
useropt_show_status=true
;;
tail)
action=''
awaiting_group=false
generate_show_report=true
get_qpkg_states=false
run_package_actions=false
useropt_show_log_tail=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseListArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
list)
requires_group=true
user_action=$arg
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg")
DebugVar group
case $group in
abs)
[[ -z $action ]] && action=list
esac
if [[ -n $action && -n $group ]];then
case $action in
list)
case $group in
abs)
action=''
awaiting_group=false
generate_help_report=true
get_qpkg_states=true
run_package_actions=false
useropt_help_abbreviations=true
;;
?(NT)active)
LoadObjects
QPKGs.AClist.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
show_title=false
;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AClist.IS${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
?(in)dependent)
LoadObjects
QPKGs.AClist.GR${group}:Set
action=''
awaiting_group=false
generate_list_report=true
get_qpkg_states=true
run_package_actions=false
show_title=false
;;
versions)
action=''
awaiting_group=false
generate_list_report=true
show_title=false
useropt_show_versions=true
;;
*)
args_remaining+=("$action")
esac
;;
*)
args_remaining+=("$arg")
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
args=(${args_remaining[@]:-})
FuncExit
}
ParseActionArgs()
{
FuncInit
local action=''
local arg=''
local -a args_remaining=()
local awaiting_group=false
local current_action=''
local group=''
local potential_action=''
local requires_group=false
local user_action=''
[[ -n ${args[*]:-} ]] && LoadPackages
for arg in "${args[@]:-}";do
[[ -n $arg ]] || continue
potential_action=$(MatchVerb "$arg");DebugVar potential_action
if [[ -n $potential_action ]];then
action=$potential_action;DebugVar action
potential_action=''
case $action in
?(de|re)activate|backup|clean|@(dis|en)able?(au)|reassign|rebuild|?(re|un)install|restore|sign|upgrade)
requires_group=true
user_action=$arg
;;
status)
generate_show_report=true
get_qpkg_states=true
requires_group=true
user_action=$arg
useropt_show_status=true
esac
if [[ -n $user_action && $user_action != "$current_action" ]];then
[[ $awaiting_group = true ]] && args_incomplete+=("$user_action")
awaiting_group=$requires_group
current_action=$user_action
group=''
continue
fi
fi
group=$(MatchNoun "$arg");DebugVar group
if [[ -n $action && -n $group ]];then
case $action in
?(de|re)activate|backup|clean|@(dis|en)able|reassign|@(re|un)install|restore|sign|upgrade)
case $group in
?(NT)active)
LoadObjects
QPKGs.AC${action}.IS${group}:Set
QPKGs.ACstatus.ISinstalled:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_active_status=true
get_qpkg_states=true
run_package_actions=true
esac
esac
case $group in
all|canbackup|?(NT)canclean|canrestarttoupdate|?(in)dependent|hasdependents)
LoadObjects
QPKGs.AC${action}.GR${group}:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_active_status=false
get_qpkg_states=true
run_package_actions=true
;;
?(NT)backedup|?(NT)enabled|?(NT)installable|?(NT)installed|?(NT)missing|?(NT)upgradable)
LoadObjects
QPKGs.AC${action}.IS${group}:Set
awaiting_group=false
generate_action_results_report=true
get_qpkg_states=true
run_package_actions=true
;;
*)
LoadObjects
QPKGs-AC${action}-to:Add "$group"
awaiting_group=false
generate_action_results_report=true
get_qpkg_states=true
run_package_actions=true
esac
else
args_remaining+=("$arg")
fi
done
if [[ $requires_group = true && $awaiting_group = true ]];then
args_incomplete+=("$user_action")
fi
for arg in "${args_incomplete[@]:-}";do
action=$(MatchVerb "$arg")
case $action in
status)
LoadObjects
QPKGs.ACstatus.ISinstalled:Set
generate_show_report=true
get_qpkg_states=true
run_package_actions=true
local a=''
local tmp=()
for a in "${args_incomplete[@]}";do
[[ $a != "$arg" ]] && tmp+=($a)
done
if [[ ${#tmp[@]:-} -eq 0 ]];then
args_incomplete=()
else
args_incomplete=("${tmp[@]}")
fi
unset tmp
esac
done
args=(${args_remaining[@]:-})
FuncExit
}
MatchVerb()
{
local a=${1:-}
case $a in
activate|start)
printf activate
;;
add|install)
printf install
;;
backup|clean|colo?(u)r?(ful)|@(dis|en)able|follow|help|list|paste|reassign|rebuild|reinstall|report-footer|reset|restore|sign|terse)
printf '%s' "$a"
;;
c|check)
printf check
;;
deactivate|stop)
printf deactivate
;;
d?(e)bug)
printf debug
;;
disable-auto-update)
printf disableau
;;
enable-auto-update)
printf enableau
;;
reactivate|restart)
printf reactivate
;;
remove|rm|uninstall)
printf uninstall
;;
s|status?(es))
printf status
;;
show|view)
printf show
;;
update|upgrade)
printf upgrade
;;
v|verbose)
printf verbose
esac
}
MatchNoun()
{
local a=${1:-}
case $a in
a|abs|abbreviations)
printf abs
;;
action?(s))
printf actions
;;
action?(s)-all|all-action?(s))
printf all-actions
;;
active|no@(n|t)-inactive|no@(n|t)-stopped|started)
printf active
;;
all|entire|everything)
printf all
;;
b|backups)
printf backups
;;
backedup|canbackup|enabled|installable|installed|missing|results|show|?(un)stable)
printf '%s' "$a"
;;
d|deps|dependencies|dependent?(s))
printf dependent
;;
disable|false|no|off|unset)
printf false
;;
disabled|no@(n|t)-enabled)
printf NTenabled
;;
enable|on|set|true|yes)
printf true
;;
f|features)
printf features
;;
group?(s))
printf groups
;;
inactive|no@(n|t)-active|no@(n|t)-started|stopped)
printf NTactive
;;
indep?(endent)?(s))
printf independent
;;
l|last)
printf last
;;
list?(s))
printf lists
;;
log|tail)
printf tail
;;
me|problem?(s))
printf problems
;;
new|updat?(e)able|upgrad@(a|e)ble)
printf upgradable
;;
no@(n|t)-back?(ed)up)
printf NTbackedup
;;
no@(n|t)-installable)
printf NTinstallable
;;
no@(n|t)-installed)
printf NTinstalled
;;
no@(n|t)-missing)
printf NTmissing
;;
no@(n|t)-upgradable)
printf NTupgradable
;;
o|option?(s))
printf options
;;
p|package?(s)|qpkg?(s))
printf packages
;;
r|repos|repositories)
printf repositories
;;
s|status?(es))
printf status
;;
tip?(s))
printf tips
;;
upgrade?(s)|upgrading)
printf upgrades
;;
version?(s))
printf versions
;;
*)
QpkgMatchAbbrv "$a"
esac
}
ShowArgSuggestions()
{
FuncInit
local arg=''
local -a args_remaining=()
if [[ ${#args_incomplete[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args_incomplete[@]}";do
case $arg in
?(de|re)activate|backup|clean|@(dis|en)able|@(dis|en)able-auto-update|reassign|@(re|un)install|?(re)start|restore|rm|sign|stop|upgrade)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg installed"
arg_problem=true
useropt_help_basic=false
;;
colo?(u)r?(ful)|terse)
DisplayAsProjSynExam "please provide a valid boolean after '$arg' like" "$arg true"
DisplayAsProjSynIndentExam '' "$arg false"
DisplayAsProjSynIndentExam '' "$arg on"
DisplayAsProjSynIndentExam '' "$arg off"
DisplayAsProjSynIndentExam '' "$arg yes"
DisplayAsProjSynIndentExam '' "$arg no"
DisplayAsProjSynIndentExam '' "$arg enable"
DisplayAsProjSynIndentExam '' "$arg disable"
arg_problem=true
useropt_help_basic=false
;;
follow)
DisplayAsProjSynExam "please provide a valid $(ShowAsTitleName) git branch to '$arg' like" "$arg stable"
DisplayAsProjSynIndentExam '' "$arg unstable"
arg_problem=true
useropt_help_basic=false
;;
install|rebuild)
DisplayAsProjSynExam "please provide valid $(ShowAsPackages) or a $(ShowAsPackageGroup) after '$arg' like" "$arg all"
arg_problem=true
useropt_help_basic=false
;;
list)
DisplayAsProjSynExam "please provide a valid source to '$arg' like" "$arg installable"
DisplayAsProjSynIndentExam '' "$arg new"
arg_problem=true
useropt_help_basic=false
;;
paste)
DisplayAsProjSynExam "please provide a valid source to '$arg' online like" "$arg log"
DisplayAsProjSynIndentExam '' "$arg last"
arg_problem=true
useropt_help_basic=false
;;
show)
DisplayAsProjSynExam "please provide a valid source after '$arg' like" "$arg abs"
DisplayAsProjSynIndentExam '' "$arg log"
DisplayAsProjSynIndentExam '' "$arg packages"
DisplayAsProjSynIndentExam '' "$arg results"
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && echo
ShowAsError "incomplete argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
args_remaining=()
fi
fi
if [[ ${#args[@]:-} -gt 0 ]];then
run_package_actions=false
for arg in "${args[@]}";do
case $arg in
active|@(dis|en)abled|started)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "deactivate $arg"
arg_problem=true
useropt_help_basic=false
;;
all)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before 'all' like" 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-activate|activate-all)
DisplayAsProjSynExam 'to activate all QPKGs, use' 'activate all'
arg_problem=true
useropt_help_basic=false
;;
all-backup|backup-all)
DisplayAsProjSynExam 'to backup all installed QPKG configurations, use' 'backup all'
arg_problem=true
useropt_help_basic=false
;;
all-deactivate|deactivate-all)
DisplayAsProjSynExam 'to deactivate all QPKGs, use' 'deactivate all'
arg_problem=true
useropt_help_basic=false
;;
all-reactivate|reactivate-all)
DisplayAsProjSynExam 'to reactivate all QPKGs, use' 'reactivate all'
arg_problem=true
useropt_help_basic=false
;;
all-restore|restore-all)
DisplayAsProjSynExam 'to restore all installed QPKG configurations, use' 'restore all'
arg_problem=true
useropt_help_basic=false
;;
all-stop|stop-all)
DisplayAsProjSynExam 'to stop all QPKGs, use' 'stop all'
arg_problem=true
useropt_help_basic=false
;;
all-uninstall|all-remove|uninstall-all|remove-all)
DisplayAsProjSynExam 'to uninstall all QPKGs, use' 'uninstall all'
arg_problem=true
useropt_help_basic=false
;;
all-upgrade|upgrade-all)
DisplayAsProjSynExam 'to upgrade all QPKGs, use' 'upgrade all'
arg_problem=true
useropt_help_basic=false
;;
@(dis|en)able|false|off|no|on|true|yes)
DisplayAsProjSynExam "please provide a valid setting before '$arg' like" "colour $arg"
DisplayAsProjSynIndentExam '' "terse $arg"
arg_problem=true
useropt_help_basic=false
;;
download)
ShowAsError "'$arg' is not a manual action"
arg_problem=true
useropt_help_basic=false
;;
@(in|not-)active|?(in)dependent?(s)|stopped)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "activate $arg"
arg_problem=true
useropt_help_basic=false
;;
?(un)stable)
DisplayAsProjSynExam "please provide a valid $(ShowAsAction) before '$arg' like" "follow $arg"
arg_problem=true
useropt_help_basic=false
;;
*)
arg_problem=true
args_remaining+=("$arg")
esac
done
if [[ ${#args_remaining[@]:-} -gt 0 ]];then
[[ $arg_problem = true ]] && Display
ShowAsError "unknown argument$(Pluralise "${#args_remaining[@]}") \"${args_remaining[*]}\". Please check the arguments again"
arg_problem=true
useropt_help_basic=false
fi
fi
DebugArray args_incomplete "${args_incomplete[*]:-}"
DebugArray args_remaining "${args_remaining[*]:-}"
FuncExit
}
AllocPackGroupsToAcs()
{
FuncInit
ShowAsProc 'match QPKG groups to actions'
local action=''
local group=''
for action in "${r_user_qpkg_actions[@]}";do
for group in "${r_qpkg_is_groups[@]}";do
if QPKGs.AC${action}.GR${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GR${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GR${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GR$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for group in "${r_qpkg_isnt_groups[@]}";do
if QPKGs.AC${action}.GRNT${group}.IsSet;then
QPKGs-AC${action}-to:Add "$(QPKGs-GRNT${group}:Array)"
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', group: 'GRNT${group}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
else
ShowAsWarn "unable to find any 'GRNT$group' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit
}
AllocPackStatesToAcs()
{
FuncInit
ShowAsProc 'match QPKG states to actions'
local action=''
local check_later=false
local state=''
for action in "${r_user_qpkg_actions[@]}";do
for state in "${r_qpkg_is_states[@]}";do
check_later=false
if QPKGs.AC${action}.IS${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
else
QPKGs-AC${action}-to:Add "$(QPKGs-IS${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'IS${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'IS${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any '$state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
for state in "${r_qpkg_isnt_states[@]}";do
check_later=false
if QPKGs.AC${action}.ISNT${state}.IsSet;then
if [[ $state = active ]];then
check_later=true
else
QPKGs-AC${action}-to:Add "$(QPKGs-ISNT${state}:Array)"
fi
if QPKGs-AC${action}-to.IsAny;then
DebugAsDone "action: '$action', state: 'ISNT${state}': found $(QPKGs-AC${action}-to:Count) package$(Pluralise "$(QPKGs-AC${action}-to:Count)") to process"
elif [[ $check_later = true ]];then
DebugAsDone "action: '$action', state: 'ISNT${state}': will add filtered-QPKGs later after 'status' has been determined"
else
ShowAsWarn "unable to find any 'not $state' QPKGs to '$(Lowercase "$action")'"
fi
fi
done
done
FuncExit
}
ResetArchivedLogs()
{
if [[ -n $r_logs_path && -d $r_logs_path ]];then
ClearPath "$r_this_package_path" "$r_logs_path"
echo 'log reset' > "$sess_active_pathfile"
ShowAsDone 'logs cleared'
fi
return 0
}
ResetCachePath()
{
if [[ -n $r_cache_path && -d $r_cache_path ]];then
ClearPath "$r_this_package_path" "$r_cache_path"
ShowAsDone 'package cache cleared'
fi
return 0
}
ResetReportsPath()
{
if [[ -n $r_reports_path && -d $r_reports_path ]];then
ClearPath /var/log/sherpa "$r_reports_path"
ShowAsDone 'reports cleared'
fi
return 0
}
Quiz()
{
local a=${1:?${FUNCNAME[0]}'()': undefined prompt}
local b=''
ShowAsQuiz "$a"
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD igncr
read -rn1 b
[[ -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD -igncr
DebugVar b
ShowAsQuizDone "$a: $b"
case ${b:0:1} in
y|Y)
return 0
;;
*)
return 1
esac
}
PatchEntwareService()
{
local -r r_tab_char=$'\t'
local -r r_prefix='# the following line was inserted by sherpa: https://git.io/sherpa'
local -r r_package_init_pathfile=$(QpkgGetInstalledServicePathFile Entware)
local find=''
local insert=''
if $GREP_CMD -q 'opt.orig' "$r_package_init_pathfile";then
DebugInfo 'patch: do the "/opt shuffle" - already done'
else
find='# sym-link $QPKG_DIR to /opt'
insert='opt_path="/opt";opt_backup_path="/opt.orig"; [[ -d "$opt_path" \&\& ! -L "$opt_path" \&\& ! -e "$opt_backup_path" ]] \&\& mv "$opt_path" "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${r_tab_char}${r_prefix}\n${r_tab_char}${insert}\n|" "$r_package_init_pathfile"
find='/bin/ln -sf $QPKG_DIR /opt'
insert='[[ -L "$opt_path" \&\& -d "$opt_backup_path" ]] \&\& cp "$opt_backup_path"/* --target-directory "$opt_path" \&\& rm -r "$opt_backup_path"'
$SED_CMD -i "s|$find|$find\n\n${r_tab_char}${r_prefix}\n${r_tab_char}${insert}\n|" "$r_package_init_pathfile"
DebugAsDone 'patch: do the "opt shuffle"'
fi
return 0
}
_UpdateEntwarePackageList_()
{
if IsNtSysFileExist $OPKG_CMD;then
DisplayAsProjSynExam 'try reactivating Entware' 'reactivate ew'
return 1
fi
[[ ${r_entware_package_list_uptodate:-false} = false ]] || return
local -i z=0
if ! IsThisFileRecent "$r_external_packages_archive_pathfile" "$r_file_change_threshold_minutes" || [[ ! -f $r_external_packages_archive_pathfile || $useropt_check = true ]];then
DebugAsProc "updating $(ShowAsPackageName Entware) package list"
RunAndLog "$OPKG_CMD update" "$r_logs_path/Entware.$r_update_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
DebugAsDone "updated $(ShowAsPackageName Entware) package list"
CloseIpkArchive
else
DebugAsWarn "Unable to update $(ShowAsPackageName Entware) package list $(ShowAsExitcode "$z")"
fi
else
DebugInfo "$(ShowAsPackageName Entware) package list was updated less-than $r_file_change_threshold_minutes minutes ago: skipping update"
fi
[[ -f $r_external_packages_archive_pathfile && ! -f $r_external_packages_pathfile ]] && OpenIpkArchive
readonly r_entware_package_list_uptodate=true
return 0
}
IsThisFileRecent()
{
[[ -e ${1:-} && $((($(ConvertNowToSeconds)-$(/usr/bin/stat "$1" -c %Z))/60)) -le ${2:-1440} ]]
}
SaveIpkAndPipList()
{
$PIP_CMD freeze | cut -d'=' -f1 > "$r_prev_pip_list_pathfile"
[[ -e $r_prev_pip_list_pathfile ]] && DebugAsDone "saved current PIP list to $(ShowAsFileName "$r_prev_pip_list_pathfile")"
$OPKG_CMD list-installed > "$r_prev_ipk_list_pathfile"
[[ -e $r_prev_ipk_list_pathfile ]] && DebugAsDone "saved current $(ShowAsPackageName Entware) IPK list to $(ShowAsFileName "$r_prev_ipk_list_pathfile")"
} 2> /dev/null
LoadIpkList()
{
local name=''
local separator=''
local version=''
if [[ -e $r_prev_ipk_list_pathfile ]];then
DebugInfo "IPKs are being loaded from $(ShowAsFileName "$r_prev_ipk_list_pathfile")"
while read -r name separator version;do
name=$(Lowercase "$name")
IPKs-ACinstall-to:Add "$name"
done < "$r_prev_ipk_list_pathfile"
fi
}
LoadPipList()
{
local name=''
local re=''
if [[ -e $r_prev_pip_list_pathfile ]];then
DebugInfo "PIPs are being loaded from $(ShowAsFileName "$r_prev_pip_list_pathfile")"
while read -r name;do
name=$(Lowercase "$name")
re=\\b$name\\b
[[ ${r_exclusion_pips[*]} =~ $re ]] || PIPs-ACinstall-to:Add "$name"
done < "$r_prev_pip_list_pathfile"
fi
}
CalcIpkDepsToInstall()
{
IsSysFileExist $GNU_GREP_CMD || return
FuncInit
local complete=false
local -a dep_acc=()
local element=''
local ipk_titles=''
local -i iterations=0
local -r r_iteration_limit=20
local -i pre_exclude_count=0
local pre_exclude_list=''
local req_list=''
local -i requested_count=0
local -a this_list=()
req_list=$(DeDupeWords "$(IPKs-ACinstall-to:List)")
dep_acc=($req_list)
this_list=($req_list)
requested_count=$($WC_CMD -w <<< "$req_list")
if [[ $requested_count -eq 0 ]];then
DebugAsWarn 'no IPKs requested'
FuncExit 1;return
fi
DebugInfo "$requested_count IPK$(Pluralise "$requested_count") requested" "'$req_list' "
while [[ $iterations -le $r_iteration_limit ]];do
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
((iterations++))
printf -v ipk_titles '^Package: %s$\|' "${this_list[@]}"
ipk_titles=${ipk_titles%??}
this_list=($($GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator '^Package:\|^Depends:' "$r_external_packages_pathfile" | $GNU_GREP_CMD -vG '^Section:\|^Version:' | $GNU_GREP_CMD --word-regexp --after-context 1 --no-group-separator "$ipk_titles" | $GNU_GREP_CMD -vG "$ipk_titles" | $GNU_GREP_CMD -vG '^Package: ' | $SED_CMD 's|^Depends: ||;s|, |\n|g' | $SORT_CMD | $UNIQ_CMD))
ShowAsIterativeProgress 'resolve IPK dependencies' "$iterations" iteration "${#dep_acc[@]}" 'unique IPK'
if [[ ${#this_list[@]} -eq 0 ]];then
complete=true
break
else
dep_acc+=(${this_list[*]})
dep_acc=($(DeDupeWords "${dep_acc[*]}"))
fi
done
sleep .5
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
if [[ $complete = true ]];then
DebugAsDone "dependency calculation complete in $iterations iteration$(Pluralise "$iterations")"
else
DebugAsError "dependency calculation incomplete in $iterations iteration$(Pluralise "$iterations"), consider raising \$r_iteration_limit [$r_iteration_limit]"
show_suggest_raise_issue=true
fi
pre_exclude_list=${dep_acc[*]}
pre_exclude_count=$($WC_CMD -w <<< "$pre_exclude_list")
if [[ $pre_exclude_count -gt 0 ]];then
ShowAsProc 'exclude IPKs already installed'
DebugInfo "$pre_exclude_count IPK$(Pluralise "$pre_exclude_count") required (including dependencies)" "'$pre_exclude_list' "
for element in $pre_exclude_list;do
if [[ $element != 'ca-certs' && $element != 'python3-gdbm' ]];then
if [[ $element != 'libjpeg' ]];then
if ! $OPKG_CMD status "$element" | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add "$element"
fi
elif ! $OPKG_CMD status 'libjpeg-turbo' | $GREP_CMD -q "Status:.*installed";then
IPKs-ACdownload-to:Add 'libjpeg-turbo'
fi
fi
done
else
DebugAsDone 'no IPKs to exclude'
fi
FuncExit
}
CalcIpkDownloadSize()
{
FuncInit
local -a size_array=()
local -i size_count=0
size_count=$(IPKs-ACdownload-to:Count)
if [[ $size_count -gt 0 ]];then
ShowAsProc "calculate size of IPK$(Pluralise "$size_count") to download"
DebugAsDone "$size_count IPK$(Pluralise "$size_count") to download: '$(IPKs-ACdownload-to:List)'"
size_array=($($GNU_GREP_CMD -w '^Package:\|^Size:' "$r_external_packages_pathfile" | $GNU_GREP_CMD --after-context 1 --no-group-separator ": $($SED_CMD 's/ /$ /g;s/\$ /\$\\\|: /g' <<< "$(IPKs-ACdownload-to:List)")" | $GREP_CMD '^Size:' | $SED_CMD 's|^Size: ||'))
IPKs-ACdownload-to:Size = "$(IFS=+;echo "$((${size_array[*]:-}))")"
DebugAsDone "$(FormatAsThous "$(IPKs-ACdownload-to:Size)") bytes ($(FormatAsIsoBytes "$(IPKs-ACdownload-to:Size)")) to download"
else
DebugAsDone 'no IPKs to size'
fi
FuncExit
}
IPKs:upgrade()
{
[[ $ipks_upgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local log_pathfile=$r_logs_path/ipks.$r_upgrade_log_file
local -i total_count=0
local -i z=0
IPKs-ACupgrade-to:Init
IPKs-ACdownload-to:Init
IPKs-ACupgrade-to:Add "$($OPKG_CMD list-upgradable | cut -f1 -d' ')"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-to:Array)"
IPKs-ACupgrade-to:Remove "$(IPKs-ACdowngrade-sk:Array)"
IPKs-ACdownload-to:Add "$(IPKs-ACupgrade-to:Array)"
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
ShowAsProc "upgrade $desc"
_DirSizeMonitor_ "$r_ipk_download_path" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD upgrade --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$log_pathfile" log:failure-only
z=$?
KillPID "$fork_pid"
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACupgrade-to:Array)" upgrade
DebugAsDone "upgraded $desc"
SaveActionResultToLog IPK auxiliary upgrade "$total_count" ok
else
NoteIpkAcAsEr "$(IPKs-ACupgrade-to:Array)" upgrade
SaveActionResultToLog IPK auxiliary upgrade "$total_count" failed "$z"
fi
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:install()
{
[[ $ipks_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local -i i=0
local log_pathfile=$r_logs_path/ipks.$r_install_log_file
local previous=''
local -i total_count=0
local -i z=0
IPKs-ACinstall-to:Init
IPKs-ACdownload-to:Init
if QPKGs-ACinstall-ok.Exist Entware || ([[ $useropt_check = true ]] && QpkgIsInstalled Entware);then
IPKs-ACinstall-to:Add "$r_essential_ipks"
if [[ -e $r_prev_ipk_list_pathfile && $useropt_check = false ]];then
LoadIpkList
mv -f "$r_prev_ipk_list_pathfile" "$r_prev_ipk_list_pathfile.installing"
fi
fi
if QPKGs.ACinstall.GRall.IsSet;then
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QpkgSetIndex
IPKs-ACinstall-to:Add "$(QpkgGetDatabaseIPKs)"
done
else
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
if QPKGs-ACinstall-to.Exist "$qpkg_name" || QPKGs-ISinstalled.Exist "$qpkg_name" || (QPKGs-ACreinstall-to.Exist "$qpkg_name" && QPKGs-ISinstalled.Exist "$qpkg_name");then
QpkgSetIndex
IPKs-ACinstall-to:Add "$(QpkgGetDatabaseIPKs)"
fi
done
fi
CalcIpkDepsToInstall
CalcIpkDownloadSize
total_count=$(IPKs-ACdownload-to:Count)
if [[ $total_count -gt 0 ]];then
desc="$total_count auxiliary IPK$(Pluralise "$total_count")"
ShowAsProc "install $desc"
_DirSizeMonitor_ "$r_ipk_download_path" "$(IPKs-ACdownload-to:Size)" &
fork_pid=$!
RunAndLog "$OPKG_CMD install --force-overwrite $(IPKs-ACdownload-to:List) --cache $r_ipk_cache_path --tmp-dir $r_ipk_download_path" "$log_pathfile" log:failure-only
z=$?
KillPID "$fork_pid"
if [[ $z -eq 0 ]];then
NoteIpkAcAsOk "$(IPKs-ACdownload-to:Array)" install
DebugAsDone "installed $desc"
SaveActionResultToLog IPK auxiliary install "$total_count" ok
HideKeystrokes
UpdateCapabilities
rm -f "$r_prev_ipk_list_pathfile.installing" 2> /dev/null
else
NoteIpkAcAsEr "$(IPKs-ACdownload-to:Array)" install
SaveActionResultToLog IPK auxiliary install "$total_count" failed "$z"
if [[ -e $r_prev_ipk_list_pathfile.installing ]];then
mv -f "$r_prev_ipk_list_pathfile.installing" "$r_prev_ipk_list_pathfile"
fi
fi
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:downgrade()
{
[[ $ipks_downgrade = true ]] || return
QPKGs-ISenabled.Exist Entware || return
ErrorIsNt || return
FuncInit
local desc=''
local -i fail_count=0
local log_pathfile=''
local name=''
local -i ok_count=0
local package_type=''
local remote_url=''
local -i total_count=0
local url_prefix=''
local url_suffix=''
local -i z=0
IPKs-ACdownload-to:Init
total_count=$(IPKs-ACdowngrade-to:Count)
if [[ $total_count -gt 0 ]];then
package_type=IPK
desc="$total_count ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_logs_path/ipks.$r_download_log_file
ShowAsProc "download $desc"
case $r_nas_qpkg_arch in
a41)
if OsIsNonStdKernelPageSize;then
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.38-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
fi
url_prefix=http://bin.entware.net/armv7sf-k3.2/archive/
url_suffix=_2.39.2-1_armv7-3.2.ipk
for name in $(IPKs-ACdowngrade-to:Array);do
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 0 "$total_count"
((ok_count++))
remote_url=${url_prefix}${name}${url_suffix}
local_pathfile=$r_ipk_downgrade_path/$($BASENAME_CMD "$remote_url")
RunAndLog "$CURL_CMD --location --output $local_pathfile $remote_url" "$log_pathfile" log:failure-only
done
ShowAsPercentProgress "download $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
esac
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
total_count=1
ok_count=0
fail_count=0
desc="$total_count auxiliary ${package_type}$(Pluralise "$total_count")"
log_pathfile=$r_logs_path/ipks.$r_downgrade_log_file
ShowAsProc "downgrade $desc"
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
RunAndLog "$OPKG_CMD install --force-downgrade --cache $r_ipk_cache_path --tmp-dir $r_ipk_downgrade_path $r_ipk_downgrade_path/*.ipk" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
NoteIpkAcAsOk "$(IPKs-ACdowngrade-to:Array)" downgrade
DebugAsDone "downgraded $desc"
SaveActionResultToLog IPK auxiliary downgrade "$ok_count" ok
else
((fail_count++))
NoteIpkAcAsEr "$(IPKs-ACdowngrade-to:Array)" downgrade
SaveActionResultToLog IPK auxiliary downgrade "$fail_count" failed "$z"
fi
ShowAsPercentProgress "downgrade $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
IPKs:uninstall()
{
:
}
PIPs:upgrade()
{
:
}
PIPs:install()
{
[[ $pips_install = true ]] || return
QPKGs-ISenabled.Exist Entware || return
$OPKG_CMD status python3-pip | $GREP_CMD -q "Status:.*installed" || return
ErrorIsNt || return
FuncInit
local desc=''
local exec_cmd=''
local -i fail_count=0
local log_pathfile=$r_logs_path/pips.$r_install_log_file
local -i ok_count=0
local package_type=PIP
local -i total_count=0
local -i z=0
if [[ $useropt_check = true ]] || IPKs-ACinstall-ok.Exist python3-pip;then
PIPs-ACinstall-to:Add "$r_essential_pips"
if [[ -e $r_prev_pip_list_pathfile && $useropt_check = false ]];then
LoadPipList
mv -f "$r_prev_pip_list_pathfile" "$r_prev_pip_list_pathfile.installing"
fi
((total_count++))
exec_cmd="$PIP_CMD install --upgrade --no-input $(PIPs-ACinstall-to:List) --cache-dir $r_pip_cache_path --root-user-action=ignore"
desc="$total_count auxiliary PIP$(Pluralise "$total_count")"
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 0 "$total_count"
RunAndLog "$exec_cmd" "$log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
((ok_count++))
DebugAsDone "installed $desc"
SaveActionResultToLog PIP auxiliary install "$ok_count" ok
rm -f "$r_prev_pip_list_pathfile.installing" 2> /dev/null
else
((fail_count++))
SaveActionResultToLog PIP auxiliary install "$fail_count" failed "$z"
if [[ -e $r_prev_pip_list_pathfile.installing ]];then
mv -f "$r_prev_pip_list_pathfile.installing" "$r_prev_pip_list_pathfile"
fi
fi
ShowAsPercentProgress "install $desc" '' "$ok_count" 0 "$fail_count" "$total_count"
[[ ${useropt_terse:=true} = false && ${useropt_verbose:=false} = false ]] && echo
fi
FuncExit $z
}
PIPs:uninstall()
{
:
}
OpenIpkArchive()
{
if [[ ! -e $r_external_packages_archive_pathfile ]];then
ShowAsError 'unable to locate the IPK list file'
return 1
fi
RunAndLog "/usr/local/sbin/7z e -o$($DIRNAME_CMD "$r_external_packages_pathfile") $r_external_packages_archive_pathfile" "$r_cache_path/ipk.archive.extract" log:failure-only
if [[ ! -e $r_external_packages_pathfile ]];then
ShowAsError 'unable to open the IPK list file'
return 1
fi
return 0
}
CloseIpkArchive()
{
rm -f "$r_external_packages_pathfile" 2> /dev/null
}
_ExecOneActionWithManyForks_()
{
FuncForkInit
local a=${1:-function null}
shift
local -a c=("$@")
fork_id=0
for qpkg_name in "${c[@]}";do
[[ ! -e $r_action_abort_pathfile ]] || break
while [[ $fork_count -ge $max_forks ]];do
[[ ! -e $r_action_abort_pathfile ]] || break 2
sleep .2
UpdateForkProgress
done
IncForkProgressIndex
MarkThisAcForkAsStarted
QpkgSetIndex
action_pidfile=$($MKTEMP_CMD "$r_async_procs_path"/bgproc_XXXXXX)
$a &
echo "$!" > "$action_pidfile"
DebugAsDone "forked $a() instance for '$qpkg_name'"
UpdateForkProgress
done
while [[ $fork_count -gt 0 ]];do
[[ ! -e $r_action_abort_pathfile ]] || break
sleep .2
UpdateForkProgress
done
FuncForkExit
}
_DirSizeMonitor_()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} ]] || exit
[[ -d $1 && ${2:-0} -gt 0 ]] || exit
IsSysFileExist $GNU_FIND_CMD || exit
local -i current_bytes=-1
local -i last_bytes=0
local perc_msg=''
local progress_msg=''
local stall_msg=''
local -i stall_seconds=0
local -i stall_seconds_threshold=4
local -i total_bytes=${2:-0}
InitProgress
while [[ $current_bytes -lt $total_bytes ]];do
current_bytes=$($GNU_FIND_CMD "$1" -type f -name '*.ipk' -exec $DU_CMD --bytes --total --apparent-size {} + 2> /dev/null | $GREP_CMD total$ | cut -f1)
[[ -z $current_bytes ]] && current_bytes=0
if [[ $current_bytes -ne $last_bytes ]];then
stall_seconds=0
last_bytes=$current_bytes
else
((stall_seconds++))
fi
perc_msg="$((200*(current_bytes)/(total_bytes)%2+100*(current_bytes)/(total_bytes)))%"
[[ $current_bytes -lt $total_bytes && $perc_msg = '100%' ]] && perc_msg='99%'
progress_msg="$perc_msg ($(TextBrightWhite "$(FormatAsIsoBytes "$current_bytes")")/$(TextBrightWhite "$(FormatAsIsoBytes "$total_bytes")"))"
if [[ $stall_seconds -ge $stall_seconds_threshold ]];then
stall_msg=' stalled for '
if [[ $stall_seconds -lt 60 ]];then
stall_msg+="$stall_seconds seconds"
else
stall_msg+=$(ConvertSecondsToDuration "$stall_seconds")
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg+=': cancel with CTRL+C and try again later'
fi
if [[ $stall_seconds -ge 90 ]];then
stall_msg=$(TextBrightRed "$stall_msg")
elif [[ $stall_seconds -ge 45 ]];then
stall_msg=$(TextBrightOrange "$stall_msg")
elif [[ $stall_seconds -ge 20 ]];then
stall_msg=$(TextBrightYellow "$stall_msg")
fi
progress_msg+=$stall_msg
fi
[[ ! -e $r_display_inhibit_pathfile ]] || return
WriteMsgInPlace "$progress_msg"
sleep 1
done
[[ -n $progress_msg ]] && WriteMsgInPlace 'done!'
}
WriteMsgInPlace()
{
local -i a=0
local b=$(tr -s ' ' <<< "${1:-}")
local c=$(StripANSICodes "$b")
if [[ $c != "$prev_clean_msg" ]];then
if [[ ${#c} -lt ${#prev_clean_msg} ]];then
a=$((${#c}-${#prev_clean_msg}))
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"; printf "%${a}s"; printf "%${a}s" | tr ' ' '\b'
else
printf "%${#prev_clean_msg}s" | tr ' ' '\b';echo -en "$b"
fi
prev_clean_msg=$c
fi
}
KillPID()
{
[[ -n ${1:-} && $1 -gt 0 && -d /proc/$1 ]] || return
kill -9 "$1"
wait
} &> /dev/null
Reset()
{
ResetCachePath
ResetReportsPath
ResetArchivedLogs
ArchiveActiveSessLog
ResetActiveSessLog
exit 0
}
UpdateColourful()
{
local a=''
if [[ $switch_colour = true && -n $user_colourful_value ]];then
for a in true false;do
[[ $a != "$user_colourful_value" ]] && continue
useropt_colourful=$user_colourful_value
if [[ ${1:-} = silent ]];then
SaveSetting Colourful "$useropt_colourful"
else
SaveSetting Colourful "$useropt_colourful" announce
fi
switch_colour=false
return
done
ShowAsAbort "user setting '$user_colourful_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
UpdateBranch()
{
local a=''
if [[ $switch_branch = true && -n $user_branch_value ]];then
for a in unstable stable;do
[[ $a != "$user_branch_value" ]] && continue
useropt_branch=$user_branch_value
if [[ ${1:-} = silent ]];then
SaveSetting Git_Branch "$useropt_branch"
else
SaveSetting Git_Branch "$useropt_branch" announce
Reset
fi
switch_branch=false
return
done
ShowAsAbort "user setting '$user_branch_value' is not 'unstable' or 'stable'"
run_package_actions=false
return 1
fi
}
UpdateReportFooter()
{
local a=''
if [[ $switch_report_footer = true && -n $user_report_footer_value ]];then
for a in true false;do
[[ $a != "$user_report_footer_value" ]] && continue
useropt_report_footer=$user_report_footer_value
if [[ ${1:-} = silent ]];then
SaveSetting ReportFooter "$useropt_report_footer"
else
SaveSetting ReportFooter "$useropt_report_footer" announce
fi
switch_report_footer=false
return
done
ShowAsAbort "user setting '$user_report_footer_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
UpdateTerse()
{
local a=''
if [[ $switch_terse = true && -n $user_terse_value ]];then
for a in true false;do
[[ $a != "$user_terse_value" ]] && continue
useropt_terse=$user_terse_value
if [[ ${1:-} = silent ]];then
SaveSetting Terse "$useropt_terse"
else
SaveSetting Terse "$useropt_terse" announce
fi
switch_terse=false
return
done
ShowAsAbort "user setting '$user_terse_value' is not 'true' or 'false'"
run_package_actions=false
return 1
fi
}
SaveSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined value}")
case $b in
true|false)
b=$(Uppercase "$b")
esac
/sbin/setcfg sherpa "$a" "$b" -f /etc/config/qpkg.conf
[[ ${3:-} = announce ]] && ShowAsDone "user setting '$a = $b' has been saved"
}
LoadSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
local b=$(Lowercase "${2:?${FUNCNAME[0]}'()': undefined default value}")
Lowercase "$(/sbin/getcfg sherpa "$a" -d "$b" -f /etc/config/qpkg.conf)"
}
DeleteSetting()
{
local a=${1:?${FUNCNAME[0]}'()': undefined name}
/sbin/setcfg -e sherpa "$a" -f /etc/config/qpkg.conf
}
UserIsOk()
{
if ! UserIsSU;then
if OsIsSupportSudo;then
ShowAsError 'this utility must be run with superuser privileges. Try again as:'
echo "${r_chars_sudo_prompt}sherpa $r_args_raw" >&2
else
ShowAsError "this utility must be run as the 'admin' user. Please login via SSH as 'admin' and try again"
fi
return 1
fi
return 0
}
UserIsSU()
{
[[ $EUID -eq 0 ]]
}
#DebugBinPathVerAndMinVer()
IsSysFileExist()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined pathfile} ]] || exit
local a=${1%% *}
if ! [[ -f $a || -L $a ]];then
ShowAsAbort "a required NAS system file $(ShowAsFileName "$a") is missing"
return 1
fi
return 0
}
IsNtSysFileExist()
{
! IsSysFileExist "${1:?${FUNCNAME[0]}'()': undefined pathfile}"
}
LenANSIDiff()
{
local a=${1:-}
local b=$(StripANSICodes "$a")
printf '%s' "$((${#a}-${#b}))"
return 0
}
AddSeparators()
{
[[ -z ${1:-} ]] && return
local a=''
a=$(Trim "$1")
a=${a// /, }
a=${a//!/ }
printf '%s' "$a"
}
DisplayAsProjSynExam()
{
printf "\n${r_chars_bullet}%s" "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf "\n%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}"
}
DisplayAsProjSynIndentExam()
{
if [[ -n $1	]];then
printf "\n%${r_help_desc_indent}s%s" '' "$(Capitalise "${1:-}")"
[[ ${1: -1} != '!' ]] && printf ':'
printf '\n'
fi
printf "%${r_help_syntax_indent}s${r_help_syntax_sudo_prefix}sherpa %s\n" '' "${2:-}"
}
DisplayAsSynExam()
{
printf "\n${r_chars_bullet}%s:\n%${r_help_syntax_indent}s${r_help_syntax_prefix}%s\n" "$(Capitalise "${1:-}")" '' "${2:-}"
}
DisplayAsIndentItem()
{
printf "%${r_help_desc_indent}s${r_chars_bullet}%s\n" '' "$(Capitalise "${1:-}")"
}
DisplayAsIndentQuotedInfoItem()
{
if OsIsSupportAutowidthTableColumns;then
printf "%${r_help_desc_indent}s%s|%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
else
printf "%${r_help_desc_indent}s%-$((r_report_footer_name_column_width+2+$(LenANSIDiff "${1:-}")))s%s\n" '' "'${1:-}'" "- $(AddPeriod "${2:-}")"
fi
}
GeneratePacksReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((r_report_qpkg_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Appl. version:'
printf "%-$((r_report_qpkg_appl_version_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Description:'
printf "%-$((r_report_qpkg_description_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GeneratePacksReportDataLine()
{
local app_ver=''
local app_ver_msg=$r_chars_blank
local description_msg=$r_chars_blank
local mode=''
local name=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local description=$(QpkgGetDatabaseDesc "$name")
local notes=$(QpkgGetDatabaseNote "$name")
[[ $notes = none ]] && notes=''
local name_msg=$r_chars_normal
local notes_msg="${notes}."
if QpkgIsInstalledMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif QpkgIsNtInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
app_ver=$(QpkgGetDatabaseApplVer)
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
app_ver_msg+=$app_ver
description_msg+="$(Capitalise "$description")."
name_msg+=$qpkg_name
case $mode in
mute)
app_ver_msg=$(TextDarkGrey "$app_ver_msg")
description_msg=$(TextDarkGrey "$description_msg")
name_msg=$(TextDarkGrey "$name_msg")
;;
highlight)
name_msg=$(TextBrightRed "$name_msg")
esac
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$app_ver_msg|$description_msg"
if [[ -n $notes ]];then
printf "%s|%s|%$((${#r_chars_blank}))s%s\n" '' '' '' "$(TextBrightOrange "${r_chars_dropend}${r_chars_note}") $notes_msg"
fi
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_appl_version_column_width+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_description_column_width+$(LenANSIDiff "$description_msg")))s" "$description_msg"
if [[ -n $notes ]];then
printf "\n%$((${#r_chars_blank}+r_report_qpkg_name_column_width+r_report_qpkg_appl_version_column_width+(r_report_column_spacing*2)))s$(TextBrightOrange "${r_chars_dropend}${r_chars_note}")%s" '' "$notes_msg"
fi
printf '\n'
fi
}
GenerateStatusReportTitleLine()
{
local a=''
a='QPKG name'
printf "%-${r_report_qpkg_name_column_width}s" "$a:"
printf "%$((r_report_column_spacing))s"
a='Status'
printf "%-${r_report_qpkg_status_column_width}s" "$a:"
printf "%$((r_report_column_spacing))s"
a='Previous action (result)'
printf "%-${r_report_qpkg_action_column_width}s" "$a:"
printf "%$((r_report_column_spacing))s"
a='QPKG version'
QPKGs-ISupgradable.IsAny && a+=" ($(TextBrightOrange new))"
printf "%-${r_report_qpkg_version_column_width}s" "$a:"
printf "%$((r_report_column_spacing))s"
a='Appl. version'
printf "%-${r_report_qpkg_appl_version_column_width}s" "$a:"
printf "%$((r_report_column_spacing))s"
a='Location'
printf "%-${r_report_qpkg_path_column_width}s" "$a:"
printf '\n'
}
GenerateStatusReportDataLine()
{
local action=''
local action_msg=$r_chars_blank
local app_ver=$(QpkgGetDatabaseApplVer)
local app_ver_msg=$r_chars_blank
local mode=''
local -i n=0
local name_msg=$r_chars_blank
local path=$(QpkgGetInstalledPath)
local path_msg=$r_chars_blank
local result=''
local status=''
local status_msg=$r_chars_normal
local ver=$(QpkgGetInstalledVer)
local ver_msg=$r_chars_blank
if QpkgIsInstalledMissing;then
mode=missing
elif QpkgIsInstalled;then
mode=normal
else
mode=mute
QpkgIsReallyInstalled && QpkgIsNtInstalledAuthorOk && mode=author
fi
case $app_ver in
dynamic|final|static)
/bin/touch "$r_report_flags_path"/app-$app_ver
esac
case $mode in
missing|normal)
if QpkgIsDatabaseSherpaCompatible;then
action=$(QpkgGetInstalledServiceAction)
/bin/touch "$r_report_flags_path"/action-$action
if [[ $action = not-found ]];then
if OsIsStarting && QpkgIsInstalledEnabled;then
action_msg+=$(TextBrightOrange pending)
/bin/touch "$r_report_flags_path"/action-pending
else
action_msg+=$(TextDarkGrey not-found)
fi
else
action_msg+=$action
fi
result=$(QpkgGetInstalledServiceResult)
/bin/touch "$r_report_flags_path"/result-$result
case $result in
aborted|failed)
action_msg+=" ($(TextBrightRed "$result"))"
;;
in-progress)
action_msg+=" ($(TextBrightOrange "$result"))"
;;
ok)
action_msg+=" ($(TextBrightGreen "$(Uppercase "$result")"))"
esac
else
action=unsupported
/bin/touch "$r_report_flags_path"/action-unsupported
action_msg+=$(TextDarkGrey "$action")
fi
;;
*)
action=N/A
/bin/touch "$r_report_flags_path"/na
esac
case $mode in
author)
/bin/touch "$r_report_flags_path"/status-wrongauthor
/bin/touch "$r_report_flags_path"/na
app_ver=N/A
status='incompatible author'
ver=N/A
action_msg+=$action
app_ver_msg+=$app_ver
name_msg+=$qpkg_name
path_msg+=$path
status_msg=${r_chars_attention}${status}
ver_msg+=$ver
action_msg=$(TextBrightOrange "$action_msg")
app_ver_msg=$(TextBrightOrange "$app_ver_msg")
name_msg=$(TextBrightOrange "$name_msg")
path_msg=$(TextBrightOrange "$path_msg")
status_msg=$(TextBrightOrange "$status_msg")
ver_msg=$(TextBrightOrange "$ver_msg")
;;
missing)
/bin/touch "$r_report_flags_path"/status-missing
status=missing
app_ver_msg+=$app_ver
name_msg+=$qpkg_name
path_msg+=$path
status_msg=${r_chars_alert}${status}
ver_msg+=$ver
app_ver_msg=$(TextBrightRed "$app_ver_msg")
name_msg=$(TextBrightRed "$name_msg")
path_msg=$(TextBrightRedBlink "$path_msg")
status_msg=$(TextBrightRedBlink "$status_msg")
ver_msg=$(TextBrightRed "$ver_msg")
;;
mute)
/bin/touch "$r_report_flags_path"/state-notinstalled
/bin/touch "$r_report_flags_path"/na
path=N/A
if ! QpkgIsDatabaseArchOK;then
status+='incompatible architecture'
elif ! QpkgIsDatabaseMinOSVerOk || ! QpkgIsDatabaseMaxOSVerOk;then
status+="incompatible $(OsGetQnapOS)"
elif ! QpkgIsDatabaseMinRAMOk;then
status+='insufficient RAM installed'
else
status+='not installed'
fi
ver=$(QpkgGetDatabaseVer "$qpkg_name")
action_msg+=$action
app_ver_msg+=$app_ver
name_msg+=$qpkg_name
path_msg+=$path
status_msg+=$status
ver_msg+=$ver
action_msg=$(TextDarkGrey "$action_msg")
app_ver_msg=$(TextDarkGrey "$app_ver_msg")
name_msg=$(TextDarkGrey "$name_msg")
path_msg=$(TextDarkGrey "$path_msg")
status_msg=$(TextDarkGrey "$status_msg")
ver_msg=$(TextDarkGrey "$ver_msg")
;;
normal)
/bin/touch "$r_report_flags_path"/state-installed
if QPKGs-ISenabled.Exist "$qpkg_name";then
status+=" $(TextBrightGreen enabled)"
/bin/touch "$r_report_flags_path"/state-enabled
else
status+=" $(TextBrightRed disabled)"
/bin/touch "$r_report_flags_path"/state-disabled
fi
if QPKGs-ISactive.Exist "$qpkg_name";then
status+=" $(TextBrightGreen active)"
/bin/touch "$r_report_flags_path"/status-active
elif QPKGs-ISslow.Exist "$qpkg_name";then
status+=" $(TextBrightOrange slow)"
/bin/touch "$r_report_flags_path"/status-slow
elif QPKGs-ISNTactive.Exist "$qpkg_name";then
status+=" $(TextBrightRed inactive)"
/bin/touch "$r_report_flags_path"/status-inactive
else
status+=" $(TextBrightOrange unknown)"
/bin/touch "$r_report_flags_path"/status-unknown
fi
app_ver_msg+=$app_ver
name_msg+=$qpkg_name
path_msg+=$path
status_msg+=$(AddSeparators "$status")
ver_msg+=$ver
esac
if QPKGs-ISupgradable.Exist "$qpkg_name";then
ver_msg+=" ($(TextBrightOrange "$(QpkgGetDatabaseVer)"))"
/bin/touch "$r_report_flags_path"/status-upgradable
fi
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$status_msg|$action_msg|$ver_msg|$app_ver_msg|$path_msg"
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$status_msg")))s" "$status_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$action_msg")))s" "$action_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$ver_msg")))s" "$ver_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$app_ver_msg")))s" "$app_ver_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_path_column_width+$(LenANSIDiff "$path_msg")))s" "$path_msg"
printf '\n'
fi
}
GenerateReposReportTitleLine()
{
local a=''
a="QPKG name:"
printf "%-$((r_report_qpkg_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a="Repository:"
printf "%-$((r_report_qpkg_repo_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a="Install date:"
printf "%-$((r_report_qpkg_install_date_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateReposReportDataLine()
{
local assigned_repo=''
local assigned_repo_msg=$r_chars_normal
local install_date=$(QpkgGetInstalledDate)
local install_date_msg=$r_chars_blank
local mode=''
local name_msg=$r_chars_blank
local store_id=$(QpkgGetInstalledStoreID)
[[ $store_id = undefined ]] && store_id=sherpa
if QpkgIsInstalledMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif QpkgIsInstalled;then
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
else
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
fi
if [[ $store_id = sherpa ]];then
assigned_repo=sherpa
/bin/touch "$r_report_flags_path"/repo-sherpa
else
assigned_repo=$(GetRepoURLFromStoreID "$store_id")
fi
case $mode in
highlight)
install_date=missing
case $assigned_repo in
sherpa)
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
;;
unassigned)
assigned_repo_msg+=$(TextBrightOrange "$assigned_repo")
;;
*)
assigned_repo_msg+=$assigned_repo
/bin/touch "$r_report_flags_path"/repo-other
esac
install_date_msg=$(TextBrightRedBlink "${r_chars_alert}${install_date}")
name_msg=$(TextBrightRed "${name_msg}${qpkg_name}")
;;
normal)
case $assigned_repo in
sherpa)
assigned_repo_msg+=$(TextBrightGreen "$assigned_repo")
name_msg+=$qpkg_name
;;
undefined)
assigned_repo_msg+=N/A
name_msg+=$qpkg_name
/bin/touch "$r_report_flags_path"/na
;;
*)
assigned_repo_msg=$(TextBrightOrange "${r_chars_attention}${assigned_repo}")
name_msg=$(TextBrightOrange "${name_msg}${qpkg_name}")
/bin/touch "$r_report_flags_path"/repo-other
esac
install_date_msg+=$install_date
;;
mute)
assigned_repo=N/A
/bin/touch "$r_report_flags_path"/na
if ! QpkgIsDatabaseArchOK;then
install_date='incompatible architecture'
elif ! QpkgIsDatabaseMinOSVerOk;then
install_date="incompatible $(OsGetQnapOS)"
elif ! QpkgIsDatabaseMinRAMOk;then
install_date='insufficient RAM installed'
else
install_date='not installed'
fi
assigned_repo_msg=$(TextDarkGrey "${assigned_repo_msg}${assigned_repo}")
install_date_msg=$(TextDarkGrey "${install_date_msg}${install_date}")
name_msg=$(TextDarkGrey "${name_msg}${qpkg_name}")
esac
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$assigned_repo_msg|$install_date_msg"
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_repo_column_width+$(LenANSIDiff "$assigned_repo_msg")))s" "$assigned_repo_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_install_date_column_width+$(LenANSIDiff "$install_date_msg")))s" "$install_date_msg"
printf '\n'
fi
}
GenerateAbsReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((r_report_qpkg_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Installed?'
printf "%-$((r_report_qpkg_is_installed_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Acceptable QPKG name abbreviations and aliases:'
printf "%-$((r_report_qpkg_abbreviations_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateAbsReportDataLine()
{
local abs_msg=''
local installed_msg=$r_chars_blank
local mode=''
local name_msg=$r_chars_blank
if QpkgIsInstalledMissing;then
mode=highlight
/bin/touch "$r_report_flags_path"/status-missing
elif QpkgIsNtInstalled;then
mode=mute
/bin/touch "$r_report_flags_path"/state-notinstalled
else
mode=normal
/bin/touch "$r_report_flags_path"/state-installed
fi
case $mode in
normal)
abs_msg=${r_chars_normal}$(AddSeparators "$(QpkgGetDatabaseAbbrvs)")
installed_msg+=true
name_msg+=$qpkg_name
;;
mute)
if ! QpkgIsDatabaseArchOK "$qpkg_name";then
abs_msg="${r_chars_alert}incompatible architecture"
elif ! QpkgIsDatabaseMinOSVerOk "$qpkg_name";then
abs_msg="${r_chars_alert}incompatible $(OsGetQnapOS) version"
elif ! QpkgIsDatabaseMinRAMOk "$qpkg_name";then
abs_msg="${r_chars_alert}insufficient RAM installed"
else
abs_msg=${r_chars_normal}$(AddSeparators "$(QpkgGetDatabaseAbbrvs "$qpkg_name")")
fi
abs_msg=$(TextDarkGrey "$abs_msg")
installed_msg+=$(TextDarkGrey false)
name_msg+=$(TextDarkGrey "$qpkg_name")
;;
highlight)
abs_msg=$(TextBrightRed "${r_chars_alert}$(AddSeparators "$(QpkgGetDatabaseAbbrvs)")")
installed_msg=$(TextBrightRedBlink "${r_chars_alert}missing")
name_msg+=$(TextBrightRed "$qpkg_name")
esac
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$installed_msg|$abs_msg"
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_is_installed_column_width+$(LenANSIDiff "$installed_msg")))s" "$installed_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_abbreviations_column_width+$(LenANSIDiff "$abs_msg")))s" "$abs_msg"
printf '\n'
fi
}
GenerateDepsReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((r_report_qpkg_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Dependencies:'
printf "%-$((r_report_qpkg_dependencies_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Installed?'
printf "%-$((r_report_qpkg_is_installed_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Enabled?'
printf "%-$((r_report_qpkg_is_enabled_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Managed?'
printf "%-$((r_report_qpkg_is_managed_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Min. RAM:'
printf "%-$((r_report_qpkg_min_ram_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Min. OS:'
printf "%-$((r_report_qpkg_min_os_version_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Max. OS:'
printf "%-$((r_report_qpkg_max_os_version_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Supported arch?'
printf "%-$((r_report_qpkg_arch_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Installed QPKG author:'
printf "%-$((r_report_lazy_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateDepsReportDataLine()
{
local author=$(QpkgGetInstalledAuthor)
local author_ok=false
local author_msg=$r_chars_blank
local arch=false
local arch_msg=$r_chars_blank
local dep_name=''
local deps=''
local deps_msg=$r_chars_normal
local deps_raw=$(QpkgGetDatabaseDependencies "$qpkg_name")
local enabled=false
local enabled_msg=$r_chars_blank
local installed=false
local installed_msg=$r_chars_blank
local managed=false
local managed_msg=$r_chars_blank
local max_os=$(QpkgGetDatabaseMaxOSVer "$qpkg_name")
local max_os_msg=$r_chars_blank
local max_os_ok=false
local min_os=$(QpkgGetDatabaseMinOSVer "$qpkg_name")
local min_os_msg=$r_chars_blank
local min_os_ok=false
local min_ram=$(QpkgGetDatabaseMinRAM "$qpkg_name")
local min_ram_msg=$r_chars_blank
local min_ram_ok=false
local mode=''
local name_msg=$r_chars_blank
local req_alert=false
local req_attention=false
/bin/touch "$r_report_flags_path"/deps
if QpkgIsInstalledMissing;then
mode=missing
elif QpkgIsInstalled;then
mode=normal
else
mode=mute
QpkgIsReallyInstalled && QpkgIsNtInstalledAuthorOk && mode=author
fi
[[ -z $deps_raw ]] && deps_raw=none
[[ -n $max_os && $max_os != none && ${#max_os} -eq 3 ]] && max_os=${max_os:0:1}.${max_os:1:1}.${max_os:2:1}
[[ -n $min_os && $min_os != none && ${#min_os} -eq 3 ]] && min_os=${min_os:0:1}.${min_os:1:1}.${min_os:2:1}
[[ $min_ram != none ]] && min_ram=$(FormatAsThous "$min_ram")kB
case $mode in
author)
/bin/touch "$r_report_flags_path"/status-wrongauthor
arch=N/A
deps='incompatible author'
enabled=N/A
installed=true
managed=N/A
max_os=N/A
min_os=N/A
min_ram=N/A
req_attention=true
arch_msg+=$arch
author_msg=${r_chars_attention}${author}
deps_msg=${r_chars_attention}${deps}
enabled_msg+=$enabled
installed_msg+=$installed
managed_msg+=$managed
max_os_msg+=$max_os
min_os_msg+=$min_os
min_ram_msg+=$min_ram
arch_msg=$(TextBrightOrange "$arch_msg")
author_msg=$(TextBrightOrange "$author_msg")
deps_msg=$(TextBrightOrange "$deps_msg")
enabled_msg=$(TextBrightOrange "$enabled_msg")
installed_msg=$(TextBrightGreen "$installed_msg")
managed_msg=$(TextBrightOrange "$managed_msg")
max_os_msg=$(TextBrightOrange "$max_os_msg")
min_os_msg=$(TextBrightOrange "$min_os_msg")
min_ram_msg=$(TextBrightOrange "$min_ram_msg")
;;
missing)
QpkgIsDatabaseArchOK && arch=true
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
if QpkgIsInstalled "$dep_name" && QpkgIsInstalledEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
fi
done
else
deps+=$(TextBrightGreen "$deps_raw")
fi
QpkgIsInstalledEnabled && enabled=true
installed=missing
QpkgIsInstalledRepoSelfManaged && managed=true
QpkgIsDatabaseMaxOSVerOk && max_os_ok=true
QpkgIsDatabaseMinOSVerOk && min_os_ok=true
QpkgIsDatabaseMinRAMOk && min_ram_ok=true
req_alert=true
if [[ $arch = true ]];then
arch_msg+=$arch
else
arch_msg=${r_chars_alert}${arch}
fi
author_msg+=$author
deps_msg+=${deps// /, }
if [[ $enabled = true ]];then
enabled_msg+=$enabled
else
enabled_msg=${r_chars_alert}${enabled}
fi
installed_msg=${r_chars_alert}${installed}
managed_msg+=$managed
if [[ $max_os_ok = true ]];then
max_os_msg+=$max_os
else
max_os_msg=${r_chars_alert}${max_os}
fi
if [[ $min_os_ok = true ]];then
min_os_msg+=$min_os
else
min_os_msg=${r_chars_alert}${min_os}
fi
if [[ $min_ram_ok = true ]];then
min_ram_msg+=$min_ram
else
min_ram_msg=${r_chars_alert}${min_ram}
fi
if [[ $arch = true ]];then
arch_msg=$(TextBrightGreen "$arch_msg")
else
arch_msg=$(TextBrightRed "$arch_msg")
fi
author_msg=$(TextBrightGreen "$author_msg")
if [[ $enabled = true ]];then
enabled_msg=$(TextBrightGreen "$enabled_msg")
else
enabled_msg=$(TextBrightRedBlink "$enabled_msg")
fi
installed_msg=$(TextBrightRedBlink "$installed_msg")
if [[ $managed = true ]];then
managed_msg=$(TextBrightGreen "$managed_msg")
else
managed_msg=$(TextBrightOrange "$managed_msg")
fi
if [[ $max_os_ok = true ]];then
if [[ $max_os != none ]];then
max_os_msg=$(TextBrightGreen "$max_os_msg")
fi
else
max_os_msg=$(TextBrightRed "$max_os_msg")
fi
if [[ $min_os_ok = true ]];then
if [[ $min_os != none ]];then
min_os_msg=$(TextBrightGreen "$min_os_msg")
fi
else
min_os_msg=$(TextBrightRed "$min_os_msg")
fi
if [[ $min_ram_ok = true ]];then
if [[ $min_ram != none ]];then
min_ram_msg=$(TextBrightGreen "$min_ram_msg")
fi
else
min_ram_msg=$(TextBrightRed "$min_ram_msg")
fi
;;
mute)
/bin/touch "$r_report_flags_path"/state-notinstalled
QpkgIsDatabaseArchOK "$qpkg_name" && arch=true
author=N/A
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
deps+=$dep_name
done
else
deps+=$deps_raw
fi
enabled=N/A
managed=N/A
QpkgIsDatabaseMaxOSVerOk "$qpkg_name" && max_os_ok=true
QpkgIsDatabaseMinOSVerOk "$qpkg_name" && min_os_ok=true
QpkgIsDatabaseMinRAMOk "$qpkg_name" && min_ram_ok=true
/bin/touch "$r_report_flags_path"/na
if [[ $arch = true ]];then
arch_msg+=$arch
else
arch_msg=${r_chars_attention}${arch}
req_attention=true
fi
author_msg+=$author
deps_msg+=${deps// /, }
enabled_msg+=$enabled
installed_msg+=$installed
managed_msg+=$managed
if [[ $max_os_ok = true ]];then
max_os_msg+=$max_os
else
max_os_msg=${r_chars_attention}${max_os}
req_attention=true
fi
if [[ $min_os_ok = true ]];then
min_os_msg+=$min_os
else
min_os_msg=${r_chars_attention}${min_os}
req_attention=true
fi
if [[ $min_ram_ok = true ]];then
min_ram_msg+=$min_ram
else
min_ram_msg=${r_chars_attention}${min_ram}
req_attention=true
fi
if [[ $arch = true ]];then
arch_msg=$(TextDarkGrey "$arch_msg")
else
arch_msg=$(TextBrightOrange "$arch_msg")
fi
author_msg=$(TextDarkGrey "$author_msg")
deps_msg=$(TextDarkGrey "$deps_msg")
enabled_msg=$(TextDarkGrey "$enabled_msg")
installed_msg=$(TextDarkGrey "$installed_msg")
managed_msg=$(TextDarkGrey "$managed_msg")
if [[ $max_os_ok = true ]];then
max_os_msg=$(TextDarkGrey "$max_os_msg")
else
max_os_msg=$(TextBrightOrange "$max_os_msg")
fi
if [[ $min_os_ok = true ]];then
min_os_msg=$(TextDarkGrey "$min_os_msg")
else
min_os_msg=$(TextBrightOrange "$min_os_msg")
fi
if [[ $min_ram_ok = true ]];then
min_ram_msg=$(TextDarkGrey "$min_ram_msg")
else
min_ram_msg=$(TextBrightOrange "$min_ram_msg")
fi
;;
normal)
QpkgIsDatabaseArchOK && arch=true
author_ok=true
QpkgIsInstalledEnabled && enabled=true
installed=true
QpkgIsInstalledRepoSelfManaged && managed=true
QpkgIsDatabaseMaxOSVerOk && max_os_ok=true
QpkgIsDatabaseMinOSVerOk && min_os_ok=true
QpkgIsDatabaseMinRAMOk && min_ram_ok=true
if [[ $arch = true ]];then
arch_msg+=$arch
else
arch_msg=${r_chars_alert}${arch}
req_alert=true
fi
author_msg+=$author
if [[ $deps_raw != none ]];then
for dep_name in $deps_raw;do
[[ -n $deps ]] && deps+=' '
if QpkgIsInstalled "$dep_name" && QpkgIsInstalledEnabled "$dep_name";then
deps+=$(TextBrightGreen "$dep_name")
else
deps+=$(TextBrightRed "$dep_name")
deps_msg=$(TextBrightRed "$r_chars_alert")
req_alert=true
fi
done
else
deps+=$deps_raw
fi
if [[ $enabled = true ]];then
enabled_msg+=$enabled
else
enabled_msg=${r_chars_alert}${enabled}
req_alert=true
fi
installed_msg+=$installed
managed_msg+=$managed
if [[ $max_os_ok = true ]];then
max_os_msg+=$max_os
else
max_os_msg=${r_chars_alert}${max_os}
req_alert=true
fi
if [[ $min_os_ok = true ]];then
min_os_msg+=$min_os
else
min_os_msg=${r_chars_alert}${min_os}
req_alert=true
fi
if [[ $min_ram_ok = true ]];then
min_ram_msg+=$min_ram
else
min_ram_msg=${r_chars_alert}${min_ram}
req_alert=true
fi
if [[ $arch = true ]];then
arch_msg=$(TextBrightGreen "$arch_msg")
else
arch_msg=$(TextBrightRed "$arch_msg")
fi
author_msg=$(TextBrightGreen "$author_msg")
deps_msg+=${deps// /, }
if [[ $enabled = true ]];then
enabled_msg=$(TextBrightGreen "$enabled_msg")
else
enabled_msg=$(TextBrightRed "$enabled_msg")
fi
installed_msg=$(TextBrightGreen "$installed_msg")
if [[ $managed = true ]];then
managed_msg=$(TextBrightGreen "$managed_msg")
else
managed_msg=$(TextBrightOrange "$managed_msg")
fi
if [[ $max_os_ok = true ]];then
if [[ $max_os != none ]];then
max_os_msg=$(TextBrightGreen "$max_os_msg")
fi
else
max_os_msg=$(TextBrightRed "$max_os_msg")
fi
if [[ $min_os_ok = true ]];then
if [[ $min_os != none ]];then
min_os_msg=$(TextBrightGreen "$min_os_msg")
fi
else
min_os_msg=$(TextBrightRed "$min_os_msg")
fi
if [[ $min_ram_ok = true ]];then
if [[ $min_ram != none ]];then
min_ram_msg=$(TextBrightGreen "$min_ram_msg")
fi
else
min_ram_msg=$(TextBrightRed "$min_ram_msg")
fi
esac
if [[ $req_alert = true ]];then
/bin/touch "$r_report_flags_path"/req-alert
name_msg=${r_chars_blank}$(TextBrightRed "$qpkg_name")
elif [[ $req_attention = true ]];then
/bin/touch "$r_report_flags_path"/req-attention
name_msg=${r_chars_blank}$(TextBrightOrange "$qpkg_name")
elif [[ $mode = mute ]];then
name_msg+=$(TextDarkGrey "$qpkg_name")
else
name_msg+=$qpkg_name
fi
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$deps_msg|$installed_msg|$enabled_msg|$managed_msg|$min_ram_msg|$min_os_msg|$max_os_msg|$arch_msg|$author_msg"
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_dependencies_column_width+$(LenANSIDiff "$deps_msg")))s" "$deps_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_is_installed_column_width+$(LenANSIDiff "$installed_msg")))s" "$installed_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_is_enabled_column_width+$(LenANSIDiff "$enabled_msg")))s" "$enabled_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_is_managed_column_width+$(LenANSIDiff "$managed_msg")))s" "$managed_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_min_ram_column_width+$(LenANSIDiff "$min_ram_msg")))s" "$min_ram_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_min_os_version_column_width+$(LenANSIDiff "$min_os_msg")))s" "$min_os_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_max_os_version_column_width+$(LenANSIDiff "$max_os_msg")))s" "$max_os_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_arch_column_width+$(LenANSIDiff "$arch_msg")))s" "$arch_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$author_msg")))s" "$author_msg"
printf '\n'
fi
}
GenerateFeaturesReportTitleLine()
{
local a=''
a='QPKG name:'
printf "%-$((r_report_qpkg_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='CanBack?'
printf "%-$((r_report_qpkg_supports_backup_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='CanClean?'
printf "%-$((r_report_qpkg_supports_clean_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='StartUpd?'
printf "%-$((r_report_qpkg_supports_start_to_update_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='AutoUpd?'
printf "%-$((r_report_qpkg_auto_update_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='LiveTest?'
printf "%-$((r_report_qpkg_active_test_builtin_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Indep?'
printf "%-$((r_report_qpkg_tier_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Compat?'
printf "%-$((r_report_qpkg_is_compatible_column_width+2+$(LenANSIDiff "$a")))s" "$a"
a='Enhanced?'
printf "%-$((r_report_lazy_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
GenerateFeaturesReportDataLine()
{
local active_test=false
local active_test_msg=$r_chars_blank
local autoupdate=false
local autoupdate_msg=$r_chars_blank
local backup=false
local backup_msg=$r_chars_blank
local clean=false
local clean_msg=$r_chars_blank
local compatible=false
local compatible_msg=$r_chars_blank
local mode=''
local name_msg=$r_chars_blank
local req_alert=false
local req_attention=false
local restart_to_update=false
local restart_to_update_msg=$r_chars_blank
local sherpa_compatible=false
local sherpa_compatible_msg=$r_chars_blank
local tier=false
local tier_msg=$r_chars_blank
if QpkgIsInstalledMissing;then
mode=missing
elif QpkgIsInstalled;then
mode=normal
else
mode=mute
QpkgIsReallyInstalled && QpkgIsNtInstalledAuthorOk && mode=author
fi
case $mode in
author)
backup='incompatible author'
req_attention=true
backup_msg=${r_chars_attention}${backup}
backup_msg=$(TextBrightOrange "$backup_msg")
;;
missing)
backup=missing
req_alert=true
backup_msg=${r_chars_alert}${backup}
backup_msg=$(TextBrightRedBlink "$backup_msg")
;;
mute)
active_test=N/A
autoupdate=N/A
backup=N/A
clean=N/A
compatible=N/A
restart_to_update=N/A
sherpa_compatible=N/A
tier=N/A
active_test_msg+=$active_test
autoupdate_msg+=$autoupdate
backup_msg+=$backup
clean_msg+=$clean
compatible_msg+=$compatible
restart_to_update_msg+=$restart_to_update
sherpa_compatible_msg+=$sherpa_compatible
tier_msg+=$tier
active_test_msg=$(TextDarkGrey "$active_test_msg")
autoupdate_msg=$(TextDarkGrey "$autoupdate_msg")
backup_msg=$(TextDarkGrey "$backup_msg")
clean_msg=$(TextDarkGrey "$clean_msg")
compatible_msg=$(TextDarkGrey "$compatible_msg")
restart_to_update_msg=$(TextDarkGrey "$restart_to_update_msg")
sherpa_compatible_msg=$(TextDarkGrey "$sherpa_compatible_msg")
tier_msg=$(TextDarkGrey "$tier_msg")
;;
normal)
[[ $(QpkgGetDatabaseActiveTest) = builtin ]] && active_test=true
if QpkgIsInstalled && QpkgIsDatabaseCanRestartToUpdate;then
if QpkgIsInstalledAutoUpdate;then
autoupdate=true
fi
elif [[ $qpkg_name = sherpa ]];then
autoupdate=true
else
autoupdate=N/A
/bin/touch "$r_report_flags_path"/na
fi
QpkgIsDatabaseCanBackup && backup=true
QpkgIsDatabaseCanClean && clean=true
QpkgIsDatabaseArchOK && compatible=true
if QpkgIsDatabaseCanRestartToUpdate;then
restart_to_update=true
elif [[ $qpkg_name = sherpa ]];then
restart_to_update=true
fi
QpkgIsDatabaseSherpaCompatible && sherpa_compatible=true
QpkgIsDatabaseIndependent && tier=true
active_test_msg+=$active_test
autoupdate_msg+=$autoupdate
backup_msg+=$backup
clean_msg+=$clean
compatible_msg+=$compatible
restart_to_update_msg+=$restart_to_update
sherpa_compatible_msg+=$sherpa_compatible
tier_msg+=$tier
if [[ $active_test = true ]];then
active_test_msg=$(TextBrightGreen "$active_test_msg")
else
active_test_msg=$(TextBrightOrange "$active_test_msg")
fi
if [[ $autoupdate = true ]];then
autoupdate_msg=$(TextBrightGreen "$autoupdate_msg")
elif [[ $autoupdate = false ]];then
autoupdate_msg=$(TextBrightOrange "$autoupdate_msg")
fi
[[ $backup = true ]] && backup_msg=$(TextBrightGreen "$backup_msg")
[[ $clean = true ]] && clean_msg=$(TextBrightGreen "$clean_msg")
if [[ $compatible = true ]];then
compatible_msg=$(TextBrightGreen "$compatible_msg")
else
compatible_msg=$(TextBrightRed "$compatible_msg")
fi
[[ $restart_to_update = true ]] && restart_to_update_msg=$(TextBrightGreen "$restart_to_update_msg")
if [[ $sherpa_compatible = true ]];then
sherpa_compatible_msg=$(TextBrightGreen "$sherpa_compatible_msg")
else
sherpa_compatible_msg=$(TextBrightOrange "$sherpa_compatible_msg")
fi
esac
if [[ $req_alert = true ]];then
/bin/touch "$r_report_flags_path"/req-alert
name_msg=${r_chars_blank}$(TextBrightRed "$qpkg_name")
elif [[ $req_attention = true ]];then
/bin/touch "$r_report_flags_path"/req-attention
name_msg=${r_chars_blank}$(TextBrightOrange "$qpkg_name")
elif [[ $mode = mute ]];then
name_msg+=$(TextDarkGrey "$qpkg_name")
else
name_msg+=$qpkg_name
fi
if OsIsSupportAutowidthTableColumns;then
echo "$name_msg|$backup_msg|$clean_msg|$restart_to_update_msg|$autoupdate_msg|$active_test_msg|$tier_msg|$compatible_msg|$sherpa_compatible_msg"
else
printf "%-$((r_report_qpkg_name_column_width+$(LenANSIDiff "$name_msg")))s" "$name_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_supports_backup_column_width+$(LenANSIDiff "$backup_msg")))s" "$backup_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_supports_clean_column_width+$(LenANSIDiff "$clean_msg")))s" "$clean_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_supports_start_to_update_column_width+$(LenANSIDiff "$restart_to_update_msg")))s" "$restart_to_update_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_auto_update_column_width+$(LenANSIDiff "$autoupdate_msg")))s" "$autoupdate_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_active_test_builtin_column_width+$(LenANSIDiff "$active_test_msg")))s" "$active_test_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_tier_column_width+$(LenANSIDiff "$tier_msg")))s" "$tier_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_qpkg_is_compatible_column_width+$(LenANSIDiff "$compatible_msg")))s" "$compatible_msg"
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_lazy_column_width+$(LenANSIDiff "$sherpa_compatible_msg")))s" "$sherpa_compatible_msg"
printf '\n'
fi
}
DisplayAsBacksReportTitleLine()
{
local a=''
printf '\n'
a="${r_chars_bullet}Backup file:"
printf "%-$((r_report_file_name_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf "%$((r_report_column_spacing))s"
a="${r_chars_bullet}Size in bytes:"
printf "%-$((r_report_file_bytes_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf "%$((r_report_column_spacing))s"
a="${r_chars_bullet}Backup date:"
printf "%-$((r_report_file_change_date_column_width+2+$(LenANSIDiff "$a")))s" "$a"
printf '\n'
}
DisplayAsBacksReportItemLine()
{
local epoch_time=${1:-0}
local epoch_time_msg=$r_chars_normal
local file_bytes=${3:-0}
local file_bytes_msg=$r_chars_blank
local file_name=${2:-}
local file_name_msg=$r_chars_blank
local local_highlight_backups_older_than=${4:-'1 week ago'}
local mode=''
if [[ ${epoch_time%.*} -lt $(/bin/date --date="$local_highlight_backups_older_than" +%s) ]];then
mode=highlight
else
mode=normal
fi
file_bytes=$(FormatAsThous "$file_bytes")
case $mode in
normal)
epoch_time_msg+=$(ConvertSecondsToFullDate "$epoch_time")
file_bytes_msg+=$file_bytes
file_name_msg+=$file_name
/bin/touch "$r_report_flags_path"/backup-file-ok
;;
highlight)
epoch_time_msg=$(TextBrightRed "${r_chars_alert}$(ConvertSecondsToFullDate "$epoch_time")")
file_bytes_msg+=$(TextBrightRed "$file_bytes")
file_name_msg+=$(TextBrightRed "$file_name")
/bin/touch "$r_report_flags_path"/backup-file-old
esac
printf "%-$((r_report_file_name_column_width+$(LenANSIDiff "$file_name_msg")))s" "$file_name_msg"
printf "%$((r_report_column_spacing))s"
printf "%$((r_report_file_bytes_column_width+$(LenANSIDiff "$file_bytes_msg")))s" "$file_bytes_msg "
printf "%$((r_report_column_spacing))s"
printf "%-$((r_report_file_change_date_column_width+$(LenANSIDiff "$epoch_time_msg")))s" "$epoch_time_msg"
printf '\n'
}
DisplayAsHelpTitle()
{
printf "\n${r_chars_bullet}%s\n" "$(Capitalise "${1:-}" | tr -s ' ')"
}
DisplayAsHelpTitleHighlighted()
{
printf "\n$(TextBrightOrange "${r_chars_bullet}%s\n")" "$(Capitalise "${1:-}")"
}
DisplayAsIndentActionResultDurationReason()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
local action=''
local duration=''
case $1 in
disableau)
action='disable auto-update'
;;
enableau)
action='enable auto-update'
;;
*)
action=$1
esac
[[ -n ${3:-} ]] && duration=$(ConvertMillisecondsToDuration "$3")
printf "%${r_report_action_result_indent}s" ''
if [[ -z ${4:-} ]];then
printf "%s %s%s" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")"
else
printf "%s %s%s (%s)" "$(Lowercase "$action")" "$2" "$([[ -n $duration ]] && printf ' in %s' "$duration")" "$4"
fi
printf '\n'
}
EraseThisLine()
{
[[ ${useropt_verbose:=false} = false ]] && printf '\033[2K\r'
} >&2
Display()
{
if [[ -z ${1:-} ]];then
printf '\n'
else
printf '%s\n' "$1"
fi
}
DisplayWait()
{
printf '%s' "${1:-}"
}
ShowHelpActions()
{
DisableDebugToArchiveAndFile
DisplayProcReport actions
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsAction) usage examples:"
DisplayAsProjSynIndentExam 'activate these packages (this will upgrade internal applications where-supported)' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "start $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'backup these application configurations to the backup location' "backup $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'check all application dependencies are installed' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clean local repository files from these packages (your config is safe, application files will be downloaded again)' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these packages' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "stop $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'generate QPKG dependencies report' dependencies
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'disable these packages. This will prevent them being activated' "disable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'disable auto-updating the application on package activation (where-supported)' "disable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable these packages. Packages must be enabled before they can be activated' "enable $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'enable auto-updating the application on package activation (where-supported)' "enable-auto-update $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'install these packages' "install $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "add $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'reactivate these packages (this will upgrade internal applications where-supported)' "reactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "restart $(ShowAsPackages)"
DisplayAsProjSynIndentExam "reassign packages to $(ShowAsTitleName). Detach packages previously installed via an online repository from further management by that repository" "reassign $(ShowAsPackages)"
DisplayAsProjSynIndentExam "rebuild these packages ('install' packages, then 'restore' configuration backups)" "rebuild $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'reinstall these packages' "reinstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'restore these application configurations from the backup location' "restore $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'digitally "sign" these QPKGs' "sign $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'uninstall these packages' "uninstall $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "remove $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "rm $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'upgrade these packages (this will upgrade internal applications where-supported)' "upgrade $(ShowAsPackages)"
DisplayAsProjSynExam "$(ShowAsAction)s to affect all packages can be seen with" 'help all-actions'
DisplayAsProjSynIndentExam '' 'help actions-all'
DisplayAsProjSynExam "multiple $(ShowAsAction)s are supported like this" "$(ShowAsAction) $(ShowAsPackages) $(ShowAsAction) $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' 'install sabnzbd sickgear reactivate transmission uninstall lazy nzbget upgrade nzbtomedia'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpActionsAll()
{
DisableDebugToArchiveAndFile
DisplayProcReport 'all actions'
{
ShowHelpBasic
DisplayAsHelpTitle "the 'all' group applies to all QPKGs. If $(ShowAsAction) is 'install all' then all available QPKGs will be installed."
DisplayAsHelpTitle "$(ShowAsAction) $(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'activate all QPKGs (this will upgrade internal applications where-supported)' 'activate all'
DisplayAsProjSynIndentExam '' 'start all'
DisplayAsProjSynIndentExam 'backup all application configurations to the backup location' 'backup all'
DisplayAsProjSynIndentExam 'clean local repository files from all QPKGs (your configs are safe, application files will be downloaded again)' 'clean all'
DisplayAsProjSynIndentExam 'deactivate all QPKGs' 'deactivate all'
DisplayAsProjSynIndentExam '' 'stop all'
DisplayAsProjSynIndentExam 'disable all QPKGs. This will prevent them being activated' 'disable all'
DisplayAsProjSynIndentExam 'disable auto-updating all applications on QPKG activation (where-supported)' 'disable-auto-update all'
DisplayAsProjSynIndentExam 'enable all QPKGs. QPKGs must be enabled before they can be started' 'enable all'
DisplayAsProjSynIndentExam 'enable auto-updating all applications on QPKG activation (where-supported)' 'enable-auto-update all'
DisplayAsProjSynIndentExam 'install everything!' 'install all'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (this will upgrade internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam '' 'restart all'
DisplayAsProjSynIndentExam "reassign all QPKGs to $(ShowAsTitleName). Detach QPKGs previously installed via an online repository from further management by that repository" 'reassign all'
DisplayAsProjSynIndentExam "rebuild all QPKGs where backup files exist ('install' QPKGs and 'restore' backups)" 'rebuild all'
DisplayAsProjSynIndentExam 'reinstall all QPKGs' 'reinstall all'
DisplayAsProjSynIndentExam 'restore all application configurations from the backup location' 'restore all'
DisplayAsProjSynIndentExam 'digitally "sign" all QPKGs' 'sign all'
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'status all'
DisplayAsProjSynIndentExam 'uninstall all QPKGs' 'uninstall all'
DisplayAsProjSynIndentExam 'upgrade all QPKGs (and internal applications where-supported)' 'upgrade all'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpBackupLocation()
{
DisplayAsSynExam 'the backup location can be accessed by running' "cd $r_qpkg_bu_path"
return 0
}
ShowHelpBasic()
{
DisplayAsHelpTitle "usage: sherpa $(ShowAsAction) $(ShowAsPackages) $(ShowAsPackageGroup) $(ShowAsOptions)"
return 0
}
ShowHelpBasicExamples()
{
DisplayAsProjSynIndentExam "to see available $(ShowAsAction)s" 'help actions'
DisplayAsProjSynIndentExam "to see available $(ShowAsPackages)" 'show packages'
DisplayAsProjSynIndentExam '' p
DisplayAsProjSynIndentExam "to see available $(ShowAsPackageGroup)s" 'help groups'
DisplayAsProjSynIndentExam "or, for more $(ShowAsOptions)" 'help options'
DisplayAsHelpTitle "more in the wiki: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/wiki')"
return 0
}
ShowHelpGroups()
{
DisableDebugToArchiveAndFile
DisplayProcReport groups
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsPackageGroup) usage examples:"
DisplayAsProjSynIndentExam 'select every package' "$(ShowAsAction) all"
DisplayAsProjSynIndentExam 'select only independent QPKGs (these do not depend on other QPKGs)' "$(ShowAsAction) independent"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) independents"
DisplayAsProjSynIndentExam 'select only dependent QPKGs (these require another QPKG to be installed and active)' "$(ShowAsAction) dependent"
DisplayAsProjSynIndentExam 'select only active QPKGs' "$(ShowAsAction) active"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) started"
DisplayAsProjSynIndentExam 'select only inactive QPKGs' "$(ShowAsAction) inactive"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) stopped"
DisplayAsProjSynIndentExam 'select only installed QPKGs' "$(ShowAsAction) installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are not installed' "$(ShowAsAction) not-installed"
DisplayAsProjSynIndentExam 'select only QPKGs that are backed-up' "$(ShowAsAction) backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are not backed-up' "$(ShowAsAction) not-backedup"
DisplayAsProjSynIndentExam 'select only QPKGs that are upgradable' "$(ShowAsAction) upgradable"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) new"
DisplayAsProjSynIndentExam 'select only missing QPKGs (these are partly installed and broken)' "$(ShowAsAction) missing"
DisplayAsProjSynExam 'multiple groups are supported like this' "$(ShowAsAction) $(ShowAsPackageGroup) $(ShowAsPackageGroup)"
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpIssue()
{
DisplayAsHelpTitle "please consider creating a new issue for this on GitHub: $(ShowAsURL 'https://github.com/OneCDOnly/sherpa/issues')"
DisplayAsHelpTitle "alternatively, post on the QNAP NAS Community Forum: $(ShowAsURL 'https://forum.qnap.com/viewtopic.php?f=320&t=132373')"
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange 'log for analysis!')"
Display
return 0
}
ShowHelpLists()
{
DisableDebugToArchiveAndFile
DisplayProcReport lists
{
ShowHelpBasic
DisplayAsHelpTitle "'list' usage examples:"
DisplayAsProjSynIndentExam 'list all available QPKGs' 'list all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam '' installable
DisplayAsProjSynIndentExam 'list only installed QPKGs' 'list installed'
DisplayAsProjSynIndentExam '' installed
DisplayAsProjSynIndentExam 'list only QPKGs that are not installed' 'list not-installed'
DisplayAsProjSynIndentExam '' not-installed
DisplayAsProjSynIndentExam 'list only upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' upgradable
DisplayAsProjSynIndentExam "list $(ShowAsTitleName) object version numbers" 'list versions'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpShow()
{
DisableDebugToArchiveAndFile
DisplayProcReport show
{
ShowHelpBasic
DisplayAsHelpTitle "'show' usage examples:"
DisplayAsProjSynIndentExam 'show QPKG abbreviations' 'show abbreviations'
DisplayAsProjSynIndentExam '' 'show abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'show application backup files' 'show backups'
DisplayAsProjSynIndentExam '' b
DisplayAsProjSynIndentExam 'show QPKG dependency report' 'show dependencies'
DisplayAsProjSynIndentExam '' 'show deps'
DisplayAsProjSynIndentExam '' d
DisplayAsProjSynIndentExam 'show QPKG repository assignments report' 'show repositories'
DisplayAsProjSynIndentExam '' 'show repos'
DisplayAsProjSynIndentExam '' r
DisplayAsProjSynIndentExam 'show last session action results' 'show results'
DisplayAsProjSynIndentExam '' results
DisplayAsProjSynIndentExam 'find the live status of each application in all QPKGs' 'show status'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpOptions()
{
DisableDebugToArchiveAndFile
DisplayProcReport options
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsOptions) usage examples:"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpPackages()
{
DisableDebugToArchiveAndFile
DisplayProcReport packages
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for QPKGs will go here:'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpProblems()
{
DisableDebugToArchiveAndFile
DisplayProcReport problems
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for dealing with problems:'
DisplayAsProjSynIndentExam 'activate these QPKGs' "activate $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'ensure all dependencies exist for installed QPKGs' check
DisplayAsProjSynIndentExam '' c
DisplayAsProjSynIndentExam 'clear local repository files from these QPKGs' "clean $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'deactivate these QPKGs' "deactivate $(ShowAsPackages)"
DisplayAsProjSynIndentExam "increase the default 'qpkg_service' timeouts from 3 minutes to 30 minutes" 'install increasetimeouts'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam "view the entire $(ShowAsTitleName) session log" log
DisplayAsProjSynIndentExam "upload the most-recent session in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste last'
DisplayAsProjSynIndentExam "upload the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to the $(ShowAsURL 'https://termbin.com') public pastebin. A URL will be generated afterward" 'paste log'
DisplayAsProjSynIndentExam 'reactivate installed QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam "remove all cached $(ShowAsTitleName) items and logs" reset
DisplayAsProjSynIndentExam 'find the live status of each application in these QPKGs' "status $(ShowAsPackages)"
DisplayAsProjSynIndentExam '' "s $(ShowAsPackages)"
DisplayAsProjSynIndentExam 'show debugging information, and record it to file' "$(ShowAsAction) $(ShowAsPackages) debug"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) verbose"
DisplayAsProjSynIndentExam '' "$(ShowAsAction) $(ShowAsPackages) v"
DisplayAsHelpTitleHighlighted "if you need help, please include a copy of your $(ShowAsTitleName) $(TextBrightOrange "log for analysis!")"
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpUpgrades()
{
DisableDebugToArchiveAndFile
DisplayProcReport upgrades
{
ShowHelpBasic
DisplayAsHelpTitle 'usage examples for upgrading your QPKGs:'
DisplayAsProjSynIndentExam 'upgrade only the upgradable QPKGs' 'upgrade upgradable'
DisplayAsProjSynIndentExam '' 'upgrade new'
DisplayAsProjSynIndentExam 'show a list of upgradable QPKGs' 'list upgradable'
DisplayAsProjSynIndentExam '' 'list new'
DisplayAsProjSynIndentExam 'find the live application status of upgradable QPKGs' 'status upgradable'
DisplayAsProjSynIndentExam '' 's upgradable'
DisplayAsProjSynIndentExam '' 's new'
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ShowHelpTips()
{
DisableDebugToArchiveAndFile
DisplayProcReport tips
{
ShowHelpBasic
DisplayAsHelpTitle 'helpful tips and shortcuts:'
DisplayAsProjSynIndentExam "install all available $(ShowAsTitleName) QPKGs" 'install all'
DisplayAsProjSynIndentExam 'package abbreviations and aliases also work. To see these' 'help abs'
DisplayAsProjSynIndentExam '' a
DisplayAsProjSynIndentExam 'reactivate all QPKGs (upgrades internal applications where-supported)' 'reactivate all'
DisplayAsProjSynIndentExam 'list only QPKGs that can be installed' 'list installable'
DisplayAsProjSynIndentExam "view only the most recent $(ShowAsTitleName) session log" last
DisplayAsProjSynIndentExam '' l
DisplayAsProjSynIndentExam 'activate all inactive QPKGs' 'activate inactive'
DisplayAsProjSynIndentExam 'upgrade the internal applications only' "reactivate $(ShowAsPackages)"
ShowHelpBackupLocation
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
return 0
}
ViewLogLast()
{
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
EraseThisLine
if [[ -e $r_session_last_pathfile ]];then
DisplayFileInViewport "$r_session_last_pathfile" linenumbers
Display
else
ShowAsError 'no last session log to display'
fi
return 0
}
ViewLogTail()
{
DisableDebugToArchiveAndFile
ExtractTailFromLog
EraseThisLine
if [[ -e $r_session_tail_pathfile ]];then
DisplayFileInViewport "$r_session_tail_pathfile" linenumbers
Display
else
ShowAsError 'no session log tail to display'
fi
return 0
}
DisplayFileInViewport()
{
local filename=${1:-}
local jumptoend=false
local options=''
local prompt=' use arrow-keys to scroll up-down & left-right, press Q to quit '
local showlinenumbers=false
local wraplines=false
if [[ ! -e $filename ]];then
echo "filename $(ShowAsFileName "$filename") not found"
return 1
fi
case 'linenumbers' in
${2:-}|${3:-}|${4:-})
showlinenumbers=true
esac
case 'jumptoend' in
${2:-}|${3:-}|${4:-})
jumptoend=true
esac
case 'wrap' in
${2:-}|${3:-}|${4:-})
wraplines=true
esac
if [[ $useropt_verbose = true ]];then
if [[ -e $CAT_CMD ]];then
$CAT_CMD "$filename"
return
else
echo "$(<$1)"
return
fi
fi
if [[ $($WC_CMD -l < "$filename") -ge $r_sess_rows || $($WC_CMD -L < "$filename") -ge $r_sess_columns ]];then
if [[ -e $GNU_LESS_CMD ]];then
options=' --quit-on-intr --tilde --mouse --RAW-CONTROL-CHARS --shift=4 --redraw-on-quit --quit-if-one-screen'
[[ $wraplines = false ]] && options+=' --chop-long-lines'
[[ $showlinenumbers = true ]] && options+=' --LINE-NUMBERS'
[[ $jumptoend = true ]] && options+=' +G'
LESSSECURE=1 ${GNU_LESS_CMD}${options} --prompt "$prompt" "$filename"
return
fi
if [[ -e $LESS_CMD ]];then
options=' -~'
[[ $wraplines = false ]] && options+='S'
[[ $showlinenumbers = true ]] && options+='N'
${LESS_CMD}${options} "$filename"
return
fi
fi
if [[ -e $CAT_CMD ]];then
[[ $showlinenumbers = true ]] && options+=' --number'
${CAT_CMD}${options} "$filename"
return
elif [[ -e $MORE_CMD ]];then
$MORE_CMD "$filename"
return
fi
echo "$(<$1)"
}
PasteLogLast()
{
local link=''
DisableDebugToArchiveAndFile
ExtractPrevSessFromTail
if [[ -e $r_session_last_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent session in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$r_session_last_pathfile" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no last session log found'
fi
return 0
}
PasteLogTail()
{
local link=''
DisableDebugToArchiveAndFile
ExtractTailFromLog
if [[ -e $r_session_tail_pathfile ]];then
if Quiz "Press 'Y' to post the most-recent $(FormatAsThous "$r_log_tail_lines") lines in your $(ShowAsTitleName) log to a public pastebin, or any other key to abort";then
ShowAsProc "upload $(ShowAsTitleName) log"
link=$($CAT_CMD --number "$r_session_tail_pathfile" | (exec 3<>/dev/tcp/termbin.com/9999;$CAT_CMD >&3; $CAT_CMD <&3; exec 3<&-))
if [[ $? -eq 0 ]];then
ShowAsDone "your $(ShowAsTitleName) log is now online at $(ShowAsURL "$link") and will be deleted in 1 month"
else
ShowAsFail "a link could not be generated. Most likely a problem occurred when talking with $(ShowAsURL 'https://termbin.com')"
fi
else
DebugInfoMinSepr
DebugScript 'user abort'
show_action_results_zero=false
return 1
fi
else
ShowAsError 'no session log tail found'
fi
return 0
}
GetLogSessStartLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*started:' "$r_session_tail_pathfile" | $TAIL_CMD -n${1:-1} | head -n1 | cut -d':' -f1)-1))
[[ $linenum -lt 1 ]] && linenum=1
printf '%s' "$linenum"
}
GetLogSessFinishLine()
{
local -i linenum=$(($($GREP_CMD -n 'SCRIPT:.*finished:' "$r_session_tail_pathfile" | $TAIL_CMD -n${1:-1} | cut -d':' -f1)+2))
[[ $linenum -eq 2 ]] && linenum=3
printf '%s' "$linenum"
}
ArchiveActiveSessLog()
{
[[ -n ${sess_active_pathfile:-} && -e $sess_active_pathfile ]] && $CAT_CMD "$sess_active_pathfile" >> "$r_session_archive_pathfile"
}
ArchivePriorSessLogs()
{
local f=''
for f in "$r_this_package_path"/session.*.active.log;do
if [[ -f $f && $f != "$sess_active_pathfile" ]];then
$CAT_CMD "$f" >> "$r_session_archive_pathfile"
rm -f "$f" 2> /dev/null
fi
done
}
ResetActiveSessLog()
{
rm -f "$sess_active_pathfile" 2> /dev/null
}
ExtractPrevSessFromTail()
{
local -i end_line=0
local -i old_session=1
local -i old_session_limit=12
local -i start_line=0
ExtractTailFromLog
if [[ -e $r_session_tail_pathfile ]];then
end_line=$(GetLogSessFinishLine "$old_session")
start_line=$((end_line+1))
while [[ $start_line -ge $end_line ]];do
start_line=$(GetLogSessStartLine "$old_session")
((old_session++))
[[ $old_session -gt $old_session_limit ]] && break
done
$SED_CMD "$start_line,$end_line!d" "$r_session_tail_pathfile" > "$r_session_last_pathfile"
else
rm -f "$r_session_last_pathfile" 2> /dev/null
fi
return 0
}
ExtractTailFromLog()
{
if [[ -e $r_session_archive_pathfile ]];then
$TAIL_CMD -n${r_log_tail_lines} "$r_session_archive_pathfile" > "$r_session_tail_pathfile"
else
rm -f "$r_session_tail_pathfile" 2> /dev/null
fi
return 0
}
InitForkCounts()
{
MakePath "$r_action_forks_count" 'action forks'
proc_counts_path=$($MKTEMP_CMD -d "$r_action_forks_count"/"${FUNCNAME[1]}"_XXXXXX)
[[ -n ${proc_counts_path:?undefined proc counts path} ]] || return
EraseForkCountPaths
proc_fork_count_path=$proc_counts_path/fork.count
proc_ok_count_path=$proc_counts_path/ok.count
proc_skip_count_path=$proc_counts_path/skip.count
proc_skip_ok_count_path=$proc_counts_path/skip.ok.count
proc_skip_error_count_path=$proc_counts_path/skip.error.count
proc_skip_abort_count_path=$proc_counts_path/skip.abort.count
proc_fail_count_path=$proc_counts_path/fail.count
mkdir -p "$proc_fork_count_path"
mkdir -p "$proc_ok_count_path"
mkdir -p "$proc_skip_count_path"
mkdir -p "$proc_skip_ok_count_path"
mkdir -p "$proc_skip_error_count_path"
mkdir -p "$proc_skip_abort_count_path"
mkdir -p "$proc_fail_count_path"
InitProgress
}
IncForkProgressIndex()
{
local a
((progress_index++))
printf -v a '%02d' "$progress_index"
proc_fork_pathfile=$proc_fork_count_path/$a
proc_ok_pathfile=$proc_ok_count_path/$a
proc_skip_pathfile=$proc_skip_count_path/$a
proc_skip_ok_pathfile=$proc_skip_ok_count_path/$a
proc_skip_error_pathfile=$proc_skip_error_count_path/$a
proc_skip_abort_pathfile=$proc_skip_abort_count_path/$a
proc_fail_pathfile=$proc_fail_count_path/$a
}
RefreshForkCounts()
{
fork_count=$(ls -A -1 "$proc_fork_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
ok_count=$(ls -A -1 "$proc_ok_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_count=$(ls -A -1 "$proc_skip_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_ok_count=$(ls -A -1 "$proc_skip_ok_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_error_count=$(ls -A -1 "$proc_skip_error_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
skip_abort_count=$(ls -A -1 "$proc_skip_abort_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
fail_count=$(ls -A -1 "$proc_fail_count_path" 2> /dev/null | $WC_CMD -l | $SED_CMD 's|^ *||')
} &> /dev/null
EraseForkCountPaths()
{
ClearPath /var/run/sherpa/actions/forks "$proc_counts_path"
[[ -e $r_action_abort_pathfile ]] && rm -f "$r_action_abort_pathfile"
} &> /dev/null
InitProgress()
{
progress_index=0
prev_clean_msg=''
RefreshForkCounts
}
UpdateForkProgress()
{
local a=''
local b=''
RefreshForkCounts
[[ $useropt_verbose = false && ! -e $r_display_inhibit_pathfile ]] || return
a=$((skip_count+skip_ok_count+skip_error_count+skip_abort_count))
b=$(PercFrac "$ok_count" "$a" "$fail_count" "$total_count")
if [[ $ok_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightGreen "$ok_count") OK"
fi
if [[ $a -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightOrange "$a") skipped"
fi
if [[ $fail_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightRed "$fail_count") failed"
fi
if [[ $fork_count -gt 0 ]];then
[[ -n $b ]] && b+=', '
b+="$(TextBrightYellow "$fork_count") in-progress"
fi
[[ -n $b && ! -e $r_display_inhibit_pathfile ]] && ShowAsProc "${fork_progress_prefix:-}" "$b"
return 0
} >&2
ShowQPKGsMissing()
{
! QPKGs.AClist.ISmissing.IsSet || return 0
! QPKGs.ACreinstall.ISmissing.IsSet || return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISmissing:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISmissing:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightRed "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightRed "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b=' is'
c='it'
else
b='s are'
c='them'
fi
ShowAsNote "the $a QPKG${b} missing or broken. Please reinstall $c"
return 1
}
ShowQPKGsNewVers()
{
! QPKGs.AClist.ISupgradable.IsSet || return 0
! QPKGs.ACupgrade.ISupgradable.IsSet || return 0
local a=''
local b=''
local c=''
local -i i=0
local name_limit=2
local -a packages=()
if [[ $(QPKGs-ISupgradable:Count) -eq 0 ]];then
return 0
else
packages+=($(QPKGs-ISupgradable:Array))
fi
for ((i=0;i<=((${#packages[@]}-1)); i++)); do
a+=$(TextBrightOrange "${packages[$i]}")
if [[ $((i+1)) -ge $name_limit && $((${#packages[@]}-name_limit)) -gt 0 ]];then
a+=" & $(TextBrightOrange "$((${#packages[@]}-name_limit))") other$(Pluralise "$((${#packages[@]}-name_limit))")"
break
elif [[ $((i+2)) -lt ${#packages[@]} ]];then
a+=', '
elif [[ $((i+2)) -eq ${#packages[@]} ]];then
a+=' & '
fi
done
if [[ ${#packages[@]} -eq 1 ]];then
b='a '
c='version is'
else
c="version$(Pluralise "${#packages[@]}") are"
fi
ShowAsNote "${b}new QPKG $c available for $a"
return 1
}
CheckQPKGsConflicts()
{
[[ $run_package_actions = false ]] || return 0
local a=''
if [[ -n ${r_base_qpkg_conflicts_with:-} ]];then
for a in "${r_base_qpkg_conflicts_with[@]}";do
if QpkgIsInstalledEnabled "$a";then
ShowAsError "the '$a' QPKG is enabled. $(ShowAsTitleName) is incompatible with this package. Please consider stopping this QPKG in your App Center"
run_package_actions=false
return 1
fi
done
fi
return 0
}
CheckQPKGsWarnings()
{
local a=''
if [[ -n ${r_base_qpkg_warnings:-} ]];then
for a in "${r_base_qpkg_warnings[@]}";do
if QpkgIsInstalledEnabled "$a";then
ShowAsWarn "the '$a' QPKG is enabled. This may cause problems with $(ShowAsTitleName) applications. Please consider stopping this QPKG in your App Center"
return 1
fi
done
fi
return 0
}
ListQPKGsActions()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
local b=''
local border_shown=false
for a in "${r_qpkg_actions[@]}";do
for b in ok er sk so se sa;do
if QPKGs-AC${a}-${b}.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
case $b in
ok|sk|so)
DebugQpkg info "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
se|sa)
DebugQpkg warning "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
;;
er)
DebugQpkg error "AC${a}-${b}" "($(QPKGs-AC${a}-${b}:Count)) $(QPKGs-AC${a}-${b}:ListCSV) "
esac
fi
done
done
[[ $border_shown = true ]] && DebugInfoMinSepr
FuncExit
}
ListIPKsActions()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
local border_shown=false
for a in "${r_ipk_actions[@]}";do
if IPKs-AC${a}-ok.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk info "AC${a}-ok" "($(IPKs-AC${a}-ok:Count)) $(IPKs-AC${a}-ok:ListCSV) "
fi
if IPKs-AC${a}-er.IsAny;then
if [[ $border_shown = false ]];then
DebugInfoMinSepr
border_shown=true
fi
DebugIpk error "AC${a}-er" "($(IPKs-AC${a}-er:Count)) $(IPKs-AC${a}-er:ListCSV) "
fi
done
[[ $border_shown = true ]] && DebugInfoMinSepr
FuncExit
}
ListPIPsActions()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
DebugInfoMinSepr
for a in "${r_pip_actions[@]}";do
PIPs-AC${a}-ok.IsAny && DebugPipInfo "AC${a}-ok" "($(PIPs-AC${a}-ok:Count)) $(PIPs-AC${a}-ok:ListCSV) "
PIPs-AC${a}-er.IsAny && DebugPipError "AC${a}-er" "($(PIPs-AC${a}-er:Count)) $(PIPs-AC${a}-er:ListCSV) "
done
DebugInfoMinSepr
FuncExit
}
ListQPKGsStates()
{
[[ $useropt_debug = true ]] || return
FuncInit
local a=''
BuildQPKGsStates
DebugInfoMinSepr
for a in "${r_qpkg_is_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]] && continue
if [[ $a = unknown ]];then
QPKGs-IS${a}.IsAny && DebugQpkg warning "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
else
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
fi
done
for a in "${r_qpkg_isnt_states[@]}" "${r_qpkg_service_results[@]}";do
[[ $a = installed ]] && continue
if [[ $a = ok ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg error "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
elif [[ $a = backedup ]];then
QPKGs-ISNT${a}.IsAny && DebugQpkg warning "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
else
QPKGs-ISNT${a}.IsAny && DebugQpkg info "ISNT${a}" "($(QPKGs-ISNT${a}:Count)) $(QPKGs-ISNT${a}:ListCSV) "
fi
done
for a in "${r_qpkg_states_transient[@]}";do
QPKGs-IS${a}.IsAny && DebugQpkg info "IS${a}" "($(QPKGs-IS${a}:Count)) $(QPKGs-IS${a}:ListCSV) "
done
DebugInfoMinSepr
FuncExit
}
BuildQPKGsTiers()
{
FuncInit
if [[ ${qpkgs_tiers_built:=false} = true ]];then
DebugAsDone "don't build tiers: they're already built"
FuncExit;return
fi
local previous=''
if [[ ! -e $r_dependent_qpkgs_list_pathfile || ! -e $r_independent_qpkgs_list_pathfile ]];then
ShowAsProc tiers
rm -f "$r_dependent_qpkgs_list_pathfile" "$r_independent_qpkgs_list_pathfile" 2> /dev/null
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QpkgSetIndex
if QpkgIsDatabaseDependent;then
echo "$qpkg_name" >> "$r_dependent_qpkgs_list_pathfile"
else
echo "$qpkg_name" >> "$r_independent_qpkgs_list_pathfile"
fi
done
qpkgs_tiers_built=true
fi
[[ -e $r_dependent_qpkgs_list_pathfile ]] && QPKGs-GRdependent:Add "$(<$r_dependent_qpkgs_list_pathfile)"
[[ -e $r_independent_qpkgs_list_pathfile ]] && QPKGs-GRindependent:Add "$(<$r_independent_qpkgs_list_pathfile)"
FuncExit
}
InitQPKGsTiers()
{
rm -f "$r_dependent_qpkgs_list_pathfile" "$r_independent_qpkgs_list_pathfile" 2> /dev/null
qpkgs_tiers_built=false
}
BuildQPKGsStates()
{
FuncInit
local a=''
local b=''
if [[ ${qpkgs_states_built:=false} = true ]];then
DebugAsDone "don't build states: they're already built"
FuncExit;return
fi
LoadPackages
InitQPKGsStates
OsIsStarting && ShowAsWarn "$(OsGetQnapOS) is starting all enabled QPKGs $r_chars_ellipsis check again in a few minutes"
OsIsStopping && ShowAsWarn "$(OsGetQnapOS) is shutting-down and all QPKGs are stopping"
if OsIsLoadAverageInsane;then
ShowAsWarn 'the NAS has an exceptionally-high system-load, recommend aborting and trying again later'
elif OsIsLoadAverageHigh;then
ShowAsWarn 'the NAS has an unusually-high system-load, so this may take a while'
elif OsIsLoadAverageElevated;then
ShowAsNote 'the NAS has an elevated system-load, so this may take a little longer than usual'
fi
ShowAsProc 'QPKG states'
MakePath "$r_qpkg_states_path" states || return
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstallable;then
echo installable
else
echo notinstallable
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstalledMissing;then
echo missing
else
echo notmissing
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsUpgradable;then
echo upgradable
else
echo notupgradable
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstalled;then
if QpkgIsInstalledEnabled;then
echo enabled
else
echo notenabled
fi
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsInstalled;then
echo installed
elif QpkgIsNtReallyInstalled;then
echo notinstalled
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgSetIndex
if QpkgIsBackupExist;then
echo backedup
else
echo notbackedup
fi >> "$r_qpkg_states_path/$qpkg_name"
done &
wait 2> /dev/null
for qpkg_name in $(QPKGs-GRall:Array);do
a=/var/log/$qpkg_name.action
b=/var/log/$qpkg_name.result
if [[ -e $a && -e $b ]];then
case $(<$b) in
in-progress)
case $(<$a) in
start)
QPKGs-ISstarting:Add "$qpkg_name"
;;
restart)
QPKGs-ISrestarting:Add "$qpkg_name"
;;
stop)
QPKGs-ISstopping:Add "$qpkg_name"
esac
;;
ok)
QPKGs-ISok:Add "$qpkg_name"
;;
failed)
QPKGs-ISNTok:Add "$qpkg_name"
esac
fi
a=$r_qpkg_states_path/$qpkg_name
[[ -e $a ]] || continue
for b in $(<$a);do
case $b in
backedup)
QPKGs-ISbackedup:Add "$qpkg_name"
;;
notbackedup)
QPKGs-ISNTbackedup:Add "$qpkg_name"
;;
backupable)
:
;;
notbackupable)
:
;;
enabled)
QPKGs-ISenabled:Add "$qpkg_name"
;;
notenabled)
QPKGs-ISNTenabled:Add "$qpkg_name"
;;
installable)
QPKGs-ISinstallable:Add "$qpkg_name"
;;
notinstallable)
QPKGs-ISNTinstallable:Add "$qpkg_name"
;;
installed)
QPKGs-ISinstalled:Add "$qpkg_name"
;;
notinstalled)
QPKGs-ISNTinstalled:Add "$qpkg_name"
;;
missing)
QPKGs-ISmissing:Add "$qpkg_name"
QPKGs-ISok:Remove "$qpkg_name"
QPKGs-ISNTok:Add "$qpkg_name"
;;
notmissing)
QPKGs-ISNTmissing:Add "$qpkg_name"
;;
upgradable)
QPKGs-ISupgradable:Add "$qpkg_name"
;;
notupgradable)
QPKGs-ISNTupgradable:Add "$qpkg_name"
esac
done
done
qpkgs_states_built=true
ShowQPKGsMissing
ShowQPKGsNewVers
FuncExit
}
InitQPKGsStates()
{
LoadObjects || return
FuncInit
local a=''
DebugAsProc 'initialising state lists'
for a in "${r_qpkg_is_states[@]:-}" "${r_qpkg_states_transient[@]:-}";do
[[ $a = active ]] && continue
QPKGs-IS${a}:Init
done
for a in "${r_qpkg_isnt_states[@]:-}";do
[[ $a = active ]] && continue
QPKGs-ISNT${a}:Init
done
ClearPath /var/run/sherpa/packages "$r_qpkg_states_path"
DebugAsDone 'initialised state lists'
qpkgs_states_built=false
FuncExit
}
BuildQPKGsIsCanBackup()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsDatabaseCanBackup "$qpkg_name" && QPKGs-GRcanbackup:Add "$qpkg_name"
done
FuncExit
}
BuildQPKGsIsCanRestartToUpdate()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsDatabaseCanRestartToUpdate "$qpkg_name" && QPKGs-GRcanrestarttoupdate:Add "$qpkg_name"
done
FuncExit
}
BuildQPKGsIsCanClean()
{
FuncInit
local qpkg_name=''
for qpkg_name in $(QPKGs-GRall:Array);do
QpkgIsDatabaseCanClean "$qpkg_name" && QPKGs-GRcanclean:Add "$qpkg_name"
done
FuncExit
}
QPKGs.IsTimeoutsIncreased()
{
[[ -e /usr/local/sbin/qpkg_service.orig ]]
}
HelpAbbreviations()
{
FuncInit
local a=''
local f=''
local -i m=0
local -i n=0
LoadPackages
DisableDebugToArchiveAndFile
DisplayProcReport abbreviations
ResetReportsPath &> /dev/null
{
ShowHelpBasic
DisplayAsHelpTitle "$(ShowAsTitleName) can recognise various abbreviations and aliases as $(ShowAsPackages)."
printf '\n'
} > "$r_report_output_pathfile"
if OsIsSupportAutowidthTableColumns;then
printf -v a '%s\n' 'QPKG name:|Installed?|Acceptable QPKG name abbreviations and aliases:'
else
printf -v a '%s\n' "$(GenerateAbsReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateAbsReportDataLine > "$r_reports_path/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi >> "$r_report_output_pathfile"
fi
DisplayAsProjSynExam "example: to install $(ShowAsPackageName SABnzbd), $(ShowAsPackageName Mylar3) and $(ShowAsPackageName nzbToMedia) all-at-once" 'install sab my nzb2' >> "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
ListQPKGsStates
FuncExit
}
ShowReportBackups()
{
FuncInit
local epoch_time=0
local -i file_bytes=0
local file_date=''
local file_name=''
local file_time=''
DisableDebugToArchiveAndFile
DisplayProcReport backups
ResetReportsPath &> /dev/null
{
DisplayAsBacksReportTitleLine
if [[ -e $GNU_FIND_CMD ]];then
while read -r epoch_time file_name file_bytes;do
[[ -z $epoch_time || -z $file_name ]] && break
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_backups_older_than"
done <<< "$($GNU_FIND_CMD "$r_qpkg_bu_path"/*.config.tar.gz -maxdepth 1 -printf '%C@ %f %s\n' 2> /dev/null | $SORT_CMD)"
else
while read -r file_date file_time file_name file_bytes;do
[[ -z $file_date || -z $file_name ]] && break
epoch_time=$(/bin/date -d "$file_date $file_time" +"%s")
file_name=$($BASENAME_CMD "$file_name")
DisplayAsBacksReportItemLine "$epoch_time" "$file_name" "$file_bytes" "$highlight_backups_older_than"
done <<< "$(cd "$r_qpkg_bu_path" && ls -l1tr --time-style=+"%Y-%m-%d %H:%M:%S" ./*.config.tar.gz 2> /dev/null | $AWK_CMD '{print $6" "$7" "$8" "$5}')"
fi
GenerateReportFooter
} > "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
FuncExit
}
ShowReportDependencies()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport dependency
ResetReportsPath &> /dev/null
if OsIsSupportAutowidthTableColumns;then
printf -v a '%s\n' 'QPKG name:|Dependencies:|Installed?|Enabled?|Managed?|Min. RAM:|Min. OS:|Max. OS:|Supported arch?|Installed QPKG author:'
else
printf -v a '%s\n' "$(GenerateDepsReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateDepsReportDataLine > "$r_reports_path/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$r_report_output_pathfile"
GenerateReportFooter >> "$r_report_output_pathfile"
fi
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
echo
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
ListQPKGsStates
FuncExit
}
ShowReportFeatures()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport features
ResetReportsPath &> /dev/null
if OsIsSupportAutowidthTableColumns;then
printf -v a '%s\n' 'QPKG name:|CanBack?|CanClean?|StartUpd?|AutoUpd?|LiveTest?|Indep?|Compat?|Enhanced?'
else
printf -v a '%s\n' "$(GenerateFeaturesReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateFeaturesReportDataLine > "$r_reports_path/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$r_report_output_pathfile"
GenerateReportHeadingsFooter >> "$r_report_output_pathfile"
fi
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
echo
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
ListQPKGsStates
FuncExit
}
ShowReportPackages()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport package
{
ShowHelpBasic
DisplayAsHelpTitle "one-or-more $(ShowAsPackages) may be specified at-once."
printf '\n'
} > "$r_report_output_pathfile"
if OsIsSupportAutowidthTableColumns;then
printf -v a '%s\n' 'QPKG name:|Appl. version:|Description:'
else
printf -v a '%s\n' "$(GeneratePacksReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GeneratePacksReportDataLine "$qpkg_name" > "$r_reports_path/$n" &
done
m=$n
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi >> "$r_report_output_pathfile"
GenerateReportFooter >> "$r_report_output_pathfile"
fi
{
DisplayAsProjSynExam "abbreviations and aliases may also be used to specify $(ShowAsPackages). To list these" 'help abs'
DisplayAsProjSynIndentExam '' a
} >> "$r_report_output_pathfile"
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
echo
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
FuncExit
}
ShowReportRepos()
{
FuncInit
local a=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport repository
ResetReportsPath &> /dev/null
if OsIsSupportAutowidthTableColumns;then
printf -v a '%s\n' 'QPKG name:|Repository:|Install date:'
else
printf -v a '%s\n' "$(GenerateReposReportTitleLine)"
fi
for qpkg_name in $(QPKGs-GRall:Array);do
((n++))
QpkgSetIndex
GenerateReposReportDataLine > "$r_reports_path/$n" &
done
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v a '%s\n' "$a$(<$f)"
done
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s' "$a"
fi > "$r_report_output_pathfile"
GenerateReportFooter >> "$r_report_output_pathfile"
fi
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
echo
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
ListQPKGsStates
FuncExit
}
ShowReportStatuses()
{
FuncInit
local a=false
local b=''
local c=''
local f=''
local -i m=0
local -i n=0
DisableDebugToArchiveAndFile
DisplayProcReport status
ResetReportsPath &> /dev/null
for qpkg_name in $(QPKGs-GRall:Array);do
QPKGs-ACstatus-dn.Exist "$qpkg_name" || continue
((n++))
QpkgSetIndex
QPKGs-ISupgradable.Exist "$qpkg_name" && a=true
GenerateStatusReportDataLine > "$r_reports_path/$n" &
done
if OsIsSupportAutowidthTableColumns;then
[[ $a = true ]] && b=" ($(TextBrightOrange new))"
printf -v c '%s\n' "QPKG name:|Status:|Previous action (result):|QPKG version${b}:|Appl. version:|Location:"
else
printf -v c '%s\n' "$(GenerateStatusReportTitleLine)"
fi
m=$n
wait 2> /dev/null
for ((n=1;n<=m; n++)); do
f="$r_reports_path/$n"
[[ -e $f ]] && printf -v c '%s\n' "$c$(<$f)"
done
if [[ -n $c ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$c" | Tableise
else
printf '%s' "$c"
fi > "$r_report_output_pathfile"
GenerateReportFooter >> "$r_report_output_pathfile"
fi
EraseThisLine
if [[ -e $r_report_output_pathfile ]];then
echo
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
ListQPKGsStates
show_action_results_ok=false
show_action_results_skipped=false
show_action_results_failed=false
FuncExit
}
ShowReportVersions()
{
DisableDebugToArchiveAndFile
EraseThisLine
Display "QPKG: ${r_this_package_ver:-undefined}"
Display "manager: ${r_this_script_ver:-undefined}"
Display "loader: ${LOADER_SCRIPT_VERSION:-undefined}"
Display "objects: ${r_objects_version:-undefined}"
Display "packages: ${r_packages_epoch}$([[ $r_packages_epoch != undefined ]] && printf '%s' " ($(ConvertSecondsToFullDate "$r_packages_epoch"))")"
return 0
}
ShowReportAllActionResults()
{
local -i a=0
local -i b=0
local -i c=0
local -i d=0
local -i e=0
local action=''
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ $useropt_show_all_results = true ]];then
show_action_results_failed=true
show_action_results_ok=true
show_action_results_skipped=true
fi
if [[ -e $r_session_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $datetime -gt 0 && $duration -gt 0 ]];then
[[ $a -eq 0 ]] && a=$datetime
b=$datetime
c=$duration
((d++))
fi
done < "$r_session_action_results_pathfile"
a=$(ConvertMillisecondsToSeconds "$a")
b=$(ConvertMillisecondsToSeconds "$b")
c=$(ConvertMillisecondsToSeconds "$c")
[[ $b -gt 0 ]] && e=$((b+c+1))
if [[ $show_action_results_ok = true || $show_action_results_skipped = true || $show_action_results_failed = true || $show_action_results_zero = true ]];then
{
DisplayAsHelpTitle "package action$(Pluralise "$d") started @ $(ConvertSecondsToTime "$a"), ended @ $(ConvertSecondsToTime "$e"), elapsed = $(ConvertSecondsToDuration "$(CalcAmountDiff "$a" "$e")")"
[[ $show_action_results_ok = true ]] && ShowReportActionResults ok
[[ $show_action_results_skipped = true ]] && ShowReportActionResults skipped
[[ $show_action_results_failed = true ]] && ShowReportActionResults failed
[[ $show_action_results_zero = true ]] && ShowZeroQpkgs
} > "$r_report_output_pathfile"
if [[ -e $r_report_output_pathfile ]];then
DisplayFileInViewport "$r_report_output_pathfile"
else
ShowAsError 'no information to display'
fi
fi
fi
}
ShowReportActionResults()
{
local action=''
local -i count=0
local -i datetime=0
local -i duration=0
local package_name=''
local package_type=''
local -i quantity=0
local reason=''
local result=''
if [[ -e $r_session_action_results_pathfile ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]] || [[ $1 = skipped && ($result = 'skipped-ok' || $result = 'skipped-error' || $result = 'skipped-abort') ]];then
[[ $action = status && $useropt_show_all_results = false ]] && continue
((count++))
[[ $count -gt 1 ]] && break
fi
done < "$r_session_action_results_pathfile"
if [[ $count -eq 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "this package action completed $(TextBrightGreen OK):"
;;
skipped)
DisplayAsHelpTitle "this package action was $(TextBrightOrange skipped) (and why):"
;;
failed)
DisplayAsHelpTitle "this package action $(TextBrightRed failed) (and why):"
esac
elif [[ $count -gt 1 ]];then
case $1 in
ok)
DisplayAsHelpTitle "these package actions completed $(TextBrightGreen OK):"
;;
skipped)
DisplayAsHelpTitle "these package actions were $(TextBrightOrange skipped) (and why):"
;;
failed)
DisplayAsHelpTitle "these package actions $(TextBrightRed failed) (and why):"
esac
fi
if [[ $count -ge 1 ]];then
while IFS='|' read -r datetime action quantity package_name package_type result duration reason;do
if [[ $result = "$1" ]] || [[ $1 = skipped && ($result = 'skipped-ok' || $result = 'skipped-error' || $result = 'skipped-abort') ]];then
[[ $action = status && $useropt_show_all_results = false ]] && continue
ShowAsActionLogDetail "$datetime" "$package_name" "$action" "$result" "$duration" "$reason" "$package_type" "$quantity"
fi
done < "$r_session_action_results_pathfile"
fi
fi
if [[ $count -eq 0 ]];then
case $1 in
ok)
DisplayAsHelpTitle "no package actions completed $(TextBrightGreen OK)."
;;
skipped)
DisplayAsHelpTitle "no package actions were $(TextBrightOrange skipped)."
;;
failed)
DisplayAsHelpTitle "no package actions $(TextBrightRed failed)."
esac
fi
return 0
}
GenerateReportFooter()
{
[[ $useropt_report_footer = true ]] || return
DisplayAsHelpTitle 'report information:'
local a=''
a=$({
if [[ -e "$r_report_flags_path"/status-missing ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed missing)" 'QPKG is missing from its installation path. Please reinstall it'
fi
if [[ -e "$r_report_flags_path"/req-alert ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" 'QPKG is prevented from working correctly'
fi
if [[ -e "$r_report_flags_path"/state-disabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed disabled)" "QPKG won't start at bootup. Enable it first, then start it"
fi
if [[ -e "$r_report_flags_path"/result-aborted ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed aborted))" 'previous action was aborted'
fi
if [[ -e "$r_report_flags_path"/result-failed ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightRed failed))" 'previous action failed'
fi
if [[ -e "$r_report_flags_path"/status-inactive ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed inactive)" 'application process is dead or not-started. Try starting it'
fi
if [[ -e "$r_report_flags_path"/backup-file-old ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightRed '!')" "QPKG backup file was updated more-than $highlight_backups_older_than."
fi
if [[ -e "$r_report_flags_path"/status-upgradable ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange new))" 'an upgraded QPKG version is available'
fi
if [[ -e "$r_report_flags_path"/status-wrongauthor ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange 'incompatible author')" "QPKG is a non-compatible, identically-named duplicate of a $(ShowAsTitleName) QPKG"
fi
if [[ -e "$r_report_flags_path"/req-attention ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '*')" "QPKG cannot be managed with $(ShowAsTitleName)"
fi
if [[ -e "$r_report_flags_path"/action-pending ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange pending)" 'QPKG is waiting to run an action. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-stopping ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange stopping)" 'QPKG is stopping. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-slow ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange slow)" 'application is alive, but was slow to respond to the status request. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-starting ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange starting)" 'QPKG is starting. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/result-in-progress ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightOrange in-progress))" 'an action is in-progress. Check again shortly'
fi
if [[ -e "$r_report_flags_path"/status-unknown ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange unknown)" 'application status could not be determined'
fi
if [[ -e "$r_report_flags_path"/repo-other ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightOrange '* URL')" 'another repository is managing this QPKG'
fi
if [[ -e "$r_report_flags_path"/state-enabled ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen enabled)" 'QPKG will be started at bootup'
fi
if [[ -e "$r_report_flags_path"/result-ok ]];then
DisplayAsIndentQuotedInfoItem "($(TextBrightGreen OK))" 'previous action was successful'
fi
if [[ -e "$r_report_flags_path"/status-active ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen active)" 'application is alive (and responsive if a daemon)'
fi
if [[ -e "$r_report_flags_path"/repo-sherpa ]];then
DisplayAsIndentQuotedInfoItem "$(TextBrightGreen sherpa)" "$(ShowAsTitleName) is managing this QPKG"
fi
if [[ -e "$r_report_flags_path"/app-dynamic ]];then
DisplayAsIndentQuotedInfoItem dynamic 'application version is the latest available'
fi
if [[ -e "$r_report_flags_path"/app-static ]];then
DisplayAsIndentQuotedInfoItem static 'application version auto-update is disabled or unsupported'
fi
if [[ -e "$r_report_flags_path"/app-final ]];then
DisplayAsIndentQuotedInfoItem final 'application version is the last available'
fi
if [[ -e "$r_report_flags_path"/na ]];then
DisplayAsIndentQuotedInfoItem N/A 'not applicable'
fi
if [[ -e "$r_report_flags_path"/action-not-found ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey not-found)" 'action tracking files were not found'
fi
if [[ -e "$r_report_flags_path"/action-unsupported ]];then
DisplayAsIndentQuotedInfoItem "$(TextDarkGrey unsupported)" 'action tracking is unsupported by this QPKG'
fi
})
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi
if [[ -e "$r_report_flags_path"/deps ]];then
DisplayAsHelpTitle "QPKG dependencies are automatically installed/started/stopped/restarted as-required by $(ShowAsTitleName)."
fi
if compgen -G "${r_report_flags_path}/backup-file-*" > /dev/null;then
DisplayAsIndentItem "backups are listed oldest-first."
fi
if compgen -G "${r_report_flags_path}/backup-file-*" > /dev/null;then
DisplayAsIndentItem "all $(ShowAsTitleName) backup files are stored here: $r_qpkg_bu_path"
fi
}
GenerateReportHeadingsFooter()
{
[[ $useropt_report_footer = true ]] || return
DisplayAsHelpTitle 'column headings:'
local a=''
a=$({
DisplayAsIndentQuotedInfoItem 'CanBack?' "application config 'backup' and 'restore' are supported"
DisplayAsIndentQuotedInfoItem 'CanClean?' "application 'clean' is supported"
DisplayAsIndentQuotedInfoItem 'StartUpd?' 'application restart-to-update is supported'
DisplayAsIndentQuotedInfoItem 'AutoUpd?' 'application restart-to-update is enabled'
DisplayAsIndentQuotedInfoItem 'LiveTest?' "has a built-in 'status' check, and can test for daemon \"live\" status"
DisplayAsIndentQuotedInfoItem 'Indep?' 'is independent of other QPKGs'
DisplayAsIndentQuotedInfoItem 'Compat?' 'has a release compatible with this NAS arch'
DisplayAsIndentQuotedInfoItem 'Enhanced?' "$(ShowAsTitleName) enhanced service actions are supported"
})
if [[ -n $a ]];then
if OsIsSupportAutowidthTableColumns;then
printf '%s' "$a" | Tableise
else
printf '%s\n' "$a"
fi
fi
}
ShowQPKGsISbackedup()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISbackedup.IsAny;then
for qpkg_name in $(QPKGs-ISbackedup:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'backed-up' QPKGs"
fi
return 0
}
ShowQPKGsISNTbackedup()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTbackedup.IsAny;then
for qpkg_name in $(QPKGs-ISNTbackedup:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not backed-up' QPKGs"
fi
return 0
}
ShowQPKGsISenabled()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISenabled.IsAny;then
for qpkg_name in $(QPKGs-ISenabled:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'enabled' QPKGs"
fi
return 0
}
ShowQPKGsISNTenabled()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTenabled.IsAny;then
for qpkg_name in $(QPKGs-ISNTenabled:Array);do
QPKGs-ISinstalled.Exist "$qpkg_name" && Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not enabled' QPKGs"
fi
return 0
}
ShowQPKGsISinstalled()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISinstalled.IsAny;then
for qpkg_name in $(QPKGs-ISinstalled:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'installed' QPKGs"
fi
return 0
}
ShowQPKGsISNTinstalled()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTinstalled.IsAny;then
for qpkg_name in $(QPKGs-ISNTinstalled:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not installed' QPKGs"
fi
return 0
}
#ShowQPKGsGRall()
ShowQPKGsISinstallable()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISinstallable.IsAny;then
for qpkg_name in $(QPKGs-ISinstallable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'installable' QPKGs"
fi
return 0
}
ShowQPKGsISNTinstallable()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTinstallable.IsAny;then
for qpkg_name in $(QPKGs-ISNTinstallable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not installable' QPKGs"
fi
return 0
}
ShowQPKGsISmissing()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISmissing.IsAny;then
for qpkg_name in $(QPKGs-ISmissing:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'missing' QPKGs"
fi
return 0
}
ShowQPKGsISNTmissing()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTmissing.IsAny;then
for qpkg_name in $(QPKGs-ISNTmissing:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'not missing' QPKGs"
fi
return 0
}
ShowQPKGsISactive()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISactive.IsAny;then
for qpkg_name in $(QPKGs-ISactive:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'active' QPKGs"
fi
return 0
}
ShowQPKGsISNTactive()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTactive.IsAny;then
for qpkg_name in $(QPKGs-ISNTactive:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'inactive' QPKGs"
fi
return 0
}
ShowQPKGsISupgradable()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISupgradable.IsAny;then
for qpkg_name in $(QPKGs-ISupgradable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'upgradable' QPKGs"
fi
return 0
}
ShowQPKGsISNTupgradable()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-ISNTupgradable.IsAny;then
for qpkg_name in $(QPKGs-ISNTupgradable:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'non-upgradable' QPKGs"
fi
return 0
}
ShowQPKGsGRindependent()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-GRindependent.IsAny;then
for qpkg_name in $(QPKGs-GRindependent:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'independent' QPKGs"
fi
return 0
}
ShowQPKGsGRdependent()
{
DisableDebugToArchiveAndFile
EraseThisLine
if QPKGs-GRdependent.IsAny;then
for qpkg_name in $(QPKGs-GRdependent:Array);do
Display "$qpkg_name"
done
else
ShowAsWarn "unable to find any 'dependent' QPKGs"
fi
return 0
}
SendParentChangeEnv()
{
WriteToActionMsgPipe env "$1" '' ''
}
SendPackageStateChange()
{
WriteToActionMsgPipe change "$1" package "$qpkg_name"
}
SendActionStatus()
{
WriteToActionMsgPipe status "$1" package "$qpkg_name"
}
WriteToActionMsgPipe()
{
[[ $action_msg_pipe_fd != none && -e /proc/$$/fd/$action_msg_pipe_fd ]] && echo "$1|$2|$3|$4" >&$action_msg_pipe_fd
return 0
}
ReadFromActionMsgPipe()
{
local _msg1_key
local _msg1_value
local _msg2_key
local _msg2_value
IFS='|' read -r _msg1_key _msg1_value _msg2_key _msg2_value <&$action_msg_pipe_fd
eval "$1='$_msg1_key' $2='$_msg1_value' $3='$_msg2_key' $4='$_msg2_value'"
return 0
}
FindNextFD()
{
local -i fd=-1
for fd in {10..100};do
if [[ ! -e /proc/$$/fd/$fd ]];then
printf '%s' "$fd"
return 0
fi
done
return 1
}
MarkThisAcForkAsStarted()
{
[[ -n $proc_fork_pathfile ]] && /bin/touch "$proc_fork_pathfile"
}
MarkThisAcForkAsOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_ok_pathfile"
SendActionStatus ok
}
MarkThisAcForkAsSkippedOk()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_ok_pathfile"
SendActionStatus so
}
MarkThisAcForkAsSkipped()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_pathfile"
SendActionStatus sk
}
MarkThisAcForkAsSkippedError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_error_pathfile"
SendActionStatus se
}
MarkThisAcForkAsSkippedAbort()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_skip_abort_pathfile"
SendActionStatus sa
}
MarkThisAcForkAsError()
{
[[ -n $proc_fork_pathfile && -e $proc_fork_pathfile ]] && mv "$proc_fork_pathfile" "$proc_fail_pathfile"
SendActionStatus er
}
NoteIpkAcAsOk()
{
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-ok:Add "$1"
return 0
}
NoteIpkAcAsEr()
{
local a="failing request to $2 $(ShowAsPackageName "$1")"
[[ -n ${3:-} ]] && a+=" as $3"
DebugAsError "$a" >&2
IPKs-AC"$2"-to:Remove "$1"
IPKs-AC"$2"-er:Add "$1"
return 0
}
ModPathToEntware()
{
local a=''
local b=/opt/bin:/opt/sbin
if QPKGs-ISenabled.Exist Entware;then
! [[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=$b:${a%:}
DebugAsDone 'prepended Entware to $PATH'
else
[[ $PATH =~ $b ]] || return
a=$($SED_CMD "s|${b}:||" <<< "$PATH:")
export PATH=${a%:}
DebugAsDone 'removed Entware from $PATH'
fi
DebugVar PATH
return 0
}
HardwareGetCPUInfo()
{
if $GREP_CMD -q '^model name' /proc/cpuinfo;then
$GREP_CMD '^model name' /proc/cpuinfo | head -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
elif $GREP_CMD -q '^Processor name' /proc/cpuinfo;then
$GREP_CMD '^Processor name' /proc/cpuinfo | head -n1 | $SED_CMD 's|^.*: ||' | tr -s ' '
else
printf unknown
return 1
fi
return 0
}
OsGetArch()
{
$UNAME_CMD -m
}
OsGetKernelVersion()
{
$UNAME_CMD -r
}
OsGetKernelPageSize()
{
if [[ -e /sbin/hal_app ]];then
/sbin/hal_app --get_pagesize
else
$GREP_CMD KernelPageSize /proc/1/smaps | head -n1 | cut -f2 -d':' | tr -d ' '
fi
}
HardwareGetPlatform()
{
/sbin/getcfg '' Platform -d undefined -f /etc/platform.conf
}
UserGetDefVol()
{
/sbin/getcfg SHARE_DEF defVolMP -d undefined -f /etc/config/def_share.info
}
Python3IsOutdated()
{
[[ -e $PYTHON3_CMD ]] || return
installed_ver=$(Python3GetVer "$PYTHON3_CMD")
[[ $r_nas_arch = armv5tel && ${installed_ver//./} -lt 3114 ]] || [[ $r_nas_arch != armv5tel && ${installed_ver//./} -lt $r_min_python_version ]]
}
Python3GetVer()
{
PythonGetVer "${1:-python3}"
}
PythonGetVer()
{
GetThisBinPath ${1:-python} &> /dev/null && ${1:-python} -V 2>&1 | $SED_CMD 's|^Python ||'
}
PerlIsOutdated()
{
[[ -e $PERL_CMD ]] || return
installed_ver=$(PerlGetVer "$PERL_CMD")
[[ $r_nas_arch = armv5tel && ${installed_ver//./} -lt 5281 ]] || [[ $r_nas_arch != armv5tel && ${installed_ver//./} -lt $r_min_perl_version ]]
}
PerlGetVer()
{
GetThisBinPath ${1:-perl} &> /dev/null && ${1:-perl} -e 'print "$^V\n"' 2> /dev/null | $SED_CMD 's|v||'
}
GetThisBinPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined binary} ]] && command -v "$1" 2>&1
}
GetRepoURLFromStoreID()
{
[[ -n ${1:-} ]] || return
/sbin/getcfg "$1" u -d undefined -f /etc/config/3rd_pkg_v2.conf
}
OsGetUptime()
{
local n=$(< /proc/uptime)
ConvertSecondsToDuration "${n%%.*}"
}
UserGetTimeInShell()
{
local n=''
[[ -n ${LOADER_SCRIPT_PPID:-} ]] && n=$($PS_CMD -o pid,etime | $GREP_CMD $LOADER_SCRIPT_PPID | head -n1)
FormatAsLongMinutesSecs "${n:6}"
}
OsGetSysLoadAverages()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print "1m:"$1", 5m:"$2", 15m:"$3}'
}
OsGetSysLoad1MinAverage()
{
$UPTIME_CMD | $SED_CMD 's|.*load average: ||' | $AWK_CMD -F', ' '{print $1}'
}
HardwareGetCPUCores()
{
local n=$($GREP_CMD -c '^processor' /proc/cpuinfo)
[[ $n -eq 0 ]] && n=$($GREP_CMD -c '^Processor' /proc/cpuinfo)
printf '%s' "$n"
}
HardwareGetInstalledRAM()
{
$GREP_CMD MemTotal /proc/meminfo | $SED_CMD 's|.*: ||;s|kB||;s| ||g'
}
OsGetFirmwareVer()
{
/sbin/getcfg System Version -d undefined -f /etc/config/uLinux.conf
}
OsGetFirmwareBuild()
{
/sbin/getcfg System Number -d undefined -f /etc/config/uLinux.conf
}
OsGetFirmwareDate()
{
/sbin/getcfg System 'Build Number' -d undefined -f /etc/config/uLinux.conf
}
OsGetQnapOS()
{
if $GREP_CMD -q zfs /proc/filesystems;then
printf 'QuTS hero'
else
printf QTS
fi
}
QpkgGetArch()
{
if [[ $(get_display_name) = 'TS-269H' ]];then
printf i53
return
fi
case $r_nas_arch in
x86_64)
[[ ${r_nas_firmware_version//.} -ge 430 ]] && printf i64 || printf i86
;;
i686|x86)
printf i86
;;
armv5tel)
printf a19
;;
armv7l)
case $r_nas_platform in
ARM_MS)
printf a31
;;
ARM_AL)
printf a41
;;
*)
printf none
esac
;;
aarch64)
printf a64
;;
*)
printf none
esac
}
QpkgGetEntwareType()
{
if QpkgIsInstalled Entware;then
if [[ -e /opt/etc/passwd ]];then
if [[ -L /opt/etc/passwd ]];then
printf std
else
printf alt
fi
else
printf none
fi
else
printf 'not-installed'
fi
} 2> /dev/null
UserGetSudoUID()
{
printf '%s' "${SUDO_UID:-undefined}"
}
OsGetUpState()
{
if OsIsStarting;then
printf 'starting-up'
elif OsIsStopping;then
printf 'shutting-down'
else
printf stable
fi
}
UserGetGitBranch()
{
/sbin/getcfg sherpa Git_Branch -d stable -f /etc/config/qpkg.conf
}
OsIsOk()
{
if ! OsIsQNAP;then
ShowAsAbort 'QNAP shell functions not found ... is this a QNAP NAS?'
return 1
fi
return 0
}
OsIsQNAP()
{
[[ -e /etc/init.d/functions ]]
}
OsIsSupported()
{
[[ ${r_nas_firmware_version//.} -ge 400 ]]
}
OsIsSupportSecureDownload()
{
[[ ${r_nas_firmware_version//.} -ge 500 ]]
}
OsIsSupportQpkgTimeout()
{
[[ ${r_nas_firmware_version//.} -ge 430 ]]
}
OsIsSupportSignedPackages()
{
[[ ${r_nas_firmware_version//.} -ge 440 ]]
}
OsIsCompatibleWithSigned()
{
[[ $r_nas_firmware_date -lt 20201015 || $r_nas_firmware_date -gt 20201020 ]]
}
OsIsSupportUnofficialPackages()
{
[[ ${r_nas_firmware_version//.} -gt 426 && ${r_nas_firmware_version//.} -le 436 ]]
}
OsIsSupportSudo()
{
[[ -e /usr/bin/sudo ]]
}
OsIsSupportSedExtRegex()
{
[[ $(echo -en "\033[1;97ma" | /bin/sed -r 's/\x1b\[[0-9;]*m//g' | /usr/bin/wc -c) -eq 1 ]]
}
OsIsSupportDecimalSleepSeconds()
{
/bin/sleep .01 &> /dev/null
}
OsIsSupportAutowidthTableColumns()
{
[[ -e $GNU_AWK_CMD ]]
}
OsIsAllowUnsignedPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Ignore_Cert -d FALSE) = TRUE ]]
}
OsIsAllowUnofficialPackages()
{
[[ $(/sbin/getcfg 'QPKG Management' Check_Official -d TRUE) = FALSE ]]
}
OsIsStarting()
{
$PS_CMD | $GREP_CMD '/bin/sh /etc/init.d/rcS' | $GREP_CMD -v grep
} &> /dev/null
OsIsStopping()
{
$PS_CMD | $GREP_CMD '/bin/sh /etc/init.d/rcK' | $GREP_CMD -v grep
} &> /dev/null
OsIsStdKernelPageSize()
{
[[ ${r_kernel_page_size:=$(OsGetKernelPageSize)} = 4096 || $r_kernel_page_size = 4kB ]]
}
OsIsNonStdKernelPageSize()
{
! OsIsStdKernelPageSize
}
OsIsLoadAverageElevated()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((r_cpu_cores*2*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OsIsLoadAverageHigh()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((r_cpu_cores*4*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
OsIsLoadAverageInsane()
{
local a=$(OsGetSysLoad1MinAverage);a=${a/./}
local b=$((r_cpu_cores*8*100))
[[ $((10#$a)) -ge $((10#$b)) ]]
}
SetError()
{
run_package_actions=false
ErrorIsSet && return
_script_error_flag_=true
DebugVar _script_error_flag_
}
ErrorIsSet()
{
[[ ${_script_error_flag_:=false} = true ]]
}
ErrorIsNt()
{
[[ ${_script_error_flag_:=false} != true ]]
}
ShowZeroQpkgs()
{
[[ ${packages_loaded:=false} = true ]] || return
local a=''
local b=''
for a in "${r_qpkg_is_states[@]:-}";do
for b in "${r_user_qpkg_actions[@]:-}";do
[[ $b = list ]] && continue
QPKGs.AC${b}.IS${a}.IsSet && QPKGs-AC${b}-ok.IsNone && ShowAsWarn "no QPKGs were able to $(Lowercase "$b")"
done
done
return 0
}
ClaimLockfile()
{
local a=''
readonly r_lock_pathfile=/var/run/sherpa.lock
for a in sherpa-manager.sh sherpa-manager.source;do
if [[ -e $r_lock_pathfile && -d /proc/$(<"$r_lock_pathfile") && $(< /proc/"$(<"$r_lock_pathfile")"/cmdline) =~ $a ]];then
ShowAsAbort "another sherpa instance was found (PID:$(<"$r_lock_pathfile")), can't continue"
return 1
fi
done
echo "$$" > "$r_lock_pathfile"
return 0
}
ReleaseLockfile()
{
[[ -n ${r_lock_pathfile:-} ]] && rm -f "$r_lock_pathfile" 2> /dev/null
}
EnableVerbose()
{
useropt_verbose=true
DebugVar useropt_verbose
useropt_terse=false
ShowKeystrokes
ShowCursor
}
EnableDebugToArchiveAndFile()
{
useropt_debug=true
DebugVar useropt_debug
ShowAsNote "debug mode activated, $(ShowAsTitleName) will run a little slower than usual"
archive_debug_afterward=true
DebugVar archive_debug_afterward
}
DisableDebugToArchiveAndFile()
{
archive_debug_afterward=false
useropt_debug=false
}
SaveActionResultToLog()
{
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_};var_safe_name=${var_safe_name//:/_}
local -r r_package_type=${1:?${FUNCNAME[0]}'()': undefined package type}
local -r r_name=${2:?${FUNCNAME[0]}'()': undefined package name}
local -r r_action=${3:?${FUNCNAME[0]}'()': undefined action}
local -r r_qty=${4:-1}
local -r r_clean_action=${r_action//\"/}
local -r r_result=${5:?${FUNCNAME[0]}'()': undefined result}
local -r r_reason=${6:-}
local -r r_starttime=$(ConvertNanosecondsToMilliseconds "${!var_safe_name}")
local -r r_duration=$(CalcAmountDiff "$r_starttime" "$(ConvertNowToMilliseconds)")
local -r r_action_times_pathfile=$r_action_times_path/$r_clean_action.milliseconds
if [[ $2 = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
echo "$r_starttime|$r_action|$r_qty|$r_name|$r_package_type|$r_result|$r_duration|$r_reason" >> "$r_session_action_results_pathfile"
if [[ -e $r_action_times_pathfile ]] && $GREP_CMD -q "^$r_name|" < "$r_action_times_pathfile";then
$SED_CMD -i "/^$r_name|/d" "$r_action_times_pathfile"
fi
echo "$r_name|$r_duration" >> "$r_action_times_pathfile"
case $4 in
ok|skipped-ok)
DebugAsInfo "$r_reason"
;;
skipped)
DebugAsWarn "$r_reason"
;;
failed|skipped-@(error|abort))
DebugAsError "$r_reason"
esac
return 0
}
_QPKG:reassign_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif [[ $(QpkgGetInstalledStoreID) = sherpa || $(QpkgGetInstalledStoreID) = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' skipped 'already assigned to sherpa'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "reassigning $(ShowAsPackageName)"
RunAndLog "/sbin/setcfg -e $qpkg_name store -f /etc/config/qpkg.conf" "$r_logs_path/$qpkg_name.$r_reassign_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" reassign '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reassign '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:download_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -r r_remote_hash=$(QpkgGetDatabaseHash)
local -r r_remote_url=$(QpkgGetDatabaseURL)
local -r r_remote_filename=$($BASENAME_CMD "$r_remote_url")
local -r r_local_pathfile=$r_qpkg_download_path/$r_remote_filename
local -r r_local_filename=$($BASENAME_CMD "$r_local_pathfile")
local -r r_log_pathfile=$r_logs_path/$r_local_filename.$r_download_log_file
local -i z=0
if [[ -z $r_remote_url || -z $r_remote_hash ]];then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped 'NAS arch is incompatible'
MarkThisAcForkAsSkipped
z=1
elif [[ -f $r_local_pathfile ]];then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
SaveActionResultToLog QPKG "$qpkg_name" download '' skipped-ok "existing file $(ShowAsFileName "$r_local_filename") checksum is correct"
MarkThisAcForkAsSkippedOk
z=2
else
DebugInfo "deleting $(ShowAsFileName "$r_local_filename") as checksum is incorrect"
rm -f "$r_local_pathfile" 2> /dev/null
fi
fi
[[ $z -eq 0 ]] || FuncForkExit $z
if [[ ! -f $r_local_pathfile ]];then
DebugAsProc "downloading $(ShowAsFileName "$r_remote_filename")"
rm -f "$r_log_pathfile" 2> /dev/null
RunAndLog "$CURL_CMD --location --output $r_local_pathfile $r_remote_url" "$r_log_pathfile" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
if FileMatchesMD5 "$r_local_pathfile" "$r_remote_hash";then
[[ $(Lowercase "${r_local_pathfile##*.}") = zip ]] && $UNZIP_CMD -nq "$r_local_pathfile" -d "$r_qpkg_download_path"
SaveActionResultToLog QPKG "$qpkg_name" download '' ok
SendPackageStateChange ISdownloaded
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "cache file $(ShowAsFileName "$r_local_filename") has incorrect checksum"
SendPackageStateChange ISNTdownloaded
MarkThisAcForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" download '' failed "$z"
MarkThisAcForkAsError
z=1
fi
fi
FuncForkExit $z
}
_QPKG:install_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'already installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsReallyInstalled && QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseArchOK "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS arch is incompatible'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseMinOSVerOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped "$(OsGetQnapOS) version is incompatible"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseMinRAMOk "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped 'NAS has insufficient RAM installed'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetDatabasePathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" install '' skipped-error 'no local file found for processing: please report this issue'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
if [[ $qpkg_name = Entware ]] && ! QPKGs-ISinstalled.Exist Entware && QPKGs-ACinstall-to.Exist Entware;then
local -r r_opt_path=/opt
local -r r_opt_bu_path=/opt.orig
if [[ -d $r_opt_path && ! -L $r_opt_path && ! -e $r_opt_bu_path ]];then
DebugAsProc 'backup original /opt'
mv "$r_opt_path" "$r_opt_bu_path"
DebugAsDone complete
fi
fi
DebugAsProc "installing $(ShowAsPackageName)"
[[ ${QPKGs_were_installed_name[*]:-} = *"$qpkg_name"* ]] && a+="QINSTALL_PATH=$(QpkgGetInstalledOriginalPath "$qpkg_name") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$r_logs_path/$($BASENAME_CMD "$local_pathfile").$r_install_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsDatabaseCanLog && ! QpkgInstalledServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
SendPackageStateChange ISinstalled
if QpkgIsInstalledEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$qpkg_name" install '' ok "version $(QpkgGetInstalledVer)"
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
SendParentChangeEnv _UpdateEntwarePackageList_
PatchEntwareService
if [[ -L ${r_opt_path:-} && -d ${r_opt_bu_path:-} ]];then
DebugAsProc 'restoring original /opt'
mv "$r_opt_bu_path"/* "$r_opt_path" && ClearPath / "$r_opt_bu_path"
DebugAsDone complete
fi
fi
OsIsSupportSignedPackages && SendParentChangeEnv "QPKGs-ACsign-to:Add $qpkg_name"
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" install '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:reinstall_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a='QPKG_REINSTALL=true '
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "not installed, please use 'install' instead."
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetDatabasePathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' skipped-error 'no local file found for processing, please report this issue.'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "reinstalling $(ShowAsPackageName)"
QpkgIsInstalled && a+="QINSTALL_PATH=$($DIRNAME_CMD "$(QpkgGetInstalledPath)") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$r_logs_path/$($BASENAME_CMD "$local_pathfile").$r_reinstall_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsDatabaseCanLog && ! QpkgInstalledServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
if QpkgIsInstalledEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' ok "version $(QpkgGetInstalledVer)"
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" reinstall '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:rebuild_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if ! QpkgIsDatabaseCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'does not support rebuild'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsReallyInstalled && QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "already installed, please use 'restore' instead"
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped 'backup file does not exist'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "meta-rebuilding $(ShowAsPackageName)"
SaveActionResultToLog QPKG "$qpkg_name" meta-rebuild '' ok
MarkThisAcForkAsOk
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:upgrade_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a='QPKG_UPGRADE=true '
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! QPKGs-ISupgradable.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped 'no new QPKG is available'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local local_pathfile=$(QpkgGetDatabasePathFilename)
if [[ -z $local_pathfile || ! -e $local_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' skipped-error 'no local file found for processing, please report this issue'
MarkThisAcForkAsSkippedError
z=4
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local prev_ver=$(QpkgGetInstalledVer)
DebugAsProc "upgrading $(ShowAsPackageName)"
QpkgIsInstalled && a+="QINSTALL_PATH=$($DIRNAME_CMD "$(QpkgGetInstalledPath "$qpkg_name")") "
RunAndLog "${a}${SH_CMD} $local_pathfile" "$r_logs_path/$($BASENAME_CMD "$local_pathfile").$_r_upgrade_log_file" log:failure-only 10
z=$?
LogQpkgServiceResult
QpkgIsDatabaseCanLog && ! QpkgInstalledServiceResultWasOk && z=1
[[ $qpkg_name = Entware ]] && IsNtSysFileExist $OPKG_CMD && z=1
if [[ $z -eq 0 || $z -eq 10 ]];then
SendPackageStateChange ISNTupgradable
if QpkgIsInstalledEnabled "$qpkg_name";then
SendPackageStateChange ISenabled
else
SendPackageStateChange ISNTenabled
fi
local current_ver=$(QpkgGetInstalledVer)
if [[ $current_ver = "$prev_ver" ]];then
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "version $current_ver"
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' ok "version $prev_ver -> version $current_ver"
fi
MarkThisAcForkAsOk
z=0
else
SaveActionResultToLog QPKG "$qpkg_name" upgrade '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:uninstall_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "it's needed here! 😉"
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_qpkg_uninstaller_pathfile=$(QpkgGetInstalledPath)/.uninstall.sh
[[ $qpkg_name = Entware ]] && SaveIpkAndPipList
if [[ -e $r_qpkg_uninstaller_pathfile ]];then
DebugAsProc "uninstalling $(ShowAsPackageName)"
RunAndLog "${a}${SH_CMD} $r_qpkg_uninstaller_pathfile" "$r_logs_path/$qpkg_name.$r_uninstall_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
[[ -e /sbin/qpkg_cli ]] && ! QPKGs-ACinstall-to.Exist "$qpkg_name" && /sbin/qpkg_cli --remove "$qpkg_name" &> /dev/null
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' ok
/sbin/rmcfg "$qpkg_name" -f /etc/config/qpkg.conf
DebugAsDone 'removed icon information from App Center'
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISNTinstalled
SendPackageStateChange ISNTactive
SendPackageStateChange ISNTenabled
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$z"
MarkThisAcForkAsError
z=1
fi
else
SaveActionResultToLog QPKG "$qpkg_name" uninstall '' failed "$(ShowAsFileName '.uninstall.sh') not found"
MarkThisAcForkAsError
fi
FuncForkExit $z
}
_QPKG:activate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "not enabled, please 'enable' it first"
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_activate_log_file
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $r_qpkg_start_timeout_seconds"
local service_pathfile=$(QpkgGetInstalledServicePathFile)
DebugAsProc "activating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" activate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} start" "$r_log_pathfile" log:failure-only
z=$?
elif QpkgIsDatabaseCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} start $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgInstalledServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile start" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" activate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISactive
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" activate '' failed "$z"
SendPackageStateChange ISNTactive
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:reactivate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "not enabled, please 'enable' it first"
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_reactivate_log_file
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $r_qpkg_restart_timeout_seconds"
local service_pathfile=$(QpkgGetInstalledServicePathFile)
DebugAsProc "reactivating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} restart" "$r_log_pathfile" log:failure-only
z=$?
elif QpkgIsDatabaseCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} restart $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgInstalledServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile restart" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" reactivate '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:deactivate_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]]	&& a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_deactivate_log_file
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $r_qpkg_stop_timeout_seconds"
local service_pathfile=$(QpkgGetInstalledServicePathFile)
DebugAsProc "deactivating $(ShowAsPackageName)"
if [[ $service_pathfile = undefined ]];then
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' skipped-error 'QPKG service-script file undefined'
MarkThisAcForkAsSkippedError
FuncForkExit 4
elif [[ $useropt_debug = true ]];then
RunAndLog "${a}${service_pathfile} stop" "$r_log_pathfile" log:failure-only
z=$?
elif QpkgIsDatabaseCanLog;then
RunAndLog "/sbin/qpkg_service${timeout} stop $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgInstalledServiceResultWasOk && z=0 || z=1
else
RunAndLog "$service_pathfile stop" "$r_log_pathfile" log:failure-only
z=$?
fi
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' ok
if [[ $qpkg_name = Entware ]];then
SendParentChangeEnv ModPathToEntware
UpdateParentCapabilities
UpdateCapabilities
fi
SendPackageStateChange ISNTactive
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" deactivate '' failed "$z"
MarkThisAcForkAsError
z=1
fi
ClearQpkgInstalledAppCenterNotifier
FuncForkExit $z
}
_QPKG:enable_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped 'already enabled'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enable '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_enable_log_file
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $r_qpkg_enable_timeout_seconds"
DebugAsProc "enabling $(ShowAsPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} enable $qpkg_name" "$r_log_pathfile" log:failure-only
QpkgIsInstalledEnabled "$qpkg_name" && SendPackageStateChange ISenabled
ClearQpkgInstalledAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" enable '' ok
MarkThisAcForkAsOk
FuncForkExit $z
}
_QPKG:disable_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif QPKGs-ISNTenabled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped 'already disabled'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disable '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
local -r r_log_pathfile=$r_logs_path/$qpkg_name.$r_disable_log_file
local timeout=''
OsIsSupportQpkgTimeout && timeout=" -t $r_qpkg_disable_timeout_seconds"
DebugAsProc "disabling $(ShowAsPackageName)"
RunAndLog "/sbin/qpkg_service${timeout} disable $qpkg_name" "$r_log_pathfile" log:failure-only
! QpkgIsInstalledEnabled "$qpkg_name" && SendPackageStateChange ISNTenabled
ClearQpkgInstalledAppCenterNotifier
SaveActionResultToLog QPKG "$qpkg_name" disable '' ok
MarkThisAcForkAsOk
FuncForkExit $z
}
_QPKG:enableau_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is always enabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped 'auto-update is unsupported'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" enableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "enabling auto-update $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetInstalledServicePathFile) enable-auto-update" "$r_logs_path/$qpkg_name.$r_enableau_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" enableau '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" enableau '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:disableau_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif [[ $qpkg_name = sherpa ]];then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update cannot be disabled'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseCanRestartToUpdate "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped 'auto-update is unsupported'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" disableau '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "disabling auto-update $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetInstalledServicePathFile) disable-auto-update" "$r_logs_path/$qpkg_name.$r_disableau_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" disableau '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" disableau '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:backup_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped 'backup is unsupported'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" backup '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "backing-up $(ShowAsPackageName) configuration"
RunAndLog "${a}$(QpkgGetInstalledServicePathFile) backup" "$r_logs_path/$qpkg_name.$r_backup_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" backup '' ok
SendPackageStateChange ISbackedup
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" backup '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:restore_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "not installed, try 'rebuild' instead"
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseCanBackup;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'restore is unsupported'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsBackupExist;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped 'backup file does not exist'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" restore '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "restoring $(ShowAsPackageName) configuration"
RunAndLog "${a}$(QpkgGetInstalledServicePathFile) restore" "$r_logs_path/$qpkg_name.$r_restore_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" restore '' ok
SendPackageStateChange ISrestored
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" restore '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:clean_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
[[ $useropt_debug = true ]] && a+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! QpkgIsDatabaseCanClean;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped 'clean is unsupported'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" clean '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "cleaning $(ShowAsPackageName)"
RunAndLog "${a}$(QpkgGetInstalledServicePathFile) clean" "$r_logs_path/$qpkg_name.$r_clean_log_file" log:failure-only
z=$?
if [[ $z -eq 0 ]];then
LogQpkgServiceResult
SaveActionResultToLog QPKG "$qpkg_name" clean '' ok
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" clean '' failed "$z"
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:sign_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
local b=''
local -i z=0
if [[ -e $r_action_abort_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort 'abort requested, unable to continue'
MarkThisAcForkAsSkippedAbort
z=3
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugVar sqlite_cmd
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledAuthorOk;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'incompatible author'
MarkThisAcForkAsSkipped
z=1
elif ! OsIsSupportSignedPackages;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped 'not required: firmware < 4.3.5'
MarkThisAcForkAsSkipped
z=1
elif QpkgIsNtInstalledRepoSelfManaged;then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped "assigned to another repository, please 'reassign' it first"
MarkThisAcForkAsSkipped
z=1
elif [[ ! -e $sqlite_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(ShowAsFileName sqlite3) binary not found"
MarkThisAcForkAsSkippedAbort
z=3
elif [[ ! -e $r_cert_db_pathfile ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' skipped-abort "$(OsGetQnapOS) QPKG certificate database not found"
MarkThisAcForkAsSkippedAbort
z=3
else
a="SELECT 1 FROM Certificate WHERE QpkgName = '$qpkg_name' LIMIT 1;"
b=$(eval "$sqlite_cmd" "$r_cert_db_pathfile" \"$a\")
if [[ $b = 1 ]];then
a="DELETE FROM Certificate WHERE QpkgName = '$qpkg_name';"
b=$(eval "$sqlite_cmd" "$r_cert_db_pathfile" \"$a\")
z=0
fi
fi
[[ $z -eq 0 ]] || FuncForkExit $z
DebugAsProc "\"signing\" $(ShowAsPackageName)"
a="INSERT INTO Certificate (Type,QpkgName,Cert,DigitalSignature) VALUES ('qpkg','$qpkg_name','$r_qpkg_certificate','$r_qpkg_signature');"
for ((retries=0;retries<10; retries++)); do
eval "$sqlite_cmd" "$r_cert_db_pathfile" "\"$a\""
z=$?
case $z in
5)
sleep 0.5
;;
*)
break
esac
done
if [[ $z -eq 0 ]];then
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' ok
SendPackageStateChange ISsigned
MarkThisAcForkAsOk
else
SaveActionResultToLog QPKG "$qpkg_name" '"sign"' '' failed "($z) but don't know why. Please report this as a bug"
SendParentChangeEnv 'show_suggest_raise_issue=true'
MarkThisAcForkAsError
z=1
fi
FuncForkExit $z
}
_QPKG:status_()
{
[[ $useropt_verbose != true ]] && exec &> /dev/null
FuncForkInit
local a=''
local b=''
[[ $useropt_debug = true ]] && b+='DEBUG_QPKG=true '
local -i z=0
if QPKGs-ISNTinstalled.Exist "$qpkg_name";then
SaveActionResultToLog QPKG "$qpkg_name" status '' skipped 'not installed'
MarkThisAcForkAsSkipped
z=1
fi
[[ $z -eq 0 ]] || FuncForkExit
DebugAsProc "status $(ShowAsPackageName)"
a=$(QpkgGetDatabaseActiveTest)
if [[ $a = builtin ]];then
if [[ -e $GNU_TIMEOUT_CMD ]];then
$GNU_TIMEOUT_CMD "$r_qpkg_status_check_timeout_seconds" /bin/bash -c "${b}$(QpkgGetInstalledServicePathFile) status"
z=$?
else
RunAndLog "${b}$(QpkgGetInstalledServicePathFile) status" "$r_logs_path/$qpkg_name.$r_status_log_file" log:failure-only
z=$?
fi
elif [[ $a != none ]];then
eval "$a" &> /dev/null
z=$?
fi
DebugVar z
case $z in
0)
SendPackageStateChange ISactive
;;
1)
SendPackageStateChange ISNTactive
;;
124)
SendPackageStateChange ISslow
;;
*)
SendPackageStateChange ISunknown
esac
SaveActionResultToLog QPKG "$qpkg_name" status '' ok
MarkThisAcForkAsOk
FuncForkExit
}
ClearQpkgInstalledAppCenterNotifier()
{
[[ -e /sbin/qpkg_cli ]] && /sbin/qpkg_cli --cancel "$qpkg_name"
QpkgIsNtInstalled && return
/sbin/setcfg "$qpkg_name" Status complete -f /etc/config/qpkg.conf
return 0
} &> /dev/null
LogQpkgServiceResult()
{
if ! local a=$(QpkgGetInstalledServiceResult);then
DebugAsWarn "unable to get status of $(ShowAsPackageName) service. It may be a non-sherpa package, or a sherpa package earlier than 200816c that doesn't support service results."
return 1
fi
case $a in
in-progress)
DebugInfo "$(ShowAsPackageName) service action is in-progress"
;;
ok)
DebugInfo "$(ShowAsPackageName) service action completed OK"
;;
failed)
if [[ -e /var/log/$qpkg_name.log ]];then
DebugAsError "$(ShowAsPackageName) service action failed. Check $(ShowAsFileName "/var/log/$qpkg_name.log") for more information"
AddExtLogToSessLog /var/log/$qpkg_name.log
else
DebugAsError "$(ShowAsPackageName) service action failed"
fi
;;
*)
DebugAsWarn "$(ShowAsPackageName) service status is unrecognised or unsupported"
esac
return 0
}
QpkgGetInstalledPath()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Install_Path -d undefined -f /etc/config/qpkg.conf
}
QpkgGetInstalledServicePathFile()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Shell -d undefined -f /etc/config/qpkg.conf
}
QpkgGetDatabaseApplVer()
{
local a=''
local -i i=0
if [[ $qpkg_index -gt 0 ]];then
a=${r_qpkg_appl_version[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_appl_version[$qpkg_default_index]}
[[ $a = version ]] && a=${r_qpkg_version[$qpkg_default_index]}
[[ $a != none ]] || return
else
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$qpkg_name" ]];then
a=${r_qpkg_appl_version[$i]}
[[ $a = version ]] && a=${r_qpkg_version[$qpkg_default_index]}
[[ $a != none ]] || return
break
fi
done
fi
[[ -n $a ]] || return
[[ $a = dynamic ]] && QpkgIsInstalled && ! QpkgIsInstalledAutoUpdate && a=static
printf '%s' "$a"
return 0
}
QpkgGetDatabaseVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$1" ]];then
printf '%s' "${r_qpkg_version[$i]}"
return 0
fi
done
elif [[ $qpkg_index -gt 0 ]];then
a=${r_qpkg_version[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_version[$qpkg_default_index]}
[[ $a != none ]] || return
printf '%s' "$a"
return 0
fi
return 1
}
QpkgGetInstalledVer()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Version -d undefined -f /etc/config/qpkg.conf
}
QpkgGetInstalledStoreID()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" store -d undefined -f /etc/config/qpkg.conf
}
QpkgGetInstalledDate()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" date -d undefined -f /etc/config/qpkg.conf
}
QpkgGetInstalledOriginalPath()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local -i i=0
if [[ ${#QPKGs_were_installed_name[@]} -gt 0 ]];then
for i in "${!QPKGs_were_installed_name[@]}";do
[[ ${QPKGs_were_installed_name[$i]} = "$a" ]] || continue
printf '%s' "${QPKGs_were_installed_path[$i]}"
return 0
done
fi
return 1
}
QpkgGetDatabasePathFilename()
{
local a=''
a=$(QpkgGetDatabaseURL)
[[ -n $a ]] || return
[[ $(Lowercase "${a##*.}") != qpkg ]] && a=${a%.*}.qpkg
printf '%s' "$r_qpkg_download_path/$($BASENAME_CMD "$a")"
return 0
}
QpkgGetDatabaseHash()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${r_qpkg_hash[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_hash[$qpkg_default_index]}
[[ $a != none ]] || return
printf '%s' "$a"
return 0
}
QpkgGetDatabaseURL()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_name[$i]} = "$1" ]] && [[ ${r_qpkg_arch[$i]} = all || ${r_qpkg_arch[$i]} = "$r_nas_qpkg_arch" ]];then
printf '%s' "${r_qpkg_url[$i]}"
return 0
fi
done
return 1
else
a=${r_qpkg_url[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_url[$qpkg_default_index]}
[[ -n $a ]] || a=none
printf '%s' "$a"
fi
return 0
}
QpkgGetDatabaseMinRAM()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_min_ram_kb[$i]}
break
done
else
a=${r_qpkg_min_ram_kb[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_min_ram_kb[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDatabaseMinOSVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_min_os_version[$i]}
break
done
else
a=${r_qpkg_min_os_version[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_min_os_version[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDatabaseMaxOSVer()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_max_os_version[$i]}
break
done
else
a=${r_qpkg_max_os_version[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_max_os_version[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDatabaseAuthor()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]] || continue
printf '%s' "${r_qpkg_author[$i]}"
return 0
done
return 1
}
QpkgGetInstalledAuthor()
{
/sbin/getcfg "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" Author -f /etc/config/qpkg.conf
}
#QpkgGetAuthorEmail()
#QpkgGetAppAuthor()
#QpkgGetAppAuthorEmail()
QpkgGetDatabaseDesc()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_description[$i]}
break
done
else
a=${r_qpkg_description[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_description[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDatabaseNote()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_note[$i]}
break
done
else
a=${r_qpkg_note[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_note[$qpkg_default_index]}
[[ $a = none ]] && return 1
fi
printf '%s' "$a"
return 0
}
QpkgGetDatabaseAbbrvs()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_abbrvs[$i]}
break
done
else
a=${r_qpkg_abbrvs[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_abbrvs[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
printf '%s' "$a"
return 0
}
QpkgGetDatabaseDependencies()
{
local alt=''
local first=''
local found=false
local g=''
local oldIFS=$IFS
local out=''
local x=''
g=${r_qpkg_depends_on[$qpkg_index]}
[[ $g = none ]] && return 1
[[ $g = default ]] && g=${r_qpkg_depends_on[$qpkg_default_index]}
if [[ $g != *'|'* ]];then
printf '%s' "$g"
return 0
fi
IFS=' '
for x in $g;do
found=false
if [[ $x != *'|'* ]];then
out+=" $x"
continue
fi
IFS='|'
for alt in $x;do
[[ -z $first && -n $alt ]] && first=$alt
if QpkgIsDatabaseArchOK "$alt";then
out+=" $alt"
found=true
break
fi
done
[[ $IFS != "$oldIFS" ]] && IFS=$oldIFS
if [[ $found = false ]];then
out+=" $first"
first=''
fi
done
printf '%s' "$out"
return 0
}
QpkgGetDatabaseDependents()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local -a ar=()
local -i i=-1
local re=\\b${qpkg_name}\\b
if QPKGs-GRindependent.Exist "$qpkg_name";then
for i in "${!r_qpkg_name[@]}";do
if [[ ${r_qpkg_depends_on[$i]} =~ $re ]];then
[[ ${ar[*]:-} != "${r_qpkg_name[$i]}" ]] && ar+=(${r_qpkg_name[$i]})
fi
done
fi
if [[ ${#ar[@]} -gt 0 ]];then
printf '%s' "${ar[*]}"
return 0
fi
return 1
}
QpkgGetDatabaseIPKs()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${r_qpkg_requires_ipks[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_requires_ipks[$qpkg_default_index]}
[[ $a = none ]] && return 1
printf '%s' "$a"
return 0
}
QpkgGetDatabaseActiveTest()
{
[[ -n $qpkg_name && $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
a=${r_qpkg_test_for_active[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_test_for_active[$qpkg_default_index]}
[[ $a = none ]] && return 1
printf '%s' "$a"
return 0
}
QpkgGetInstalledServiceAction()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local b=''
[[ -e /var/log/$a.action ]] && b=$(</var/log/${a}.action)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi
}
QpkgGetInstalledServiceResult()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local b=''
[[ -e /var/log/$a.result ]] && b=$(</var/log/${a}.result)
if [[ -n $b ]];then
printf '%s' "$b"
else
printf not-found
fi
}
QpkgInstalledServiceResultWasOk()
{
[[ -n $qpkg_name ]] || return
[[ $(QpkgGetInstalledServiceResult) = ok ]]
}
QpkgMatchAbbrv()
{
local -a ar=()
local -i i=0
local -i j=0
local -i z=1
for i in "${!r_qpkg_name[@]}";do
ar=(${r_qpkg_abbrvs[$i]})
for j in "${!ar[@]}";do
[[ ${ar[$j]} = "$1" ]] || continue
printf '%s' "${r_qpkg_name[$i]}"
z=0
break 2
done
done
return $z
}
QpkgSetIndex()
{
[[ -n ${qpkg_name:-} ]] || return
QpkgSetDefaultIndex
for qpkg_index in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$qpkg_index]} = "$qpkg_name" ]] || continue
[[ ${r_qpkg_arch[$qpkg_index]} = all || ${r_qpkg_arch[$qpkg_index]} = "$r_nas_qpkg_arch" ]] || continue
return 0
done
qpkg_index=0
return 1
}
QpkgSetDefaultIndex()
{
[[ -n ${qpkg_name:-} ]] || return
for qpkg_default_index in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$qpkg_default_index]} = "$qpkg_name" ]] || continue
return 0
done
qpkg_default_index=0
return 1
}
QpkgIsInstalledRepoSelfManaged()
{
local a=$(QpkgGetInstalledStoreID "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -z $a || $a = undefined || $a = sherpa ]]
}
QpkgIsNtInstalledRepoSelfManaged()
{
! QpkgIsInstalledRepoSelfManaged "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
QpkgIsBackupExist()
{
[[ -e $r_qpkg_bu_path/${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}.config.tar.gz ]]
}
QpkgIsUpgradable()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
QpkgIsInstalled "$a" && QpkgIsInstalledAuthorOk "$a" && QpkgIsInstalledRepoSelfManaged "$a" && [[ $(QpkgGetInstalledVer "$a") != "$(QpkgGetDatabaseVer "$a")" ]] && QpkgIsDatabaseArchOK "$a" && QpkgIsDatabaseMinOSVerOk "$a" && QpkgIsDatabaseMaxOSVerOk "$a" && QpkgIsDatabaseMinRAMOk "$a"
}
QpkgIsInstallable()
{
[[ $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
QpkgIsNtReallyInstalled && QpkgIsDatabaseArchOK && QpkgIsDatabaseMinOSVerOk && QpkgIsDatabaseMaxOSVerOk && QpkgIsDatabaseMinRAMOk
}
QpkgIsDatabaseDependent()
{
[[ $qpkg_index -gt 0 && $qpkg_default_index -gt 0 ]] || return
local a=''
a=${r_qpkg_depends_on[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_depends_on[$qpkg_default_index]}
[[ $a != none ]]
}
QpkgIsDatabaseIndependent()
{
! QpkgIsDatabaseDependent
}
QpkgIsDatabaseArchOK()
{
local a=$(QpkgGetDatabaseURL "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a && $a != none ]]
}
QpkgIsDatabaseMinRAMOk()
{
local a=$(QpkgGetDatabaseMinRAM "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || $r_nas_ram_kb -ge $a ]]
}
QpkgIsDatabaseMinOSVerOk()
{
local a=$(QpkgGetDatabaseMinOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || ${r_nas_firmware_version//.} -ge $a ]]
}
QpkgIsDatabaseMaxOSVerOk()
{
local a=$(QpkgGetDatabaseMaxOSVer "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ -n $a ]] && [[ $a = none || ${r_nas_firmware_version//.} -le $a ]]
}
QpkgIsDatabaseCanBackup()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_can_backup[$i]}
break
done
else
a=${r_qpkg_can_backup[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_can_backup[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
[[ $a = true ]]
}
QpkgIsDatabaseCanRestartToUpdate()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]] || continue
${r_qpkg_can_restart_to_update[$i]} && return 0 || break
done
return 1
}
QpkgIsDatabaseCanClean()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$a" ]] || continue
${r_qpkg_can_clean[$i]} && return 0 || break
done
return 1
}
QpkgIsDatabaseSherpaCompatible()
{
local a=''
local -i i=0
if [[ -n ${1:-} ]];then
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "$1" ]] || continue
a=${r_qpkg_is_sherpa_compatible[$i]}
break
done
else
a=${r_qpkg_is_sherpa_compatible[$qpkg_index]}
[[ $a = default ]] && a=${r_qpkg_is_sherpa_compatible[$qpkg_default_index]}
fi
[[ -n $a ]] || a=none
[[ $a = true ]]
}
QpkgIsDatabaseCanLog()
{
local -i i=0
for i in "${!r_qpkg_name[@]}";do
[[ ${r_qpkg_name[$i]} = "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}" ]] || continue
${r_qpkg_can_log[$i]} && return 0 || break
done
return 1
}
QpkgIsInstalledAutoUpdate()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
[[ $(/sbin/getcfg "$a" Auto_Update -u -f /etc/config/qpkg.conf) = TRUE ]]
}
QpkgIsInstalledAuthorOk()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
[[ $(QpkgGetDatabaseAuthor "$a") = "$(QpkgGetInstalledAuthor "$a")" ]]
}
QpkgIsNtInstalledAuthorOk()
{
! QpkgIsInstalledAuthorOk "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
QpkgIsInstalled()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
$GREP_CMD -q "^\[$a\]" /etc/config/qpkg.conf && QpkgIsInstalledAuthorOk "$a"
}
QpkgIsNtInstalled()
{
! QpkgIsInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
QpkgIsReallyInstalled()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
$GREP_CMD -q "^\[$a\]" /etc/config/qpkg.conf
}
QpkgIsNtReallyInstalled()
{
! QpkgIsReallyInstalled "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
QpkgIsInstalledMissing()
{
local a=$(QpkgGetInstalledPath "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}")
[[ $a != undefined && ! -d $a ]]
}
QpkgIsInstalledEnabled()
{
local a=${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}
[[ $(/sbin/getcfg "$a" Enable -u -f /etc/config/qpkg.conf) = TRUE ]]
}
LoadQpkgSigning()
{
r_qpkg_certificate=''
r_qpkg_signature=''
read -r -d '' r_qpkg_certificate << EOB
-----BEGIN CERTIFICATE-----
MIIDwzCCAqugAwIBAgIFALhDVuwwDQYJKoZIhvcNAQELBQAwgYAxCzAJBgNVBAYT
AlRXMQ8wDQYDVQQIDAZUYWl3YW4xDzANBgNVBAcMBlRhaXBlaTENMAsGA1UECgwE
UU5BUDEMMAoGA1UECwwDTkFTMRAwDgYDVQQDDAdRTkFQX0NBMSAwHgYJKoZIhvcN
AQkBFhFzZWN1cml0eUBxbmFwLmNvbTAeFw0yMjAzMTgwNzM5MTRaFw0yNTAzMTcw
NzM5MTRaMIGGMQswCQYDVQQGEwJUVzEPMA0GA1UECAwGVGFpd2FuMQ8wDQYDVQQH
DAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsMA05BUzEWMBQGA1UEAwwN
TGljZW5zZUNlbnRlcjEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlAcW5hcC5jb20w
ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC/bAgbZryVvBXfpBHNUKQV
sAkAfvDXjKnxa7lKHrRIcFcOnf+voUZcP1Ly9qWb782gB2eUHsUS1Xqj4CF/dUJf
FEnOBrQUo9+Q9B3x4oTRpMdky7acP4dxAbt4T92swgaReQXAewy9s9//a52HIBca
1dAA4JPwplqiZ/oh18GDCKxh84Iu9Gcu2J5e+VXEI/KUxCwKUd22aDTpv128MSoq
dYexCerCJtQbgM3cwkkMiDnFpjrsta5iFpyrNKdLoBJ7YbY3d5Onkqy4DjE8hwR7
0j7Qd+3xbMqv3FOCKeLLLn6N03IXHKP/big/MdXKY1dJQVA3/ks/knPH8mhcOM0d
AgMBAAGjPDA6MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9kb3dubG9hZC5xbmFw
LmNvbS9jcmwvcXRzX3YxLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAWlT1GDH6v8G3
laIAs2/RdxhPgtKX4aL+fnTEFNF5V2yH0G4luyq5tHQw+VCHtDM6Z3GXWhciKPAR
upbRcHq744JCFaUb6i8z1w1KVJDaQ38EVE5+JtpoPMrrnb+hKB/gGmi4PoMSpnvX
VCxLbCbBnwi19o6t/MnPbz0shvUB2NDngnal6lYQFw/F8Sr6cSjV6GAY4TOZotdu
+gunwqQtYUycEVfNyiWVk/flgED8R8oxTPl9ZoDGen+OgjkZrvgynKnqPLHyxZSd
hYSoWyWcZWkMCQ+69kOgJVvrRa7z9F9y30uAHXIUrsLV2d/dImVjApMHbZ60iALG
AVIlas0e4g==
-----END CERTIFICATE-----
EOB
read -r -d '' r_qpkg_signature << EOB
MIME-Version: 1.0
Content-Disposition: attachment;filename=\"smime.p7m\"
Content-Type: application/pkcs7-mime;smime-type=signed-data; name=\"smime.p7m\"
Content-Transfer-Encoding: base64

MIIGtAYJKoZIhvcNAQcCoIIGpTCCBqECAQExDTALBglghkgBZQMEAgEwIwYJKoZI
hvcNAQcBoBYEFAkoseBaFir08zCz63r2YA82DXzxoIIDxzCCA8MwggKroAMCAQIC
BQC4Q1bsMA0GCSqGSIb3DQEBCwUAMIGAMQswCQYDVQQGEwJUVzEPMA0GA1UECAwG
VGFpd2FuMQ8wDQYDVQQHDAZUYWlwZWkxDTALBgNVBAoMBFFOQVAxDDAKBgNVBAsM
A05BUzEQMA4GA1UEAwwHUU5BUF9DQTEgMB4GCSqGSIb3DQEJARYRc2VjdXJpdHlA
cW5hcC5jb20wHhcNMjIwMzE4MDczOTE0WhcNMjUwMzE3MDczOTE0WjCBhjELMAkG
A1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UEBwwGVGFpcGVpMQ0wCwYD
VQQKDARRTkFQMQwwCgYDVQQLDANOQVMxFjAUBgNVBAMMDUxpY2Vuc2VDZW50ZXIx
IDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tMIIBIjANBgkqhkiG9w0B
AQEFAAOCAQ8AMIIBCgKCAQEAv2wIG2a8lbwV36QRzVCkFbAJAH7w14yp8Wu5Sh60
SHBXDp3/r6FGXD9S8valm+/NoAdnlB7FEtV6o+Ahf3VCXxRJzga0FKPfkPQd8eKE
0aTHZMu2nD+HcQG7eE/drMIGkXkFwHsMvbPf/2udhyAXGtXQAOCT8KZaomf6IdfB
gwisYfOCLvRnLtieXvlVxCPylMQsClHdtmg06b9dvDEqKnWHsQnqwibUG4DN3MJJ
DIg5xaY67LWuYhacqzSnS6ASe2G2N3eTp5KsuA4xPIcEe9I+0Hft8WzKr9xTgini
yy5+jdNyFxyj/24oPzHVymNXSUFQN/5LP5Jzx/JoXDjNHQIDAQABozwwOjA4BgNV
HR8EMTAvMC2gK6AphidodHRwOi8vZG93bmxvYWQucW5hcC5jb20vY3JsL3F0c192
MS5jcmwwDQYJKoZIhvcNAQELBQADggEBAFpU9Rgx+r/Bt5WiALNv0XcYT4LSl+Gi
/n50xBTReVdsh9BuJbsqubR0MPlQh7QzOmdxl1oXIijwEbqW0XB6u+OCQhWlG+ov
M9cNSlSQ2kN/BFROfibaaDzK652/oSgf4BpouD6DEqZ711QsS2wmwZ8ItfaOrfzJ
z289LIb1AdjQ54J2pepWEBcPxfEq+nEo1ehgGOEzmaLXbvoLp8KkLWFMnBFXzcol
lZP35YBA/EfKMUz5fWaAxnp/joI5Ga74Mpyp6jyx8sWUnYWEqFslnGVpDAkPuvZD
oCVb60Wu8/Rfct9LgB1yFK7C1dnf3SJlYwKTB22etIgCxgFSJWrNHuIxggKbMIIC
lwIBATCBijCBgDELMAkGA1UEBhMCVFcxDzANBgNVBAgMBlRhaXdhbjEPMA0GA1UE
BwwGVGFpcGVpMQ0wCwYDVQQKDARRTkFQMQwwCgYDVQQLDANOQVMxEDAOBgNVBAMM
B1FOQVBfQ0ExIDAeBgkqhkiG9w0BCQEWEXNlY3VyaXR5QHFuYXAuY29tAgUAuENW
7DALBglghkgBZQMEAgGggeQwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
hkiG9w0BCQUxDxcNMjIxMjAyMDMwOTE3WjAvBgkqhkiG9w0BCQQxIgQgvtdZSm+m
c7QevdJma9Em5ycFr3I7Wo4aG40Vcx/mT5IweQYJKoZIhvcNAQkPMWwwajALBglg
hkgBZQMEASowCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBAjAKBggqhkiG9w0DBzAO
BggqhkiG9w0DAgICAIAwDQYIKoZIhvcNAwICAUAwBwYFKw4DAgcwDQYIKoZIhvcN
AwICASgwDQYJKoZIhvcNAQEBBQAEggEAuInAOUj+ebOkTqlqg3cf7v2FdKeCvZZn
cunx1xRnHJRVAAvcH/UZ3t7RF6MV5NmEQdVN79NBZl0KU1x7K3zyvcXnkacNuHnI
t+6neKKKkxJmB4hh4ljeYtx9a1RBgwH+PiYyH8+58S7+MF3MVhSH8jEiomgSbvsK
BroOCFQDoYWk14K/VIXW1scmvpNvFNBWwm19pYwi977rF+lPWzMHx/0jVXspFSEd
U48h9xKvPg6CsIlyfuKetHBjZZI6iSCvh2FZOWsD1/W2oGYkkY9Hdff24B34/res
cKXk/K9/JFAONWBbXUpxtzpBCeVJlZS1wQgu4Q+Fr6imaBXJkiyiNg==
EOB
readonly r_qpkg_certificate
readonly r_qpkg_signature
}
MakePath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined path} && -n ${2:?${FUNCNAME[0]}'()': undefined reason} ]] || return
if [[ $1 != undefined ]] && ! mkdir -p "$1";then
ShowAsError "unable to create $2 path $(ShowAsFileName "$1") $(ShowAsExitcode "$?")"
show_suggest_raise_issue=true
return 1
fi
return 0
}
ClearPath()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined parent path} && -n ${2:?${FUNCNAME[0]}'()': undefined target path} ]] || return
local parent=${1:-undefined}
local target=$($BASENAME_CMD "${2:-undefined}")
[[ -n $parent && $parent != undefined && -n $target && $target != undefined && -d $parent/$target ]] && rm -rf "${parent:?}/${target:?}"/*
}
RunAndLog()
{
[[ -n ${1:?${FUNCNAME[0]}'()': undefined commandstring} && -n ${2:?${FUNCNAME[0]}'()': undefined pathfile} ]] || return
FuncInit
MakePath "$r_run_logs_path" 'runtime logs'
local -r r_log_pathfile=$($MKTEMP_CMD "$r_run_logs_path"/"${FUNCNAME[0]}"_XXXXXX)
local -i z=0
ShowAsCommand "$1" > "$2"
DebugAsProc "exec: '$1'"
if [[ $useropt_verbose = true ]];then
eval "$1 > >($TEE_CMD $r_log_pathfile) 2>&1"
z=$?
else
(eval "$1" > "$r_log_pathfile" 2>&1)
z=$?
fi
if [[ -e $r_log_pathfile ]];then
ShowAsResultAndStdout "$z" "$(<"$r_log_pathfile")" >> "$2"
rm -f "$r_log_pathfile" 2> /dev/null
else
ShowAsResultAndStdout "$z" '<null>' >> "$2"
fi
case $z in
0|"${4:-}")
[[ ${3:-} != log:failure-only || $useropt_debug = true ]] && AddExtLogToSessLog "$2"
DebugAsDone 'exec: complete'
[[ $useropt_debug = false ]] && rm -f "$2" 2> /dev/null
;;
*)
AddExtLogToSessLog "$2"
DebugAsError 'exec: complete, but with errors'
esac
FuncExit $z
}
DeDupeWords()
{
[[ -n ${1:-} ]] || return
tr ' ' '\n' <<< "$1" | $SORT_CMD | $UNIQ_CMD | tr '\n' ' ' | $SED_CMD 's|^[[:blank:]]*||;s|[[:blank:]]*$||'
}
FileMatchesMD5()
{
[[ $($MD5SUM_CMD "${1:?${FUNCNAME[0]}'()': undefined pathfile}" | cut -f1 -d' ') = "${2:?${FUNCNAME[0]}'()': undefined checksum}" ]]
}
Pluralise()
{
[[ ${1:-0} -ne 1 ]] && printf s
}
Capitalise()
{
[[ -n ${1:-} ]] || return
if [[ $1 == sherpa* ]];then
printf '%s' "$1"
else
printf '%s' "$(Uppercase ${1:0:1})${1:1}"
fi
}
Uppercase()
{
tr 'a-z' 'A-Z' <<< "${1:-}"
}
Lowercase()
{
tr 'A-Z' 'a-z' <<< "${1:-}"
}
LTrim()
{
[[ -n ${1:-} ]] || return
printf '%s' "${1##+(' ')}"
}
RTrim()
{
[[ -n ${1:-} ]] || return
printf '%s' "${1%%+(' ')}"
}
Trim()
{
[[ -n ${1:-} ]] || return
RTrim "$(LTrim "$1")"
}
FormatAsThous()
{
local a=$($SED_CMD 's/[^0-9]*//g' <<< "${1:-}")
local b=''
local c=''
while [[ ${#a} -gt 0 ]];do
b=${a:${#a}<3?0:-3}
if [[ -z $c ]];then
c=$b
else
c=$b,$c
fi
if [[ ${#b} -eq 3 ]];then
a=${a%???}
else
break
fi
done
printf '%s' "$c"
return 0
}
FormatAsIsoBytes()
{
$AWK_CMD 'BEGIN{ u[0]="B";u[1]="kB"; u[2]="MB"; u[3]="GB"} { n = $1; i = 0; while(n > 1000) { i+=1; n= int((n/1000)+0.5) } print n u[i] } ' <<< "$1"
}
ShowTitle()
{
[[ $show_title = true && $title_shown = false && $useropt_verbose = false ]] || return
EraseThisLine
if [[ -z ${r_args_raw[*]:-} ]];then
Display "$(ShowTitleArt)"
else
Display "$(ShowAsTitleName) $(ShowAsVersion)"
fi
title_shown=true
}
ShowAsTitleName()
{
TextBrightWhite sherpa
}
ShowTitleArt()
{
Display "$(TextBrightOrange '     _')"
Display "$(TextBrightOrange ' ___| |__   ___ _ __ _ __   __ _')"
Display "$(TextBrightOrange "/ __| '_ \ / _ \ '__| '_ \ / _\` |")  $(ShowAsDescription)"
Display "$(TextBrightOrange '\__ \ | | |  __/ |  | |_) | (_| |')  $(ShowAsCopyrightBasic)"
Display "$(TextBrightOrange '|___/_| |_|\___|_|  | .__/ \__,_|')  $(ShowAsVersion)"
Display "$(TextBrightOrange '                    |_|')"
}
ShowAsDescription()
{
printf '%s' 'a mini-package-manager for QNAP NAS'
}
ShowAsCopyrightBasic()
{
printf '%s' 'copyright (C) 2017-2024 OneCD'
}
ShowAsVersion()
{
printf '%s' "v$r_this_script_ver"
}
#ShowAsEmail()
ShowAsAction()
{
TextBrightYellow '[action]'
}
ShowAsPackages()
{
TextBrightOrange '[packages]'
}
ShowAsPackageGroup()
{
TextBrightOrange '[package group]'
}
ShowAsOptions()
{
TextBrightRed '[options]'
}
ShowAsPackageName()
{
printf '%s' "${1:-${qpkg_name:?${FUNCNAME[0]}'()': undefined package name}}"
}
ShowAsFileName()
{
printf '%s' "'${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsURL()
{
TextUnderlinedCyan "${1:?${FUNCNAME[0]}'()': undefined URL}"
}
ShowAsExitcode()
{
printf '%s' "[${1:?${FUNCNAME[0]}'()': undefined exitcode}]"
}
ShowAsLogFilename()
{
printf '%s' "${r_chars_results}log file: '${1:?${FUNCNAME[0]}'()': undefined filename}'"
}
ShowAsCommand()
{
echo "${r_chars_results}command: '${1:?${FUNCNAME[0]}'()': undefined commandstring}'"
}
ShowAsResultAndStdout()
{
[[ -n ${1:-} ]] || return
[[ -n ${2:-} ]] || return
local a=$r_chars_results
[[ ${1:-0} -ne 0 ]] && a=$r_chars_alert
echo "${a}result_code: $(ShowAsExitcode "$1") ***** stdout/stderr begins below *****"
echo "$2"
echo "${a}***** stdout/stderr is complete *****"
}
DisplayProcReport()
{
[[ ${report_title_shown:=false} = false ]] || return
local a=''
[[ -n ${1:-} ]] && a="$1 "
ShowAsProc "${a}report"
report_title_shown=true
}
DebugInfoMajSepr()
{
DebugInfo "$(eval printf '%0.s=' "{1..$r_debug_log_full_width}")"
}
DebugInfoMinSepr()
{
DebugInfo "$(eval printf '%0.s-' "{1..$r_debug_log_full_width}")"
}
DebugExtLogMinSepr()
{
DebugAsLog "$(eval printf '%0.s-' "{1..$r_debug_log_full_width}")"
}
DebugScript()
{
DebugDetectTabld SCRIPT "${1:-}" "${2:-}"
}
DebugHardware()
{
case ${1:-} in
warning)
DebugWarningTabld HARDWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld HARDWARE "${2:-}" "${3:-}"
esac
}
DebugFirmware()
{
case ${1:-} in
warning)
DebugWarningTabld FIRMWARE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld FIRMWARE "${2:-}" "${3:-}"
esac
}
DebugUserspace()
{
case ${1:-} in
warning)
DebugWarningTabld USERSPACE "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld USERSPACE "${2:-}" "${3:-}"
esac
}
DebugIpk()
{
case ${1:-} in
error)
DebugErrorTabld IPK "${2:-}" "${3:-}"
;;
*)
DebugInfoTabld IPK "${2:-}" "${3:-}"
esac
}
DebugQpkg()
{
case ${1:-} in
error)
DebugErrorTabld QPKG "${2:-}" "${3:-}"
;;
warning)
DebugWarningTabld QPKG "${2:-}" "${3:-}"
;;
info)
DebugInfoTabld QPKG "${2:-}" "${3:-}"
;;
*)
DebugDetectTabld QPKG "${2:-}" "${3:-}"
esac
}
DebugDetectTabld()
{
if [[ -z ${3:-} ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsDetect "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugInfoTabld()
{
if [[ -z ${3:-} ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsInfo "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugWarningTabld()
{
if [[ -z ${3:-} ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsWarn "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugErrorTabld()
{
if [[ -z ${3:-} ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s\n" "${1:-}" "${2:-}")"
elif [[ ${3:-} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: none\n" "${1:-}" "${2:-}")"
elif [[ ${3: -1} = ' ' ]];then
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "$($SED_CMD 's| *$||' <<< "${3:-}")")"
else
DebugAsError "$(printf "%${r_debug_log_first_column_width}s: %${r_debug_log_second_column_width}s: %-s\n" "${1:-}" "${2:-}" "${3:-}")"
fi
}
DebugVar()
{
if [[ -n ${!1:-} ]];then
DebugAsVar "\$$1 : '${!1}'"
else
DebugAsVar "\$$1 : null"
fi
}
DebugArray()
{
[[ -n ${1:-} ]] || return
if [[ -n ${2:-} ]];then
DebugAsArray "\$$1 : ['$2']"
else
DebugAsArray "\$$1 : [null]"
fi
}
DebugInfo()
{
[[ -n ${1:-} ]] || return
if [[ ${2:-} = ' ' || ${2:-} = "'' " ]];then
DebugAsInfo "$1: none"
elif [[ -n ${2:-} ]];then
DebugAsInfo "$1: ${2:-}"
else
DebugAsInfo "$1"
fi
}
FuncInit()
{
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn
}
FuncExit()
{
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
return ${1:-0}
}
FuncForkInit()
{
trap '[[ -n ${action_pidfile:-} && -e $action_pidfile ]] && rm -f "$action_pidfile" 2> /dev/null;[[ -n ${pidfile:-} && -e ${pidfile:-} ]] && rm -f "$pidfile" 2> /dev/null; exit' SIGINT
original_sess_active_pathfile=$sess_active_pathfile
MakePath "$r_action_logs_path" 'action logs'
sess_active_pathfile=$($MKTEMP_CMD "$r_action_logs_path"/"${FUNCNAME[1]}"_XXXXXX)
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
eval "$var_safe_name=$(ConvertNowToNanoseconds)"
DebugAsFuncEn
}
FuncForkExit()
{
local -r r_var_name=${FUNCNAME[1]}_STARTNANOSECONDS
local var_safe_name=${r_var_name//[.-]/_}
var_safe_name=${var_safe_name//:/_}
SendActionStatus ex
DebugAsFuncEx "${1:-0}" "$(ConvertMillisecondsToFuncDuration "$(CalcMillisecondsDiffFromNanoseconds "${!var_safe_name}" "$(ConvertNowToNanoseconds)")")"
if [[ -n $sess_active_pathfile && -e $sess_active_pathfile ]];then
if [[ -s $sess_active_pathfile ]];then
$CAT_CMD "$sess_active_pathfile" >> "$original_sess_active_pathfile"
fi
rm -f "$sess_active_pathfile" 2> /dev/null
fi
[[ -n ${action_pidfile:-} && -e $action_pidfile ]] && rm -f "$action_pidfile" 2> /dev/null;[[ -n ${pidfile:-} && -e ${pidfile:-} ]] && rm -f "$pidfile" 2> /dev/null
exit ${1:-0}
}
CalcAmountDiff()
{
if [[ $2 -gt $1 ]];then
printf '%s' "$(($2-$1))"
else
printf '%s' "$(($1-$2))"
fi
} 2> /dev/null
CalcMillisecondsDiffFromNanoseconds()
{
printf '%s' "$((($2-$1)/(10**6)))"
} 2> /dev/null
ConvertSecondsToFullDate()
{
/bin/date -d @"$1" +%c | tr -s ' '
} 2> /dev/null
ConvertSecondsToTime()
{
/bin/date -d @"$1" '+%-l:%M:%S %p' | tr -s ' '
} 2> /dev/null
ConvertSecondsToDuration()
{
((h=${1:-0}/3600))
((m=(${1:-0}%3600)/60))
((s=${1:-0}%60))
if [[ $h -gt 0 ]];then
printf '%01dh:%02dm:%02ds' "$h" "$m" "$s"
elif [[ $m -gt 0 ]];then
printf '%01dm:%02ds' "$m" "$s"
else
[[ $s -eq 0 ]] && s=1
if [[ $s -eq 1 ]];then
printf '%d second' "$s"
else
printf '%d seconds' "$s"
fi
fi
} 2> /dev/null
ConvertMillisecondsToSeconds()
{
printf '%s' "$(($1/(10**3)))"
} 2> /dev/null
ConvertMillisecondsToDuration()
{
ConvertSecondsToDuration "$(ConvertMillisecondsToSeconds "$1")"
} 2> /dev/null
ConvertMillisecondsToFuncDuration()
{
if [[ ${1:-0} -lt 30000 ]];then
printf '%s' "$(FormatAsThous "${1:-0}")ms" | $TAIL_CMD -n1
else
ConvertMillisecondsToDuration "$1"
fi
} 2> /dev/null
ConvertNanosecondsToMilliseconds()
{
printf '%s' "$(($1/(10**6)))"
} 2> /dev/null
ConvertNowToFullDate()
{
/bin/date +%c | tr -s ' '
} 2> /dev/null
ConvertNowToSeconds()
{
/bin/date +%s
} 2> /dev/null
ConvertNowToMilliseconds()
{
ConvertNanosecondsToMilliseconds "$(ConvertNowToNanoseconds)"
} 2> /dev/null
ConvertNowToNanoseconds()
{
/bin/date +%s%N
} 2> /dev/null
FormatAsLongMinutesSecs()
{
local m=${1%%:*}
local s=${1#*:}
m=${m##* }
s=${s##* }
printf '%01dm:%02ds\n' "$((10#$m))" "$((10#$s))"
} 2> /dev/null
DebugAsFuncEn()
{
DebugThis "(>>) ${FUNCNAME[2]}()"
}
DebugAsFuncEx()
{
DebugThis "(<<) ${FUNCNAME[2]}|${1:-0}|${2:-}"
}
DebugAsProc()
{
[[ -n $1 ]] && DebugThis "(--) $1"
}
DebugAsDone()
{
[[ -n $1 ]] && DebugThis "(==) $1"
}
DebugAsDetect()
{
[[ -n $1 ]] && DebugThis "(**) $1"
}
DebugAsInfo()
{
[[ -n $1 ]] && DebugThis "(II) $1"
}
DebugAsWarn()
{
[[ -n $1 ]] && DebugThis "(WW) $1"
}
DebugAsError()
{
[[ -n $1 ]] && DebugThis "(EE) $1"
}
DebugAsLog()
{
[[ -n $1 ]] && DebugThis "(LL) $1"
}
DebugAsVar()
{
[[ -n $1 ]] && DebugThis "(vv) $1"
}
DebugAsArray()
{
[[ -n $1 ]] && DebugThis "(aa) $1"
}
DebugThis()
{
[[ -n ${1:-} ]] || return
[[ ${useropt_verbose:-false} = true ]] && ShowAsDebug "$1"
WriteToLog dbug "$1"
}
AddExtLogToSessLog()
{
local a=''
local b=false
if [[ $useropt_verbose = true ]];then
b=true
useropt_verbose=false
fi
DebugAsLog 'adding external log to main log'
DebugExtLogMinSepr
DebugAsLog "$(ShowAsLogFilename "${1:?${FUNCNAME[0]}'()': undefined pathfile}")"
while read -r a;do
DebugAsLog "$a"
done < "$1"
DebugExtLogMinSepr
useropt_verbose=$b
}
ShowAsProcLong()
{
ShowAsProc "${1:-} (might take a while)" "${2:-}"
} >&2
ShowAsProc()
{
local a=''
local b=''
[[ -n ${1:-} ]] && a=$1 || return
[[ -n ${2:-} ]] && b=${2:-}
if [[ ${useropt_verbose:=false} = false && ${useropt_terse:=true} = true ]] || [[ ${useropt_verbose:=false} = false && -n ${2:-} ]];then
OpStepClearWait "$(TextBrightYellow proc)" "$a $r_chars_ellipsis $b"
else
OpStepClear "$(TextBrightYellow proc)" "$a $r_chars_ellipsis $b"
fi
WriteToLog proc "${a}${b}"
} >&2
ShowAsDebug()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBlackOnCyan dbug)" "$1"
}
ShowAsNote()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightYellow note)" "$a"
WriteToLog note "$a"
} >&2
ShowAsDone()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightGreen 'done')" "$a"
WriteToLog 'done' "$a"
} >&2
ShowAsWarn()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightOrange warn)" "$a"
WriteToLog warn "$a"
} >&2
ShowAsAbort()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed bort)" "$a"
WriteToLog bort "$a"
SetError
} >&2
ShowAsFail()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed fail)" "$a"
WriteToLog fail "$a"
} >&2
ShowAsError()
{
local a=''
[[ -n ${1:-} ]] && a=$(AddPeriod "$1") || return
OpStepClear "$(TextBrightRed derp)" "$a"
WriteToLog derp "$a"
SetError
} >&2
ShowAsQuiz()
{
[[ -n ${1:-} ]] || return
OpStepClearWait "$(TextBrightOrangeBlink quiz)" "$1:"
WriteToLog quiz "$1:"
}
ShowAsQuizDone()
{
[[ -n ${1:-} ]] || return
OpStepClear "$(TextBrightOrange quiz)" "$1"
}
AddPeriod()
{
[[ -n ${1:-} ]] || return
[[ ${1: -1} != ':' && ${1: -1} != '?' && ${1: -1} != '.' ]] && printf '%s.' "$1" || printf '%s' "$1"
}
ShowAsPercentProgress()
{
local -r r_a=${1:-}
local -i b=${3:-0}
local -i c=${4:-0}
local -i d=${5:-0}
local -i e=${6:-0}
local -r r_f=$(PercFrac "$b" "$c" "$d" "$e")
if [[ ${2:-} != long ]];then
ShowAsProc "$r_a" "$r_f"
else
ShowAsProcLong "$r_a" "$r_f"
fi
[[ $((b+c+d)) -ge $e ]] && sleep 0.5
return 0
} >&2
PercFrac()
{
local -i a=$((${1:-0}+${2:-0}+${3:-0}))
local -i b=${4:-0}
local c=''
[[ $b -gt 0 ]] || return
if [[ $a -gt $b ]];then
a=$b
c='100%'
else
c="$((200*(a+1)/(b+1)%2+100*(a+1)/(b+1)))%"
fi
printf '%s' "$c ($(TextBrightWhite "$a")/$(TextBrightWhite "$b"))"
return 0
} 2> /dev/null
ShowAsIterativeProgress()
{
local -r r_a=${1:?${FUNCNAME[0]}'()': undefined action}
local -i b=${2:-0}
local -r r_c=${3:?${FUNCNAME[0]}'()': undefined suffix1}
local -i d=${4:-0}
local -r r_e=${5:?${FUNCNAME[0]}'()': undefined suffix2}
local f=''
f="$(TextBrightWhite "$b") ${r_c}$(Pluralise "$b") ($(TextBrightWhite "$d") ${r_e}$(Pluralise "$d"))"
if [[ ${6:-short} != long ]];then
ShowAsProc "$r_a" "$f"
else
ShowAsProcLong "$r_a" "$f"
fi
return 0
}
ShowAsActionLogDetail()
{
if [[ ${2:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$2"
return 1
fi
if [[ ${7:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$7"
return 1
fi
local package_type=''
local quantity_msg=''
package_type=$7$(Pluralise "$8")
case $8 in
0)
quantity_msg='no '
;;
1)
:
;;
*)
quantity_msg="$8 "
esac
if [[ ${8:-undefined} = undefined ]];then
ShowAsError "${FUNCNAME[0]}() was provided an undefined value for \$8"
return 1
fi
case ${4:-} in
failed)
if [[ -n "${6:-}" ]];then
case $3 in
download|?(reas)sign|uninstall)
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
;;
*)
if QpkgIsDatabaseCanLog "$2";then
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "For more information: /etc/init.d/$($BASENAME_CMD "$(QpkgGetInstalledServicePathFile "$2")") log"
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" "$6"
fi
esac
else
DisplayAsIndentActionResultDurationReason "$3" "$2 $package_type" "$5" 'no reason was provided by the service-script'
fi
;;
skipped*)
if [[ -n "${6:-}" ]];then
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "$6"
else
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" '' "no reason provided"
fi
;;
*)
DisplayAsIndentActionResultDurationReason "$3" "${quantity_msg}${2} $package_type" "$5" "$6"
esac
return 0
}
OpStepClearWait()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
DisplayWait "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
OpStepClear()
{
local -i n=4
[[ ${useropt_colourful:=false} = true ]] && n=10
Display "$(printf "\033[2K\r%-${n}s: %s" "${1:-}" "${2:-}")"
return 0
}
WriteToLog()
{
[[ -n ${1:-} && -n ${2:-} ]] || return
[[ ${useropt_debug:=false} = true && -n ${sess_active_pathfile:-} ]] && printf '%-4s: %s\n' "$(StripANSICodes "$1")" "$(StripANSICodes "$2")" >> "$sess_active_pathfile"
}
TextBrightGreen()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;32m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightYellow()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;33m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightOrange()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightOrangeBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;38;5;214m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightRed()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightRedBlink()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;5;31m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
#TextCyan()
TextDarkGrey()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;90m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
#TextUnderlined()
TextUnderlinedCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[4;36m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBlackOnCyan()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[30;46m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
TextBrightWhite()
{
[[ -n ${1:-} ]] || return
if [[ ${useropt_colourful:=false} = true ]];then
printf '\033[1;97m%s\033[0m' "$1"
else
printf '%s' "$1"
fi
} 2> /dev/null
Tableise()
{
awk '{
nf[NR]=NF
for (i = 1;i <= NF; i++) {
cell[NR,i] = $i
gsub(/\033\[[0-9;]*[mK]/, "", $i)
len[NR,i] = l = length($i)
if (l > max[i]) max[i] = l
}
}
END {
for (row = 1;row <= NR; row++) {
for (col = 1;col < nf[row]; col++)
printf "%s%*s%s", cell[row,col], max[col]-len[row,col], "", OFS
print cell[row,nf[row]]
}
}' FS='|' OFS="$(printf "%$((r_report_column_spacing))s")"
}
StripANSICodes()
{
if [[ ${sed_ext_regex_supported:=false} = true ]];then
echo -en "${1:-}" | /bin/sed -r 's/\x1b\[[0-9;]*m//g'
elif [[ -e /opt/bin/sed && -L /opt/etc/passwd ]];then
echo -en "${1:-}" | /opt/bin/sed -r 's/\x1b\[[0-9;]*m//g'
else
echo -en "${1:-}"
fi
} 2> /dev/null
UpdateParentCapabilities()
{
SendParentChangeEnv UpdateColourisation
SendParentChangeEnv UpdateSedRexegSupport
SendParentChangeEnv UpdateSleepDecimalSecondsSupport
}
UpdateCapabilities()
{
UpdateColourisation
UpdateSedRexegSupport
UpdateSleepDecimalSecondsSupport
}
UpdateColourisation()
{
if [[ -e /opt/bin/sed && -L /opt/etc/passwd && $(LoadSetting Colourful "$colourful_default") = true ]];then
useropt_colourful=true
SendParentChangeEnv 'useropt_colourful=true'
else
useropt_colourful=false
SendParentChangeEnv 'useropt_colourful=false'
fi
}
UpdateSedRexegSupport()
{
OsIsSupportSedExtRegex && sed_ext_regex_supported=true || sed_ext_regex_supported=false
}
UpdateSleepDecimalSecondsSupport()
{
OsIsSupportDecimalSleepSeconds && sleep_decimal_seconds_supported=true || sleep_decimal_seconds_supported=false
}
HideCursor()
{
[[ $useropt_verbose = false ]] && printf '\033[?25l'
}
ShowCursor()
{
printf '\033[?25h'
}
HideKeystrokes()
{
[[ $useropt_verbose = false && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD '-echo'
}
ShowKeystrokes()
{
[[ -n ${GNU_STTY_CMD:-} && -e $GNU_STTY_CMD && -t 0 ]] && $GNU_STTY_CMD 'echo'
}
sleep()
{
local n=${1:-}
[[ ${n//.} -eq 0 ]] && n=1
if [[ ${sleep_decimal_seconds_supported:=false} = true ]];then
$SLEEP_CMD "$n"
elif [[ -e $GNU_SLEEP_CMD && -L /opt/etc/passwd ]];then
$GNU_SLEEP_CMD "$n"
else
$SLEEP_CMD "$((${n%.*}+1))"
fi
return 0
} 2> /dev/null
LoadObjects()
{
[[ ${objects_loaded:=false} = false ]] || return 0
FuncInit
LoadLists
if [[ ! -e $PWD/dont-refresh-objects ]];then
if [[ ! -e $r_objects_pathfile ]] || ! IsThisFileRecent "$r_objects_pathfile" "$r_file_change_threshold_minutes";then
ShowAsProc 'download objects'
if $CURL_CMD --silent --fail "$r_objects_archive_url" > "$r_objects_archive_pathfile";then
$TAR_CMD --extract --gzip --no-same-owner --file="$r_objects_archive_pathfile" --directory="$r_cache_path"
fi
fi
fi
if [[ ! -e $r_objects_pathfile ]];then
ShowAsAbort 'objects missing'
FuncExit 1;exit
fi
ShowAsProc objects
. "$r_objects_pathfile"
objects_loaded=true
readonly r_objects_version
DebugVar r_objects_version
FuncExit
}
LoadPackages()
{
[[ ${packages_loaded:=false} = false ]] || return 0
FuncInit
local previous=''
LoadObjects
if [[ ! -e $PWD/dont-refresh-packages ]];then
if [[ ! -e $r_packages_pathfile ]] || ! IsThisFileRecent "$r_packages_pathfile" "$r_file_change_threshold_minutes";then
ShowAsProc 'download QPKG list'
if $CURL_CMD --silent --fail "$r_packages_archive_url" > "$r_packages_archive_pathfile";then
$TAR_CMD --extract --gzip --no-same-owner --file="$r_packages_archive_pathfile" --directory="$r_cache_path"
fi
InitQPKGsTiers
fi
fi
if [[ ! -e $r_packages_pathfile ]];then
ShowAsAbort 'QPKG list missing'
FuncExit 1;exit
fi
ShowAsProc QPKGs
unset r_qpkg_abbrvs
unset r_qpkg_appl_author
unset r_qpkg_appl_author_email
unset r_qpkg_appl_version
unset r_qpkg_arch
unset r_qpkg_author
unset r_qpkg_author_email
unset r_qpkg_can_backup
unset r_qpkg_can_clean
unset r_qpkg_can_log
unset r_qpkg_can_restart_to_update
unset r_qpkg_conflicts_with
unset r_qpkg_depends_on
unset r_qpkg_description
unset r_qpkg_hash
unset r_qpkg_is_sherpa_compatible
unset r_qpkg_max_os_version
unset r_qpkg_min_os_version
unset r_qpkg_min_ram_kb
unset r_qpkg_name
unset r_qpkg_note
unset r_qpkg_requires_ipks
unset r_qpkg_test_for_active
unset r_qpkg_url
unset r_qpkg_version
r_packages_epoch=undefined
r_qpkg_abbrvs+=('')
r_qpkg_appl_author+=('')
r_qpkg_appl_author_email+=('')
r_qpkg_appl_version+=('')
r_qpkg_arch+=('')
r_qpkg_author+=('')
r_qpkg_author_email+=('')
r_qpkg_can_backup+=('')
r_qpkg_can_clean+=('')
r_qpkg_can_log+=('')
r_qpkg_can_restart_to_update+=('')
r_qpkg_conflicts_with+=('')
r_qpkg_depends_on+=('')
r_qpkg_description+=('')
r_qpkg_hash+=('')
r_qpkg_is_sherpa_compatible+=('')
r_qpkg_max_os_version+=('')
r_qpkg_min_os_version+=('')
r_qpkg_min_ram_kb+=('')
r_qpkg_name+=('')
r_qpkg_note+=('')
r_qpkg_requires_ipks+=('')
r_qpkg_test_for_active+=('')
r_qpkg_url+=('')
r_qpkg_version+=('')
. "$r_packages_pathfile"
readonly r_qpkg_abbrvs
readonly r_qpkg_appl_author
readonly r_qpkg_appl_author_email
readonly r_qpkg_appl_version
readonly r_qpkg_arch
readonly r_qpkg_author
readonly r_qpkg_author_email
readonly r_qpkg_can_backup
readonly r_qpkg_can_clean
readonly r_qpkg_can_log
readonly r_qpkg_can_restart_to_update
readonly r_qpkg_conflicts_with
readonly r_qpkg_depends_on
readonly r_qpkg_description
readonly r_qpkg_hash
readonly r_qpkg_is_sherpa_compatible
readonly r_qpkg_max_os_version
readonly r_qpkg_min_os_version
readonly r_qpkg_min_ram_kb
readonly r_qpkg_name
readonly r_qpkg_note
readonly r_qpkg_requires_ipks
readonly r_qpkg_test_for_active
readonly r_qpkg_url
readonly r_qpkg_version
packages_loaded=true
readonly r_base_qpkg_conflicts_with
readonly r_base_qpkg_warnings
readonly r_essential_ipks
readonly r_essential_pips
readonly r_exclusion_pips
readonly r_min_perl_version
readonly r_min_python_version
readonly r_packages_epoch
DebugVar r_packages_epoch
for qpkg_name in "${r_qpkg_name[@]}";do
[[ $previous = "$qpkg_name" ]] && continue || previous=$qpkg_name
QPKGs-GRall:Add "$qpkg_name"
done
BuildQPKGsTiers
FuncExit
}
CaughtSIGINT()
{
trap - SIGINT
[[ -n ${r_display_inhibit_pathfile:-} ]] && [[ -d $($DIRNAME_CMD "$r_display_inhibit_pathfile") ]] && /bin/touch "$r_display_inhibit_pathfile"
[[ -n ${r_action_abort_pathfile:-} ]] && [[ -d $($DIRNAME_CMD "$r_action_abort_pathfile") ]] && /bin/touch "$r_action_abort_pathfile"
EraseThisLine
ShowAsAbort 'caught SIGINT'
CloseActionMsgPipe
exit
}
CaughtEXIT()
{
trap - EXIT
ShowKeystrokes
ShowCursor
ReleaseLockfile
}
readonly r_script_startseconds=$(ConvertNowToSeconds)
trap CaughtSIGINT SIGINT
trap CaughtEXIT EXIT
Init || exit
ProcActions
ShowResults
ErrorIsNt
