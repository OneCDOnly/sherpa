#!/bin/bash

Init()
	{

	script_file="sabnzbd-installer.sh"
	script_version="2017.02.28.01 (beta)"
	qpkg_pathfile="/etc/config/qpkg.conf"
	working_path="/share/Public/${script_file}.tmp"
	sab_launcher_pathfile="/etc/init.d/sabnzbd.sh"
	sab_ini_file="sabnzbd.ini"
	install_log_file="install.log"
	download_log_file="download.log"
	exitcode=0

	echo "$script_file ($script_version)"
	echo

	}

GetVer()
	{

	# a "reimagining" of Clinton Hall's arch detection code ;)
	# I'll add new rules as required.

	local arc="$(uname -m)"

	[ "$arc" == "armv5tejl" ] && ver="arm"
	[ "$arc" == "armv5tel" ] && ver="arm"
	[ "$arc" == "i686" ] && ver="x86"
	[ "$arc" == "x86_64" ] && ver="x86"
	[ "$arc" == "armv71" ] && ver="x31"

	if [ -z "$ver" ]; then
		ShowFailed "could not determine NAS architecture ($arc)"
		exitcode=1
	fi

	}

CreateWorkingPath()
	{

	mkdir -p "$working_path"

	if [ "$?" -ne "0" ]; then
		ShowFailed "unable to create working directory ($working_path)"
		exitcode=2
		return
	fi

	cd "$working_path"

	}

StopSab()
	{

	if [ -e "$sab_launcher_pathfile" ]; then
		"$sab_launcher_pathfile" stop > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon stopped"
		else
			ShowFailed "could not stop SABnzbd daemon"
			exitcode=1
		fi
	fi

	}

BackupIni()
	{

	StopSab

	sab_installed_path="$(getcfg "SABnzbdplus" Install_Path -f "$qpkg_pathfile")"
	sab_ini_orig_pathfile="${sab_installed_path}/Config/${sab_ini_file}"
	sab_ini_backup_pathfile="${working_path}/${sab_ini_file}"

	if [ -e "$sab_ini_orig_pathfile" ]; then
		ShowProcessing "backing-up ($sab_ini_file)"
		cp "$sab_ini_orig_pathfile" "$sab_ini_backup_pathfile"
		backup_made=true
	else
		backup_made=false
	fi

	}

UninstallExistingQPKG()
	{

	grep -F "[$1]" < "$qpkg_pathfile" > /dev/null

	if [ "$?" -eq "0" ]; then
		ShowWarning "detected previous ($1) installation"
		qpkg_installed_path="$(getcfg "$1" Install_Path -f "$qpkg_pathfile")"

		ShowProcessing "uninstalling previous ($1)"
		${qpkg_installed_path}/.uninstall.sh > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "previous ($1) uninstalled"
		else
			ShowFailed "unable to uninstall ($1)"
			exitcode=3
		fi
	fi

	}

UninstallEntwarePython()
	{

	# forcibly remove Python packages so they will be reinstalled

	IsPackageInstalled "Entware-3x"

	if [ "$?" -ne "0" ]; then
		ShowProcessing "uninstalling Entware Python"

		opkg -V0 remove python --force-removal-of-dependent-packages --force-remove 2> /dev/null
	fi

	}

DownloadAllQPKGs()
	{

	IsPackageInstalled "Python" && DownloadAndInstallQPKG "http://download.qnap.com/QPKG/Python_2.7.3_${ver}.zip" #&
	IsPackageInstalled "Entware-3x" && DownloadAndInstallQPKG "http://entware-3x.zyxmon.org/binaries/other/Entware-3x_0.99std.qpkg" #&

	IsPackageInstalled "git"
	if [ "$?" -eq "0" ]; then
		[ "$ver" == "x86" ] && giturl="https://www.dropbox.com/s/fiay536scdscew7/git_2.1.0_x86.qpkg"
		[ "$ver" == "arm" ] && giturl="https://www.dropbox.com/s/li00l16znp0zcue/git_2.1.0_arm.qpkg"
		[ "$ver" == "x31" ] && giturl="https://www.dropbox.com/s/aixw0rbzk3skm32/git_2.1.1_x31.qpkg"
		DownloadAndInstallQPKG "$giturl"
	fi

	[ "$exitcode" -eq "0" ] && DownloadAndInstallQPKG "http://bit.ly/2jPntF9" "SABnzbdplus_170131.qpkg"
	[ "$exitcode" -eq "0" ] && StopSab

	}

ReloadProfile()
	{

	. /etc/profile > /dev/null
	. /root/.profile > /dev/null

	cd "$working_path"

	}

InstallPythonPipModules()
	{

	DownloadAndExecute "Python via Entware" "opkg update; opkg install python python-pip gcc python-cffi python-pyopenssl && opkg install python-dev --force-overwrite"
	DownloadAndExecute "pip modules" "pip install --upgrade pip setuptools && pip install http://www.golug.it/pub/yenc/yenc-0.4.0.tar.gz cheetah"

	}

SwitchPython()
	{

	[ "$exitcode" -eq "0" ] && "$sab_launcher_pathfile" start > /dev/null
	sed -i 's|/usr/bin/python2.7|/opt/bin/python|' /etc/init.d/sabnzbd.sh

	}

CreateYENCLinks()
	{

	ent_python_path="$(getcfg "Entware-3x" Install_Path -f /etc/config/qpkg.conf)/lib/python2.7/site-packages"
	sab_python_path="$(getcfg "SABnzbdplus" Install_Path -f /etc/config/qpkg.conf)/$ver/python"
	ln -fs "${ent_python_path}/yenc.py" "$sab_python_path"
	ln -fs "${ent_python_path}/_yenc.so" "$sab_python_path"

	}

StartSab()
	{

	if [ -e "$sab_launcher_pathfile" ]; then
		"$sab_launcher_pathfile" start > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon started"
		else
			ShowFailed "could not start SABnzbd daemon"
			exitcode=1
		fi
	fi

	}

RestoreIni()
	{

	if [ "$backup_made" == "true" ]; then
		ShowProcessing "restoring ($sab_ini_orig_pathfile)"
		cp "$sab_ini_backup_pathfile" "$sab_ini_orig_pathfile"
	fi

	}

RestartSab()
	{

	if [ -e "$sab_launcher_pathfile" ]; then
		"$sab_launcher_pathfile" restart > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon restarted"
		else
			ShowFailed "could not restart SABnzbd daemon"
			exitcode=1
		fi
	fi

	}

IsPackageInstalled()
	{

	# If package has been installed, check that it has also been enabled.
	# If not enabled, then enable it.
	# If not installed, return 1

	# $1 = package name to check/enable

	if [ $(grep -F "[$1]" < "$qpkg_pathfile") ]; then
		ShowInfo "($1) already installed"
		[ "$(getcfg "$1" Enable -u -f "$qpkg_pathfile")" != "TRUE" ] && setcfg "$1" Enable TRUE -f "$qpkg_pathfile"
	fi

	}

ColourTextBrightGreen()
	{

	echo -en '\E[1;32m'"$(PrintResetColours "$1")"

	}

ColourTextBrightOrange()
	{

	echo -en '\E[1;38;5;214m'"$(PrintResetColours "$1")"

	}

ColourTextBrightRed()
	{

	echo -en '\E[1;31m'"$(PrintResetColours "$1")"

	}

ColourTextBrightWhite()
	{

	echo -en '\E[1;97m'"$(PrintResetColours "$1")"

	}

PrintResetColours()
	{

	echo -en "$1"'\E[0m'

	}

ShowLogLine()
	{

	# $1 = pass/fail
	# $2 = message

	printf "%-10s %-33s\n" "$1" "$2"

	}

ShowSuccess()
	{

	ShowLogLine "[   $(ColourTextBrightGreen "OK")   ]" "$1"

	}

ShowWarning()
	{

	ShowLogLine "[$(ColourTextBrightOrange "WARNING") ]" "$1"

	}

ShowInfo()
	{

	ShowLogLine "[  $(ColourTextBrightWhite "INFO")  ]" "$1"

	}

ShowFailed()
	{

	ShowLogLine "[ $(ColourTextBrightRed "FAILED") ]" "$1"

	}

ShowProcessing()
	{

	ShowLogLine "[  --->  ]" "$1"

	}

DownloadAndExecute()
	{

	# $1 = package display name
	# $2 = command(s) to run

	ShowProcessing "downloading and installing ($1)"

	install_msgs=$(eval $2)

	if [ "$?" -eq "0" ]; then
		ShowSuccess "installed ($1)"
	else
		ShowFailed "($1) installation failed"
		echo "$install_msgs" > "$(echo "$1" | tr " " "_").$install_log_file"
		exitcode=6
	fi

	}

DownloadAndInstallQPKG()
	{

	# $1 = QPKG URL
	# $2 = package name (optional)

	[ -z "$2" ] && target_qpkg_file=$(basename "$1") || target_qpkg_file="$2"

	if [ ! -e "$target_qpkg_file" ]; then
		ShowProcessing "downloading ($target_qpkg_file)"

		/usr/bin/wget -q -o "$target_qpkg_file.$download_log_file" "$1" -O "$target_qpkg_file"

		if [ "$?" -eq "0" ]; then
			ShowSuccess "downloaded ($target_qpkg_file)"
			[ -e "$target_qpkg_file.$download_log_file" ] && rm -f "$target_qpkg_file.$download_log_file"
		fi
	else
		ShowInfo "file ($target_qpkg_file) already downloaded"
	fi

	if [ "$?" -eq "0" ]; then
		extension="${target_qpkg_file##*.}"

		if [ "$extension" == "zip" ]; then
			unzip -nq "$target_qpkg_file"
			target_qpkg_file="${target_qpkg_file%.*}.qpkg"
		fi

		ShowProcessing "installing ($target_qpkg_file)"

		install_msgs=$((sh "$target_qpkg_file")2>&1)

		if [ "$?" -eq "10" ]; then
			ShowSuccess "installed ($target_qpkg_file)"
		else
			ShowFailed "installation failed ($target_qpkg_file)"
			echo "$install_msgs" > "$target_qpkg_file.$install_log_file"
			exitcode=5
		fi
	else
		ShowFailed "download failed ($target_qpkg_file)"
		exitcode=4
	fi

	}

Init
GetVer
[ "$exitcode" -eq "0" ] && CreateWorkingPath
[ "$exitcode" -eq "0" ] && BackupIni
[ "$exitcode" -eq "0" ] && UninstallExistingQPKG SABnzbdplus
[ "$exitcode" -eq "0" ] && UninstallEntwarePython
[ "$exitcode" -eq "0" ] && DownloadAllQPKGs
[ "$exitcode" -eq "0" ] && ReloadProfile
[ "$exitcode" -eq "0" ] && InstallPythonPipModules
[ "$exitcode" -eq "0" ] && SwitchPython
[ "$exitcode" -eq "0" ] && CreateYENCLinks
[ "$exitcode" -eq "0" ] && StartSab
[ "$exitcode" -eq "0" ] && RestoreIni
[ "$exitcode" -eq "0" ] && RestartSab

echo

if [ "$exitcode" -eq "0" ]; then
	ShowSuccess "SABnzbd has been successfully installed"
else
	ShowFailed "SABnzbd install failed"
fi

exit "$exitcode"
