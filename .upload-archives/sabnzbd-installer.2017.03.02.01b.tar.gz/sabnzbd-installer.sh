#!/bin/bash

Init()
	{

	local script_file="sabnzbd-installer.sh"
	local script_version="2017.03.02.01b"
	QPKG_CONFIG_PATHFILE="/etc/config/qpkg.conf"
	WORKING_PATH="/share/Public/${script_file}.tmp"
	SAB_INIT_PATHFILE="/etc/init.d/sabnzbd.sh"
	SAB_INI_FILE="sabnzbd.ini"
	INSTALL_LOG_FILE="install.log"
	DOWNLOAD_LOG_FILE="download.log"
	exitcode=0

	echo "$script_file ($script_version)"
	echo

	}

GetVer()
	{

	# a "reimagining" of Clinton Hall's arch detection code ;)
	# I'll add new rules as required.

	local arc="$(uname -m)"

	[ "$arc" == "armv5tejl" ] && VER="arm"
	[ "$arc" == "armv5tel" ] && VER="arm"
	[ "$arc" == "i686" ] && VER="x86"
	[ "$arc" == "x86_64" ] && VER="x86"
	[ "$arc" == "armv71" ] && VER="x31"

	if [ -z "$VER" ]; then
		ShowFailed "could not determine NAS architecture ($arc)"
		exitcode=1
	fi

	}

CreateWorkingPath()
	{

	mkdir -p "$WORKING_PATH"

	if [ "$?" -ne "0" ]; then
		ShowFailed "unable to create working directory ($WORKING_PATH)"
		exitcode=2
		return
	fi

	cd "$WORKING_PATH"

	}

StopSab()
	{

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		"$SAB_INIT_PATHFILE" stop > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon stopped"
		else
			ShowFailed "could not stop SABnzbd daemon"
			exitcode=3
		fi
	fi

	}

BackupSabIni()
	{

	local sab_installed_path="$(getcfg "SABnzbdplus" Install_Path -f "$QPKG_CONFIG_PATHFILE")"
	SAB_INI_ORIG_PATHFILE="${sab_installed_path}/Config/${SAB_INI_FILE}"
	SAB_INI_BACKUP_PATHFILE="${WORKING_PATH}/${SAB_INI_FILE}"

	if [ -e "$SAB_INI_ORIG_PATHFILE" ]; then
		cp "$SAB_INI_ORIG_PATHFILE" "$SAB_INI_BACKUP_PATHFILE"

		if [ "$?" -eq "0" ]; then
			ShowSuccess "backup created ($SAB_INI_BACKUP_PATHFILE)"
			backup_made=true
		else
			ShowFailed "could not create backup of ($SAB_INI_ORIG_PATHFILE)"
			backup_made=false
			exitcode=4
		fi
	else
		backup_made=false
	fi

	}

UninstallExistingQPKG()
	{

	qpkg_installed_path="$(getcfg "$1" Install_Path -f "$QPKG_CONFIG_PATHFILE")"

	if [ "$?" -eq "0" ]; then
		qpkg_installed_path="$(getcfg "$1" Install_Path -f "$QPKG_CONFIG_PATHFILE")"

		if [ -e "${qpkg_installed_path}/.uninstall.sh" ]; then
			${qpkg_installed_path}/.uninstall.sh > /dev/null

			if [ "$?" -eq "0" ]; then
				ShowSuccess "($1) uninstalled"
			else
				ShowFailed "unable to uninstall ($1)"
				exitcode=5
			fi
		fi
	fi

	}

UninstallEntwarePython()
	{

	# forcibly remove Python packages so they will be reinstalled

	IsQPKGNotInstalled "Entware-3x"

	if [ "$?" -ne "0" ]; then
		msg="Python via Entware"
		ShowProcessing "uninstalling ($msg)"
		opkg -V0 remove python --force-removal-of-dependent-packages --force-remove 2> /dev/null

		true # this is cheating ;)
		# opkg sometimes fails with
			# Collected errors:
			# * pkg_run_script: Internal error: python-cryptography has a NULL tmp_unpack_dir.
		# so, until I can reliably remove Python without error, set returncode as 'true'.

		if [ "$?" -eq "0" ]; then
			ShowSuccess "($msg) uninstalled"
		else
			ShowFailed "unable to uninstall ($msg)"
			exitcode=6
		fi
	fi

	}

DownloadInstallAllRequiredQPKGs()
	{

	IsQPKGNotInstalled "Python" && DownloadInstallQPKG "http://download.qnap.com/QPKG/Python_2.7.3_${VER}.zip" #&
	IsQPKGNotInstalled "Entware-3x" && DownloadInstallQPKG "http://entware-3x.zyxmon.org/binaries/other/Entware-3x_0.99std.qpkg" #&

	IsQPKGNotInstalled "git"
	if [ "$?" -eq "0" ]; then
		[ "$VER" == "x86" ] && giturl="https://www.dropbox.com/s/fiay536scdscew7/git_2.1.0_x86.qpkg"
		[ "$VER" == "arm" ] && giturl="https://www.dropbox.com/s/li00l16znp0zcue/git_2.1.0_arm.qpkg"
		[ "$VER" == "x31" ] && giturl="https://www.dropbox.com/s/aixw0rbzk3skm32/git_2.1.1_x31.qpkg"
		DownloadInstallQPKG "$giturl"
	fi

	[ "$exitcode" -eq "0" ] && DownloadInstallQPKG "http://bit.ly/2jPntF9" "SABnzbdplus_170131.qpkg"
	[ "$exitcode" -eq "0" ] && StopSab

	}

ReloadProfile()
	{

	. /etc/profile > /dev/null
	. /root/.profile > /dev/null

	cd "$WORKING_PATH"

	}

InstallPythonPipModules()
	{

	DownloadAndExecute "Python via Entware" "opkg update; opkg install python python-pip gcc python-cffi python-pyopenssl && opkg install python-dev --force-overwrite"
	DownloadAndExecute "pip modules" "pip install --upgrade pip setuptools && pip install http://www.golug.it/pub/yenc/yenc-0.4.0.tar.gz cheetah"

	}

SwitchPython()
	{

	[ "$exitcode" -eq "0" ] && "$SAB_INIT_PATHFILE" start > /dev/null
	sed -i 's|/usr/bin/python2.7|/opt/bin/python|' "$SAB_INIT_PATHFILE"

	}

CreateYENCLinks()
	{

	local ent_python_path="$(getcfg "Entware-3x" Install_Path -f "$QPKG_CONFIG_PATHFILE")/lib/python2.7/site-packages"
	local sab_python_path="$(getcfg "SABnzbdplus" Install_Path -f "$QPKG_CONFIG_PATHFILE")/$VER/python"

	ln -fs "${ent_python_path}/yenc.py" "$sab_python_path"
	ln -fs "${ent_python_path}/_yenc.so" "$sab_python_path"

	}

StartSab()
	{

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		"$SAB_INIT_PATHFILE" start > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon started"
		else
			ShowFailed "could not start SABnzbd daemon"
			exitcode=7
		fi
	fi

	}

RestoreSabIni()
	{

	if [ "$backup_made" == "true" ]; then
		ShowProcessing "restoring ($SAB_INI_ORIG_PATHFILE)"
		cp "$SAB_INI_BACKUP_PATHFILE" "$SAB_INI_ORIG_PATHFILE"
	fi

	}

RestartSab()
	{

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		"$SAB_INIT_PATHFILE" restart > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon restarted"
		else
			ShowFailed "could not restart SABnzbd daemon"
			exitcode=8
		fi
	fi

	}

IsQPKGNotInstalled()
	{

	# If package has been installed, check that it has also been enabled.
	# If not enabled, then enable it.
	# If not installed, return 1

	# $1 = package name to check/enable

	if [ $(grep -F "[$1]" < "$QPKG_CONFIG_PATHFILE") ]; then
		ShowInfo "package ($1) is already installed"
		[ "$(getcfg "$1" Enable -u -f "$QPKG_CONFIG_PATHFILE")" != "TRUE" ] && setcfg "$1" Enable TRUE -f "$QPKG_CONFIG_PATHFILE"
	fi

	}

ColourTextBrightGreen()
	{

	echo -en '\E[1;32m'"$(PrintResetColours "$1")"

	}

ColourTextBrightOrange()
	{

	echo -en '\E[1;38;5;214m'"$(PrintResetColours "$1")"

	}

ColourTextBrightRed()
	{

	echo -en '\E[1;31m'"$(PrintResetColours "$1")"

	}

ColourTextBrightWhite()
	{

	echo -en '\E[1;97m'"$(PrintResetColours "$1")"

	}

PrintResetColours()
	{

	echo -en "$1"'\E[0m'

	}

ShowLogLine()
	{

	# $1 = pass/fail
	# $2 = message

	printf "%-10s %-33s\n" "$1" "$2"

	}

ShowSuccess()
	{

	ShowLogLine "[   $(ColourTextBrightGreen "OK")   ]" "$1"

	}

ShowWarning()
	{

	ShowLogLine "[$(ColourTextBrightOrange "WARNING") ]" "$1"

	}

ShowInfo()
	{

	ShowLogLine "[  $(ColourTextBrightWhite "INFO")  ]" "$1"

	}

ShowFailed()
	{

	ShowLogLine "[ $(ColourTextBrightRed "FAILED") ]" "$1"

	}

ShowProcessing()
	{

	ShowLogLine "[  --->  ]" "$1"

	}

DownloadAndExecute()
	{

	# $1 = package display name
	# $2 = command(s) to run

	ShowProcessing "downloading and installing ($1)"

	local install_msgs=$(eval $2)

	if [ "$?" -eq "0" ]; then
		ShowSuccess "installed ($1)"
	else
		ShowFailed "($1) installation failed"
		echo "$install_msgs" > "$(echo "$1" | tr " " "_").$INSTALL_LOG_FILE"
		exitcode=9
	fi

	}

DownloadInstallQPKG()
	{

	# $1 = QPKG URL
	# $2 = package name (optional)

	[ -z "$2" ] && target_qpkg_file=$(basename "$1") || target_qpkg_file="$2"

	if [ ! -e "$target_qpkg_file" ]; then
		ShowProcessing "downloading ($target_qpkg_file)"

		/usr/bin/wget -q -o "$target_qpkg_file.$DOWNLOAD_LOG_FILE" "$1" -O "$target_qpkg_file"

		if [ "$?" -eq "0" ]; then
			ShowSuccess "downloaded ($target_qpkg_file)"
			[ -e "$target_qpkg_file.$DOWNLOAD_LOG_FILE" ] && rm -f "$target_qpkg_file.$DOWNLOAD_LOG_FILE"
		fi
	else
		ShowInfo "file ($target_qpkg_file) is already downloaded"
	fi

	if [ "$?" -eq "0" ]; then
		if [ "${target_qpkg_file##*.}" == "zip" ]; then
			unzip -nq "$target_qpkg_file"
			target_qpkg_file="${target_qpkg_file%.*}.qpkg"
		fi

		ShowProcessing "installing ($target_qpkg_file)"

		local install_msgs=$((sh "$target_qpkg_file")2>&1)

		result=$?

		if [ "$result" -eq "0" ]; then
			ShowSuccess "installed ($target_qpkg_file)"
		else
			ShowFailed "installation failed ($target_qpkg_file)"
			echo -e "${install_msgs}\nresultcode=[$result]" > "$target_qpkg_file.$INSTALL_LOG_FILE"

			exitcode=11
		fi
	else
		ShowFailed "download failed ($target_qpkg_file)"
		exitcode=10
	fi

	}

Init
GetVer
[ "$exitcode" -eq "0" ] && CreateWorkingPath
[ "$exitcode" -eq "0" ] && StopSab
[ "$exitcode" -eq "0" ] && BackupSabIni
[ "$exitcode" -eq "0" ] && UninstallExistingQPKG SABnzbdplus
[ "$exitcode" -eq "0" ] && UninstallEntwarePython
[ "$exitcode" -eq "0" ] && DownloadInstallAllRequiredQPKGs
[ "$exitcode" -eq "0" ] && ReloadProfile
[ "$exitcode" -eq "0" ] && InstallPythonPipModules
[ "$exitcode" -eq "0" ] && SwitchPython
[ "$exitcode" -eq "0" ] && CreateYENCLinks
[ "$exitcode" -eq "0" ] && StartSab
[ "$exitcode" -eq "0" ] && RestoreSabIni
[ "$exitcode" -eq "0" ] && RestartSab

echo

if [ "$exitcode" -eq "0" ]; then
	ShowSuccess "SABnzbd has been successfully installed"
else
	ShowFailed "SABnzbd install failed"
fi

exit "$exitcode"
