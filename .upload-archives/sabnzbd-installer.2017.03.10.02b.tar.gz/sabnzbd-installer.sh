#!/bin/bash

debug=false

[ ! -z "$1" ] && [ "$1" == "--debug" ] && debug=true

Init()
	{

	DebugFuncEntry

	local SCRIPT_FILE="sabnzbd-installer.sh"
	local SCRIPT_VERSION="2017.03.10.02b"
	QPKG_CONFIG_PATHFILE="/etc/config/qpkg.conf"
	local DOWNLOAD_PATH="/share/Download"
	local PUBLIC_PATH="/share/Public"
	WORKING_PATH="${PUBLIC_PATH}/${SCRIPT_FILE}.tmp"
	SAB_INI_FILE="sabnzbd.ini"
	SAB_ADMIN_DIR="admin"
	INSTALL_LOG_FILE="install.log"
	DOWNLOAD_LOG_FILE="download.log"
	DEBUG_LOG_FILE="download.log"

	RE=""
	exitcode=0
	SAB_INSTALLED=false

	echo -e "$(ColourTextBrightWhite "$SCRIPT_FILE") ($SCRIPT_VERSION)\n"

	if [ "$debug" == "true" ]; then
		ShowDebugSeparator
		echo "(/etc/config/uLinux.conf)"
		head -n6 < /etc/config/uLinux.conf | tail -n5
		ShowDebugSeparator
		echo "(/share/Download*)"
		ls -la /share/Download*
		ShowDebugSeparator
	fi

	GetArchVer
	GetClintonVer
	RefreshSABPaths

	SAB_WAS_INSTALLED=$SAB_INSTALLED

	if [ ! -L "$DOWNLOAD_PATH" ]; then
		ShowFailed "system share does not exist ($DOWNLOAD_PATH)"
		exitcode=1
	fi

	if [ ! -L "$PUBLIC_PATH" ]; then
		ShowFailed "system share does not exist ($PUBLIC_PATH)"
		exitcode=2
	fi

	if [ "$exitcode" -eq "0" ]; then
		mkdir -p "$WORKING_PATH"

		if [ "$?" -ne "0" ]; then
			ShowFailed "unable to create working directory ($WORKING_PATH)"
			exitcode=3
			return
		fi

		cd "$WORKING_PATH"
	fi

	DebugFuncExit

	}

DownloadRequiredQPKGs()
	{

	DebugFuncEntry

	if ! QPKGIsInstalled "Python"; then
		LookupQPKGDetails "Python"
		DownloadQPKG "$qpkg_url" "$qpkg_md5"
	fi

	if [ "$exitcode" -eq "0" ]; then
		if ! QPKGIsInstalled "Entware-3x"; then
			LookupQPKGDetails "Entware-3x"
			DownloadQPKG "$qpkg_url" "$qpkg_md5"
		else
			local testfile="/opt/etc/passwd"
			[ -e "$testfile" ] && { [ -L "$testfile" ] && ENTWARE_VER="std" || ENTWARE_VER="alt" ;} || ENTWARE_VER="none"

			DebugThis "\$ENTWARE_VER: [$ENTWARE_VER]"

			if [ "$ENTWARE_VER" == "alt" ]; then
				ShowFailed "Entware-3x (alt) is installed. This config has not been tested. Can't continue."
				exitcode=4
			fi
		fi
	fi

	if [ "$exitcode" -eq "0" ]; then
		if ! QPKGIsInstalled "git"; then
			LookupQPKGDetails "git"
			DownloadQPKG "$qpkg_url" "$qpkg_md5"
		fi
	fi

	[ "$exitcode" -eq "0" ] && LookupQPKGDetails "SABnzbdplus" && DownloadQPKG "$qpkg_url" "$qpkg_md5" "$qpkg_file"

	DebugFuncExit

	}

BackupSabSettings()
	{

	DebugFuncEntry

	# set this 'true' to overwrite an existing backup file set
	local overwrite_previous=true
	#local overwrite_previous=false

	DebugThis "\$overwrite_previous: [$overwrite_previous]"

	if [ "$SAB_INSTALLED" == "true" ]; then
		if [ -e "$SAB_INI_ORIG_PATHFILE" ]; then
			if [ -e "$SAB_INI_BACKUP_PATHFILE" ]; then
				if [ "$overwrite_previous" == "true" ]; then
					rm -f "$SAB_INI_BACKUP_PATHFILE"

					if [ "$?" -eq "0" ]; then
						DebugThis "removed previous backup ($SAB_INI_BACKUP_PATHFILE)"
					else
						ShowFailed "could not remove previous backup of ($SAB_INI_BACKUP_PATHFILE)"
						exitcode=5
						return
					fi
				else
					ShowInfo "backup already exists ($SAB_INI_BACKUP_PATHFILE)"
				fi
			fi

			cp "$SAB_INI_ORIG_PATHFILE" "$SAB_INI_BACKUP_PATHFILE"

			if [ "$?" -eq "0" ]; then
				ShowSuccess "created backup ($SAB_INI_BACKUP_PATHFILE)"
			else
				ShowFailed "could not create backup of ($SAB_INI_ORIG_PATHFILE)"
				exitcode=6
			fi
		fi

		if [ -e "$SAB_ADMIN_ORIG_PATHDIR" ]; then
			if [ -e "$SAB_ADMIN_BACKUP_PATHDIR" ]; then
				if [ "$overwrite_previous" == "true" ]; then
					rm -R "$SAB_ADMIN_BACKUP_PATHDIR"

					if [ "$?" -eq "0" ]; then
						DebugThis "removed previous backup ($SAB_ADMIN_BACKUP_PATHDIR)"
					else
						ShowFailed "could not remove previous backup of ($SAB_ADMIN_BACKUP_PATHDIR)"
						exitcode=7
						return
					fi
				else
					ShowInfo "backup already exists ($SAB_ADMIN_BACKUP_PATHDIR)"
				fi
			fi

			cp -R "$SAB_ADMIN_ORIG_PATHDIR" "$SAB_ADMIN_BACKUP_PATHDIR"

			if [ "$?" -eq "0" ]; then
				ShowSuccess "created backup ($SAB_ADMIN_ORIG_PATHDIR)"
			else
				ShowFailed "could not create backup of ($SAB_ADMIN_ORIG_PATHDIR)"
				exitcode=8
			fi
		fi
	fi

	DebugFuncExit

	}

RemoveUnrequiredQPKGs()
	{

	DebugFuncEntry

	UninstallExistingQPKG Entware-ng
	UninstallExistingQPKG SABnzbdplus

	DebugFuncExit

	}

UninstallEntwarePython()
	{

	DebugFuncEntry

	# forcibly remove Python packages so they will be reinstalled

	if QPKGIsInstalled "Entware-3x"; then
		msg="Python through Entware"
		ShowProcessing "uninstalling \"$msg\""
		opkg -V0 remove python --force-removal-of-dependent-packages --force-remove 2> /dev/null

		true # this is cheating ;)
		# opkg sometimes fails with
			# Collected errors:
			# * pkg_run_script: Internal error: python-cryptography has a NULL tmp_unpack_dir.
		# so, until I can reliably remove Python without error, set returncode as 'true'.

		if [ "$?" -eq "0" ]; then
			ShowSuccess "\"$msg\" uninstalled"
		else
			ShowFailed "unable to uninstall \"$msg\""
			exitcode=9
		fi
	fi

	DebugFuncExit

	}

InstallRequiredQPKGs()
	{

	DebugFuncEntry

	if ! QPKGIsInstalled "Python"; then
		LookupQPKGDetails "Python"
		InstallQPKG "$qpkg_file"
	fi

	if [ "$exitcode" -eq "0" ]; then
		if ! QPKGIsInstalled "Entware-3x"; then
			LookupQPKGDetails "Entware-3x"
			InstallQPKG "$qpkg_file"
		else
			local testfile="/opt/etc/passwd"
			[ -e "$testfile" ] && { [ -L "$testfile" ] && ENTWARE_VER="std" || ENTWARE_VER="alt" ;} || ENTWARE_VER="none"

			DebugThis "\$ENTWARE_VER: [$ENTWARE_VER]"

			if [ "$ENTWARE_VER" == "alt" ]; then
				ShowFailed "Entware-3x (alt) is installed. This config has not been tested. Can't continue."
				exitcode=10
			fi
		fi
	fi

	if [ "$exitcode" -eq "0" ]; then
		if ! QPKGIsInstalled "git"; then
			LookupQPKGDetails "git"
			InstallQPKG "$qpkg_file"
		fi
	fi

	if [ "$exitcode" -eq "0" ]; then
		if ! QPKGIsInstalled "SABnzbdplus"; then
			LookupQPKGDetails "SABnzbdplus"
			InstallQPKG "$qpkg_file"
			RefreshSABPaths
		fi
	fi

	DebugFuncExit

	}

ReloadProfile()
	{

	DebugFuncEntry

	. /etc/profile > /dev/null
	. /root/.profile > /dev/null

	cd "$WORKING_PATH"

	DebugThis "reloaded environment"

	DebugFuncExit

	}

CreateWaiter()
	{

	DebugFuncEntry

	local WAITER_PATHFILE="$(dirname "$SAB_INSTALLED_PATH")/wait-for-Entware.sh"
	local WAIT_FOR_PATH="/opt/Entware-3x.sh"

	cat > "$WAITER_PATHFILE" << EOF
#!/bin/sh

[ ! -z "\$1" ] && timeout="\$1" || timeout=600
[ ! -z "\$2" ] && testfile="\$2" || testfile="$WAIT_FOR_PATH"
scriptname="\$(basename \$0)"
waitlog="/tmp/wait-counter-\${scriptname}.log"

if [ ! -e "\$testfile" ]; then
   (
      for ((count=1; count<=timeout; count++)); do
         sleep 1
         [ -e "\$testfile" ] &&
            {
            echo "waited for \$count seconds" >> "\$waitlog"
            true
            exit
            }

      done
      false
   )

   if [ "\$?" -ne "0" ]; then
      echo "timeout exceeded!" >> "\$waitlog"
      /sbin/write_log "[\$scriptname] Could not continue: timeout exceeded." 1
      false
      exit
   fi

   # if here, then testfile has appeared, so reload environment
   . /etc/profile
   . /root/.profile
fi
EOF

	if [ "$?" -eq "0" ]; then
		ShowSuccess "waiter created"
		chmod +x "$WAITER_PATHFILE"
	else
		ShowFailed "unable to create waiter ($WAITER_PATHFILE)"
		exitcode=11
	fi

	DebugFuncExit

	}

InstallThuEntware()
	{

	DebugFuncEntry

	DownloadAndExecute "Python through Entware" "opkg update; opkg install python python-pip gcc python-cffi python-pyopenssl nano && opkg install python-dev --force-overwrite"
	DownloadAndExecute "CA certificates through Entware" "opkg install ca-certificates"
	DownloadAndExecute "pip modules" "pip install --upgrade pip setuptools && pip install http://www.golug.it/pub/yenc/yenc-0.4.0.tar.gz cheetah"

	DebugFuncExit

	}

PatchInitWithPython()
	{

	DebugFuncEntry

	result=0

	if [ -f "$SAB_INIT_PATHFILE" ]; then
		/bin/sed -i 's|/usr/bin/python2.7|/opt/bin/python|' "$SAB_INIT_PATHFILE"
		result=$?

		if [ "$result" -eq "0" ]; then
			ShowSuccess "patched SABnzbd init with Python ($SAB_INIT_PATHFILE)"
		else
			ShowFailed "could not patch SABnzbd init with new Python interpreter ($SAB_INIT_PATHFILE) [$result]"
			exitcode=12
		fi
	else
		ShowFailed "SABnzbd init not found ($SAB_INIT_PATHFILE)"
		exitcode=13
	fi

	DebugFuncExit

	}

PatchInitWithWaiter()
	{

	DebugFuncEntry

	local tag='#!/bin/sh'
	local inserttext=". $(dirname "$SAB_INSTALLED_PATH")/wait-for-Entware.sh 300"
	result=0

	if [ -f "$SAB_INIT_PATHFILE" ]; then
		(grep "$inserttext" < "$SAB_INIT_PATHFILE" > /dev/null) || /bin/sed -i "s|$tag|$tag\n\n$inserttext|" "$SAB_INIT_PATHFILE"
		result=$?

		if [ "$result" -eq "0" ]; then
			ShowSuccess "patched SABnzbd init with waiter ($SAB_INIT_PATHFILE)"
		else
			ShowFailed "could not patch SABnzbd init with waiter ($SAB_INIT_PATHFILE) [$result]"
			exitcode=14
		fi
	else
		ShowFailed "SABnzbd init not found ($SAB_INIT_PATHFILE)"
		exitcode=15
	fi

	DebugFuncExit

	}

CreateYENCLinks()
	{

	DebugFuncEntry

	local ent_python_path="$(getcfg "Entware-3x" Install_Path -f "$QPKG_CONFIG_PATHFILE")/lib/python2.7/site-packages"
	local sab_python_path="$(getcfg "SABnzbdplus" Install_Path -f "$QPKG_CONFIG_PATHFILE")/$CLINTON_VER/python"

	ln -fs "${ent_python_path}/yenc.py" "$sab_python_path"
	ln -fs "${ent_python_path}/_yenc.so" "$sab_python_path"

	DebugFuncExit

	}

RestoreSabSettings()
	{

	DebugFuncEntry

	if [ -e "$SAB_INI_BACKUP_PATHFILE" ]; then
		cp "$SAB_INI_BACKUP_PATHFILE" "$SAB_INI_ORIG_PATHFILE"

		if [ "$?" -eq "0" ]; then
			ShowSuccess "restored backup ($SAB_INI_ORIG_PATHFILE)"
		else
			ShowFailed "could not restore backup of ($SAB_INI_ORIG_PATHFILE)"
			exitcode=16
		fi
	fi

	return # next part is not operational yet!

	if [ -d "$SAB_ADMIN_BACKUP_PATHDIR" ]; then
		cp -R "$SAB_ADMIN_BACKUP_PATHDIR" "${SAB_CONFIG_PATH}/"

		if [ "$?" -eq "0" ]; then
			ShowSuccess "restored backup ($SAB_ADMIN_ORIG_PATHDIR)"
		else
			ShowFailed "could not restore backup of ($SAB_ADMIN_ORIG_PATHDIR)"
			exitcode=17
		fi
	fi

	DebugFuncExit

	}

DownloadQPKG()
	{

	DebugFuncEntry

	# $1 = QPKG URL
	# $2 = QPKG MD5 checksum
	# $3 = package name (optional)

	DebugThis "\$1: [$1]"
	DebugThis "\$2: [$2]"
	DebugThis "\$3: [$3]"

	local result=0

	[ "$exitcode" -gt "0" ] && return

	if [ -z "$1" ]; then
		DebugThis "QPKG URL not specified"
		exitcode=18
		return
	fi

	if [ -z "$2" ]; then
		DebugThis "QPKG MD5 not specified"
		exitcode=19
		return
	fi

	[ -z "$3" ] && target_qpkg_file=$(basename "$1") || target_qpkg_file="$3"

	local target_qpkg_pathfile="${WORKING_PATH}/${target_qpkg_file}"
	local expected_checksum=$2

	if [ -e "$target_qpkg_pathfile" ]; then
		file_checksum=$(/bin/md5sum "$target_qpkg_pathfile" | cut -f1 -d' ')
		result=$?

		if [ "$result" -eq "0" ]; then
			if [ "$file_checksum" == "$expected_checksum" ]; then
				DebugThis "QPKG already downloaded ($target_qpkg_pathfile)"
			else
				DebugThis "invalid existing download found - deleting"
				rm -f "$target_qpkg_pathfile"
			fi
		else
			ShowFailed "problem creating checksum from existing file [$result]"
			exitcode=20
		fi
	fi

	if [ ! -e "$target_qpkg_pathfile" ]; then
		ShowProcessing "downloading QPKG ($target_qpkg_file)"

		/usr/bin/wget -q -o "$target_qpkg_file.$DOWNLOAD_LOG_FILE" "$1" -O "$target_qpkg_file"
		result=$?

		if [ "$result" -eq "0" ]; then
			file_checksum=$(/bin/md5sum "$target_qpkg_pathfile" | cut -f1 -d' ')
			result=$?

			if [ "$result" -eq "0" ]; then
				if [ "$file_checksum" == "$expected_checksum" ]; then
					ShowSuccess "downloaded ($target_qpkg_file)"
				else
					ShowFailed "download failed checksum ($target_qpkg_pathfile)"
					exitcode=21
				fi
			else
				ShowFailed "problem creating checksum from downloaded file [$result]"
				exitcode=22
			fi
		else
			ShowFailed "download failed ($target_qpkg_file) [$result]"

			if [ "$debug" == "true" ]; then
				ShowDebugSeparator
				cat "$target_qpkg_file.$DOWNLOAD_LOG_FILE"
				ShowDebugSeparator
			fi

			exitcode=23
		fi
	fi

	DebugFuncExit

	}

DebugThis()
	{

	[ "$debug" == "true" ] && ShowDebug "$1"

	}

GetArchVer()
	{

	DebugFuncEntry

	# reduce NAS architecture down to 5 possibilities

	local ARCH="$(uname -m)"

	# X86
	# These models return:
	[ "$ARCH" == "i686" ] && ARCH_VER="x86"
	[ "$ARCH" == "x86_64" ] && ARCH_VER="x86"

	# ARM
	# These models return:
	[ "$ARCH" == "armv5tel" ] && ARCH_VER="x19"

	# (unknown)
	# These models return:
	[ "$ARCH" == "armv5tejl" ] && ARCH_VER=""

	# TS-X31
	# TS-X31U
	# These models return:
	[ "$ARCH" == "------" ] && ARCH_VER="x31"

	# TS-X31X
	# TS-X31XU
	# TS-X35
	# TS-X31+
	# TAS-X68
	# TS-X28
	# These models return:
	[ "$ARCH" == "armv71" ] && ARCH_VER="x41"

	# TS-269H
	# These models return:
	[ "$ARCH" == "------" ] && ARCH_VER="x269"

	if [ -z "$ARCH_VER" ]; then
		ShowFailed "could not determine NAS architecture ($ARCH)"
		exitcode=24
	fi

	DebugThis "\$ARCH: [$ARCH]"
	DebugThis "\$ARCH_VER: [$ARCH_VER]"

	DebugFuncExit

	}

GetClintonVer()
	{

	DebugFuncEntry

	# a "reimagining" of Clinton Hall's arch detection code ;)
	# reduce NAS architecture down to 3 possibilities

	local ARCH="$(uname -m)"

	[ "$ARCH" == "armv5tejl" ] && CLINTON_VER="arm"
	[ "$ARCH" == "armv5tel" ] && CLINTON_VER="arm"
	[ "$ARCH" == "i686" ] && CLINTON_VER="x86"
	[ "$ARCH" == "x86_64" ] && CLINTON_VER="x86"
	[ "$ARCH" == "armv71" ] && CLINTON_VER="x31"

	if [ -z "$CLINTON_VER" ]; then
		ShowFailed "could not determine NAS architecture ($ARCH)"
		exitcode=25
	fi

	DebugThis "\$ARCH: [$ARCH]"
	DebugThis "\$CLINTON_VER: [$CLINTON_VER]"

	DebugFuncExit

	}

RefreshSABPaths()
	{

	DebugFuncEntry

	SAB_INSTALLED_PATH="$(getcfg "SABnzbdplus" Install_Path -f "$QPKG_CONFIG_PATHFILE")"

	result=$?

	DebugThis "\$result: [$result]"

	if [ "$result" -eq "0" ]; then
		SAB_INSTALLED=true
		SAB_CONFIG_PATH="${SAB_INSTALLED_PATH}/Config"
		SAB_INIT_PATHFILE="${SAB_INSTALLED_PATH}/sabnzbd.sh"
		SAB_INI_ORIG_PATHFILE="${SAB_CONFIG_PATH}/${SAB_INI_FILE}"
		SAB_ADMIN_ORIG_PATHDIR="${SAB_CONFIG_PATH}/${SAB_ADMIN_DIR}"
		SAB_INI_BACKUP_PATHFILE="${WORKING_PATH}/${SAB_INI_FILE}"
		SAB_ADMIN_BACKUP_PATHDIR="${WORKING_PATH}/${SAB_ADMIN_DIR}"
	fi

	DebugThis "\$SAB_INSTALLED: [$SAB_INSTALLED]"
	DebugThis "\$QPKG_CONFIG_PATHFILE: [$QPKG_CONFIG_PATHFILE]"
	DebugThis "\$SAB_INSTALLED_PATH: [$SAB_INSTALLED_PATH]"
	DebugThis "\$SAB_CONFIG_PATH: [$SAB_CONFIG_PATH]"
	DebugThis "\$SAB_INIT_PATHFILE: [$SAB_INIT_PATHFILE]"
	DebugThis "\$SAB_INI_ORIG_PATHFILE: [$SAB_INI_ORIG_PATHFILE]"
	DebugThis "\$SAB_ADMIN_ORIG_PATHDIR: [$SAB_ADMIN_ORIG_PATHDIR]"
	DebugThis "\$SAB_INI_BACKUP_PATHFILE: [$SAB_INI_BACKUP_PATHFILE]"
	DebugThis "\$SAB_ADMIN_BACKUP_PATHDIR: [$SAB_ADMIN_BACKUP_PATHDIR]"

	DebugFuncExit

	}

InstallQPKG()
	{

	DebugFuncEntry

	# $1 = QPKG file name as '.qpkg' or '.zip'

	DebugThis "\$1: [$1]"

	local result=0

	[ "$exitcode" -gt "0" ] && return

	if [ ! -z "$1" ]; then
		target_qpkg_file="$1"
	else
		DebugThis "QPKG name not specified"
		exitcode=26
		return
	fi

	local target_qpkg_pathfile="${WORKING_PATH}/${target_qpkg_file}"

	if [ "$exitcode" -eq "0" ]; then
		if [ "${target_qpkg_file##*.}" == "zip" ]; then
			unzip -nq "$target_qpkg_file"
			target_qpkg_file="${target_qpkg_file%.*}.qpkg"
		fi

		ShowProcessing "installing QPKG ($target_qpkg_file)"

		install_msgs=$(eval sh "$target_qpkg_file" 2>&1)
		result=$?

		echo -e "${install_msgs}\nresultcode=[$result]" > "$target_qpkg_file.$INSTALL_LOG_FILE"

		if [ "$result" -eq "0" ] || [ "$result" -eq "10" ]; then
			ShowSuccess "installed QPKG ($target_qpkg_pathfile)"
		else
			ShowFailed "QPKG installation failed ($target_qpkg_pathfile)"

			if [ "$debug" == "true" ]; then
				ShowDebugSeparator
				cat "$target_qpkg_file.$INSTALL_LOG_FILE"
				ShowDebugSeparator
			fi

			exitcode=27
		fi
	fi

	DebugFuncExit

	}

UninstallExistingQPKG()
	{

	DebugFuncEntry

	# $1 = QPKG name

	DebugThis "\$1: [$1]"

	qpkg_installed_path="$(getcfg "$1" Install_Path -f "$QPKG_CONFIG_PATHFILE")"

	if [ "$?" -eq "0" ]; then
		qpkg_installed_path="$(getcfg "$1" Install_Path -f "$QPKG_CONFIG_PATHFILE")"

		if [ -e "${qpkg_installed_path}/.uninstall.sh" ]; then
			ShowProcessing "uninstalling QPKG \"$1\""

			${qpkg_installed_path}/.uninstall.sh > /dev/null

			if [ "$?" -eq "0" ]; then
				ShowSuccess "QPKG \"$1\" uninstalled"
			else
				ShowFailed "unable to uninstall QPKG \"$1\""
				exitcode=28
			fi
		fi

		RemoveConfigBlock "$1"
	else
		DebugThis "QPKG \"$1\" not installed"
	fi

	DebugFuncExit

	}

LookupQPKGDetails()
	{

	DebugFuncEntry

	# $1 = QPKG name

	DebugThis "\$1: [$1]"

	if [ -z "$1" ]; then
		DebugThis "QPKG name not specified"
		exitcode=29
		return
	fi

	qpkg_url=""
	qpkg_md5=""
	qpkg_file=""
	local base_url=""

	if [ "$1" == "git" ]; then
		base_url="https://www.dropbox.com/s"
		[ "$CLINTON_VER" == "x86" ] && { qpkg_url="${base_url}/fiay536scdscew7/git_2.1.0_x86.qpkg"; qpkg_md5="fc2f73b0f4317b5aad219a733c13030c";}
		[ "$CLINTON_VER" == "arm" ] && { qpkg_url="${base_url}/li00l16znp0zcue/git_2.1.0_arm.qpkg"; qpkg_md5="17e593c48e963c9eafa1399d4d341f26";}
		[ "$CLINTON_VER" == "x31" ] && { qpkg_url="${base_url}/aixw0rbzk3skm32/git_2.1.1_x31.qpkg"; qpkg_md5="441e429235488d6200713461de2e6e97";}

	elif [ "$1" == "Entware-3x" ]; then
		qpkg_url="http://entware-3x.zyxmon.org/binaries/other/Entware-3x_0.99std.qpkg"; qpkg_md5="3663c9e4323e694fb25897e276f55623"

	elif [ "$1" == "Python" ]; then
		base_url="http://download.qnap.com/QPKG"
		[ "$ARCH_VER" == "x86" ] && { qpkg_url="${base_url}/Python_2.7.3_x86.zip"; qpkg_md5="1cdf292bfdb271a99b0bf61d2ffec8ae";}
		[ "$ARCH_VER" == "x269" ] && { qpkg_url="${base_url}/QPKG_CE53XX/Python_2.7.3-0908_x86_ce53xx.zip"; qpkg_md5="22a0f05a202b7d943318110809c14603";}
		[ "$ARCH_VER" == "x19" ] && { qpkg_url="${base_url}/Python_2.7.3_arm-x19.zip"; qpkg_md5="ac76de6cdccc0d38d624464f6a7dbc2e";}
		[ "$ARCH_VER" == "x31" ] && { qpkg_url="${base_url}/X31/Python_2.7.3_arm-x31.zip"; qpkg_md5="2c4e551387f2e5037ecd55d2954587ee";}
		[ "$ARCH_VER" == "x41" ] && { qpkg_url="${base_url}/Python_2.7.3_arm-x41.zip"; qpkg_md5="68b9fa1e7cc1b8106935f7bf17c775a7";}

	elif [ "$1" == "SABnzbdplus" ]; then
		qpkg_url="http://bit.ly/2jPntF9"; qpkg_md5="03077bc11289b944d9e3a58927c269fe"; qpkg_file="SABnzbdplus_170131.qpkg"

	else
		DebugThis "QPKG name not found"
		exitcode=30
	fi

	[ -z "$qpkg_file" ] && [ ! -z "$qpkg_url" ] && qpkg_file=$(basename "$qpkg_url")

	DebugThis "\$qpkg_url: [$qpkg_url]"
	DebugThis "\$qpkg_md5: [$qpkg_md5]"
	DebugThis "\$qpkg_file: [$qpkg_file]"

	DebugFuncExit

	}

StopSab()
	{

	DebugFuncEntry

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		ShowProcessing "stopping SABnzbd daemon"
		"$SAB_INIT_PATHFILE" stop > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon stopped"
		else
			ShowFailed "could not stop SABnzbd daemon"
			exitcode=31
		fi
	fi

	DebugFuncExit

	}

StartSab()
	{

	DebugFuncEntry

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		ShowProcessing "starting SABnzbd daemon"

		"$SAB_INIT_PATHFILE" start > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon started"
		else
			ShowFailed "could not start SABnzbd daemon"
			exitcode=32
		fi
	fi

	DebugFuncExit

	}

RestartSab()
	{

	DebugFuncEntry

	if [ -e "$SAB_INIT_PATHFILE" ]; then
		ShowProcessing "restarting SABnzbd daemon"

		"$SAB_INIT_PATHFILE" restart > /dev/null

		if [ "$?" -eq "0" ]; then
			ShowSuccess "SABnzbd daemon restarted"
		else
			ShowFailed "could not restart SABnzbd daemon"
			exitcode=33
		fi
	fi

	DebugFuncExit

	}

QPKGIsInstalled()
	{

	DebugFuncEntry

	# If package has been installed, check that it has also been enabled.
	# If not enabled, then enable it.
	# If not installed, return 1

	# $1 = package name to check/enable

	DebugThis "\$1: [$1]"

	grep -F "[$1]" < "$QPKG_CONFIG_PATHFILE" > /dev/null

	if [ "$?" -eq "0" ]; then
		DebugThis "QPKG \"$1\" already installed"
		[ "$(getcfg "$1" Enable -u -f "$QPKG_CONFIG_PATHFILE")" != "TRUE" ] && setcfg "$1" Enable TRUE -f "$QPKG_CONFIG_PATHFILE"
		return 0
	else
		DebugThis "QPKG \"$1\" not installed"
		return 1
	fi

	}

ColourTextBrightGreen()
	{

	echo -en '\E[1;32m'"$(PrintResetColours "$1")"

	}

ColourTextBrightOrange()
	{

	echo -en '\E[1;38;5;214m'"$(PrintResetColours "$1")"

	}

ColourTextBrightRed()
	{

	echo -en '\E[1;31m'"$(PrintResetColours "$1")"

	}

ColourTextBlackOnCyan()
	{

	echo -en '\E[30;46m'"$(PrintResetColours "$1")"

	}

ColourTextBrightWhite()
	{

	echo -en '\E[1;97m'"$(PrintResetColours "$1")"

	}

PrintResetColours()
	{

	echo -en "$1"'\E[0m'

	}

ShowLogLine()
	{

	# $1 = pass/fail
	# $2 = message

	printf "[ %-10s ] %-33s\n" "$1" "$2"

	}

ShowSuccess()
	{

	ShowLogLine "$(ColourTextBrightGreen "done")" "$1"

	}

ShowInfo()
	{

	ShowLogLine "$(ColourTextBrightWhite "info")" "$1"

	}

ShowFailed()
	{

	ShowLogLine "$(ColourTextBrightRed "fail")" "$1"

	}

ShowDebug()
	{

	ShowLogLine "$(ColourTextBlackOnCyan "dbug")" "$1"

	}

ShowDebugSeparator()
	{

	echo "--------------------------"

	}

ShowProcessing()
	{

	ShowLogLine "$(ColourTextBrightOrange "proc")" "$1 ..."

	}

DebugFuncEntry()
	{

	DebugThis ">> entered <${FUNCNAME[1]}>"

	}

DebugFuncExit()
	{

	DebugThis "<< leaving <${FUNCNAME[1]}> [$exitcode]"

	}

DownloadAndExecute()
	{

	DebugFuncEntry

	# $1 = package display name
	# $2 = command(s) to run

	DebugThis "\$1: [$1]"
	DebugThis "\$2: [$2]"

	ShowProcessing "downloading and installing \"$1\""

	install_msgs=$(eval $2)

	if [ "$?" -eq "0" ]; then
		ShowSuccess "installed \"$1\""
	else
		ShowFailed "\"$1\" installation failed"
		echo "$install_msgs" > "$(echo "$1" | tr " " "_").$INSTALL_LOG_FILE"
		exitcode=34
	fi

	DebugFuncExit

	}

RemoveConfigBlock()
	{

	DebugFuncEntry

	# $1 = QPKG data block name to remove

	DebugThis "\$1: [$1]"

	if [ -z "$1" ]; then
		exitcode=35
		return
	fi

	if [ ! -e "$QPKG_CONFIG_PATHFILE" ]; then
		exitcode=36
		return
	fi

	local start_line=$(grep -nF "[$1]" "$QPKG_CONFIG_PATHFILE" | cut -f1 -d':')
	local last_line=$(wc -l < "$QPKG_CONFIG_PATHFILE" | tr -d ' ')
	local block_length=$(tail -n$((last_line-start_line)) < "$QPKG_CONFIG_PATHFILE" | grep -nF "[" | head -n1 | cut -f1 -d':')
	[ ! -z "$block_length" ] && endline=$((start_line+block_length-1)) || endline=$last_line

	/bin/sed -i "$start_line,${endline}d" "$QPKG_CONFIG_PATHFILE"

	DebugFuncExit

	}

DisplayResult()
	{

	DebugFuncEntry

	[ "$SAB_WAS_INSTALLED" == "true" ] && RE="(re)"

	echo

	if [ "$exitcode" -eq "0" ]; then
		ShowSuccess "SABnzbd has been successfully ${RE}installed! :)"
	else
		ShowFailed "SABnzbd install failed! :( [$exitcode]"
	fi

	DebugFuncExit

	}

Init
[ "$exitcode" -eq "0" ] && DownloadRequiredQPKGs
[ "$exitcode" -eq "0" ] && StopSab
[ "$exitcode" -eq "0" ] && BackupSabSettings
[ "$exitcode" -eq "0" ] && RemoveUnrequiredQPKGs
[ "$exitcode" -eq "0" ] && UninstallEntwarePython
[ "$exitcode" -eq "0" ] && InstallRequiredQPKGs
[ "$exitcode" -eq "0" ] && ReloadProfile
[ "$exitcode" -eq "0" ] && CreateWaiter
[ "$exitcode" -eq "0" ] && StopSab
[ "$exitcode" -eq "0" ] && InstallThuEntware
[ "$exitcode" -eq "0" ] && PatchInitWithPython
[ "$exitcode" -eq "0" ] && PatchInitWithWaiter
[ "$exitcode" -eq "0" ] && CreateYENCLinks
[ "$exitcode" -eq "0" ] && StartSab
[ "$exitcode" -eq "0" ] && RestoreSabSettings
[ "$exitcode" -eq "0" ] && RestartSab
DisplayResult

exit "$exitcode"
